# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: coast-postprocess.spec.ts >> standalone geography is painted and all46countries selectable at 1280x800
- Location: tests/e2e/coast-postprocess.spec.ts:33:97

# Error details

```
Error: ENOENT: no such file or directory, open '/work/docs/prototypes/new-game/T64/preview.html'
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - banner [ref=e2]:
    - heading "Seed 1994 · Nine Isles" [level=1] [ref=e3]
    - generic "Map controls" [ref=e4]:
      - button "Proposed geography" [pressed] [ref=e5] [cursor=pointer]
      - button "Current map and routes" [ref=e6] [cursor=pointer]
      - button "Inspector" [ref=e7] [cursor=pointer]
      - button "Export SVG" [ref=e8] [cursor=pointer]
      - generic [ref=e9]:
        - generic [ref=e10]: Seat 1
        - generic [ref=e12]: Seat 2
        - generic [ref=e14]: ★ production centre
    - generic [ref=e15]: DESIGNED VISUAL PROPOSAL · NOT THE PLAYABLE GRAPH
  - main [ref=e16]:
    - generic "Interactive map" [ref=e17]:
      - img "Proposed contiguous island map" [ref=e18]:
        - generic: North Isle +3
        - generic: East Isle +3
        - generic: West Isle +3
        - generic: South Isle +3
        - generic: Central Isle +5
        - generic: Harbor Isle +4
        - generic: Palm Isle +5
        - generic: Cliff Isle +5
        - generic: Great Isle +7
        - button "River gate, Seat 1, 2 armies" [ref=e77]:
          - generic [ref=e78] [cursor=pointer]
        - button "New port, Seat 2, 3 armies" [ref=e79]:
          - generic [ref=e80] [cursor=pointer]
        - button "North rest, Seat 1, 1 armies" [ref=e81]:
          - generic [ref=e82] [cursor=pointer]
        - button "River keep, Seat 2, 1 armies" [ref=e83]:
          - generic [ref=e84] [cursor=pointer]
        - button "North town, Seat 1, 1 armies" [ref=e85]:
          - generic [ref=e86] [cursor=pointer]
        - button "Dark ford, Seat 2, 3 armies" [ref=e87]:
          - generic [ref=e88] [cursor=pointer]
        - button "Iron point, Seat 1, 3 armies" [ref=e89]:
          - generic [ref=e90] [cursor=pointer]
        - button "South rest, Seat 2, 3 armies" [ref=e91]:
          - generic [ref=e92] [cursor=pointer]
        - button "High shore, Seat 2, 1 armies" [ref=e93]:
          - generic [ref=e94] [cursor=pointer]
        - button "Wind town, Seat 1, 1 armies" [ref=e95]:
          - generic [ref=e96] [cursor=pointer]
        - button "New glen, Seat 2, 1 armies" [ref=e97]:
          - generic [ref=e98] [cursor=pointer]
        - button "Old rock, Seat 2, 2 armies" [ref=e99]:
          - generic [ref=e100] [cursor=pointer]
        - button "Blue peak, Seat 2, 3 armies" [ref=e101]:
          - generic [ref=e102] [cursor=pointer]
        - button "West haven, Seat 2, 2 armies" [ref=e103]:
          - generic [ref=e104] [cursor=pointer]
        - button "Stone watch, Seat 2, 3 armies" [ref=e105]:
          - generic [ref=e106] [cursor=pointer]
        - button "Upper ridge, Seat 1, 2 armies" [ref=e107]:
          - generic [ref=e108] [cursor=pointer]
        - button "Marsh keep, Seat 1, 2 armies" [ref=e109]:
          - generic [ref=e110] [cursor=pointer]
        - button "New fell, Seat 1, 2 armies" [ref=e111]:
          - generic [ref=e112] [cursor=pointer]
        - button "Moon point, Seat 2, 2 armies" [ref=e113]:
          - generic [ref=e114] [cursor=pointer]
        - button "South fell, Seat 1, 2 armies" [ref=e115]:
          - generic [ref=e116] [cursor=pointer]
        - button "High ridge, Seat 1, 1 armies" [ref=e117]:
          - generic [ref=e118] [cursor=pointer]
        - button "Bay ford, Seat 2, 2 armies" [ref=e119]:
          - generic [ref=e120] [cursor=pointer]
        - button "Low moor, Seat 2, 1 armies" [ref=e121]:
          - generic [ref=e122] [cursor=pointer]
        - button "Lower field, Seat 1, 2 armies" [ref=e123]:
          - generic [ref=e124] [cursor=pointer]
        - button "Wind gate, Seat 1, 2 armies" [ref=e125]:
          - generic [ref=e126] [cursor=pointer]
        - button "Silver shore, Seat 1, 3 armies" [ref=e127]:
          - generic [ref=e128] [cursor=pointer]
        - button "Low peak, Seat 1, 2 armies" [ref=e129]:
          - generic [ref=e130] [cursor=pointer]
        - button "Wind port, Seat 1, 3 armies" [ref=e131]:
          - generic [ref=e132] [cursor=pointer]
        - button "Gold point, Seat 2, 1 armies" [ref=e133]:
          - generic [ref=e134] [cursor=pointer]
        - button "Rock moor, Seat 1, 2 armies" [ref=e135]:
          - generic [ref=e136] [cursor=pointer]
        - button "Marsh rest, Seat 1, 2 armies" [ref=e137]:
          - generic [ref=e138] [cursor=pointer]
        - button "Wind dale, Seat 2, 3 armies" [ref=e139]:
          - generic [ref=e140] [cursor=pointer]
        - button "Silver ford, Seat 1, 3 armies" [ref=e141]:
          - generic [ref=e142] [cursor=pointer]
        - button "Iron field, Seat 2, 3 armies" [ref=e143]:
          - generic [ref=e144] [cursor=pointer]
        - button "North wood, Seat 2, 1 armies" [ref=e145]:
          - generic [ref=e146] [cursor=pointer]
        - button "Fort town, Seat 1, 2 armies" [ref=e147]:
          - generic [ref=e148] [cursor=pointer]
        - button "Red field, Seat 2, 1 armies" [ref=e149]:
          - generic [ref=e150] [cursor=pointer]
        - button "South ridge, Seat 2, 2 armies" [ref=e151]:
          - generic [ref=e152] [cursor=pointer]
        - button "Rock bay, Seat 1, 2 armies" [ref=e153]:
          - generic [ref=e154] [cursor=pointer]
        - button "North ford, Seat 1, 3 armies" [ref=e155]:
          - generic [ref=e156] [cursor=pointer]
        - button "Port ridge, Seat 2, 3 armies" [ref=e157]:
          - generic [ref=e158] [cursor=pointer]
        - button "New rock, Seat 1, 1 armies" [ref=e159]:
          - generic [ref=e160] [cursor=pointer]
        - button "South reach, Seat 2, 1 armies" [ref=e161]:
          - generic [ref=e162] [cursor=pointer]
        - button "Silver point, Seat 2, 2 armies" [ref=e163]:
          - generic [ref=e164] [cursor=pointer]
        - button "East ford, Seat 1, 2 armies" [ref=e165]:
          - generic [ref=e166] [cursor=pointer]
        - button "Gold town, Seat 2, 2 armies" [ref=e167]:
          - generic [ref=e168] [cursor=pointer]
        - generic [ref=e169]:
          - generic [ref=e170]:
            - generic: River gate
            - generic: "2"
          - generic [ref=e171]:
            - generic: New port
            - generic: "3"
          - generic [ref=e172]:
            - generic: North rest
            - generic: "1"
          - generic [ref=e173]:
            - generic: River keep
            - generic: "1"
          - generic [ref=e174]:
            - generic: North town
            - generic: "1"
          - generic [ref=e175]:
            - generic: Dark ford
            - generic: "3"
          - generic [ref=e176]:
            - generic: Iron point
            - generic: "3"
          - generic [ref=e177]:
            - generic: South rest
            - generic: "3"
          - generic [ref=e178]:
            - generic: High shore
            - generic: "1"
          - generic [ref=e179]:
            - generic: Wind town
            - generic: "1"
          - generic [ref=e180]:
            - generic: New glen
            - generic: "1"
          - generic [ref=e181]:
            - generic: Old rock
            - generic: "2"
          - generic [ref=e182]:
            - generic: ★ Blue peak
            - generic: "3"
          - generic [ref=e183]:
            - generic: West haven
            - generic: "2"
          - generic [ref=e184]:
            - generic: Stone watch
            - generic: "3"
          - generic [ref=e185]:
            - generic: Upper ridge
            - generic: "2"
          - generic [ref=e186]:
            - generic: Marsh keep
            - generic: "2"
          - generic [ref=e187]:
            - generic: New fell
            - generic: "2"
          - generic [ref=e188]:
            - generic: ★ Moonpoint
            - generic: "2"
          - generic [ref=e189]:
            - generic: South fell
            - generic: "2"
          - generic [ref=e190]:
            - generic: High ridge
            - generic: "1"
          - generic [ref=e191]:
            - generic: Bay ford
            - generic: "2"
          - generic [ref=e192]:
            - generic: Low moor
            - generic: "1"
          - generic [ref=e193]:
            - generic: Lowerfield
            - generic: "2"
          - generic [ref=e194]:
            - generic: Wind gate
            - generic: "2"
          - generic [ref=e195]:
            - generic: Silvershore
            - generic: "3"
          - generic [ref=e196]:
            - generic: Low peak
            - generic: "2"
          - generic [ref=e197]:
            - generic: Wind port
            - generic: "3"
          - generic [ref=e198]:
            - generic: Gold point
            - generic: "1"
          - generic [ref=e199]:
            - generic: Rock moor
            - generic: "2"
          - generic [ref=e200]:
            - generic: Marshrest
            - generic: "2"
          - generic [ref=e201]:
            - generic: Winddale
            - generic: "3"
          - generic [ref=e202]:
            - generic: Silverford
            - generic: "3"
          - generic [ref=e203]:
            - generic: Ironfield
            - generic: "3"
          - generic [ref=e204]:
            - generic: Northwood
            - generic: "1"
          - generic [ref=e205]:
            - generic: Forttown
            - generic: "2"
          - generic [ref=e206]:
            - generic: ★ Red field
            - generic: "1"
          - generic [ref=e207]:
            - generic: South ridge
            - generic: "2"
          - generic [ref=e208]:
            - generic: Rock bay
            - generic: "2"
          - generic [ref=e209]:
            - generic: North ford
            - generic: "3"
          - generic [ref=e210]:
            - generic: Portridge
            - generic: "3"
          - generic [ref=e211]:
            - generic: New rock
            - generic: "1"
          - generic [ref=e212]:
            - generic: South reach
            - generic: "1"
          - generic [ref=e213]:
            - generic: Silver point
            - generic: "2"
          - generic [ref=e214]:
            - generic: East ford
            - generic: "2"
          - generic [ref=e215]:
            - generic: Gold town
            - generic: "2"
    - generic: Proposed shared-border geography · links changed; open Inspector for the full diff.
```

# Test source

```ts
  1  | import {test,expect} from "@playwright/test";
  2  | import type {Page} from "@playwright/test";
  3  | import {readFileSync,mkdirSync,mkdtempSync,writeFileSync} from "node:fs";
  4  | import {join} from "node:path";
  5  | import type expectedType from "../../docs/prototypes/new-game/T64/acceptance/board.json";
  6  | const expected:typeof expectedType=JSON.parse(readFileSync(new URL("../../docs/prototypes/new-game/T64/acceptance/board.json",import.meta.url),"utf8"));
  7  | import type originalType from "../../docs/prototypes/new-game/T63/board.json";
  8  | const original:typeof originalType=JSON.parse(readFileSync(new URL("../../docs/prototypes/new-game/T63/board.json",import.meta.url),"utf8"));
  9  | import {fixture,step} from "./battle-fixture";
  10 | import {deserializeVersionedMatch} from "../../src/core/match-save";
  11 | import {logicalState} from "../core/versioned-match-fixture";
  12 | const root=process.env["COAST_EVIDENCE_DIR"]??"screenshots";
  13 | const country=(page:Page,id:string)=>page.locator(`[data-id="${id}"]`);
  14 | function output(label:string){mkdirSync(root,{recursive:true});return mkdtempSync(join(root,label+"-"));}
  15 | async function shot(page:Page,dir:string,name:string){await page.mouse.move(0,0);await page.screenshot({path:join(dir,name+".png")});}
  16 | async function painted(page:Page){
  17 |  await expect(page.locator(".country")).toHaveCount(46);
  18 |  expect(await page.locator(".coast").evaluateAll(nodes=>nodes.map(n=>n.getAttribute("d")))).toEqual(expected.islands.map(i=>"M"+i.polygon.map(p=>p.join(",")).join("L")+"Z"));
  19 |  for(const p of expected.provinces)await expect(country(page,p.id).locator(".cell")).toHaveAttribute("d","M"+p.polygon.map(q=>q.join(",")).join("L")+"Z");
  20 |  expect(await page.locator(".lane").evaluateAll(nodes=>nodes.map(n=>n.getAttribute("points")))).toEqual(expected.routes.map(r=>r.points.map(p=>p.join(",")).join(" ")));
  21 |  const hits=await page.evaluate((board)=>board.provinces.map(p=>{
  22 |   const group=document.querySelector<SVGGElement>(`[data-id="${p.id}"]`)!,shape=group.querySelector<SVGGeometryElement>(".cell")!,matrix=shape.getScreenCTM()!;
  23 |   const [x,y]=p.labelAt,point=new DOMPoint(x!,y!).matrixTransform(matrix);
  24 |   const hit=document.elementFromPoint(point.x,point.y)?.closest(".country")?.getAttribute("data-id");
  25 |   const corners=[[-20,-20],[-20,20],[20,-20],[20,20]].every(([dx,dy])=>shape.isPointInFill(new DOMPoint(x!+dx!,y!+dy!)));
  26 |   return{id:p.id,hit,corners};
  27 |  }),expected);
  28 |  expect(hits.filter(p=>p.hit!==p.id||!p.corners)).toEqual([]);
  29 |  const labels=await page.locator(".country-label").evaluateAll(nodes=>nodes.map(n=>{const b=n.getBoundingClientRect();return{x:b.x,y:b.y,right:b.right,bottom:b.bottom};}));
  30 |  const viewport=page.viewportSize()!;for(const b of labels){expect(b.x).toBeGreaterThanOrEqual(0);expect(b.y).toBeGreaterThanOrEqual(0);expect(b.right).toBeLessThanOrEqual(viewport.width);expect(b.bottom).toBeLessThanOrEqual(viewport.height);}
  31 |  for(let i=0;i<labels.length;i++)for(let j=i+1;j<labels.length;j++){const a=labels[i]!,b=labels[j]!;expect(a.right<=b.x||b.right<=a.x||a.bottom<=b.y||b.bottom<=a.y,`labels ${i}/${j} overlap`).toBe(true);}
  32 | }
  33 | for(const viewport of [{width:800,height:540},{width:1280,height:800},{width:1920,height:1080}])test(`standalone geography is painted and all46countries selectable at ${viewport.width}x${viewport.height}`,async({page},info)=>{
  34 |  const dir=output(`standalone-${viewport.width}-${info.project.name}`),errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));await page.setViewportSize(viewport);
  35 |  await page.setContent(readFileSync(new URL("../../docs/prototypes/new-game/T63/preview.html",import.meta.url),"utf8"));await shot(page,dir,"before-T63");
  36 |  await page.setContent(readFileSync(new URL("../../docs/prototypes/map-1994/preview.html",import.meta.url),"utf8"));await shot(page,dir,"approved-T22-reference");
> 37 |  await page.setContent(readFileSync(new URL("../../docs/prototypes/new-game/T64/preview.html",import.meta.url),"utf8"));await painted(page);await shot(page,dir,"after-opening");
     |                        ^ Error: ENOENT: no such file or directory, open '/work/docs/prototypes/new-game/T64/preview.html'
  38 |  for(const p of expected.provinces){await country(page,p.id).click();await expect(country(page,p.id)).toHaveAttribute("aria-pressed","true");expect(await page.locator(".country.neighbor").evaluateAll(nodes=>nodes.map(n=>(n as SVGGElement).dataset["id"]).sort())).toEqual([...p.borders,...p.seaLanes].sort());}
  39 |  await country(page,expected.provinces[0]!.id).focus();await page.keyboard.press("Space");await expect(country(page,expected.provinces[0]!.id)).toHaveAttribute("aria-pressed","true");
  40 |  await shot(page,dir,"selected");expect(errors).toEqual([]);
  41 | });
  42 | test("playable geography uses new paint/hit positions and ordinary deterministic attacks while saves keep canonical map",async({page},info)=>{
  43 |  const dir=output(`playable-${info.project.name}`),f=fixture("manual"),errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));
  44 |  await page.goto("/?control=manual");await page.getByLabel("Seed",{exact:true}).fill(String(f.seed));await page.getByLabel("Seats",{exact:true}).selectOption("2");await page.getByRole("button",{name:"Start game",exact:true}).click();
  45 |  try{await painted(page);}finally{await shot(page,dir,"opening");}
  46 |  for(let n=0;n<f.placements;n++)await country(page,f.from).click();await page.locator("#start-combat-button").click();
  47 |  const save=async()=>{const event=page.waitForEvent("download");await page.getByRole("button",{name:"Save game",exact:true}).click();const text=readFileSync((await(await event).path())!,"utf8");writeFileSync(join(dir,"save-"+Date.now()+".json"),text);return deserializeVersionedMatch(text).state;};
  48 |  let state=await save();await country(page,f.from).click();await country(page,f.to).click();state=step(state,{kind:"attack",from:f.from,to:f.to});expect(logicalState(await save())).toEqual(logicalState(state));
  49 |  expect(state.map.provinces.map(p=>p.polygon)).toEqual(original.provinces.map(p=>p.polygon));
  50 |  await expect(country(page,f.from)).toHaveAttribute("aria-pressed","true");await shot(page,dir,"direct-attack");expect(errors).toEqual([]);
  51 | });
  52 | 
```