# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: coast-postprocess.spec.ts >> playable geography uses new paint/hit positions and ordinary deterministic attacks while saves keep canonical map
- Location: tests/e2e/coast-postprocess.spec.ts:57:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  locator('[data-id="province_4"]').locator('.centre')
Expected: "342.25"
Received: "349"
Timeout:  5000ms

Call log:
  - Expect "toHaveAttribute" locator('[data-id="province_4"]').locator('.centre') with timeout 5000ms
  - waiting for locator('[data-id="province_4"]').locator('.centre')
    14 × locator resolved to <text y="38" x="349" class="centre">★</text>
       - unexpected value "349"

```

```yaml
- banner:
  - heading "Malpaco" [level=1]
  - text: Nine Isles · 2 human seats · Seed 0 Seat 1 23 provinces · 46 armies Seat 2 23 provinces · 46 armies
  - contentinfo:
    - button "New game"
  - button "Save game"
  - text: Load game
  - button "Load game"
- main:
  - img "Nine Isles reference map":
    - button "River gate, Seat 1, 3 armies, Seat 1": River gate 3
    - button "New port, Seat 2, 2 armies, Seat 2": New port 2
    - button "North rest, Seat 1, 2 armies, Seat 1": North rest 2
    - button "River keep, Seat 2, 1 armies, Seat 2": River keep 1
    - button "North town, Seat 1, 2 armies, Seat 1": North town 2
    - button "Dark ford, Seat 1, 3 armies, Seat 1": Dark ford 3
    - button "Iron point, Seat 2, 2 armies, Seat 2": Iron point 2
    - button "South rest, Seat 2, 3 armies, Seat 2": South rest 3
    - button "High shore, Seat 1, 3 armies, Seat 1": High shore 3
    - button "Wind town, Seat 1, 3 armies, Seat 1": Wind town 3
    - button "New glen, Seat 1, 1 armies, Seat 1": New glen 1
    - button "Old rock, Seat 2, 1 armies, Seat 2": Old rock 1
    - button "Blue peak, Seat 2, 1 armies, Seat 2": Blue peak 1
    - button "West haven, Seat 1, 2 armies, Seat 1": West haven 2
    - button "Stone watch, Seat 2, 3 armies, Seat 2": Stone watch 3
    - button "Upper ridge, Seat 1, 2 armies, Seat 1": Upper ridge 2
    - button "Marsh keep, Seat 2, 2 armies, Seat 2": Marsh keep 2
    - button "New fell, Seat 1, 1 armies, Seat 1": New fell 1
    - button "Moon point, Seat 2, 2 armies, Seat 2": Moon point 2
    - button "South fell, Seat 2, 3 armies, Seat 2": South fell 3
    - button "High ridge, Seat 2, 1 armies, Seat 2": High ridge 1 ★
    - button "Bay ford, Seat 1, 3 armies, Seat 1": Bay ford 3
    - button "Low moor, Seat 2, 2 armies, Seat 2": Low moor 2
    - button "Lower field, Seat 1, 1 armies, Seat 1": Lower field 1
    - button "Wind gate, Seat 2, 2 armies, Seat 2": Wind gate 2
    - button "Silver shore, Seat 1, 2 armies, Seat 1": Silver shore 2
    - button "Low peak, Seat 1, 1 armies, Seat 1": Low peak 1
    - button "Wind port, Seat 2, 3 armies, Seat 2": Wind port 3
    - button "Gold point, Seat 2, 3 armies, Seat 2": Gold point 3
    - button "Rock moor, Seat 1, 1 armies, Seat 1": Rock moor 1
    - button "Marsh rest, Seat 1, 3 armies, Seat 1": Marsh rest 3 ★
    - button "Wind dale, Seat 1, 2 armies, Seat 1": Wind dale 2
    - button "Silver ford, Seat 1, 1 armies, Seat 1": Silver ford 1
    - button "Iron field, Seat 2, 3 armies, Seat 2": Iron field 3
    - button "North wood, Seat 2, 1 armies, Seat 2": North wood 1
    - button "Fort town, Seat 1, 2 armies, Seat 1": Fort town 2
    - button "Red field, Seat 2, 1 armies, Seat 2": Red field 1
    - button "South ridge, Seat 2, 3 armies, Seat 2": South ridge 3
    - button "Rock bay, Seat 1, 2 armies, Seat 1": Rock bay 2
    - button "North ford, Seat 2, 1 armies, Seat 2": North ford 1
    - button "Port ridge, Seat 1, 3 armies, Seat 1": Port ridge 3
    - button "New rock, Seat 2, 3 armies, Seat 2": New rock 3
    - button "South reach, Seat 2, 1 armies, Seat 2": South reach 1 ★
    - button "Silver point, Seat 1, 1 armies, Seat 1": Silver point 1
    - button "East ford, Seat 1, 2 armies, Seat 1": East ford 2
    - button "Gold town, Seat 2, 2 armies, Seat 2": Gold town 2
    - text: North Isle +3 East Isle +3 West Isle +3 South Isle +3 Central Isle +5 Harbor Isle +5 Palm Isle +6 Cliff Isle +5 Great Isle +9
  - complementary:
    - text: Seat 1's turn Round 1 · Reinforcement Province income
    - strong: "7"
    - text: Island income
    - strong: "0"
    - text: Armies to place
    - strong: "7"
    - paragraph: Place your armies on your countries, then start combat.
    - button "Start combat" [disabled]
    - button "End turn" [disabled]
    - heading "Battle log" [level=3]
    - list "Battle log"
```

# Test source

```ts
  1  | import {test,expect} from "@playwright/test";
  2  | import type {Page} from "@playwright/test";
  3  | import {readFileSync,mkdirSync,mkdtempSync,writeFileSync} from "node:fs";
  4  | import {join} from "node:path";
  5  | import type expectedType from "../../docs/prototypes/new-game/T64/acceptance/board.json";
  6  | const expected:typeof expectedType=JSON.parse(readFileSync(new URL("../../docs/prototypes/new-game/T64/acceptance/board.json",import.meta.url),"utf8"));
  7  | import type originalType from "../../docs/prototypes/new-game/T63/board.json";
  8  | const original:typeof originalType=JSON.parse(readFileSync(new URL("../../docs/prototypes/new-game/T63/board.json",import.meta.url),"utf8"));
  9  | import {fixture,step} from "./battle-fixture";
  10 | import {deserializeVersionedMatch} from "../../src/core/match-save";
  11 | import {logicalState} from "../core/versioned-match-fixture";
  12 | const root=process.env["COAST_EVIDENCE_DIR"]??"screenshots";
  13 | const country=(page:Page,id:string)=>page.locator(`[data-id="${id}"]`);
  14 | function output(label:string){mkdirSync(root,{recursive:true});return mkdtempSync(join(root,label+"-"));}
  15 | async function shot(page:Page,dir:string,name:string){await page.mouse.move(0,0);await page.screenshot({path:join(dir,name+".png")});}
  16 | async function painted(page:Page){
  17 |  await expect(page.locator(".country")).toHaveCount(46);
  18 |  expect(await page.locator(".coast").evaluateAll(nodes=>nodes.map(n=>n.getAttribute("d")))).toEqual(expected.islands.map(i=>"M"+i.polygon.map(p=>p.join(",")).join("L")+"Z"));
  19 |  for(const p of expected.provinces)await expect(country(page,p.id).locator(".cell")).toHaveAttribute("d","M"+p.polygon.map(q=>q.join(",")).join("L")+"Z");
  20 |  expect(await page.locator(".lane").evaluateAll(nodes=>nodes.map(n=>n.getAttribute("points")))).toEqual(expected.routes.map(r=>r.points.map(p=>p.join(",")).join(" ")));
  21 |  const hits=await page.evaluate((board)=>board.provinces.map(p=>{
  22 |   const group=document.querySelector<SVGGElement>(`[data-id="${p.id}"]`)!,shape=group.querySelector<SVGGeometryElement>(".cell")!,matrix=shape.getScreenCTM()!;
  23 |   const [x,y]=p.labelAt,point=new DOMPoint(x!,y!).matrixTransform(matrix);
  24 |   const hit=document.elementFromPoint(point.x,point.y)?.closest(".country")?.getAttribute("data-id");
  25 |   const corners=[[-20,-20],[-20,20],[20,-20],[20,20]].every(([dx,dy])=>shape.isPointInFill(new DOMPoint(x!+dx!,y!+dy!)));
  26 |   return{id:p.id,hit,corners};
  27 |  }),expected);
  28 |  expect(hits.filter(p=>p.hit!==p.id||!p.corners)).toEqual([]);
  29 |  const captions=await page.locator(".island-name").evaluateAll(nodes=>nodes.map(node=>{
  30 |   const b=(node as SVGGraphicsElement).getBBox(),coasts=[...node.closest("svg")!.querySelectorAll<SVGGeometryElement>(".coast")];
  31 |   const onLand=[[b.x,b.y],[b.x+b.width,b.y],[b.x,b.y+b.height],[b.x+b.width,b.y+b.height],[b.x+b.width/2,b.y+b.height/2]].some(([x,y])=>coasts.some(c=>c.isPointInFill(new DOMPoint(x,y))));
  32 |   const intersects=(a:DOMPoint,bp:DOMPoint)=>{
  33 |    let low=0,high=1;
  34 |    for(const [origin,delta,min,max]of[[a.x,bp.x-a.x,b.x-1,b.x+b.width+1],[a.y,bp.y-a.y,b.y-1,b.y+b.height+1]]){
  35 |     if(delta===0){if(origin!<min!||origin!>max!)return false;continue;}
  36 |     const t1=(min!-origin!)/delta!,t2=(max!-origin!)/delta!;low=Math.max(low,Math.min(t1,t2));high=Math.min(high,Math.max(t1,t2));
  37 |    }
  38 |    return low<=high;
  39 |   };
  40 |   const onRoute=[...node.closest("svg")!.querySelectorAll<SVGPolylineElement>(".lane")].some(line=>{const points=line.points;for(let j=1;j<points.numberOfItems;j++){const a=points.getItem(j-1),c=points.getItem(j);if(intersects(new DOMPoint(a.x,a.y),new DOMPoint(c.x,c.y)))return true;}return false;});
  41 |   return{text:node.textContent,onLand,onRoute,inFrame:b.x>=0&&b.y>=0&&b.x+b.width<=800&&b.y+b.height<=460};
  42 |  }));
  43 |  expect(captions).toHaveLength(9);expect(captions.filter(c=>c.onLand||c.onRoute||!c.inFrame),"island captions need unobstructed water space").toEqual([]);
  44 |  const labels=await page.locator(".country-label").evaluateAll(nodes=>nodes.map(n=>{const b=n.getBoundingClientRect();return{x:b.x,y:b.y,right:b.right,bottom:b.bottom};}));
  45 |  const viewport=page.viewportSize()!;for(const b of labels){expect(b.x).toBeGreaterThanOrEqual(0);expect(b.y).toBeGreaterThanOrEqual(0);expect(b.right).toBeLessThanOrEqual(viewport.width);expect(b.bottom).toBeLessThanOrEqual(viewport.height);}
  46 |  for(let i=0;i<labels.length;i++)for(let j=i+1;j<labels.length;j++){const a=labels[i]!,b=labels[j]!;expect(a.right<=b.x||b.right<=a.x||a.bottom<=b.y||b.bottom<=a.y,`labels ${i}/${j} overlap`).toBe(true);}
  47 | }
  48 | for(const viewport of [{width:800,height:540},{width:1280,height:800},{width:1920,height:1080}])test(`standalone geography is painted and all46countries selectable at ${viewport.width}x${viewport.height}`,async({page},info)=>{
  49 |  const dir=output(`standalone-${viewport.width}-${info.project.name}`),errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));await page.setViewportSize(viewport);
  50 |  await page.setContent(readFileSync(new URL("../../docs/prototypes/new-game/T63/preview.html",import.meta.url),"utf8"));await shot(page,dir,"before-T63");
  51 |  await page.setContent(readFileSync(new URL("../../docs/prototypes/map-1994/preview.html",import.meta.url),"utf8"));await shot(page,dir,"approved-T22-reference");
  52 |  await page.setContent(readFileSync(new URL("../../docs/prototypes/new-game/T64/preview.html",import.meta.url),"utf8"));try{await painted(page);}finally{await shot(page,dir,"after-opening");}
  53 |  for(const p of expected.provinces){await country(page,p.id).click();await expect(country(page,p.id)).toHaveAttribute("aria-pressed","true");expect(await page.locator(".country.neighbor").evaluateAll(nodes=>nodes.map(n=>(n as SVGGElement).dataset["id"]).sort())).toEqual([...p.borders,...p.seaLanes].sort());const collisions=await page.locator(".country-label").evaluateAll(nodes=>{const boxes=nodes.map(n=>n.getBoundingClientRect());return boxes.flatMap((a,j)=>boxes.slice(j+1).flatMap((b,k)=>a.right>b.left&&b.right>a.left&&a.bottom>b.top&&b.bottom>a.top?[[j,j+k+1]]:[]));});expect(collisions,`selected ${p.id}: labels overlap`).toEqual([]);}
  54 |  await country(page,expected.provinces[0]!.id).focus();await page.keyboard.press("Space");await expect(country(page,expected.provinces[0]!.id)).toHaveAttribute("aria-pressed","true");
  55 |  await shot(page,dir,"selected");expect(errors).toEqual([]);
  56 | });
  57 | test("playable geography uses new paint/hit positions and ordinary deterministic attacks while saves keep canonical map",async({page},info)=>{
  58 |  const dir=output(`playable-${info.project.name}`),f=fixture("manual"),errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));
  59 |  await page.goto("/?control=manual");await page.getByLabel("Seed",{exact:true}).fill(String(f.seed));await page.getByLabel("Seats",{exact:true}).selectOption("2");await page.getByRole("button",{name:"Start game",exact:true}).click();
  60 |  try{await painted(page);}finally{await shot(page,dir,"opening");}
> 61 |  for(const p of expected.provinces){await expect(country(page,p.id).locator(".centre")).toHaveAttribute("x",String(p.labelAt[0]!-25));await expect(country(page,p.id).locator(".centre")).toHaveAttribute("y",String(p.labelAt[1]!-10));}
     |                                                                                         ^ Error: expect(locator).toHaveAttribute(expected) failed
  62 |  for(let n=0;n<f.placements;n++)await country(page,f.from).click();await page.locator("#start-combat-button").click();
  63 |  const save=async()=>{const event=page.waitForEvent("download");await page.getByRole("button",{name:"Save game",exact:true}).click();const text=readFileSync((await(await event).path())!,"utf8");writeFileSync(join(dir,"save-"+Date.now()+".json"),text);return deserializeVersionedMatch(text).state;};
  64 |  let state=await save();await country(page,f.from).click();await country(page,f.to).click();state=step(state,{kind:"attack",from:f.from,to:f.to});expect(logicalState(await save())).toEqual(logicalState(state));
  65 |  expect(state.map.provinces.map(p=>p.polygon)).toEqual(original.provinces.map(p=>p.polygon));
  66 |  expect(state.map.provinces.map(p=>p.labelAt)).toEqual(original.provinces.map(p=>p.labelAt));
  67 |  await expect(country(page,f.from)).toHaveAttribute("aria-pressed","true");await shot(page,dir,"direct-attack");expect(errors).toEqual([]);
  68 | });
  69 | 
```