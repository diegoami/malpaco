export const coastPostprocess=input=>structuredClone(input);
