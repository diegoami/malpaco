# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: coast-postprocess.spec.ts >> standalone geography is painted and all46countries selectable at 1280x800
- Location: tests/e2e/coast-postprocess.spec.ts:48:97

# Error details

```
Error: selected province_16: labels overlap

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 6

- Array []
+ Array [
+   Array [
+     6,
+     8,
+   ],
+ ]
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - banner [ref=e2]:
    - heading "Seed 1994 · Nine Isles" [level=1] [ref=e3]
    - generic [ref=e4]:
      - button "Topology" [ref=e5] [cursor=pointer]
      - button "Export SVG" [ref=e6] [cursor=pointer]
    - generic [ref=e7]: "High shore · seat2 · 1 armies · Neighbours: Iron point, South rest, Lower field"
  - main [ref=e8]:
    - img "Exact graph comparison map" [ref=e9]:
      - button "River gate" [ref=e35] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: 1 · 2
      - button "New port" [ref=e37] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: 2 · 3
      - button "North rest" [ref=e39] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: 1 · 1
      - button "River keep" [ref=e41] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: 2 · 1
      - button "North town" [ref=e43] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: 1 · 1
      - button "Dark ford" [ref=e45] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: 2 · 3
      - button "Iron point" [ref=e47] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: 1 · 3
      - button "South rest" [ref=e49] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: 2 · 3
      - button "High shore" [active] [pressed] [ref=e51] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: 2 · 1
      - button "Wind town" [ref=e53] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: 1 · 1
      - button "New glen" [ref=e55] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: 2 · 1
      - button "Old rock" [ref=e57] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: 2 · 2
      - button "Blue peak" [ref=e59] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: 2 · 3
        - generic [ref=e61]: ★
      - button "West haven" [ref=e62] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: 2 · 2
      - button "Stone watch" [ref=e64] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: 2 · 3
      - button "Upper ridge" [ref=e66] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: 1 · 2
      - button "Marsh keep" [ref=e68] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: 1 · 2
      - button "New fell" [ref=e70] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: 1 · 2
      - button "Moon point" [ref=e72] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: 2 · 2
        - generic [ref=e74]: ★
      - button "South fell" [ref=e75] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: 1 · 2
      - button "High ridge" [ref=e77] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: 1 · 1
      - button "Bay ford" [ref=e79] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: 2 · 2
      - button "Low moor" [ref=e81] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: 2 · 1
      - button "Lower field" [ref=e83] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: 1 · 2
      - button "Wind gate" [ref=e85] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: 1 · 2
      - button "Silver shore" [ref=e87] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: 1 · 3
      - button "Low peak" [ref=e89] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: 1 · 2
      - button "Wind port" [ref=e91] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: 1 · 3
      - button "Gold point" [ref=e93] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: 2 · 1
      - button "Rock moor" [ref=e95] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: 1 · 2
      - button "Marsh rest" [ref=e97] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: 1 · 2
      - button "Wind dale" [ref=e99] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: 2 · 3
      - button "Silver ford" [ref=e101] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: 1 · 3
      - button "Iron field" [ref=e103] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: 2 · 3
      - button "North wood" [ref=e105] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: 2 · 1
      - button "Fort town" [ref=e107] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: 1 · 2
      - button "Red field" [ref=e109] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: 2 · 1
        - generic [ref=e111]: ★
      - button "South ridge" [ref=e112] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: 2 · 2
      - button "Rock bay" [ref=e114] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: 1 · 2
      - button "North ford" [ref=e116] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: 1 · 3
      - button "Port ridge" [ref=e118] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: 2 · 3
      - button "New rock" [ref=e120] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: 1 · 1
      - button "South reach" [ref=e122] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: 2 · 1
      - button "Silver point" [ref=e124] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: 2 · 2
      - button "East ford" [ref=e126] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: 1 · 2
      - button "Gold town" [ref=e128] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: 2 · 2
      - generic [ref=e160]: North Isle +3
      - generic [ref=e161]: East Isle +3
      - generic [ref=e162]: West Isle +3
      - generic [ref=e163]: South Isle +3
      - generic [ref=e164]: Central Isle +5
      - generic [ref=e165]: Harbor Isle +5
      - generic [ref=e166]: Palm Isle +6
      - generic [ref=e167]: Cliff Isle +5
      - generic [ref=e168]: Great Isle +9
```

# Test source

```ts
  1  | import {test,expect} from "@playwright/test";
  2  | import type {Page} from "@playwright/test";
  3  | import {readFileSync,mkdirSync,mkdtempSync,writeFileSync} from "node:fs";
  4  | import {join} from "node:path";
  5  | import type expectedType from "../../docs/prototypes/new-game/T64/acceptance/board.json";
  6  | const expected:typeof expectedType=JSON.parse(readFileSync(new URL("../../docs/prototypes/new-game/T64/acceptance/board.json",import.meta.url),"utf8"));
  7  | import type originalType from "../../docs/prototypes/new-game/T63/board.json";
  8  | const original:typeof originalType=JSON.parse(readFileSync(new URL("../../docs/prototypes/new-game/T63/board.json",import.meta.url),"utf8"));
  9  | import {fixture,step} from "./battle-fixture";
  10 | import {deserializeVersionedMatch} from "../../src/core/match-save";
  11 | import {logicalState} from "../core/versioned-match-fixture";
  12 | const root=process.env["COAST_EVIDENCE_DIR"]??"screenshots";
  13 | const country=(page:Page,id:string)=>page.locator(`[data-id="${id}"]`);
  14 | function output(label:string){mkdirSync(root,{recursive:true});return mkdtempSync(join(root,label+"-"));}
  15 | async function shot(page:Page,dir:string,name:string){await page.mouse.move(0,0);await page.screenshot({path:join(dir,name+".png")});}
  16 | async function painted(page:Page){
  17 |  await expect(page.locator(".country")).toHaveCount(46);
  18 |  expect(await page.locator(".coast").evaluateAll(nodes=>nodes.map(n=>n.getAttribute("d")))).toEqual(expected.islands.map(i=>"M"+i.polygon.map(p=>p.join(",")).join("L")+"Z"));
  19 |  for(const p of expected.provinces)await expect(country(page,p.id).locator(".cell")).toHaveAttribute("d","M"+p.polygon.map(q=>q.join(",")).join("L")+"Z");
  20 |  expect(await page.locator(".lane").evaluateAll(nodes=>nodes.map(n=>n.getAttribute("points")))).toEqual(expected.routes.map(r=>r.points.map(p=>p.join(",")).join(" ")));
  21 |  const hits=await page.evaluate((board)=>board.provinces.map(p=>{
  22 |   const group=document.querySelector<SVGGElement>(`[data-id="${p.id}"]`)!,shape=group.querySelector<SVGGeometryElement>(".cell")!,matrix=shape.getScreenCTM()!;
  23 |   const [x,y]=p.labelAt,point=new DOMPoint(x!,y!).matrixTransform(matrix);
  24 |   const hit=document.elementFromPoint(point.x,point.y)?.closest(".country")?.getAttribute("data-id");
  25 |   const corners=[[-20,-20],[-20,20],[20,-20],[20,20]].every(([dx,dy])=>shape.isPointInFill(new DOMPoint(x!+dx!,y!+dy!)));
  26 |   return{id:p.id,hit,corners};
  27 |  }),expected);
  28 |  expect(hits.filter(p=>p.hit!==p.id||!p.corners)).toEqual([]);
  29 |  const captions=await page.locator(".island-name").evaluateAll(nodes=>nodes.map(node=>{
  30 |   const b=(node as SVGGraphicsElement).getBBox(),coasts=[...node.closest("svg")!.querySelectorAll<SVGGeometryElement>(".coast")];
  31 |   const onLand=[[b.x,b.y],[b.x+b.width,b.y],[b.x,b.y+b.height],[b.x+b.width,b.y+b.height],[b.x+b.width/2,b.y+b.height/2]].some(([x,y])=>coasts.some(c=>c.isPointInFill(new DOMPoint(x,y))));
  32 |   const intersects=(a:DOMPoint,bp:DOMPoint)=>{
  33 |    let low=0,high=1;
  34 |    for(const [origin,delta,min,max]of[[a.x,bp.x-a.x,b.x-1,b.x+b.width+1],[a.y,bp.y-a.y,b.y-1,b.y+b.height+1]]){
  35 |     if(delta===0){if(origin!<min!||origin!>max!)return false;continue;}
  36 |     const t1=(min!-origin!)/delta!,t2=(max!-origin!)/delta!;low=Math.max(low,Math.min(t1,t2));high=Math.min(high,Math.max(t1,t2));
  37 |    }
  38 |    return low<=high;
  39 |   };
  40 |   const onRoute=[...node.closest("svg")!.querySelectorAll<SVGPolylineElement>(".lane")].some(line=>{const points=line.points;for(let j=1;j<points.numberOfItems;j++){const a=points.getItem(j-1),c=points.getItem(j);if(intersects(new DOMPoint(a.x,a.y),new DOMPoint(c.x,c.y)))return true;}return false;});
  41 |   return{text:node.textContent,onLand,onRoute,inFrame:b.x>=0&&b.y>=0&&b.x+b.width<=800&&b.y+b.height<=460};
  42 |  }));
  43 |  expect(captions).toHaveLength(9);expect(captions.filter(c=>c.onLand||c.onRoute||!c.inFrame),"island captions need unobstructed water space").toEqual([]);
  44 |  const labels=await page.locator(".country-label").evaluateAll(nodes=>nodes.map(n=>{const b=n.getBoundingClientRect();return{x:b.x,y:b.y,right:b.right,bottom:b.bottom};}));
  45 |  const viewport=page.viewportSize()!;for(const b of labels){expect(b.x).toBeGreaterThanOrEqual(0);expect(b.y).toBeGreaterThanOrEqual(0);expect(b.right).toBeLessThanOrEqual(viewport.width);expect(b.bottom).toBeLessThanOrEqual(viewport.height);}
  46 |  for(let i=0;i<labels.length;i++)for(let j=i+1;j<labels.length;j++){const a=labels[i]!,b=labels[j]!;expect(a.right<=b.x||b.right<=a.x||a.bottom<=b.y||b.bottom<=a.y,`labels ${i}/${j} overlap`).toBe(true);}
  47 | }
  48 | for(const viewport of [{width:800,height:540},{width:1280,height:800},{width:1920,height:1080}])test(`standalone geography is painted and all46countries selectable at ${viewport.width}x${viewport.height}`,async({page},info)=>{
  49 |  const dir=output(`standalone-${viewport.width}-${info.project.name}`),errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));await page.setViewportSize(viewport);
  50 |  await page.setContent(readFileSync(new URL("../../docs/prototypes/new-game/T63/preview.html",import.meta.url),"utf8"));await shot(page,dir,"before-T63");
  51 |  await page.setContent(readFileSync(new URL("../../docs/prototypes/map-1994/preview.html",import.meta.url),"utf8"));await shot(page,dir,"approved-T22-reference");
  52 |  await page.setContent(readFileSync(new URL("../../docs/prototypes/new-game/T64/preview.html",import.meta.url),"utf8"));try{await painted(page);}finally{await shot(page,dir,"after-opening");}
> 53 |  for(const p of expected.provinces){await country(page,p.id).click();await expect(country(page,p.id)).toHaveAttribute("aria-pressed","true");expect(await page.locator(".country.neighbor").evaluateAll(nodes=>nodes.map(n=>(n as SVGGElement).dataset["id"]).sort())).toEqual([...p.borders,...p.seaLanes].sort());const collisions=await page.locator(".country-label").evaluateAll(nodes=>{const boxes=nodes.map(n=>n.getBoundingClientRect());return boxes.flatMap((a,j)=>boxes.slice(j+1).flatMap((b,k)=>a.right>b.left&&b.right>a.left&&a.bottom>b.top&&b.bottom>a.top?[[j,j+k+1]]:[]));});expect(collisions,`selected ${p.id}: labels overlap`).toEqual([]);}
     |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ^ Error: selected province_16: labels overlap
  54 |  await country(page,expected.provinces[0]!.id).focus();await page.keyboard.press("Space");await expect(country(page,expected.provinces[0]!.id)).toHaveAttribute("aria-pressed","true");
  55 |  await shot(page,dir,"selected");expect(errors).toEqual([]);
  56 | });
  57 | test("playable geography uses new paint/hit positions and ordinary deterministic attacks while saves keep canonical map",async({page},info)=>{
  58 |  const dir=output(`playable-${info.project.name}`),f=fixture("manual"),errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));
  59 |  await page.goto("/?control=manual");await page.getByLabel("Seed",{exact:true}).fill(String(f.seed));await page.getByLabel("Seats",{exact:true}).selectOption("2");await page.getByRole("button",{name:"Start game",exact:true}).click();
  60 |  try{await painted(page);}finally{await shot(page,dir,"opening");}
  61 |  for(const p of expected.provinces){await expect(country(page,p.id).locator(".centre")).toHaveAttribute("x",String(p.labelAt[0]!-25));await expect(country(page,p.id).locator(".centre")).toHaveAttribute("y",String(p.labelAt[1]!-10));}
  62 |  for(let n=0;n<f.placements;n++)await country(page,f.from).click();await page.locator("#start-combat-button").click();
  63 |  const save=async()=>{const event=page.waitForEvent("download");await page.getByRole("button",{name:"Save game",exact:true}).click();const text=readFileSync((await(await event).path())!,"utf8");writeFileSync(join(dir,"save-"+Date.now()+".json"),text);return deserializeVersionedMatch(text).state;};
  64 |  let state=await save();await country(page,f.from).click();await country(page,f.to).click();state=step(state,{kind:"attack",from:f.from,to:f.to});expect(logicalState(await save())).toEqual(logicalState(state));
  65 |  expect(state.map.provinces.map(p=>p.polygon)).toEqual(original.provinces.map(p=>p.polygon));
  66 |  expect(state.map.provinces.map(p=>p.labelAt)).toEqual(original.provinces.map(p=>p.labelAt));
  67 |  await expect(country(page,f.from)).toHaveAttribute("aria-pressed","true");await shot(page,dir,"direct-attack");expect(errors).toEqual([]);
  68 | });
  69 | 
```