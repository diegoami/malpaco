// Disposable parent feasibility UI; retained as mock evidence then removed.
import {BattleController} from './battleController';
import type {App} from './app';
import type {GameState} from '../core';
import type {View} from '../../tests/ui/battle-fixtures';
export function attachMockBattle(app:App,root:HTMLElement){
 const a=app as unknown as {state:GameState;selected:string|null;target:string|null;render():void;dispose():void};
 const box=document.createElement('section');box.setAttribute('role','region');box.setAttribute('aria-label','Battle controls');box.style.cssText='position:fixed;top:280px;right:20px;width:260px;max-height:calc(100vh - 330px);overflow:auto;background:#142a38;border:1px solid #698697;padding:8px;z-index:6;font-size:12px';
 let amount=1,pendingKey='';let c:BattleController;
 const render=(v:View)=>{
  a.state=v.state;a.selected=v.from;a.target=v.to;a.render();
  const panel=root.querySelector('.panel')!;panel.append(box);const active=v.state.phase!=='reinforce';box.hidden=!active;
  (panel.querySelector('.action') as HTMLElement).style.display=active?'none':'';(panel.querySelector('.log-card') as HTMLElement).style.display=active?'none':'';
  box.dataset['historyCount']=String(v.state.history.length);box.dataset['running']=String(v.running);box.dataset['revision']=String(v.revision);box.dataset['paused']=String(v.paused);
  const name=(id:string|null)=>v.state.map.provinces.find(p=>p.id===id)?.name??'';
  box.innerHTML=`<div id="battle-source-name"></div><b id="battle-source-armies"></b> → <div id="battle-target-name"></div><b id="battle-target-armies"></b><div id="battle-status">Battle</div><div>Ties <span id="battle-ties"></span></div><label>Stop at <input id="battle-stop-threshold" type="number" min="1" style="width:60px"></label><select id="battle-speed" aria-label="Battle speed"><option value="slow">Slow</option><option value="normal">Normal</option><option value="fast">Fast</option></select><div id="mock-buttons"></div><div id="mock-rolls"></div><div id="mock-capture"></div>`;
  const text=(id:string,value:string)=>box.querySelector('#'+id)!.textContent=value;text('battle-source-name',name(v.from));text('battle-target-name',name(v.to));text('battle-source-armies',String(v.from?v.state.armies[v.from]:''));text('battle-target-armies',String(v.to?v.state.armies[v.to]:''));text('battle-ties',String(v.ties));
  const threshold=box.querySelector<HTMLInputElement>('#battle-stop-threshold')!;threshold.value=String(v.threshold);threshold.onchange=()=>c.setThreshold(Number(threshold.value),v.revision);
  const speed=box.querySelector<HTMLSelectElement>('#battle-speed')!;speed.value=v.speed;speed.onchange=()=>c.setSpeed(speed.value as View['speed'],v.revision);
  const button=(parent:Element,id:string,label:string,action:()=>void)=>{const b=document.createElement('button');b.id=id;b.textContent=label;b.type='button';b.style.cssText='font-size:12px;padding:4px;margin:2px;min-height:30px';b.onclick=action;parent.append(b);return b;};
  const buttons=box.querySelector('#mock-buttons')!;button(buttons,'fight-on-button',v.paused?'Keep watching':'Fight on',()=>c.fightOn(v.revision));button(buttons,'single-exchange-button','Single exchange',()=>c.singleExchange(v.revision));button(buttons,'stop-battle-button','Stop',()=>c.stop(v.revision));
  for(const roll of v.rolls){const row=document.createElement('div');row.dataset['battleRoll']='true';row.dataset['a']=String(roll.attackerRolls[0]);row.dataset['d']=String(roll.defenderRolls[0]);row.dataset['result']=roll.results[0];row.textContent=`${roll.attackerRolls[0]} vs ${roll.defenderRolls[0]} · ${roll.results[0]}`;box.querySelector('#mock-rolls')!.append(row);}
  const pending=v.state.pendingCapture;if(pending){const key=`${pending.from}|${pending.to}|${v.state.history.length}`;if(key!==pendingKey){pendingKey=key;amount=pending.defaultAmount;}
   const group=box.querySelector('#mock-capture')!;const input=document.createElement('input');input.id='capture-amount';input.type='number';input.min='1';input.max=String(pending.max);input.value=String(amount);input.style.width='60px';input.oninput=()=>{amount=Number(input.value);};group.append(input);
   const set=(n:number)=>{amount=Math.max(1,Math.min(pending.max,n));render(v);};button(group,'capture-minimum-button','1',()=>set(1));button(group,'capture-less-button','−',()=>set(amount-1));button(group,'capture-more-button','+',()=>set(amount+1));button(group,'capture-maximum-button','All but one',()=>set(pending.max));button(group,'confirm-capture-button','Confirm',()=>c.confirmCapture(amount,v.revision));
  }else pendingKey='';
  const end=root.querySelector('#end-turn-button');if(active&&end)buttons.append(end);
 };
 c=new BattleController(a.state,{schedule:(callback,delay)=>window.setTimeout(callback,delay),cancel:handle=>window.clearTimeout(handle)},render);
 const block=(e:Event)=>{if(c.state.pendingCapture&&(e.target as Element).closest('[data-country]')){e.preventDefault();e.stopImmediatePropagation();}};
 const select=(e:Event)=>{if(!(e.target as Element).closest('[data-country]')||a.state.phase!=='attack')return;if(c.state!==a.state)c.replaceGame(a.state,'load');c.select(a.selected,a.target);};root.addEventListener('click',block,true);root.addEventListener('click',select);
 const dispose=a.dispose.bind(a);a.dispose=()=>{root.removeEventListener('click',block,true);root.removeEventListener('click',select);c.dispose();dispose();};render(c.view);
}
