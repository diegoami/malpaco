# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: battle-controls.spec.ts >> one chosen exchange shows actual ties, dice and live stacks without a later exchange
- Location: tests/e2e/battle-controls.spec.ts:25:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('[data-battle-roll][data-result="tie"]')
Expected: visible
Error: strict mode violation: locator('[data-battle-roll][data-result="tie"]') resolved to 2 elements:
    1) <div data-a="2" data-d="2" data-result="tie" data-battle-roll="true">2 vs 2 · tie</div> aka getByText('vs 2 · tie')
    2) <div data-a="6" data-d="6" data-result="tie" data-battle-roll="true">6 vs 6 · tie</div> aka getByText('vs 6 · tie')

Call log:
  - Expect "toBeVisible" locator('[data-battle-roll][data-result="tie"]') with timeout 5000ms
  - waiting for locator('[data-battle-roll][data-result="tie"]')

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 2 human seats · Seed 6
  - main [ref=e6]:
    - img "Nine Isles reference map" [ref=e8]:
      - button "River gate, Seat 2, 9 armies" [pressed] [ref=e33] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: 2 · 9
      - button "New port, Seat 1, 3 armies" [ref=e35] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: 1 · 3
      - button "North rest, Seat 2, 2 armies" [ref=e37] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: 2 · 2
      - button "River keep, Seat 2, 1 armies" [ref=e39] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: 2 · 1
        - generic [ref=e41]: ★
      - button "North town, Seat 1, 2 armies" [ref=e42] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: 1 · 2
      - button "Dark ford, Seat 1, 1 armies" [ref=e44] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: 1 · 1
      - button "Iron point, Seat 2, 1 armies" [ref=e46] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: 2 · 1
      - button "South rest, Seat 2, 2 armies" [ref=e48] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: 2 · 2
      - button "High shore, Seat 1, 1 armies" [ref=e50] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: 1 · 1
      - button "Wind town, Seat 2, 3 armies" [ref=e52] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: 2 · 3
      - button "New glen, Seat 1, 1 armies" [ref=e54] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: 1 · 1
      - button "Old rock, Seat 1, 3 armies" [ref=e56] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: 1 · 3
      - button "Blue peak, Seat 1, 1 armies" [ref=e58] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: 1 · 1
      - button "West haven, Seat 2, 1 armies" [ref=e60] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: 2 · 1
      - button "Stone watch, Seat 1, 1 armies" [ref=e62] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: 1 · 1
      - button "Upper ridge, Seat 1, 1 armies" [ref=e64] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: 1 · 1
      - button "Marsh keep, Seat 1, 2 armies" [ref=e66] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: 1 · 2
      - button "New fell, Seat 2, 2 armies" [ref=e68] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: 2 · 2
      - button "Moon point, Seat 2, 2 armies" [ref=e70] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: 2 · 2
      - button "South fell, Seat 1, 3 armies" [ref=e72] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: 1 · 3
      - button "High ridge, Seat 2, 2 armies" [ref=e74] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: 2 · 2
      - button "Bay ford, Seat 2, 2 armies" [ref=e76] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: 2 · 2
      - button "Low moor, Seat 2, 3 armies" [ref=e78] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: 2 · 3
      - button "Lower field, Seat 2, 3 armies" [ref=e80] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: 2 · 3
      - button "Wind gate, Seat 2, 2 armies" [ref=e82] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: 2 · 2
      - button "Silver shore, Seat 2, 3 armies" [ref=e84] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: 2 · 3
      - button "Low peak, Seat 1, 3 armies" [ref=e86] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: 1 · 3
      - button "Wind port, Seat 1, 3 armies" [ref=e88] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: 1 · 3
      - button "Gold point, Seat 2, 2 armies" [ref=e90] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: 2 · 2
      - button "Rock moor, Seat 1, 3 armies" [ref=e92] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: 1 · 3
      - button "Marsh rest, Seat 2, 3 armies" [ref=e94] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: 2 · 3
      - button "Wind dale, Seat 2, 1 armies" [ref=e96] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: 2 · 1
      - button "Silver ford, Seat 2, 2 armies" [ref=e98] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: 2 · 2
      - button "Iron field, Seat 1, 3 armies" [ref=e100] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: 1 · 3
      - button "North wood, Seat 1, 2 armies" [ref=e102] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: 1 · 2
      - button "Fort town, Seat 2, 2 armies" [ref=e104] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: 2 · 2
      - button "Red field, Seat 2, 2 armies" [ref=e106] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: 2 · 2
      - button "South ridge, Seat 1, 3 armies" [ref=e108] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: 1 · 3
      - button "Rock bay, Seat 2, 1 armies" [ref=e110] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: 2 · 1
      - button "North ford, Seat 1, 1 armies" [ref=e112] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: 1 · 1
      - button "Port ridge, Seat 2, 1 armies" [ref=e114] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: 2 · 1
      - button "New rock, Seat 1, 3 armies" [ref=e116] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: 1 · 3
      - button "South reach, Seat 1, 1 armies" [ref=e118] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: 1 · 1
        - generic [ref=e120]: ★
      - button "Silver point, Seat 1, 2 armies" [ref=e121] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: 1 · 2
      - button "East ford, Seat 1, 1 armies" [ref=e123] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: 1 · 1
        - generic [ref=e125]: ★
      - button "Gold town, Seat 1, 2 armies" [ref=e126] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: 1 · 2
      - generic [ref=e158]: North Isle +3
      - generic [ref=e159]: East Isle +3
      - generic [ref=e160]: West Isle +3
      - generic [ref=e161]: South Isle +3
      - generic [ref=e162]: Central Isle +5
      - generic [ref=e163]: Harbor Isle +5
      - generic [ref=e164]: Palm Isle +6
      - generic [ref=e165]: Cliff Isle +5
      - generic [ref=e166]: Great Isle +9
    - complementary [ref=e167]:
      - generic [ref=e171]:
        - generic [ref=e172]: Seat 2's turn
        - generic [ref=e173]: Round 1 · Attack
      - generic [ref=e174]:
        - generic [ref=e178]:
          - generic [ref=e179]: Seat 1
          - generic [ref=e180]: 23 provinces · 46 armies
        - generic [ref=e184]:
          - generic [ref=e185]: Seat 2
          - generic [ref=e186]: 23 provinces · 52 armies
      - generic [ref=e187]:
        - button "New game" [ref=e188] [cursor=pointer]
        - generic [ref=e189]: seed 6
      - region "Battle controls" [ref=e190]:
        - generic [ref=e191]: River gate
        - text: 9 →
        - generic [ref=e192]: New port
        - text: "3"
        - generic [ref=e193]: Battle
        - generic [ref=e194]: Ties 2
        - generic [ref=e195]:
          - text: Stop at
          - spinbutton "Stop at" [ref=e196]: "2"
        - combobox "Battle speed" [ref=e197]:
          - option "Slow"
          - option "Normal" [selected]
          - option "Fast"
        - generic [ref=e198]:
          - button "Fight on" [ref=e199] [cursor=pointer]
          - button "Single exchange" [ref=e200] [cursor=pointer]
          - button "Stop" [ref=e201] [cursor=pointer]
        - generic [ref=e202]:
          - generic [ref=e203]: 2 vs 2 · tie
          - generic [ref=e204]: 6 vs 6 · tie
          - generic [ref=e205]: 3 vs 4 · defender
```

# Test source

```ts
  1  | import {test,expect} from "@playwright/test";
  2  | import type {Page} from "@playwright/test";
  3  | import {mkdirSync,mkdtempSync} from "node:fs";
  4  | import {join} from "node:path";
  5  | import {fixture,map,step} from "./battle-fixture";
  6  | import type {GameState} from "../../src/core";
  7  | const region=(p:Page)=>p.getByRole("region",{name:"Battle controls",exact:true});
  8  | const country=(p:Page,id:string)=>p.locator(`[data-country="${id}"]`);
  9  | async function prepare(page:Page,kind:Parameters<typeof fixture>[0]){
  10 |  const f=fixture(kind);await page.clock.install();await page.clock.pauseAt(new Date());await page.goto("/?view=reference-game");
  11 |  await page.getByLabel("Seed",{exact:true}).fill(String(f.seed));await page.getByLabel("Human seats").selectOption("2");await page.getByRole("button",{name:"Start game",exact:true}).click();
  12 |  for(let n=0;n<f.placements;n++)await country(page,f.from).click();await page.locator("#start-combat-button").click();await country(page,f.from).click();await country(page,f.to).click();
  13 |  await expect(region(page)).toBeVisible();await expect(page.locator("#battle-stop-threshold")).toHaveValue("2");await paint(page,f.ready);return f;
  14 | }
  15 | async function paint(page:Page,state:GameState){
  16 |  for(const p of map.provinces){await expect(country(page,p.id)).toHaveAttribute("data-owner",state.ownerOf[p.id]!);await expect(country(page,p.id)).toHaveAttribute("data-armies",String(state.armies[p.id]));await expect(country(page,p.id).locator(".army-count")).toHaveText(`${state.players.findIndex(q=>q.id===state.ownerOf[p.id])+1} · ${state.armies[p.id]}`);}
  17 | }
  18 | async function history(page:Page,count:number){await expect(region(page)).toHaveAttribute("data-history-count",String(count));}
  19 | async function capture(page:Page,name:string,project:string){const root=process.env["BATTLE_EVIDENCE_DIR"]??"screenshots";mkdirSync(root,{recursive:true});const dir=mkdtempSync(join(root,"battle-"));await page.mouse.move(0,0);await page.screenshot({path:join(dir,`${name}-${project}.png`)});}
  20 | async function context(page:Page,s:GameState,from:string,to:string){
  21 |  await expect(page.locator("#battle-source-name")).toHaveText(map.provinces.find(p=>p.id===from)!.name);await expect(page.locator("#battle-target-name")).toHaveText(map.provinces.find(p=>p.id===to)!.name);
  22 |  await expect(page.locator("#battle-source-armies")).toHaveText(String(s.armies[from]));await expect(page.locator("#battle-target-armies")).toHaveText(String(s.armies[to]));
  23 |  const v=page.viewportSize()!;for(const id of ["fight-on-button","single-exchange-button","stop-battle-button","battle-stop-threshold","battle-speed"]){const n=page.locator('#'+id);await expect(n).toBeVisible();const b=await n.boundingBox();expect(b).not.toBeNull();expect(b!.x).toBeGreaterThanOrEqual(0);expect(b!.y).toBeGreaterThanOrEqual(0);expect(b!.x+b!.width).toBeLessThanOrEqual(v.width);expect(b!.y+b!.height).toBeLessThanOrEqual(v.height);}
  24 | }
  25 | test("one chosen exchange shows actual ties, dice and live stacks without a later exchange",async({page},info)=>{
  26 |  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));const f=await prepare(page,"tie");await page.locator("#single-exchange-button").click();const next=step(f.ready,{kind:"attack",from:f.from,to:f.to});
  27 |  await history(page,next.history.length);await paint(page,next);await context(page,next,f.from,f.to);
  28 |  expect(await page.locator("[data-battle-roll]").evaluateAll(ns=>ns.map(n=>({a:Number((n as HTMLElement).dataset["a"]),d:Number((n as HTMLElement).dataset["d"]),result:(n as HTMLElement).dataset["result"]})))).toEqual(f.first.rolls);
> 29 |  await expect(page.locator('[data-battle-roll][data-result="tie"]')).toBeVisible();await expect(page.locator("#battle-ties")).toHaveText(String(f.first.rolls.filter(r=>r.result==="tie").length));
     |                                                                      ^ Error: expect(locator).toBeVisible() failed
  30 |  await page.clock.runFor(4000);await history(page,next.history.length);await paint(page,next);await capture(page,"single-tie",info.project.name);expect(errors).toEqual([]);
  31 | });
  32 | test("manual Stop takes effect before the next exchange while context stays visible",async({page},info)=>{
  33 |  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));const f=await prepare(page,"manual");await page.locator("#battle-stop-threshold").fill("1");await page.locator("#battle-stop-threshold").press("Tab");await page.locator("#fight-on-button").click();
  34 |  const next=step(f.ready,{kind:"attack",from:f.from,to:f.to});await history(page,next.history.length);await expect(region(page)).toHaveAttribute("data-running","true");await page.locator("#stop-battle-button").click();
  35 |  await expect(region(page)).toHaveAttribute("data-running","false");await page.clock.runFor(4000);await history(page,next.history.length);await paint(page,next);await context(page,next,f.from,f.to);await capture(page,"manual-stop",info.project.name);expect(errors).toEqual([]);
  36 | });
  37 | test("fight-on stops at the chosen fixed threshold after a loss",async({page},info)=>{
  38 |  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));const f=await prepare(page,"loss"),threshold=f.ready.armies[f.from]!-1;
  39 |  await page.locator("#battle-stop-threshold").fill(String(threshold));await page.locator("#battle-stop-threshold").press("Tab");await page.locator("#fight-on-button").click();const next=step(f.ready,{kind:"attack",from:f.from,to:f.to});
  40 |  expect(next.armies[f.from]).toBe(threshold);await expect(region(page)).toHaveAttribute("data-running","false");await expect(page.locator("#battle-stop-threshold")).toHaveValue(String(threshold));await page.clock.runFor(4000);await history(page,next.history.length);await paint(page,next);await context(page,next,f.from,f.to);await capture(page,"threshold-stop",info.project.name);expect(errors).toEqual([]);
  41 | });
  42 | for(const quantity of ["minimum","maximum"] as const)test(`capture ${quantity} preserves armies and rejects stale/unrelated controls`,async({page},info)=>{
  43 |  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));const f=await prepare(page,"capture");await page.locator("#battle-stop-threshold").fill("1");await page.locator("#battle-stop-threshold").press("Tab");await page.locator("#battle-speed").selectOption("fast");
  44 |  const stale=await page.locator("#single-exchange-button").elementHandle();await page.locator("#fight-on-button").click();let next=step(f.ready,{kind:"attack",from:f.from,to:f.to});
  45 |  for(let n=0;next.phase==="attack"&&n<128;n++){await page.clock.runFor(200);next=step(next,{kind:"attack",from:f.from,to:f.to});}
  46 |  expect(next.phase).toBe("capture");const pending=next.pendingCapture!;await expect(page.locator("#capture-amount")).toHaveValue(String(pending.defaultAmount));await history(page,next.history.length);await paint(page,next);
  47 |  await stale!.evaluate(n=>n.dispatchEvent(new MouseEvent("click",{bubbles:true})));await page.locator("#end-turn-button").dispatchEvent("click");await country(page,f.from).click();await page.clock.runFor(2000);await history(page,next.history.length);await paint(page,next);await context(page,next,f.from,f.to);
  48 |  await page.locator("#capture-amount").fill("0");await page.locator("#confirm-capture-button").dispatchEvent("click");await history(page,next.history.length);await paint(page,next);
  49 |  await page.locator("#capture-minimum-button").click();await expect(page.locator("#capture-amount")).toHaveValue("1");await page.locator("#capture-more-button").click();await expect(page.locator("#capture-amount")).toHaveValue("2");await page.locator("#capture-less-button").click();await expect(page.locator("#capture-amount")).toHaveValue("1");
  50 |  if(quantity==="maximum")await page.locator("#capture-maximum-button").click();const amount=quantity==="minimum"?1:pending.max;await expect(page.locator("#capture-amount")).toHaveValue(String(amount));await capture(page,`capture-${quantity}-pending`,info.project.name);
  51 |  const oldConfirm=await page.locator("#confirm-capture-button").elementHandle();await page.locator("#confirm-capture-button").click();next=step(next,{kind:"captureMove",amount});await paint(page,next);await history(page,next.history.length);await oldConfirm!.evaluate(n=>n.dispatchEvent(new MouseEvent("click",{bubbles:true})));await page.clock.runFor(2000);await history(page,next.history.length);await paint(page,next);await context(page,next,f.from,f.to);await capture(page,`capture-${quantity}-done`,info.project.name);expect(errors).toEqual([]);
  52 | });
  53 | 
```