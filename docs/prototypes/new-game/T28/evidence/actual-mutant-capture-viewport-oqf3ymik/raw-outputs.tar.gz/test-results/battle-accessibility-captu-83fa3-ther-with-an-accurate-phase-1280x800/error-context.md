# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: battle-accessibility.spec.ts >> capture confirmation, quantities and context fit together with an accurate phase
- Location: tests/e2e/battle-accessibility.spec.ts:36:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 26

- Array []
+ Array [
+   Object {
+     "fits": false,
+     "id": "capture-amount",
+   },
+   Object {
+     "fits": false,
+     "id": "capture-minimum-button",
+   },
+   Object {
+     "fits": false,
+     "id": "capture-less-button",
+   },
+   Object {
+     "fits": false,
+     "id": "capture-more-button",
+   },
+   Object {
+     "fits": false,
+     "id": "capture-maximum-button",
+   },
+   Object {
+     "fits": false,
+     "id": "confirm-capture-button",
+   },
+ ]
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 2 human seats · Seed 0
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]: 24 provinces · 50 armies
      - generic [ref=e16]:
        - generic [ref=e17]: Seat 2
        - generic [ref=e18]: 22 provinces · 45 armies
    - contentinfo [ref=e19]:
      - button "New game" [ref=e20] [cursor=pointer]
  - main [ref=e21]:
    - img "Nine Isles reference map" [ref=e23]:
      - button "River gate, Seat 1, 3 armies" [ref=e48] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: 1 · 3
      - button "New port, Seat 2, 2 armies" [ref=e50] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: 2 · 2
      - button "North rest, Seat 1, 5 armies" [pressed] [ref=e52] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: 1 · 5
      - button "River keep, Seat 1, 1 armies" [ref=e54] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: 1 · 1
      - button "North town, Seat 1, 2 armies" [ref=e56] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: 1 · 2
      - button "Dark ford, Seat 1, 3 armies" [ref=e58] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: 1 · 3
      - button "Iron point, Seat 2, 2 armies" [ref=e60] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: 2 · 2
      - button "South rest, Seat 2, 3 armies" [ref=e62] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: 2 · 3
      - button "High shore, Seat 1, 3 armies" [ref=e64] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: 1 · 3
      - button "Wind town, Seat 1, 3 armies" [ref=e66] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: 1 · 3
      - button "New glen, Seat 1, 1 armies" [ref=e68] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: 1 · 1
      - button "Old rock, Seat 2, 1 armies" [ref=e70] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: 2 · 1
      - button "Blue peak, Seat 2, 1 armies" [ref=e72] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: 2 · 1
      - button "West haven, Seat 1, 2 armies" [ref=e74] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: 1 · 2
      - button "Stone watch, Seat 2, 3 armies" [ref=e76] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: 2 · 3
      - button "Upper ridge, Seat 1, 2 armies" [ref=e78] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: 1 · 2
      - button "Marsh keep, Seat 2, 2 armies" [ref=e80] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: 2 · 2
      - button "New fell, Seat 1, 1 armies" [ref=e82] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: 1 · 1
      - button "Moon point, Seat 2, 2 armies" [ref=e84] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: 2 · 2
      - button "South fell, Seat 2, 3 armies" [ref=e86] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: 2 · 3
      - button "High ridge, Seat 2, 1 armies" [ref=e88] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: 2 · 1
        - generic [ref=e90]: ★
      - button "Bay ford, Seat 1, 3 armies" [ref=e91] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: 1 · 3
      - button "Low moor, Seat 2, 2 armies" [ref=e93] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: 2 · 2
      - button "Lower field, Seat 1, 1 armies" [ref=e95] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: 1 · 1
      - button "Wind gate, Seat 2, 2 armies" [ref=e97] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: 2 · 2
      - button "Silver shore, Seat 1, 2 armies" [ref=e99] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: 1 · 2
      - button "Low peak, Seat 1, 1 armies" [ref=e101] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: 1 · 1
      - button "Wind port, Seat 2, 3 armies" [ref=e103] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: 2 · 3
      - button "Gold point, Seat 2, 3 armies" [ref=e105] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: 2 · 3
      - button "Rock moor, Seat 1, 1 armies" [ref=e107] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: 1 · 1
      - button "Marsh rest, Seat 1, 3 armies" [ref=e109] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: 1 · 3
        - generic [ref=e111]: ★
      - button "Wind dale, Seat 1, 2 armies" [ref=e112] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: 1 · 2
      - button "Silver ford, Seat 1, 1 armies" [ref=e114] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: 1 · 1
      - button "Iron field, Seat 2, 3 armies" [ref=e116] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: 2 · 3
      - button "North wood, Seat 2, 1 armies" [ref=e118] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: 2 · 1
      - button "Fort town, Seat 1, 2 armies" [ref=e120] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: 1 · 2
      - button "Red field, Seat 2, 1 armies" [ref=e122] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: 2 · 1
      - button "South ridge, Seat 2, 3 armies" [ref=e124] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: 2 · 3
      - button "Rock bay, Seat 1, 2 armies" [ref=e126] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: 1 · 2
      - button "North ford, Seat 2, 1 armies" [ref=e128] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: 2 · 1
      - button "Port ridge, Seat 1, 3 armies" [ref=e130] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: 1 · 3
      - button "New rock, Seat 2, 3 armies" [ref=e132] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: 2 · 3
      - button "South reach, Seat 2, 1 armies" [ref=e134] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: 2 · 1
        - generic [ref=e136]: ★
      - button "Silver point, Seat 1, 1 armies" [ref=e137] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: 1 · 1
      - button "East ford, Seat 1, 2 armies" [ref=e139] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: 1 · 2
      - button "Gold town, Seat 2, 2 armies" [ref=e141] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: 2 · 2
      - generic [ref=e173]: North Isle +3
      - generic [ref=e174]: East Isle +3
      - generic [ref=e175]: West Isle +3
      - generic [ref=e176]: South Isle +3
      - generic [ref=e177]: Central Isle +5
      - generic [ref=e178]: Harbor Isle +5
      - generic [ref=e179]: Palm Isle +6
      - generic [ref=e180]: Cliff Isle +5
      - generic [ref=e181]: Great Isle +9
    - complementary [ref=e182]:
      - generic [ref=e186]:
        - generic [ref=e187]: Seat 1's turn
        - generic [ref=e188]: Round 1 · Capture move-in
      - generic [ref=e189]:
        - button "End turn" [disabled] [ref=e191]
        - region "Battle controls" [ref=e192]:
          - heading "Battle" [level=2] [ref=e193]
          - generic [ref=e194]:
            - generic [ref=e195]:
              - generic [ref=e196]: From
              - strong [ref=e197]: North rest
              - generic "Source armies" [ref=e198]: "5"
            - generic [ref=e199]:
              - generic [ref=e200]: Target
              - strong [ref=e201]: River keep
              - generic "Target armies" [ref=e202]: "1"
          - generic [ref=e203]:
            - generic [ref=e204]:
              - text: Stop at armies
              - spinbutton "Stop at armies" [disabled] [ref=e205]: "1"
            - generic [ref=e206]:
              - text: Battle speed
              - combobox "Battle speed" [ref=e207]:
                - option "Slow"
                - option "Normal"
                - option "Fast" [selected]
          - paragraph [ref=e208]: This battle stops at 1 army, or on capture.
          - generic [ref=e209]:
            - button "Fight on" [disabled] [ref=e210]
            - button "Stop" [disabled] [ref=e211]
            - button "Single exchange" [disabled] [ref=e212]
          - generic [ref=e213]:
            - strong [ref=e214]: Target captured
            - paragraph [ref=e215]: Captured. Choose how many armies move in.
          - paragraph [ref=e216]:
            - text: Won 1 · Lost 3 · Ties
            - strong [ref=e217]: "2"
          - list "Latest exchange dice" [ref=e218]:
            - listitem [ref=e219]:
              - img "Attacker rolled 6" [ref=e220]: "6"
              - generic [ref=e221]: Attacker wins
              - img "Defender rolled 2" [ref=e222]: "2"
          - region "Capture move-in" [ref=e223]:
            - heading "Move armies into the capture" [level=3] [ref=e224]
            - paragraph [ref=e225]: Choose 1–5 total armies. Leave at least one behind.
            - generic [ref=e226]:
              - text: Armies to move
              - spinbutton "Armies to move" [ref=e227]: "5"
            - generic [ref=e228]:
              - button "Minimum" [ref=e229] [cursor=pointer]
              - button "Move one fewer army" [ref=e230] [cursor=pointer]: −
              - button "Move one more army" [ref=e231] [cursor=pointer]: +
              - button "Maximum" [ref=e232] [cursor=pointer]
            - button "Confirm move-in" [ref=e233] [cursor=pointer]
      - generic [ref=e234]:
        - heading "Battle log" [level=3] [ref=e235]
        - list "Battle log" [ref=e236]:
          - listitem [ref=e237]: "T1 Seat 1: North rest → River keep, took River keep"
          - listitem [ref=e238]: "T1 Seat 1: North rest → River keep, -1 / -0"
          - listitem [ref=e239]: "T1 Seat 1: North rest → River keep, -1 / -0"
          - listitem [ref=e240]: "T1 Seat 1: North rest → River keep, -1 / -0"
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import type { Page } from "@playwright/test";
  3  | import { fixture, map, step } from "./battle-fixture";
  4  | import { mkdirSync, mkdtempSync } from "node:fs";
  5  | import { join } from "node:path";
  6  | 
  7  | const country = (page: Page, id: string) => page.locator(`[data-country="${id}"]`);
  8  | async function ready(page: Page, kind: "manual" | "capture") {
  9  |   const f = fixture(kind);
  10 |   await page.clock.install(); await page.clock.pauseAt(new Date());
  11 |   await page.goto("/?view=reference-game");
  12 |   await page.getByLabel("Seed", { exact: true }).fill(String(f.seed));
  13 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  14 |   for (let n = 0; n < f.placements; n++) await country(page, f.from).click();
  15 |   await page.locator("#start-combat-button").click();
  16 |   await country(page, f.from).click(); await country(page, f.to).click();
  17 |   await page.locator("#battle-stop-threshold").fill("1");
  18 |   await page.locator("#battle-stop-threshold").press("Tab");
  19 |   await page.locator("#battle-speed").selectOption("fast");
  20 |   return f;
  21 | }
  22 | async function capture(page: Page, name: string, project: string) {
  23 |   const dir = process.env["BATTLE_EVIDENCE_DIR"] ?? "screenshots";
  24 |   mkdirSync(dir, { recursive: true });
  25 |   await page.screenshot({ path: join(mkdtempSync(join(dir, "accessibility-")), `${name}-${project}.png`) });
  26 | }
  27 | async function fits(page: Page, selectors: string[]) {
  28 |   const bounds = await page.locator(selectors.join(",")).evaluateAll(nodes => nodes.map(node => {
  29 |     const box = node.getBoundingClientRect();
  30 |     return { id: node.id, fits: box.width > 0 && box.height > 0 && box.left >= 0 && box.top >= 0 && box.right <= innerWidth && box.bottom <= innerHeight };
  31 |   }));
  32 |   expect(bounds).toHaveLength(selectors.length);
> 33 |   expect(bounds.filter(b => !b.fits)).toEqual([]);
     |                                       ^ Error: expect(received).toEqual(expected) // deep equality
  34 | }
  35 | 
  36 | test("capture confirmation, quantities and context fit together with an accurate phase", async ({ page }, info) => {
  37 |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  38 |   const f = await ready(page, "capture");
  39 |   await page.locator("#fight-on-button").click();
  40 |   let state = step(f.ready, { kind: "attack", from: f.from, to: f.to });
  41 |   while (state.phase === "attack") { await page.clock.runFor(200); state = step(state, { kind: "attack", from: f.from, to: f.to }); }
  42 |   await expect(page.locator("#turn-phase")).toHaveText("Capture move-in");
  43 |   await fits(page, ["#battle-source-name", "#battle-target-name", "#battle-status", "#fight-on-button", "#single-exchange-button", "#stop-battle-button", "#capture-amount", "#capture-minimum-button", "#capture-maximum-button", "#capture-less-button", "#capture-more-button", "#confirm-capture-button", "#new-game-button"]);
  44 |   await expect(page.getByLabel("Armies to move", { exact: true })).toHaveAttribute("min", "1");
  45 |   await expect(page.getByRole("button", { name: "Move one more army", exact: true })).toBeVisible();
  46 |   await capture(page, "capture-controls-fit", info.project.name);
  47 |   expect(errors).toEqual([]);
  48 | });
  49 | 
  50 | test("keyboard Stop retains focus across an exchange; new game cancels work and remembers preferences", async ({ page }, info) => {
  51 |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  52 |   const f = await ready(page, "manual");
  53 |   const oldEnd = await page.locator("#end-turn-button").elementHandle();
  54 |   await page.locator("#fight-on-button").click();
  55 |   await page.locator("#stop-battle-button").focus(); await page.clock.runFor(200);
  56 |   await expect(page.locator("#stop-battle-button")).toBeFocused();
  57 |   await page.keyboard.press("Enter");
  58 |   const count = f.ready.history.length + 2;
  59 |   await expect(page.getByRole("region", { name: "Battle controls", exact: true })).toHaveAttribute("data-history-count", String(count));
  60 |   await oldEnd!.evaluate(n => n.dispatchEvent(new MouseEvent("click", { bubbles: true })));
  61 |   await page.clock.runFor(2000);
  62 |   await expect(page.getByRole("region", { name: "Battle controls", exact: true })).toHaveAttribute("data-history-count", String(count));
  63 |   await capture(page, "keyboard-stop", info.project.name);
  64 |   await page.locator("#fight-on-button").click();
  65 |   await page.locator("#new-game-button").click();
  66 |   await expect(page.getByRole("heading", { name: "New reference game", exact: true })).toBeVisible();
  67 |   await page.clock.runFor(2000);
  68 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  69 |   for (const p of map.provinces) await expect(country(page, p.id)).toHaveAttribute("data-armies", String(f.start.armies[p.id]));
  70 |   await expect(page.locator("#battle-stop-threshold")).toHaveValue("1");
  71 |   await expect(page.locator("#battle-speed")).toHaveValue("fast");
  72 |   await page.clock.runFor(2000);
  73 |   for (const p of map.provinces) await expect(country(page, p.id)).toHaveAttribute("data-armies", String(f.start.armies[p.id]));
  74 |   expect(errors).toEqual([]);
  75 | });
  76 | 
```