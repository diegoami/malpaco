import { activePlayer, attackTargets, ownerOf, whyNot } from "../core";
import type { GameMap, GameState } from "../core";
import { BattleController } from "./battleController";
import type { BattleSpeed } from "./battleController";
import { BattleView } from "./battleView";
import { h } from "./dom";
import { Panel } from "./panel";
import { ReferenceMapView } from "./referenceMapView";

/** Session-only preferences. Full presentation persistence is T56. */
export interface BattlePreferences { threshold: number; speed: BattleSpeed }

/** Reference-route host: the controller owns every selection and ordinary action. */
export class ReferenceBattleGame {
  private readonly controller: BattleController;
  private readonly mapView: ReferenceMapView;
  private readonly panel: Panel;
  private readonly battle: BattleView;
  private hover: string | null = null;
  private mounted = false;
  private disposed = false;
  private readonly onKeyDown = (event: KeyboardEvent) => {
    if (event.key !== "Escape") return;
    if (!this.controller.stop()) this.controller.select(null, null);
  };

  constructor(private readonly map: GameMap, private readonly seed: number, private readonly onNewGame: () => void, state: GameState, preferences: BattlePreferences) {
    this.controller = new BattleController(state, {
      schedule: (callback, delay) => window.setTimeout(callback, delay), cancel: handle => window.clearTimeout(handle),
    }, view => {
      preferences.threshold = view.threshold;
      preferences.speed = view.speed;
      if (this.mounted && !this.disposed) this.render();
    });
    const threshold = preferences.threshold, speed = preferences.speed;
    this.controller.setThreshold(threshold);
    this.controller.setSpeed(speed);
    this.mapView = new ReferenceMapView(map, {
      onProvince: id => this.clickProvince(id),
      onBackground: () => { this.controller.select(null, null); },
      onHover: id => { this.hover = id; if (this.mounted && !this.disposed) this.renderMap(); },
    });
    this.panel = new Panel({
      onAttack: () => { this.controller.singleExchange(); },
      onStartCombat: () => { this.controller.dispatch({ kind: "endReinforcement" }); },
      onEndTurn: () => { this.controller.dispatch({ kind: "endTurn" }); },
      onNewGame: () => { if (!this.disposed) this.onNewGame(); },
    });
    this.battle = new BattleView(this.controller);
    this.panel.el.querySelector(".action")!.append(this.battle.el);
  }

  mount(root: HTMLElement): void {
    root.classList.add("battle-reference");
    root.replaceChildren(
      h("header", { class: "topbar" }, h("h1", {}, "Malpaco"), h("span", { class: "subtitle" }, `Nine Isles · ${this.controller.state.players.length} human seats · Seed ${this.seed}`)),
      h("main", { class: "stage" }, h("section", { class: "board" }, this.mapView.el), this.panel.el));
    document.body.dataset["ready"] = "true";
    window.addEventListener("keydown", this.onKeyDown);
    this.mounted = true;
    this.render();
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    this.controller.dispose();
    window.removeEventListener("keydown", this.onKeyDown);
  }

  private clickProvince(id: string): void {
    if (this.disposed) return;
    const { state, from, to } = this.controller.view;
    if (state.phase === "reinforce") {
      this.controller.dispatch({ kind: "reinforce", province: id, amount: 1 });
    } else if (ownerOf(state, id) === activePlayer(state)?.id) {
      this.controller.select(from === id && to === null ? null : id, null);
    } else if (from !== null) {
      this.controller.select(from, id);
    }
  }

  private renderMap(): void {
    const { state, from, to, running, paused } = this.controller.view;
    const blocked = running || paused || state.pendingCapture !== undefined || state.phase === "finished";
    this.mapView.render({ state, selected: from, target: to, targets: !blocked && from ? attackTargets(state, from) : [], hover: this.hover, flash: [] });
    // Countries remain reachable for inspection and refusal feedback; the pure
    // controller refuses selection during automation and a pending move-in.
    this.mapView.el.dataset["inputBlocked"] = String(blocked);
  }

  private render(): void {
    const { state, from, to, running, paused } = this.controller.view;
    this.renderMap();
    this.panel.render({ state, from, to, blocked: from && to ? whyNot(state, from, to) : "Choose a source and target.", seed: this.seed,
      hint: state.phase === "reinforce" ? state.reinforcementPool ? "Place your armies on your countries, then start combat." : "All armies placed. Start combat when ready." : "",
    });
    const action = this.panel.el.querySelector<HTMLElement>(".action")!;
    action.dataset["battle"] = String(state.phase !== "reinforce");
    this.panel.el.querySelector<HTMLButtonElement>("#end-turn-button")!.disabled = running || paused || state.phase === "capture" || state.phase === "reinforce" || state.phase === "finished";
    this.battle.render(this.controller.view);
  }
}
