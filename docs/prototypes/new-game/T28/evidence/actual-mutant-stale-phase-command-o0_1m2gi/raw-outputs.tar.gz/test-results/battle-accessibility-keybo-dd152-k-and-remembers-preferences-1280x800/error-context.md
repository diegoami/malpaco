# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: battle-accessibility.spec.ts >> keyboard Stop retains focus across an exchange; new game cancels work and remembers preferences
- Location: tests/e2e/battle-accessibility.spec.ts:50:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator: getByRole('region', { name: 'Battle controls', exact: true })
Expected: "10"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toHaveAttribute" getByRole('region', { name: 'Battle controls', exact: true }) with timeout 5000ms
  - waiting for getByRole('region', { name: 'Battle controls', exact: true })

```

```yaml
- banner:
  - heading "Malpaco" [level=1]
  - text: Nine Isles · 2 human seats · Seed 0 Seat 1 23 provinces · 51 armies Seat 2 23 provinces · 46 armies
  - contentinfo:
    - button "New game"
- main:
  - img "Nine Isles reference map":
    - button "River gate, Seat 1, 3 armies": River gate 1 · 3
    - button "New port, Seat 2, 2 armies": New port 2 · 2
    - button "North rest, Seat 1, 2 armies": North rest 1 · 2
    - button "River keep, Seat 2, 1 armies": River keep 2 · 1
    - button "North town, Seat 1, 2 armies": North town 1 · 2
    - button "Dark ford, Seat 1, 3 armies": Dark ford 1 · 3
    - button "Iron point, Seat 2, 2 armies": Iron point 2 · 2
    - button "South rest, Seat 2, 3 armies": South rest 2 · 3
    - button "High shore, Seat 1, 8 armies": High shore 1 · 8
    - button "Wind town, Seat 1, 3 armies": Wind town 1 · 3
    - button "New glen, Seat 1, 1 armies": New glen 1 · 1
    - button "Old rock, Seat 2, 1 armies": Old rock 2 · 1
    - button "Blue peak, Seat 2, 1 armies": Blue peak 2 · 1
    - button "West haven, Seat 1, 2 armies": West haven 1 · 2
    - button "Stone watch, Seat 2, 3 armies": Stone watch 2 · 3
    - button "Upper ridge, Seat 1, 2 armies": Upper ridge 1 · 2
    - button "Marsh keep, Seat 2, 2 armies": Marsh keep 2 · 2
    - button "New fell, Seat 1, 1 armies": New fell 1 · 1
    - button "Moon point, Seat 2, 2 armies": Moon point 2 · 2
    - button "South fell, Seat 2, 3 armies": South fell 2 · 3
    - button "High ridge, Seat 2, 1 armies": High ridge 2 · 1 ★
    - button "Bay ford, Seat 1, 3 armies": Bay ford 1 · 3
    - button "Low moor, Seat 2, 2 armies": Low moor 2 · 2
    - button "Lower field, Seat 1, 1 armies": Lower field 1 · 1
    - button "Wind gate, Seat 2, 2 armies": Wind gate 2 · 2
    - button "Silver shore, Seat 1, 2 armies": Silver shore 1 · 2
    - button "Low peak, Seat 1, 1 armies": Low peak 1 · 1
    - button "Wind port, Seat 2, 3 armies": Wind port 2 · 3
    - button "Gold point, Seat 2, 3 armies": Gold point 2 · 3
    - button "Rock moor, Seat 1, 1 armies": Rock moor 1 · 1
    - button "Marsh rest, Seat 1, 3 armies": Marsh rest 1 · 3 ★
    - button "Wind dale, Seat 1, 2 armies": Wind dale 1 · 2
    - button "Silver ford, Seat 1, 1 armies": Silver ford 1 · 1
    - button "Iron field, Seat 2, 3 armies": Iron field 2 · 3
    - button "North wood, Seat 2, 1 armies": North wood 2 · 1
    - button "Fort town, Seat 1, 2 armies": Fort town 1 · 2
    - button "Red field, Seat 2, 1 armies": Red field 2 · 1
    - button "South ridge, Seat 2, 3 armies": South ridge 2 · 3
    - button "Rock bay, Seat 1, 2 armies": Rock bay 1 · 2
    - button "North ford, Seat 2, 1 armies": North ford 2 · 1
    - button "Port ridge, Seat 1, 3 armies": Port ridge 1 · 3
    - button "New rock, Seat 2, 3 armies": New rock 2 · 3
    - button "South reach, Seat 2, 1 armies": South reach 2 · 1 ★
    - button "Silver point, Seat 1, 1 armies": Silver point 1 · 1
    - button "East ford, Seat 1, 2 armies": East ford 1 · 2
    - button "Gold town, Seat 2, 2 armies": Gold town 2 · 2
    - text: North Isle +3 East Isle +3 West Isle +3 South Isle +3 Central Isle +5 Harbor Isle +5 Palm Isle +6 Cliff Isle +5 Great Isle +9
  - complementary:
    - text: Seat 2's turn Round 1 · Reinforcement Province income
    - strong: "7"
    - text: Island income
    - strong: "0"
    - text: Armies to place
    - strong: "7"
    - paragraph: Place your armies on your countries, then start combat.
    - button "Start combat" [disabled]
    - button "End turn" [disabled]
    - heading "Battle log" [level=3]
    - list "Battle log":
      - listitem: T1 Seat 1 ends the turn
      - listitem: "T1 Seat 1: High shore → South rest, -1 / -0"
      - listitem: "T1 Seat 1: High shore → South rest, -1 / -0"
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import type { Page } from "@playwright/test";
  3  | import { fixture, map, step } from "./battle-fixture";
  4  | import { mkdirSync, mkdtempSync } from "node:fs";
  5  | import { join } from "node:path";
  6  | 
  7  | const country = (page: Page, id: string) => page.locator(`[data-country="${id}"]`);
  8  | async function ready(page: Page, kind: "manual" | "capture") {
  9  |   const f = fixture(kind);
  10 |   await page.clock.install(); await page.clock.pauseAt(new Date());
  11 |   await page.goto("/?view=reference-game");
  12 |   await page.getByLabel("Seed", { exact: true }).fill(String(f.seed));
  13 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  14 |   for (let n = 0; n < f.placements; n++) await country(page, f.from).click();
  15 |   await page.locator("#start-combat-button").click();
  16 |   await country(page, f.from).click(); await country(page, f.to).click();
  17 |   await page.locator("#battle-stop-threshold").fill("1");
  18 |   await page.locator("#battle-stop-threshold").press("Tab");
  19 |   await page.locator("#battle-speed").selectOption("fast");
  20 |   return f;
  21 | }
  22 | async function capture(page: Page, name: string, project: string) {
  23 |   const dir = process.env["BATTLE_EVIDENCE_DIR"] ?? "screenshots";
  24 |   mkdirSync(dir, { recursive: true });
  25 |   await page.screenshot({ path: join(mkdtempSync(join(dir, "accessibility-")), `${name}-${project}.png`) });
  26 | }
  27 | async function fits(page: Page, selectors: string[]) {
  28 |   const bounds = await page.locator(selectors.join(",")).evaluateAll(nodes => nodes.map(node => {
  29 |     const box = node.getBoundingClientRect();
  30 |     return { id: node.id, fits: box.width > 0 && box.height > 0 && box.left >= 0 && box.top >= 0 && box.right <= innerWidth && box.bottom <= innerHeight };
  31 |   }));
  32 |   expect(bounds).toHaveLength(selectors.length);
  33 |   expect(bounds.filter(b => !b.fits)).toEqual([]);
  34 | }
  35 | 
  36 | test("capture confirmation, quantities and context fit together with an accurate phase", async ({ page }, info) => {
  37 |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  38 |   const f = await ready(page, "capture");
  39 |   await page.locator("#fight-on-button").click();
  40 |   let state = step(f.ready, { kind: "attack", from: f.from, to: f.to });
  41 |   while (state.phase === "attack") { await page.clock.runFor(200); state = step(state, { kind: "attack", from: f.from, to: f.to }); }
  42 |   await expect(page.locator("#turn-phase")).toHaveText("Capture move-in");
  43 |   await fits(page, ["#battle-source-name", "#battle-target-name", "#battle-status", "#fight-on-button", "#single-exchange-button", "#stop-battle-button", "#capture-amount", "#capture-minimum-button", "#capture-maximum-button", "#capture-less-button", "#capture-more-button", "#confirm-capture-button", "#new-game-button"]);
  44 |   await expect(page.getByLabel("Armies to move", { exact: true })).toHaveAttribute("min", "1");
  45 |   await expect(page.getByRole("button", { name: "Move one more army", exact: true })).toBeVisible();
  46 |   await capture(page, "capture-controls-fit", info.project.name);
  47 |   expect(errors).toEqual([]);
  48 | });
  49 | 
  50 | test("keyboard Stop retains focus across an exchange; new game cancels work and remembers preferences", async ({ page }, info) => {
  51 |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  52 |   const f = await ready(page, "manual");
  53 |   const oldEnd = await page.locator("#end-turn-button").elementHandle();
  54 |   await page.locator("#fight-on-button").click();
  55 |   await page.locator("#stop-battle-button").focus(); await page.clock.runFor(200);
  56 |   await expect(page.locator("#stop-battle-button")).toBeFocused();
  57 |   await page.keyboard.press("Enter");
  58 |   const count = f.ready.history.length + 2;
  59 |   await expect(page.getByRole("region", { name: "Battle controls", exact: true })).toHaveAttribute("data-history-count", String(count));
  60 |   await oldEnd!.evaluate(n => n.dispatchEvent(new MouseEvent("click", { bubbles: true })));
  61 |   await page.clock.runFor(2000);
> 62 |   await expect(page.getByRole("region", { name: "Battle controls", exact: true })).toHaveAttribute("data-history-count", String(count));
     |                                                                                    ^ Error: expect(locator).toHaveAttribute(expected) failed
  63 |   await capture(page, "keyboard-stop", info.project.name);
  64 |   await page.locator("#fight-on-button").click();
  65 |   await page.locator("#new-game-button").click();
  66 |   await expect(page.getByRole("heading", { name: "New reference game", exact: true })).toBeVisible();
  67 |   await page.clock.runFor(2000);
  68 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  69 |   for (const p of map.provinces) await expect(country(page, p.id)).toHaveAttribute("data-armies", String(f.start.armies[p.id]));
  70 |   await expect(page.locator("#battle-stop-threshold")).toHaveValue("1");
  71 |   await expect(page.locator("#battle-speed")).toHaveValue("fast");
  72 |   await page.clock.runFor(2000);
  73 |   for (const p of map.provinces) await expect(country(page, p.id)).toHaveAttribute("data-armies", String(f.start.armies[p.id]));
  74 |   expect(errors).toEqual([]);
  75 | });
  76 | 
```