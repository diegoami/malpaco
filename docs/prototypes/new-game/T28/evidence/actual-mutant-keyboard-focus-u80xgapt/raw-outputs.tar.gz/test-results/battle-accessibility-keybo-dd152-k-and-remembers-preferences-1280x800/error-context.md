# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: battle-accessibility.spec.ts >> keyboard Stop retains focus across an exchange; new game cancels work and remembers preferences
- Location: tests/e2e/battle-accessibility.spec.ts:50:1

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  locator('#stop-battle-button')
Expected: focused
Received: inactive
Timeout:  5000ms

Call log:
  - Expect "toBeFocused" locator('#stop-battle-button') with timeout 5000ms
  - waiting for locator('#stop-battle-button')
    14 × locator resolved to <button class="" type="button" id="stop-battle-button">Stop</button>
       - unexpected value "inactive"

```

```yaml
- button "Stop"
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import type { Page } from "@playwright/test";
  3  | import { fixture, map, step } from "./battle-fixture";
  4  | import { mkdirSync, mkdtempSync } from "node:fs";
  5  | import { join } from "node:path";
  6  | 
  7  | const country = (page: Page, id: string) => page.locator(`[data-country="${id}"]`);
  8  | async function ready(page: Page, kind: "manual" | "capture") {
  9  |   const f = fixture(kind);
  10 |   await page.clock.install(); await page.clock.pauseAt(new Date());
  11 |   await page.goto("/?view=reference-game");
  12 |   await page.getByLabel("Seed", { exact: true }).fill(String(f.seed));
  13 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  14 |   for (let n = 0; n < f.placements; n++) await country(page, f.from).click();
  15 |   await page.locator("#start-combat-button").click();
  16 |   await country(page, f.from).click(); await country(page, f.to).click();
  17 |   await page.locator("#battle-stop-threshold").fill("1");
  18 |   await page.locator("#battle-stop-threshold").press("Tab");
  19 |   await page.locator("#battle-speed").selectOption("fast");
  20 |   return f;
  21 | }
  22 | async function capture(page: Page, name: string, project: string) {
  23 |   const dir = process.env["BATTLE_EVIDENCE_DIR"] ?? "screenshots";
  24 |   mkdirSync(dir, { recursive: true });
  25 |   await page.screenshot({ path: join(mkdtempSync(join(dir, "accessibility-")), `${name}-${project}.png`) });
  26 | }
  27 | async function fits(page: Page, selectors: string[]) {
  28 |   const bounds = await page.locator(selectors.join(",")).evaluateAll(nodes => nodes.map(node => {
  29 |     const box = node.getBoundingClientRect();
  30 |     return { id: node.id, fits: box.width > 0 && box.height > 0 && box.left >= 0 && box.top >= 0 && box.right <= innerWidth && box.bottom <= innerHeight };
  31 |   }));
  32 |   expect(bounds).toHaveLength(selectors.length);
  33 |   expect(bounds.filter(b => !b.fits)).toEqual([]);
  34 | }
  35 | 
  36 | test("capture confirmation, quantities and context fit together with an accurate phase", async ({ page }, info) => {
  37 |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  38 |   const f = await ready(page, "capture");
  39 |   await page.locator("#fight-on-button").click();
  40 |   let state = step(f.ready, { kind: "attack", from: f.from, to: f.to });
  41 |   while (state.phase === "attack") { await page.clock.runFor(200); state = step(state, { kind: "attack", from: f.from, to: f.to }); }
  42 |   await expect(page.locator("#turn-phase")).toHaveText("Capture move-in");
  43 |   await fits(page, ["#battle-source-name", "#battle-target-name", "#battle-status", "#fight-on-button", "#single-exchange-button", "#stop-battle-button", "#capture-amount", "#capture-minimum-button", "#capture-maximum-button", "#capture-less-button", "#capture-more-button", "#confirm-capture-button", "#new-game-button"]);
  44 |   await expect(page.getByLabel("Armies to move", { exact: true })).toHaveAttribute("min", "1");
  45 |   await expect(page.getByRole("button", { name: "Move one more army", exact: true })).toBeVisible();
  46 |   await capture(page, "capture-controls-fit", info.project.name);
  47 |   expect(errors).toEqual([]);
  48 | });
  49 | 
  50 | test("keyboard Stop retains focus across an exchange; new game cancels work and remembers preferences", async ({ page }, info) => {
  51 |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  52 |   const f = await ready(page, "manual");
  53 |   const oldEnd = await page.locator("#end-turn-button").elementHandle();
  54 |   await page.locator("#fight-on-button").click();
  55 |   await page.locator("#stop-battle-button").focus(); await page.clock.runFor(200);
> 56 |   await expect(page.locator("#stop-battle-button")).toBeFocused();
     |                                                     ^ Error: expect(locator).toBeFocused() failed
  57 |   await page.keyboard.press("Enter");
  58 |   const count = f.ready.history.length + 2;
  59 |   await expect(page.getByRole("region", { name: "Battle controls", exact: true })).toHaveAttribute("data-history-count", String(count));
  60 |   await oldEnd!.evaluate(n => n.dispatchEvent(new MouseEvent("click", { bubbles: true })));
  61 |   await page.clock.runFor(2000);
  62 |   await expect(page.getByRole("region", { name: "Battle controls", exact: true })).toHaveAttribute("data-history-count", String(count));
  63 |   await capture(page, "keyboard-stop", info.project.name);
  64 |   await page.locator("#fight-on-button").click();
  65 |   await page.locator("#new-game-button").click();
  66 |   await expect(page.getByRole("heading", { name: "New reference game", exact: true })).toBeVisible();
  67 |   await page.clock.runFor(2000);
  68 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  69 |   for (const p of map.provinces) await expect(country(page, p.id)).toHaveAttribute("data-armies", String(f.start.armies[p.id]));
  70 |   await expect(page.locator("#battle-stop-threshold")).toHaveValue("1");
  71 |   await expect(page.locator("#battle-speed")).toHaveValue("fast");
  72 |   await page.clock.runFor(2000);
  73 |   for (const p of map.provinces) await expect(country(page, p.id)).toHaveAttribute("data-armies", String(f.start.armies[p.id]));
  74 |   expect(errors).toEqual([]);
  75 | });
  76 | 
```