# T39 Raid targeting and automatic Shield defence

- **Kind**: feature
- **Issue**: #84 · **Branch**: `task/T39-raid-targeting-and-automatic-shield-defence` · **Merge after**: T38.
- **Difficulty**: Medium; estimate, not a model assignment.
- **Implementer**: owner-selected under rule 6; use an isolated worktree and record the choice before dispatch.
- **Reviewer**: owner-selected OpenCode model of another family under rule 6; record the choice before review.
- **Evidence**: [pinned variety design](https://github.com/diegoami/isle-wars-archaeology/blob/ae298e37c2f5177039e55767607f9345b6cb0e7a/design/variety.md), owner roadmap accepted 2026-10-15, and upstream task evidence. T23 resolves source anchors; new constants need citations or explicit [designed] provenance.
- **Owns**: src/core/**; tests/core/**; src/ui/gameEventLog.ts (mechanical raidTarget action label only); src/ui/panel.ts (mechanical public raid event formatter only; coordinate with T71); docs/prototypes/new-game/T39/**; docs/spike.md; append-only RUN-NOTES.md.
- **Scope**: Implement trading a Raid set with a chosen enemy country anywhere on the board. Replace its stack with a uniformly drawn integer from one to max(1,floor(stack/2)), retaining ownership and pool. A held Shield automatically cancels the raid and is discarded; traded cards are spent either way. Use an explicit pending target state and record only public information. Keep ordinary combat unchanged. Preserve the historical deck-v1/trade-v1 codecs and Raid refusal; enable the effect only under raid-v1/cards3/schema5. Declare the adjacent exhaustive raidTarget event-log label and public raid-event sidebar formatter under rule 12; reuse T71 history/scroller behavior unchanged. Protocol choices are [designed]: an unshielded raid consumes one bounded rules-RNG draw even for a one-army stack; a Shield cancellation consumes none and discards the first held Shield in hand order.
- **Done when**:
  1. `npx vitest run tests/core/raid-shield.test.ts` — remote targets, friendly/unknown refusals, odd/even/one-army bounds, no ownership change and Shield consumption use scripted draws and exact card counts.
  2. `npx vitest run tests/core/raid-shield-replay.test.ts` — target selection, cancellation and unshielded outcomes replay exactly; invalid targets leave all state and RNG unchanged.
  3. `npm test` and `npm run build` pass; affected pinned browser suites pass without weakening existing assertions. Retain measured outputs, screenshots where applicable, commands and hashes in the owned evidence path; report negative-before/positive-after checks and exact restoration.
- **Hazards**: Do not cap a large-stack raid or require adjacency. A Shield does not consume an unrelated card or reveal the rest of its hand. Main session preflights acceptance before dispatch; unresolved design conflicts stop implementation, never weaken a Done-when.
