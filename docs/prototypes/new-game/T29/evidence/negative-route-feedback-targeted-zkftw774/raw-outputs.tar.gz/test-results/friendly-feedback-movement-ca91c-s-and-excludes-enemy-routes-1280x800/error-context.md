# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: friendly-feedback.spec.ts >> movement route emphasis includes own sea neighbours and excludes enemy routes
- Location: tests/e2e/friendly-feedback.spec.ts:7:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 0
+ Received  + 1

  Array [
    "province_19|province_8",
+   "province_38|province_8",
  ]
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 2 human seats · Seed 0
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]: 23 provinces · 53 armies
      - generic [ref=e16]:
        - generic [ref=e17]: Seat 2
        - generic [ref=e18]: 23 provinces · 46 armies
    - contentinfo [ref=e19]:
      - button "New game" [ref=e20] [cursor=pointer]
  - main [ref=e21]:
    - img "Nine Isles reference map" [ref=e23]:
      - button "River gate, Seat 1, 3 armies" [ref=e48] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: 1 · 3
      - button "New port, Seat 2, 2 armies" [ref=e50] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: 2 · 2
      - button "North rest, Seat 1, 9 armies" [active] [pressed] [ref=e52] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: 1 · 9
      - button "River keep, Seat 2, 1 armies" [ref=e54] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: 2 · 1
      - button "North town, Seat 1, 2 armies" [ref=e56] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: 1 · 2
      - button "Dark ford, Seat 1, 3 armies" [ref=e58] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: 1 · 3
      - button "Iron point, Seat 2, 2 armies" [ref=e60] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: 2 · 2
      - button "South rest, Seat 2, 3 armies" [ref=e62] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: 2 · 3
      - button "High shore, Seat 1, 3 armies" [ref=e64] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: 1 · 3
      - button "Wind town, Seat 1, 3 armies" [ref=e66] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: 1 · 3
      - button "New glen, Seat 1, 1 armies" [ref=e68] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: 1 · 1
      - button "Old rock, Seat 2, 1 armies" [ref=e70] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: 2 · 1
      - button "Blue peak, Seat 2, 1 armies" [ref=e72] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: 2 · 1
      - button "West haven, Seat 1, 2 armies" [ref=e74] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: 1 · 2
      - button "Stone watch, Seat 2, 3 armies" [ref=e76] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: 2 · 3
      - button "Upper ridge, Seat 1, 2 armies" [ref=e78] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: 1 · 2
      - button "Marsh keep, Seat 2, 2 armies" [ref=e80] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: 2 · 2
      - button "New fell, Seat 1, 1 armies" [ref=e82] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: 1 · 1
      - button "Moon point, Seat 2, 2 armies" [ref=e84] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: 2 · 2
      - button "South fell, Seat 2, 3 armies" [ref=e86] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: 2 · 3
      - button "High ridge, Seat 2, 1 armies" [ref=e88] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: 2 · 1
        - generic [ref=e90]: ★
      - button "Bay ford, Seat 1, 3 armies" [ref=e91] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: 1 · 3
      - button "Low moor, Seat 2, 2 armies" [ref=e93] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: 2 · 2
      - button "Lower field, Seat 1, 1 armies" [ref=e95] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: 1 · 1
      - button "Wind gate, Seat 2, 2 armies" [ref=e97] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: 2 · 2
      - button "Silver shore, Seat 1, 2 armies" [ref=e99] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: 1 · 2
      - button "Low peak, Seat 1, 1 armies" [ref=e101] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: 1 · 1
      - button "Wind port, Seat 2, 3 armies" [ref=e103] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: 2 · 3
      - button "Gold point, Seat 2, 3 armies" [ref=e105] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: 2 · 3
      - button "Rock moor, Seat 1, 1 armies" [ref=e107] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: 1 · 1
      - button "Marsh rest, Seat 1, 3 armies" [ref=e109] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: 1 · 3
        - generic [ref=e111]: ★
      - button "Wind dale, Seat 1, 2 armies" [ref=e112] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: 1 · 2
      - button "Silver ford, Seat 1, 1 armies" [ref=e114] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: 1 · 1
      - button "Iron field, Seat 2, 3 armies" [ref=e116] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: 2 · 3
      - button "North wood, Seat 2, 1 armies" [ref=e118] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: 2 · 1
      - button "Fort town, Seat 1, 2 armies" [ref=e120] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: 1 · 2
      - button "Red field, Seat 2, 1 armies" [ref=e122] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: 2 · 1
      - button "South ridge, Seat 2, 3 armies" [ref=e124] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: 2 · 3
      - button "Rock bay, Seat 1, 2 armies" [ref=e126] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: 1 · 2
      - button "North ford, Seat 2, 1 armies" [ref=e128] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: 2 · 1
      - button "Port ridge, Seat 1, 3 armies" [ref=e130] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: 1 · 3
      - button "New rock, Seat 2, 3 armies" [ref=e132] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: 2 · 3
      - button "South reach, Seat 2, 1 armies" [ref=e134] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: 2 · 1
        - generic [ref=e136]: ★
      - button "Silver point, Seat 1, 1 armies" [ref=e137] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: 1 · 1
      - button "East ford, Seat 1, 2 armies" [ref=e139] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: 1 · 2
      - button "Gold town, Seat 2, 2 armies" [ref=e141] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: 2 · 2
      - generic [ref=e173]: North Isle +3
      - generic [ref=e174]: East Isle +3
      - generic [ref=e175]: West Isle +3
      - generic [ref=e176]: South Isle +3
      - generic [ref=e177]: Central Isle +5
      - generic [ref=e178]: Harbor Isle +5
      - generic [ref=e179]: Palm Isle +6
      - generic [ref=e180]: Cliff Isle +5
      - generic [ref=e181]: Great Isle +9
    - complementary [ref=e182]:
      - generic [ref=e186]:
        - generic [ref=e187]: Seat 1's turn
        - generic [ref=e188]: Round 1 · Friendly move
      - region "Friendly move" [ref=e190]:
        - heading "Friendly move" [level=2] [ref=e191]
        - generic [ref=e192]:
          - generic [ref=e193]:
            - generic [ref=e194]: From
            - strong [ref=e195]: North rest
            - generic [ref=e196]: "9"
          - generic [ref=e197]:
            - generic [ref=e198]: To
            - strong [ref=e199]: Choose an owned neighbour
            - generic [ref=e200]: —
        - paragraph [ref=e201]: Move 1–8 armies. Leave at least one behind. This ends your turn.
        - generic [ref=e202]:
          - text: Armies to move
          - spinbutton "Armies to move" [disabled] [ref=e203]: "8"
        - generic [ref=e204]:
          - button "Minimum" [disabled] [ref=e205]
          - button "Move one fewer army" [disabled] [ref=e206]: −
          - button "Move one more army" [disabled] [ref=e207]: +
          - button "Maximum" [disabled] [ref=e208]
        - button "Move and end turn" [disabled] [ref=e209]
        - generic [ref=e210]:
          - button "Cancel · back to attacks" [ref=e211] [cursor=pointer]
          - button "Skip move · end turn" [ref=e212] [cursor=pointer]
      - generic [ref=e213]:
        - heading "Battle log" [level=3] [ref=e214]
        - list "Battle log"
```

# Test source

```ts
  1  | import {test,expect} from "@playwright/test";
  2  | import type {Page} from "@playwright/test";
  3  | import {fixture,seaFixture,map,targets} from "./friendly-fixture";
  4  | const country=(page:Page,id:string)=>page.locator(`[data-country="${id}"]`);
  5  | async function ready(page:Page,mixed=false){const f=mixed?seaFixture():fixture();await page.goto("/?view=reference-game");await page.getByLabel("Seed",{exact:true}).fill(String(f.seed));await page.getByLabel("Human seats").selectOption("2");await page.getByRole("button",{name:"Start game",exact:true}).click();for(let n=0;n<f.placements;n++)await country(page,f.from).click();await page.locator("#start-combat-button").click();return f;}
  6  | 
  7  | test("movement route emphasis includes own sea neighbours and excludes enemy routes",async({page})=>{
  8  |  const f=await ready(page,true),source=map.provinces.find(p=>p.id===f.from)!;
  9  |  const legal=targets(f.ready,f.from),ownSea=source.seaLanes.filter(id=>legal.includes(id)),enemySea=source.seaLanes.filter(id=>!legal.includes(id));
  10 |  expect(ownSea.length).toBeGreaterThan(0);expect(enemySea.length).toBeGreaterThan(0);
  11 |  await page.locator("#start-friendly-move-button").click();await country(page,f.from).click();
  12 |  const active=await page.locator("#reference-map .lane.active").evaluateAll(ns=>ns.map(n=>n.getAttribute("data-edge")!.split("|").sort().join("|")).sort());
> 13 |  expect(active).toEqual(ownSea.map(id=>[f.from,id].sort().join("|")).sort());
     |                 ^ Error: expect(received).toEqual(expected) // deep equality
  14 | });
  15 | 
  16 | test("Escape cancels a move draft and restores the previous battle selection",async({page})=>{
  17 |  const f=await ready(page),source=map.provinces.find(p=>p.id===f.from)!,enemy=[...source.borders,...source.seaLanes].find(id=>f.ready.ownerOf[id]!==f.ready.ownerOf[f.from])!;expect(enemy).toBeTruthy();
  18 |  await country(page,f.from).click();await country(page,enemy).click();const sourceName=await page.locator("#battle-source-name").textContent(),targetName=await page.locator("#battle-target-name").textContent();
  19 |  await page.locator("#start-friendly-move-button").click();await country(page,f.from).click();await country(page,f.to).click();await page.keyboard.press("Escape");
  20 |  await expect(page.getByRole("region",{name:"Friendly move",exact:true})).toBeHidden();await expect(page.getByRole("region",{name:"Battle controls",exact:true})).toHaveAttribute("data-history-count",String(f.ready.history.length));await expect(page.locator("#battle-source-name")).toHaveText(sourceName!);await expect(page.locator("#battle-target-name")).toHaveText(targetName!);
  21 |  for(const p of map.provinces)await expect(country(page,p.id)).toHaveAttribute("data-armies",String(f.ready.armies[p.id]));
  22 | });
  23 | 
```