# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: friendly-move.spec.ts >> a just-captured country can supply the final friendly move
- Location: tests/e2e/friendly-move.spec.ts:33:1

# Error details

```
Error: expect(locator).toBeDisabled() failed

Locator: locator('#start-friendly-move-button')
Expected: disabled
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeDisabled" locator('#start-friendly-move-button') with timeout 5000ms
  - waiting for locator('#start-friendly-move-button')

```

```yaml
- banner:
  - heading "Malpaco" [level=1]
  - text: Nine Isles · 2 human seats · Seed 0 Seat 1 24 provinces · 50 armies Seat 2 22 provinces · 45 armies
  - contentinfo:
    - button "New game"
- main:
  - img "Nine Isles reference map":
    - button "River gate, Seat 1, 3 armies": River gate 1 · 3
    - button "New port, Seat 2, 2 armies": New port 2 · 2
    - button "North rest, Seat 1, 5 armies" [pressed]: North rest 1 · 5
    - button "River keep, Seat 1, 1 armies": River keep 1 · 1
    - button "North town, Seat 1, 2 armies": North town 1 · 2
    - button "Dark ford, Seat 1, 3 armies": Dark ford 1 · 3
    - button "Iron point, Seat 2, 2 armies": Iron point 2 · 2
    - button "South rest, Seat 2, 3 armies": South rest 2 · 3
    - button "High shore, Seat 1, 3 armies": High shore 1 · 3
    - button "Wind town, Seat 1, 3 armies": Wind town 1 · 3
    - button "New glen, Seat 1, 1 armies": New glen 1 · 1
    - button "Old rock, Seat 2, 1 armies": Old rock 2 · 1
    - button "Blue peak, Seat 2, 1 armies": Blue peak 2 · 1
    - button "West haven, Seat 1, 2 armies": West haven 1 · 2
    - button "Stone watch, Seat 2, 3 armies": Stone watch 2 · 3
    - button "Upper ridge, Seat 1, 2 armies": Upper ridge 1 · 2
    - button "Marsh keep, Seat 2, 2 armies": Marsh keep 2 · 2
    - button "New fell, Seat 1, 1 armies": New fell 1 · 1
    - button "Moon point, Seat 2, 2 armies": Moon point 2 · 2
    - button "South fell, Seat 2, 3 armies": South fell 2 · 3
    - button "High ridge, Seat 2, 1 armies": High ridge 2 · 1 ★
    - button "Bay ford, Seat 1, 3 armies": Bay ford 1 · 3
    - button "Low moor, Seat 2, 2 armies": Low moor 2 · 2
    - button "Lower field, Seat 1, 1 armies": Lower field 1 · 1
    - button "Wind gate, Seat 2, 2 armies": Wind gate 2 · 2
    - button "Silver shore, Seat 1, 2 armies": Silver shore 1 · 2
    - button "Low peak, Seat 1, 1 armies": Low peak 1 · 1
    - button "Wind port, Seat 2, 3 armies": Wind port 2 · 3
    - button "Gold point, Seat 2, 3 armies": Gold point 2 · 3
    - button "Rock moor, Seat 1, 1 armies": Rock moor 1 · 1
    - button "Marsh rest, Seat 1, 3 armies": Marsh rest 1 · 3 ★
    - button "Wind dale, Seat 1, 2 armies": Wind dale 1 · 2
    - button "Silver ford, Seat 1, 1 armies": Silver ford 1 · 1
    - button "Iron field, Seat 2, 3 armies": Iron field 2 · 3
    - button "North wood, Seat 2, 1 armies": North wood 2 · 1
    - button "Fort town, Seat 1, 2 armies": Fort town 1 · 2
    - button "Red field, Seat 2, 1 armies": Red field 2 · 1
    - button "South ridge, Seat 2, 3 armies": South ridge 2 · 3
    - button "Rock bay, Seat 1, 2 armies": Rock bay 1 · 2
    - button "North ford, Seat 2, 1 armies": North ford 2 · 1
    - button "Port ridge, Seat 1, 3 armies": Port ridge 1 · 3
    - button "New rock, Seat 2, 3 armies": New rock 2 · 3
    - button "South reach, Seat 2, 1 armies": South reach 2 · 1 ★
    - button "Silver point, Seat 1, 1 armies": Silver point 1 · 1
    - button "East ford, Seat 1, 2 armies": East ford 1 · 2
    - button "Gold town, Seat 2, 2 armies": Gold town 2 · 2
    - text: North Isle +3 East Isle +3 West Isle +3 South Isle +3 Central Isle +5 Harbor Isle +5 Palm Isle +6 Cliff Isle +5 Great Isle +9
  - complementary:
    - text: Seat 1's turn Round 1 · Capture move-in
    - button "End turn" [disabled]
    - region "Battle controls":
      - heading "Battle" [level=2]
      - text: From
      - strong: North rest
      - text: 5 Target
      - strong: River keep
      - text: 1 Stop at armies
      - spinbutton "Stop at armies" [disabled]: "2"
      - text: Battle speed
      - combobox "Battle speed":
        - option "Slow"
        - option "Normal" [selected]
        - option "Fast"
      - paragraph: This battle stops at 2 armies, or on capture.
      - button "Fight on" [disabled]
      - button "Stop" [disabled]
      - button "Single exchange" [disabled]
      - strong: Target captured
      - paragraph: Captured. Choose how many armies move in.
      - paragraph:
        - text: Won 1 · Lost 3 · Ties
        - strong: "2"
      - list "Latest exchange dice":
        - listitem:
          - img "Attacker rolled 6": "6"
          - text: Attacker wins
          - img "Defender rolled 2": "2"
      - region "Capture move-in":
        - heading "Move armies into the capture" [level=3]
        - paragraph: Choose 1–5 total armies. Leave at least one behind.
        - text: Armies to move
        - spinbutton "Armies to move": "5"
        - button "Minimum"
        - button "Move one fewer army": −
        - button "Move one more army": +
        - button "Maximum"
        - button "Confirm move-in"
    - heading "Battle log" [level=3]
    - list "Battle log":
      - listitem: "T1 Seat 1: North rest → River keep, took River keep"
      - listitem: "T1 Seat 1: North rest → River keep, -1 / -0"
      - listitem: "T1 Seat 1: North rest → River keep, -1 / -0"
      - listitem: "T1 Seat 1: North rest → River keep, -1 / -0"
```

# Test source

```ts
  1  | import {test,expect} from "@playwright/test";
  2  | import type {Page} from "@playwright/test";
  3  | import type {GameState} from "../../src/core";
  4  | import {reinforcementIncome} from "../../src/core";
  5  | import {fixture,map,step,targets} from "./friendly-fixture";
  6  | import {mkdirSync,mkdtempSync} from "node:fs";
  7  | import {join} from "node:path";
  8  | const country=(page:Page,id:string)=>page.locator(`[data-country="${id}"]`);
  9  | async function paint(page:Page,s:GameState){for(const p of map.provinces){await expect(country(page,p.id)).toHaveAttribute("data-owner",s.ownerOf[p.id]!);await expect(country(page,p.id)).toHaveAttribute("data-armies",String(s.armies[p.id]));}}
  10 | async function prepare(page:Page,capture=false){const f=fixture(capture);await page.goto("/?view=reference-game");await page.getByLabel("Seed",{exact:true}).fill(String(f.seed));await page.getByLabel("Human seats").selectOption("2");await page.getByRole("button",{name:"Start game",exact:true}).click();for(let n=0;n<f.placements;n++)await country(page,f.from).click();await page.locator("#start-combat-button").click();await paint(page,f.ready);return f;}
  11 | async function screenshot(page:Page,label:string,project:string){const root=process.env["FRIENDLY_EVIDENCE_DIR"]??"screenshots";mkdirSync(root,{recursive:true});await page.screenshot({path:join(mkdtempSync(join(root,"friendly-")),`${label}-${project}.png`)});}
  12 | async function begin(page:Page){await expect(page.locator("#start-friendly-move-button")).toBeVisible();await page.locator("#start-friendly-move-button").click();await expect(page.getByRole("region",{name:"Friendly move",exact:true})).toBeVisible();}
  13 | async function select(page:Page,s:GameState,from:string,to:string){
  14 |  await country(page,from).click();expect((await page.locator('[data-country][data-target="true"]').evaluateAll(ns=>ns.map(n=>n.getAttribute("data-country")))).sort()).toEqual(targets(s,from).sort());
  15 |  for(const id of targets(s,from))await expect(country(page,id)).toHaveClass(/neighbor/);
  16 |  await country(page,to).click();await expect(page.locator("#friendly-move-amount")).toHaveValue(String(s.armies[from]!-1));await expect(page.locator("#friendly-move-amount")).toHaveAttribute("min","1");await expect(page.locator("#friendly-move-amount")).toHaveAttribute("max",String(s.armies[from]!-1));
  17 | }
  18 | async function handoff(page:Page,s:GameState){await paint(page,s);await expect(page.locator("#turn-title")).toHaveText(`${s.players[s.currentPlayer]!.name}'s turn`);await expect(page.locator("#reinforcement-pool")).toHaveText(String(reinforcementIncome(s,s.players[s.currentPlayer]!.id).total));await expect(page.locator("#confirm-friendly-move-button")).toHaveCount(0);}
  19 | for(const amount of ["minimum","maximum"] as const)test(`friendly ${amount} transfer ends turn, fits and refuses stale confirmation`,async({page},info)=>{
  20 |  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));const f=await prepare(page);await begin(page);await select(page,f.ready,f.from,f.to);
  21 |  await page.locator("#friendly-move-amount").fill("0");await page.locator("#confirm-friendly-move-button").click();await paint(page,f.ready);
  22 |  await page.locator("#friendly-move-minimum-button").click();await expect(page.locator("#friendly-move-amount")).toHaveValue("1");await page.locator("#friendly-move-more-button").click();await expect(page.locator("#friendly-move-amount")).toHaveValue("2");await page.locator("#friendly-move-less-button").click();await expect(page.locator("#friendly-move-amount")).toHaveValue("1");
  23 |  if(amount==="maximum")await page.locator("#friendly-move-maximum-button").click();
  24 |  const n=amount==="minimum"?1:f.ready.armies[f.from]!-1;await expect(page.locator("#friendly-move-amount")).toHaveValue(String(n));
  25 |  const fits=await page.locator('#friendly-move-amount,#confirm-friendly-move-button,#cancel-friendly-move-button,#skip-friendly-move-button').evaluateAll(ns=>ns.every(n=>{const b=n.getBoundingClientRect();return b.width>0&&b.height>0&&b.left>=0&&b.top>=0&&b.right<=innerWidth&&b.bottom<=innerHeight;}));expect(fits).toBe(true);
  26 |  await expect(page.locator("#confirm-friendly-move-button")).toContainText(/end.*turn/i);await screenshot(page,`choose-${amount}`,info.project.name);
  27 |  const stale=await page.locator("#confirm-friendly-move-button").elementHandle();await page.locator("#confirm-friendly-move-button").click();const done=step(f.ready,{kind:"friendlyMove",from:f.from,to:f.to,amount:n});await handoff(page,done);await stale!.evaluate(n=>n.dispatchEvent(new MouseEvent("click",{bubbles:true})));await handoff(page,done);await screenshot(page,`done-${amount}`,info.project.name);expect(errors).toEqual([]);
  28 | });
  29 | test("cancel returns to attacks without movement; skip hands off normally",async({page},info)=>{
  30 |  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));const f=await prepare(page);await begin(page);await select(page,f.ready,f.from,f.to);const stale=await page.locator("#confirm-friendly-move-button").elementHandle();await page.locator("#cancel-friendly-move-button").click();await expect(page.locator("#start-friendly-move-button")).toBeVisible();await stale!.evaluate(n=>n.dispatchEvent(new MouseEvent("click",{bubbles:true})));await paint(page,f.ready);await expect(page.getByRole("region",{name:"Battle controls",exact:true})).toHaveAttribute("data-history-count",String(f.ready.history.length));
  31 |  await begin(page);await page.locator("#skip-friendly-move-button").click();await handoff(page,step(f.ready,{kind:"endTurn"}));await screenshot(page,"skipped",info.project.name);expect(errors).toEqual([]);
  32 | });
  33 | test("a just-captured country can supply the final friendly move",async({page},info)=>{
> 34 |  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));const f=await prepare(page,true);let state=f.ready;await country(page,f.from).click();await country(page,f.to).click();for(let n=0;n<128&&state.phase==="attack";n++){await page.locator("#single-exchange-button").click();state=step(state,{kind:"attack",from:f.from,to:f.to});}expect(state.phase).toBe("capture");await expect(page.locator("#start-friendly-move-button")).toBeDisabled();await page.locator("#confirm-capture-button").click();state=step(state,{kind:"captureMove",amount:state.pendingCapture!.max});await begin(page);await select(page,state,f.to,f.from);await page.locator("#friendly-move-minimum-button").click();await screenshot(page,"captured-source",info.project.name);await page.locator("#confirm-friendly-move-button").click();await handoff(page,step(state,{kind:"friendlyMove",from:f.to,to:f.from,amount:1}));expect(errors).toEqual([]);
     |                                                                                                                                                                                                                                                                                                                                                                                                                                                           ^ Error: expect(locator).toBeDisabled() failed
  35 | });
  36 | 
```