# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: friendly-feedback.spec.ts >> Escape cancels a move draft and restores the previous battle selection
- Location: tests/e2e/friendly-feedback.spec.ts:16:1

# Error details

```
Error: expect(locator).toBeHidden() failed

Locator:  getByRole('region', { name: 'Friendly move', exact: true })
Expected: hidden
Received: visible
Timeout:  5000ms

Call log:
  - Expect "toBeHidden" getByRole('region', { name: 'Friendly move', exact: true }) with timeout 5000ms
  - waiting for getByRole('region', { name: 'Friendly move', exact: true })
    14 × locator resolved to <section role="region" aria-label="Friendly move" class="battle-controls friendly-move-controls">…</section>
       - unexpected value "visible"

```

```yaml
- region "Friendly move":
  - heading "Friendly move" [level=2]
  - text: From
  - strong: Choose a marked country
  - text: — To
  - strong: Choose an owned neighbour
  - text: —
  - paragraph: Marked countries can supply armies. Choose one, then an owned neighbour.
  - text: Armies to move
  - spinbutton "Armies to move" [disabled]: "1"
  - button "Minimum" [disabled]
  - button "Move one fewer army" [disabled]: −
  - button "Move one more army" [disabled]: +
  - button "Maximum" [disabled]
  - button "Move and end turn" [disabled]
  - button "Cancel · back to attacks"
  - button "Skip move · end turn"
```

# Test source

```ts
  1  | import {test,expect} from "@playwright/test";
  2  | import type {Page} from "@playwright/test";
  3  | import {fixture,seaFixture,map,targets} from "./friendly-fixture";
  4  | const country=(page:Page,id:string)=>page.locator(`[data-country="${id}"]`);
  5  | async function ready(page:Page,mixed=false){const f=mixed?seaFixture():fixture();await page.goto("/?view=reference-game");await page.getByLabel("Seed",{exact:true}).fill(String(f.seed));await page.getByLabel("Human seats").selectOption("2");await page.getByRole("button",{name:"Start game",exact:true}).click();for(let n=0;n<f.placements;n++)await country(page,f.from).click();await page.locator("#start-combat-button").click();return f;}
  6  | 
  7  | test("movement route emphasis includes own sea neighbours and excludes enemy routes",async({page})=>{
  8  |  const f=await ready(page,true),source=map.provinces.find(p=>p.id===f.from)!;
  9  |  const legal=targets(f.ready,f.from),ownSea=source.seaLanes.filter(id=>legal.includes(id)),enemySea=source.seaLanes.filter(id=>!legal.includes(id));
  10 |  expect(ownSea.length).toBeGreaterThan(0);expect(enemySea.length).toBeGreaterThan(0);
  11 |  await page.locator("#start-friendly-move-button").click();await country(page,f.from).click();
  12 |  const active=await page.locator("#reference-map .lane.active").evaluateAll(ns=>ns.map(n=>n.getAttribute("data-edge")!.split("|").sort().join("|")).sort());
  13 |  expect(active).toEqual(ownSea.map(id=>[f.from,id].sort().join("|")).sort());
  14 | });
  15 | 
  16 | test("Escape cancels a move draft and restores the previous battle selection",async({page})=>{
  17 |  const f=await ready(page),source=map.provinces.find(p=>p.id===f.from)!,enemy=[...source.borders,...source.seaLanes].find(id=>f.ready.ownerOf[id]!==f.ready.ownerOf[f.from])!;expect(enemy).toBeTruthy();
  18 |  await country(page,f.from).click();await country(page,enemy).click();const sourceName=await page.locator("#battle-source-name").textContent(),targetName=await page.locator("#battle-target-name").textContent();
  19 |  await page.locator("#start-friendly-move-button").click();await country(page,f.from).click();await country(page,f.to).click();await page.keyboard.press("Escape");
> 20 |  await expect(page.getByRole("region",{name:"Friendly move",exact:true})).toBeHidden();await expect(page.getByRole("region",{name:"Battle controls",exact:true})).toHaveAttribute("data-history-count",String(f.ready.history.length));await expect(page.locator("#battle-source-name")).toHaveText(sourceName!);await expect(page.locator("#battle-target-name")).toHaveText(targetName!);
     |                                                                           ^ Error: expect(locator).toBeHidden() failed
  21 |  for(const p of map.provinces)await expect(country(page,p.id)).toHaveAttribute("data-armies",String(f.ready.armies[p.id]));
  22 | });
  23 | 
```