// Disposable parent feasibility mock. Archived and removed before implementation.
export function installFriendlyMock(host: any): void {
 const c=host.controller;
 let moving=false,from:string|null=null,to:string|null=null,epoch=0;
 const el=document.createElement("section");el.className="battle-controls";el.setAttribute("role","region");el.setAttribute("aria-label","Friendly move");host.panel.el.querySelector(".action").append(el);
 const targets=(id:string)=>{const s=c.state,p=s.map.provinces.find((p:any)=>p.id===id);return s.armies[id]>1&&s.ownerOf[id]===s.players[s.currentPlayer].id?p?[...p.borders,...p.seaLanes].filter((q:string)=>s.ownerOf[q]===s.players[s.currentPlayer].id):[]:[];};
 const oldClick=host.clickProvince.bind(host);host.clickProvince=(id:string)=>{if(!moving){oldClick(id);return;}if(from&&targets(from).includes(id))to=id;else if(targets(id).length){from=id;to=null;}host.render();};
 const oldRender=host.render.bind(host);
 host.render=()=>{
  oldRender();epoch++;
  const s=c.state;
  const start=document.createElement("button");start.type="button";start.id="start-friendly-move-button";start.textContent="Move armies";start.disabled=s.phase!=="attack"||c.view.running||c.view.paused;
  start.onclick=()=>{if(start.disabled)return;moving=true;from=to=null;host.render();};host.phaseActions.append(start);
  host.phaseActions.style.display=moving?"none":"";host.battle.el.hidden=moving||host.battle.el.hidden;el.hidden=!moving;
  if(!moving){el.replaceChildren();return;}
  const token=epoch,max=from?s.armies[from]-1:1;
  host.mapView.render({state:s,selected:from,target:to,targets:from?targets(from):s.map.provinces.filter((p:any)=>targets(p.id).length>0).map((p:any)=>p.id),hover:null,flash:[]});
  el.innerHTML='<h2 class="battle-title">Friendly move</h2><p>Choose an owned neighbour. The move ends the turn.</p><p>'+String(from??"Choose source")+' → '+String(to??"Choose target")+'</p><label>Armies <input id="friendly-move-amount" type="number" min="1" max="'+max+'" value="'+max+'" style="width:100px"></label><div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin:8px 0"><button type="button" id="friendly-move-minimum-button">Minimum</button><button type="button" id="friendly-move-maximum-button">Maximum</button><button type="button" id="friendly-move-less-button">−</button><button type="button" id="friendly-move-more-button">+</button></div><button type="button" id="confirm-friendly-move-button">Move and end turn</button><button type="button" id="cancel-friendly-move-button">Cancel</button><button type="button" id="skip-friendly-move-button">Skip move</button>';
  const amount=el.querySelector<HTMLInputElement>("#friendly-move-amount")!;
  const on=(id:string,fn:()=>void)=>{el.querySelector<HTMLButtonElement>("#"+id)!.onclick=()=>{if(moving&&token===epoch)fn();};};
  on("friendly-move-minimum-button",()=>{amount.value="1";});on("friendly-move-maximum-button",()=>{amount.value=String(max);});on("friendly-move-less-button",()=>{amount.value=String(Math.max(1,amount.valueAsNumber-1));});on("friendly-move-more-button",()=>{amount.value=String(Math.min(max,amount.valueAsNumber+1));});
  on("cancel-friendly-move-button",()=>{moving=false;host.render();});on("skip-friendly-move-button",()=>{moving=false;c.dispatch({kind:"endTurn"});host.render();});
  on("confirm-friendly-move-button",()=>{const n=amount.valueAsNumber;if(!from||!to||!Number.isSafeInteger(n)||n<1||n>max)return;moving=false;c.dispatch({kind:"friendlyMove",from,to,amount:n});host.render();});
 };
}
