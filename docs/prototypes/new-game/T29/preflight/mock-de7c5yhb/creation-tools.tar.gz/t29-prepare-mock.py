from pathlib import Path
import tarfile,tempfile,hashlib,json
repo=Path('/home/diego/projects/malpaco/.cache/t29-work');root=repo/'docs/prototypes/new-game/T29'
paths=['src/core/types.ts','src/core/state.ts','src/core/rules.ts','src/core/index.ts','src/ui/referenceGame.ts','src/ui/referenceBattleGame.ts','src/ui/__t29_mock.ts']
out=Path(tempfile.mkdtemp(prefix='mock-',dir=root/'preflight'));original={p:(repo/p).read_bytes() if (repo/p).exists() else None for p in paths}
with tarfile.open(out/'original-sources.tar.gz','w:gz') as a:
 for p,b in original.items():
  if b is not None:a.add(repo/p,arcname=p)
(out/'original-manifest.json').write_text(json.dumps({p:hashlib.sha256(b).hexdigest() if b is not None else None for p,b in original.items()},indent=2)+'\n')
Path('/tmp/t29-active-mock-dir').write_text(str(out))
try:
 p=repo/paths[0];s=p.read_text().replace('  readonly id: string;\n  /** [designed] T11','  readonly id: string;\n  readonly movement?: "adjacent";\n  /** [designed] T11').replace('  | { readonly kind: "captureMove"; readonly amount?: number };','  | { readonly kind: "captureMove"; readonly amount?: number }\n  | { readonly kind: "friendlyMove"; readonly from: string; readonly to: string; readonly amount?: number };');p.write_text(s)
 p=repo/paths[1];p.write_text(p.read_text()+'\nexport function friendlyMoveRules(): RuleSet { return {...captureChoiceRules(),id:"malpaco-friendly-move",movement:"adjacent"}; }\n')
 p=repo/paths[2];p.write_text(p.read_text().replace('export function apply(state:', 'function applyInherited(state:')+'\n'+Path('/tmp/t29-mock-core.txt').read_text())
 p=repo/paths[3];p.write_text(p.read_text()+'\nexport {friendlyMoveRules} from "./state";\nexport {friendlyTargets} from "./rules";\n')
 p=repo/paths[4];p.write_text(p.read_text().replace('captureChoiceRules','friendlyMoveRules'))
 p=repo/paths[5];s=p.read_text();s='import {installFriendlyMock} from "./__t29_mock";\n'+s;s=s.replace('this.panel.el.querySelector(".action")!.append(this.battle.el);','this.panel.el.querySelector(".action")!.append(this.battle.el);\n    installFriendlyMock(this);');p.write_text(s)
 (repo/paths[6]).write_bytes(Path('/tmp/t29-mock-ui.txt').read_bytes())
 with tarfile.open(out/'mock-sources.tar.gz','w:gz') as a:
  for p in paths:a.add(repo/p,arcname=p)
 print(out)
except BaseException:
 for p,b in original.items():
  if b is not None:(repo/p).write_bytes(b)
  elif (repo/p).exists():(repo/p).unlink()
 raise
