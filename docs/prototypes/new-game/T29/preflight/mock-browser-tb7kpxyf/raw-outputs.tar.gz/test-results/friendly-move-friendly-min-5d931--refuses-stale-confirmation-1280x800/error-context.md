# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: friendly-move.spec.ts >> friendly minimum transfer ends turn, fits and refuses stale confirmation
- Location: tests/e2e/friendly-move.spec.ts:19:52

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('#confirm-friendly-move-button')
Expected: 0
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('#confirm-friendly-move-button') with timeout 5000ms
  - waiting for locator('#confirm-friendly-move-button')
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 2 human seats · Seed 0
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]: 23 provinces · 53 armies
      - generic [ref=e16]:
        - generic [ref=e17]: Seat 2
        - generic [ref=e18]: 23 provinces · 46 armies
    - contentinfo [ref=e19]:
      - button "New game" [ref=e20] [cursor=pointer]
  - main [ref=e21]:
    - img "Nine Isles reference map" [ref=e23]:
      - button "River gate, Seat 1, 9 armies" [ref=e48] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: 1 · 9
      - button "New port, Seat 2, 2 armies" [ref=e50] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: 2 · 2
      - button "North rest, Seat 1, 3 armies" [ref=e52] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: 1 · 3
      - button "River keep, Seat 2, 1 armies" [ref=e54] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: 2 · 1
      - button "North town, Seat 1, 2 armies" [ref=e56] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: 1 · 2
      - button "Dark ford, Seat 1, 3 armies" [ref=e58] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: 1 · 3
      - button "Iron point, Seat 2, 2 armies" [ref=e60] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: 2 · 2
      - button "South rest, Seat 2, 3 armies" [ref=e62] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: 2 · 3
      - button "High shore, Seat 1, 3 armies" [ref=e64] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: 1 · 3
      - button "Wind town, Seat 1, 3 armies" [ref=e66] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: 1 · 3
      - button "New glen, Seat 1, 1 armies" [ref=e68] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: 1 · 1
      - button "Old rock, Seat 2, 1 armies" [ref=e70] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: 2 · 1
      - button "Blue peak, Seat 2, 1 armies" [ref=e72] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: 2 · 1
      - button "West haven, Seat 1, 2 armies" [ref=e74] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: 1 · 2
      - button "Stone watch, Seat 2, 3 armies" [ref=e76] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: 2 · 3
      - button "Upper ridge, Seat 1, 2 armies" [ref=e78] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: 1 · 2
      - button "Marsh keep, Seat 2, 2 armies" [ref=e80] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: 2 · 2
      - button "New fell, Seat 1, 1 armies" [ref=e82] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: 1 · 1
      - button "Moon point, Seat 2, 2 armies" [ref=e84] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: 2 · 2
      - button "South fell, Seat 2, 3 armies" [ref=e86] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: 2 · 3
      - button "High ridge, Seat 2, 1 armies" [ref=e88] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: 2 · 1
        - generic [ref=e90]: ★
      - button "Bay ford, Seat 1, 3 armies" [ref=e91] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: 1 · 3
      - button "Low moor, Seat 2, 2 armies" [ref=e93] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: 2 · 2
      - button "Lower field, Seat 1, 1 armies" [ref=e95] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: 1 · 1
      - button "Wind gate, Seat 2, 2 armies" [ref=e97] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: 2 · 2
      - button "Silver shore, Seat 1, 2 armies" [ref=e99] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: 1 · 2
      - button "Low peak, Seat 1, 1 armies" [ref=e101] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: 1 · 1
      - button "Wind port, Seat 2, 3 armies" [ref=e103] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: 2 · 3
      - button "Gold point, Seat 2, 3 armies" [ref=e105] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: 2 · 3
      - button "Rock moor, Seat 1, 1 armies" [ref=e107] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: 1 · 1
      - button "Marsh rest, Seat 1, 3 armies" [ref=e109] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: 1 · 3
        - generic [ref=e111]: ★
      - button "Wind dale, Seat 1, 2 armies" [ref=e112] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: 1 · 2
      - button "Silver ford, Seat 1, 1 armies" [ref=e114] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: 1 · 1
      - button "Iron field, Seat 2, 3 armies" [ref=e116] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: 2 · 3
      - button "North wood, Seat 2, 1 armies" [ref=e118] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: 2 · 1
      - button "Fort town, Seat 1, 2 armies" [ref=e120] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: 1 · 2
      - button "Red field, Seat 2, 1 armies" [ref=e122] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: 2 · 1
      - button "South ridge, Seat 2, 3 armies" [ref=e124] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: 2 · 3
      - button "Rock bay, Seat 1, 2 armies" [ref=e126] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: 1 · 2
      - button "North ford, Seat 2, 1 armies" [ref=e128] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: 2 · 1
      - button "Port ridge, Seat 1, 3 armies" [ref=e130] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: 1 · 3
      - button "New rock, Seat 2, 3 armies" [ref=e132] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: 2 · 3
      - button "South reach, Seat 2, 1 armies" [ref=e134] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: 2 · 1
        - generic [ref=e136]: ★
      - button "Silver point, Seat 1, 1 armies" [ref=e137] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: 1 · 1
      - button "East ford, Seat 1, 2 armies" [ref=e139] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: 1 · 2
      - button "Gold town, Seat 2, 2 armies" [ref=e141] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: 2 · 2
      - generic [ref=e173]: North Isle +3
      - generic [ref=e174]: East Isle +3
      - generic [ref=e175]: West Isle +3
      - generic [ref=e176]: South Isle +3
      - generic [ref=e177]: Central Isle +5
      - generic [ref=e178]: Harbor Isle +5
      - generic [ref=e179]: Palm Isle +6
      - generic [ref=e180]: Cliff Isle +5
      - generic [ref=e181]: Great Isle +9
    - complementary [ref=e182]:
      - generic [ref=e186]:
        - generic [ref=e187]: Seat 2's turn
        - generic [ref=e188]: Round 1 · Reinforcement
      - generic [ref=e189]:
        - generic [ref=e190]:
          - generic [ref=e191]:
            - generic [ref=e192]: Province income
            - strong [ref=e193]: "7"
          - generic [ref=e194]:
            - generic [ref=e195]: Island income
            - strong [ref=e196]: "0"
          - generic [ref=e197]:
            - generic [ref=e198]: Armies to place
            - strong [ref=e199]: "7"
        - paragraph [ref=e200]: Place your armies on your countries, then start combat.
        - generic [ref=e201]:
          - button "Start combat" [disabled] [ref=e202]
          - button "End turn" [disabled] [ref=e203]
          - button "Move armies" [disabled] [ref=e204]
      - generic [ref=e205]:
        - heading "Battle log" [level=3] [ref=e206]
        - list "Battle log" [ref=e207]:
          - listitem [ref=e208]: T1 Seat 1 ends the turn
```

# Test source

```ts
  1  | import {test,expect} from "@playwright/test";
  2  | import type {Page} from "@playwright/test";
  3  | import type {GameState} from "../../src/core";
  4  | import {reinforcementIncome} from "../../src/core";
  5  | import {fixture,map,step,targets} from "./friendly-fixture";
  6  | import {mkdirSync,mkdtempSync} from "node:fs";
  7  | import {join} from "node:path";
  8  | const country=(page:Page,id:string)=>page.locator(`[data-country="${id}"]`);
  9  | async function paint(page:Page,s:GameState){for(const p of map.provinces){await expect(country(page,p.id)).toHaveAttribute("data-owner",s.ownerOf[p.id]!);await expect(country(page,p.id)).toHaveAttribute("data-armies",String(s.armies[p.id]));}}
  10 | async function prepare(page:Page,capture=false){const f=fixture(capture);await page.goto("/?view=reference-game");await page.getByLabel("Seed",{exact:true}).fill(String(f.seed));await page.getByLabel("Human seats").selectOption("2");await page.getByRole("button",{name:"Start game",exact:true}).click();for(let n=0;n<f.placements;n++)await country(page,f.from).click();await page.locator("#start-combat-button").click();await paint(page,f.ready);return f;}
  11 | async function screenshot(page:Page,label:string,project:string){const root=process.env["FRIENDLY_EVIDENCE_DIR"]??"screenshots";mkdirSync(root,{recursive:true});await page.screenshot({path:join(mkdtempSync(join(root,"friendly-")),`${label}-${project}.png`)});}
  12 | async function begin(page:Page,state:GameState){await expect(page.locator("#start-friendly-move-button")).toBeVisible();await page.locator("#start-friendly-move-button").click();await expect(page.getByRole("region",{name:"Friendly move",exact:true})).toBeVisible();expect((await page.locator('[data-country][data-target="true"]').evaluateAll(ns=>ns.map(n=>n.getAttribute("data-country")))).sort()).toEqual(map.provinces.filter(p=>state.ownerOf[p.id]===state.players[state.currentPlayer]!.id&&targets(state,p.id).length>0).map(p=>p.id).sort());}
  13 | async function select(page:Page,s:GameState,from:string,to:string){
  14 |  await country(page,from).click();expect((await page.locator('[data-country][data-target="true"]').evaluateAll(ns=>ns.map(n=>n.getAttribute("data-country")))).sort()).toEqual(targets(s,from).sort());
  15 |  for(const id of targets(s,from))await expect(country(page,id)).toHaveClass(/neighbor/);
  16 |  await country(page,to).click();await expect(page.locator("#friendly-move-amount")).toHaveValue(String(s.armies[from]!-1));await expect(page.locator("#friendly-move-amount")).toHaveAttribute("min","1");await expect(page.locator("#friendly-move-amount")).toHaveAttribute("max",String(s.armies[from]!-1));
  17 | }
> 18 | async function handoff(page:Page,s:GameState){await paint(page,s);await expect(page.locator("#turn-title")).toHaveText(`${s.players[s.currentPlayer]!.name}'s turn`);await expect(page.locator("#reinforcement-pool")).toHaveText(String(reinforcementIncome(s,s.players[s.currentPlayer]!.id).total));await expect(page.locator("#confirm-friendly-move-button")).toHaveCount(0);}
     |                                                                                                                                                                                                                                                                                                                                                                    ^ Error: expect(locator).toHaveCount(expected) failed
  19 | for(const amount of ["minimum","maximum"] as const)test(`friendly ${amount} transfer ends turn, fits and refuses stale confirmation`,async({page},info)=>{
  20 |  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));const f=await prepare(page);await begin(page,f.ready);await select(page,f.ready,f.from,f.to);
  21 |  await page.locator("#friendly-move-amount").fill("0");await page.locator("#confirm-friendly-move-button").click();await paint(page,f.ready);
  22 |  await page.locator("#friendly-move-minimum-button").click();await expect(page.locator("#friendly-move-amount")).toHaveValue("1");await page.locator("#friendly-move-more-button").click();await expect(page.locator("#friendly-move-amount")).toHaveValue("2");await page.locator("#friendly-move-less-button").click();await expect(page.locator("#friendly-move-amount")).toHaveValue("1");
  23 |  if(amount==="maximum")await page.locator("#friendly-move-maximum-button").click();
  24 |  const n=amount==="minimum"?1:f.ready.armies[f.from]!-1;await expect(page.locator("#friendly-move-amount")).toHaveValue(String(n));
  25 |  const fits=await page.locator('#friendly-move-amount,#confirm-friendly-move-button,#cancel-friendly-move-button,#skip-friendly-move-button').evaluateAll(ns=>ns.every(n=>{const b=n.getBoundingClientRect();return b.width>0&&b.height>0&&b.left>=0&&b.top>=0&&b.right<=innerWidth&&b.bottom<=innerHeight;}));expect(fits).toBe(true);
  26 |  await expect(page.locator("#confirm-friendly-move-button")).toContainText(/end.*turn/i);await screenshot(page,`choose-${amount}`,info.project.name);
  27 |  const stale=await page.locator("#confirm-friendly-move-button").elementHandle();await page.locator("#confirm-friendly-move-button").click();const done=step(f.ready,{kind:"friendlyMove",from:f.from,to:f.to,amount:n});await handoff(page,done);await stale!.evaluate(n=>n.dispatchEvent(new MouseEvent("click",{bubbles:true})));await handoff(page,done);await screenshot(page,`done-${amount}`,info.project.name);expect(errors).toEqual([]);
  28 | });
  29 | test("cancel returns to attacks without movement; skip hands off normally",async({page},info)=>{
  30 |  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));const f=await prepare(page);await begin(page,f.ready);await select(page,f.ready,f.from,f.to);const stale=await page.locator("#confirm-friendly-move-button").elementHandle();await page.locator("#cancel-friendly-move-button").click();await expect(page.locator("#start-friendly-move-button")).toBeVisible();await stale!.evaluate(n=>n.dispatchEvent(new MouseEvent("click",{bubbles:true})));await paint(page,f.ready);await expect(page.getByRole("region",{name:"Battle controls",exact:true})).toHaveAttribute("data-history-count",String(f.ready.history.length));
  31 |  await begin(page,f.ready);await page.locator("#skip-friendly-move-button").click();await handoff(page,step(f.ready,{kind:"endTurn"}));await screenshot(page,"skipped",info.project.name);expect(errors).toEqual([]);
  32 | });
  33 | test("a just-captured country can supply the final friendly move",async({page},info)=>{
  34 |  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));const f=await prepare(page,true);let state=f.ready;await country(page,f.from).click();await country(page,f.to).click();for(let n=0;n<128&&state.phase==="attack";n++){await page.locator("#single-exchange-button").click();state=step(state,{kind:"attack",from:f.from,to:f.to});}expect(state.phase).toBe("capture");await expect(page.locator("#start-friendly-move-button")).toBeDisabled();await page.locator("#confirm-capture-button").click();state=step(state,{kind:"captureMove",amount:state.pendingCapture!.max});await begin(page,state);await select(page,state,f.to,f.from);await page.locator("#friendly-move-minimum-button").click();await screenshot(page,"captured-source",info.project.name);await page.locator("#confirm-friendly-move-button").click();await handoff(page,step(state,{kind:"friendlyMove",from:f.to,to:f.from,amount:1}));expect(errors).toEqual([]);
  35 | });
  36 | 
```