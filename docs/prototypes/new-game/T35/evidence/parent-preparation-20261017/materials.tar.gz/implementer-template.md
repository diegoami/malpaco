# T35 Sea crossings, bonuses and fair complete boards

- **Kind**: slice
- **Issue**: #80 · **Branch**: `task/T35-sea-crossings-bonuses-and-fair-complete-boards` · **Merge after**: T34.
- **Difficulty**: Very hard; estimate, not a model assignment.
- **Implementer**: owner-selected under rule 6; use an isolated worktree and record the choice before dispatch.
- **Reviewer**: owner-selected OpenCode model of another family under rule 6; record the choice before review.
- **Evidence**: [pinned core-rules design](https://github.com/diegoami/isle-wars-archaeology/blob/ae298e37c2f5177039e55767607f9345b6cb0e7a/design/core-rules.md), owner roadmap accepted 2026-10-15, and upstream task evidence. T23 resolves source anchors; new constants need citations or explicit [designed] provenance.
- **Owns**: src/core/**; tests/core/**; docs/prototypes/new-game/T35/**; docs/spike.md; append-only RUN-NOTES.md.
- **Scope**: Complete T34's joint coast/entrance construction with 14–18 ordinary inter-island edges and routes satisfying the owner-approved T62 attachment/traceability contract. Repair placement, entrance coasts and ports together rather than forcing long bypasses around frozen countries. Enforce degree 2–5, connected country/island graphs and all existing fairness rules. Recompute bonuses from island size and distinct entrance countries. Integrate the versioned generator and recoverable bounded exhaustion. Keep old-version generation available for supported saves.
- **Done when**:
  1. `npx vitest run tests/core/geographic-board.test.ts` — independently reconstructed shared-border and sea-edge sets equal declared adjacency; route endpoints/crossings, degrees, bonuses and each fairness invariant pass.
  2. `node docs/prototypes/new-game/T35/sweep.mjs` — seeds 0..99 meet the T24 approved success/attempt budget; retain counts, exact failing seeds and deterministic board/deal/RNG hashes including exhaustion.
  3. `npm test` and `npm run build` pass; affected pinned browser suites pass without weakening existing assertions. Retain measured outputs, screenshots where applicable, commands and hashes in the owned evidence path; report negative-before/positive-after checks and exact restoration.
- **Hazards**: Do not connect distant countries merely to satisfy counts or silently replace failed seeds. A topology change can change bonuses and strategic chokepoints. Main session preflights acceptance before dispatch; unresolved design conflicts stop implementation, never weaken a Done-when.



The brief is the task file pasted in full, then this block, then on a rework round the review's URL.
The `implementer` agent file repeats the run mechanics; this block is the contract, for the main
session implementing directly as much as for the subagent. A line that needs the user's machine outside the
worktree, or a cloud session, is the main session's (L26).

```text
You implement <T<nn>>. The task file above is the contract.
- Build only what the task asks for, even inside a file it requires; say why for each changed file. (L44)
- A Done-when you cannot meet: stop and report. Never weaken an assertion, skip a test or edit the task file.
- **Constraint-feasibility probe** (when the task names structural constraints and a target success
  rate): before any algorithmic change, run a small smoke test that confirms the constraint
  set alone is feasible at the target rate (often a wide-seed sweep of the existing generator
  body, plus the new constraints, with no algorithmic rewrite). If the probe shows the target
  is unreachable, STOP and report. Do not weaken a constraint to make the algorithm pass
  (rule 5); the user prefers a design amendment (preferred) over a quieter relaxation, and
  the probe surfaces the conflict one round earlier than a full implementation.
- Every new test fails before your change and passes after it; say how you checked.
- Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
  restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
  a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
  copy inside your worktree (`<file>.saved`, deleted afterwards) or in a `mktemp -d` folder under
  `/tmp`, never as a loose file elsewhere.
- If you measure: every output a finding or the PR may cite goes under a tracked path the task owns,
  pushed per batch and every 30 min, never deleted or overwritten; originals out, hashes recorded. (L40)
- A comment that asserts behaviour at an edge comes with the test that visits that edge.
- A defect you find outside the task: report it. A one-file mechanical fix that blocks you may
  ride this PR, declared under Scope in the PR body.
- Update any document your change makes wrong, in this PR. Never write status into a document.
- PR body: Closes #<issue>; Scope (files and why); a fenced block with each Done-when command and
  the tail of its output; Docs changed.
```


T35 preparation, read-only observations while T34 review/rework runs; no dispatch or implementation.
- Preserve old board-gen.ts semantics: legacy exactly16 lanes, minimum2 entrance countries and MAX_BOARD_ATTEMPTS1 are old generated/1 identity. Geographic T24 contract is14–18 crossings and approved fairness, bounded50; do not force legacy structuralErrors onto new generator.
- T34 partial geography now100/100; three plans14/15 reservations can directly support feasibility tests via diagnosticBoard, but conversion/shared-border/route/bonus equivalence must be independently reconstructed, not producer self-validation.
- New generator should keep one continuous RNG through failed geography candidates, deal and centre selection. T34 currently exposes seed-based generateIslandGeography; adding shared-stream seam for T35 must preserve original seed API and no seed replacement.
- Existing GameMap has plain provinces/islands/bounds, no coast-route shape metadata. Preserve one map adjacency and return suitable geometry sidecar for T36; do not change UI/default untilT36.
- Match save legacy v1 generated/1 and v2 fixed-reference/1 remain supported. Add explicit new identity/version, preserve old recorded actions and reject unknown identities with current errors. Never silently reinterpret version.
- Parent must lock acceptance/fail-before/mock-positive and run updated feasibility smoke in isolatedT35tree afterT34merge, then dispatch SolMedium under standing owner choices; do not reuse old narrow-family feasibility counts as current proof.

Read-only Sol Medium preparation on resume (2026-10-17): existing diagnosticBoard is a feasible conversion starting point; independent T35 acceptance must combine ACTUAL returned GameMap adjacency/bonus with ACTUAL sidecar paths, never regenerate those values in its checker. Reuse unchanged T62 inspect, which preserves T24 island-degree maximum4 (legacy fairness allows5 and is insufficient alone). Do not wrap50-geography-attempt loops in another50. Extract a shared-RNG geography seam preserving existing seed-wrapper equivalence; continue same advanced stream through conversion and existing createGameWithRng deal/centres. New generator uses existing modern victory/1 and schema2, consistent with T36 integrating current playable game; default switching remainsT36. Preserve old generated/1 and fixed-reference/1 replay bytes. Acceptance must catch missing land edges, asymmetric/mismatched sea edges/routes, wrong distinct-country bonus, bypassed invalid candidate, retry/cap/RNG reset, restarted deal stream and wrong identity dispatch. Reuse existing refusal matrix; avoid duplicating T34 guards. Native preparation was read-only, no implementation, measurements, model/CI dispatch or repository edits by subagent.

PREPARATION ONLY: DO NOT DISPATCH THIS TEMPLATE. Main must integrate approved T34, lock acceptance and retain fail-before/disposable-positive and updated feasibility before choosing a concrete head. Preserve existing .cache/t35-work and all historical evidence. Runtime/new-game default remains fixed-reference until T36. Implementer Sol Medium; planned reviewer Claude Sonnet High for harder generator/replay work, standing owner authorization. Record concrete choice before dispatch.
