# T35 acceptance proposal — unexecuted

These files are drafts for parent review. No producer, task, worktree, GitHub state,
tests, sweep, CI or models were changed or run while preparing them.

Install the test at `tests/core/geographic-board.test.ts`; install the two scripts
under `docs/prototypes/new-game/T35/`. Relative imports deliberately target those
destinations. The proposal cannot run in this staging directory.

## API assumptions to freeze before dispatch

- `geographic-board.ts`: `generateGeographicBoard(seed,{attempts?})` and
  `generateGeographicBoardWithRng(rng,{attempts?})` return the parent-selected shape.
  `geography` is the existing fixed-point `IslandGeography`, including actual
  entrance-reservation paths. Map geometry is that geometry divided by its units.
- `island-geography.ts`: add `generateIslandGeographyWithRng` preserving the old wrapper.
- `geographic-game.ts`: `createGeographicGame(options,rules?,generationOptions?)`
  defaults to `victoryRules(options)`. Success returns `state` and `geography`;
  failure returns `ok:false` without a state. Further board metadata is permitted.
- Existing format 2 accepts exactly `geographic/1 + victory/1 + schema 2` in
  addition to its existing supported identity. Historical save tests remain intact.

## What the draft protects

The adapter combines actual map adjacency/bonus/country polygons with actual
geography island coasts and reservation routes. It never repairs rules values.
Unchanged T62/T24 inspectors reconstruct shared borders, route-edge equality,
bonus and every approved fairness constraint. Diagnostic text specifications are
the existing approved budgets; they do not prove rendered UI appearance.

Focused tests cover accepted seeds, copied-output defects, seed/shared-stream
equivalence, a meaningful continued-stream deal expectation, zero-budget recovery,
one real rejection with exactly one global attempt, and new-identity action replay.
The real-rejection test uses seed 0: T34's retained `sweep-JPXDhX/report.json`
records seven attempts. Parent preflight must reconfirm its one-attempt failure.
If the constructor later changes so it succeeds immediately, replace this fixture transparently with a narrow mocked
geography seam; do not introduce a requirement that healthy generation must fail.

The draft intentionally expects conversion to preserve a valid T34 result rather
than spending extra RNG or changing geometry. If extra construction is necessary,
the exact partial/full exhaustion expectation requires parent adjustment before
freezing acceptance, while retaining the one-global-budget and continuous-stream
requirements. This is a proposed seam, not a new owner design gate.

## Parent sequence

Review/adopt/freeze, run absent-producer negative, then a disposable conversion
positive using T34's existing reservations. Save and restore exact bytes. Run
the updated feasible-conversion sweep before producer dispatch. At least 99 of
100 seeds must succeed within 50 global attempts; every exported success must be
valid. The sweep retains full outcomes, rejected candidates, board/deal/geometry/
RNG hashes, bounded exhaustion, exact seed lists and copied hashed source inputs.

After implementation, run the task's focused command, sweep, full units/build and
affected pinned browser suites. Retain command outputs and browser evidence in
the owned path using the existing repository wrappers. No new test framework,
T34 refusal matrix, default/UI integration or visual approval gate is proposed.
