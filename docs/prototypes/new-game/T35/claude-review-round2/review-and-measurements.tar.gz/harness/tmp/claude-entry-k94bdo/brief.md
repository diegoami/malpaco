T69 review (Claude)
You review PR #1 at bf374734a2a42df8d09e49d4c3834b901162a948.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
