from pathlib import Path
import hashlib,json,subprocess,tarfile,sys,re
ROOT=Path('/home/diego/projects/malpaco');TREE=Path(sys.argv[1]).resolve();SOURCE=Path(sys.argv[2]).resolve();OUT=ROOT/'.cache/t35-work/docs/prototypes/new-game/T35/claude-review-round2'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (SOURCE/'receipt.json').is_file() and (SOURCE/'final.md').is_file()
OUT.mkdir(exist_ok=False)
tracked=set(subprocess.check_output(['git','ls-files'],cwd=TREE,text=True).splitlines());changed=set(subprocess.check_output(['git','diff','--name-only'],cwd=TREE,text=True).splitlines());files={}
for p in SOURCE.rglob('*'):
 if p.is_file() and not p.is_symlink():files['harness/'+str(p.relative_to(SOURCE))]=p
for p in TREE.rglob('*'):
 rel=p.relative_to(TREE)
 if any(x in {'.git','node_modules'} for x in rel.parts):continue
 if p.is_file() and not p.is_symlink() and (str(rel) not in tracked or str(rel) in changed):files['review-worktree/'+str(rel)]=p
for prefix,parent in [('native-session',Path('/home/diego/.claude/projects')/re.sub(r'[^A-Za-z0-9-]', '-', str(TREE)))]:
 if parent.exists():
  for p in parent.rglob('*'):
   if p.is_file() and not p.is_symlink():files[prefix+'/'+str(p.relative_to(parent))]=p
for name in ['review2-final.md','claude-review2.log','archive-review2.py','review2-choice.md','rework-brief.md']:
 files['dispatch/'+name]=ROOT/'.cache/t35-dispatch/resume-20261018'/name
hashes={n:sha(p) for n,p in files.items()};archive=OUT/'review-and-measurements.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
seen={}
with tarfile.open(archive,'r|gz') as tar:
 for member in tar:
  if member.isfile():seen[member.name]=hashlib.sha256(tar.extractfile(member).read()).hexdigest()
assert seen==hashes
(OUT/'archive-manifest.json').write_text(json.dumps({'archive':archive.name,'sha256':sha(archive),'members':hashes,'originalsPreservedAtArchive':True,'reviewWorktreeAndHarnessPreserved':True,'changedTrackedReviewFiles':sorted(changed)},indent=2)+'\n')
for name in ['final.md','receipt.json','inventory.json']:(OUT/name).write_bytes((SOURCE/name).read_bytes())
print(json.dumps({'output':str(OUT),'members':len(hashes),'archiveBytes':archive.stat().st_size,'changedTrackedReviewFiles':sorted(changed)}))
