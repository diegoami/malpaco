# T35 Sea crossings, bonuses and fair complete boards

- **Kind**: slice
- **Issue**: #80 · **Branch**: `task/T35-sea-crossings-bonuses-and-fair-complete-boards` · **Merge after**: T34.
- **Difficulty**: Very hard; estimate, not a model assignment.
- **Implementer**: owner-selected under rule 6; use an isolated worktree and record the choice before dispatch.
- **Reviewer**: owner-selected OpenCode model of another family under rule 6; record the choice before review.
- **Evidence**: [pinned core-rules design](https://github.com/diegoami/isle-wars-archaeology/blob/ae298e37c2f5177039e55767607f9345b6cb0e7a/design/core-rules.md), owner roadmap accepted 2026-10-15, and upstream task evidence. T23 resolves source anchors; new constants need citations or explicit [designed] provenance.
- **Owns**: src/core/**; tests/core/**; docs/prototypes/new-game/T35/**; docs/spike.md; append-only RUN-NOTES.md.
- **Scope**: Complete T34's joint coast/entrance construction with 14–18 ordinary inter-island edges and routes satisfying the owner-approved T62 attachment/traceability contract. Repair placement, entrance coasts and ports together rather than forcing long bypasses around frozen countries. Enforce degree 2–5, connected country/island graphs and all existing fairness rules. Recompute bonuses from island size and distinct entrance countries. Integrate the versioned generator and recoverable bounded exhaustion. Keep old-version generation available for supported saves.
- **Done when**:
  1. `npx vitest run tests/core/geographic-board.test.ts tests/core/geographic-match-identity.test.ts` — geographic saves reject wrong rules, action schemas and extra identity keys while fixed-reference saves remain supported; independently reconstructed shared-border and sea-edge sets equal declared adjacency; route endpoints/crossings, degrees, bonuses and each fairness invariant pass.
  2. `node docs/prototypes/new-game/T35/sweep.mjs` — seeds 0..99 meet the T24 approved success/attempt budget; retain counts, exact failing seeds and deterministic board/deal/RNG hashes including exhaustion.
  3. `npm test` and `npm run build` pass; affected pinned browser suites pass without weakening existing assertions. Retain measured outputs, screenshots where applicable, commands and hashes in the owned evidence path; report negative-before/positive-after checks and exact restoration.
- **Hazards**: Do not connect distant countries merely to satisfy counts or silently replace failed seeds. A topology change can change bonuses and strategic chokepoints. Main session preflights acceptance before dispatch; unresolved design conflicts stop implementation, never weaken a Done-when.



The brief is the task file pasted in full, then this block, then on a rework round the review's URL.
The `implementer` agent file repeats the run mechanics; this block is the contract, for the main
session implementing directly as much as for the subagent. A line that needs the user's machine outside the
worktree, or a cloud session, is the main session's (L26).

```text
You implement <T<nn>>. The task file above is the contract.
- Build only what the task asks for, even inside a file it requires; say why for each changed file. (L44)
- A Done-when you cannot meet: stop and report. Never weaken an assertion, skip a test or edit the task file.
- **Constraint-feasibility probe** (when the task names structural constraints and a target success
  rate): before any algorithmic change, run a small smoke test that confirms the constraint
  set alone is feasible at the target rate (often a wide-seed sweep of the existing generator
  body, plus the new constraints, with no algorithmic rewrite). If the probe shows the target
  is unreachable, STOP and report. Do not weaken a constraint to make the algorithm pass
  (rule 5); the user prefers a design amendment (preferred) over a quieter relaxation, and
  the probe surfaces the conflict one round earlier than a full implementation.
- Every new test fails before your change and passes after it; say how you checked.
- Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
  restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
  a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
  copy inside your worktree (`<file>.saved`, deleted afterwards) or in a `mktemp -d` folder under
  `/tmp`, never as a loose file elsewhere.
- If you measure: every output a finding or the PR may cite goes under a tracked path the task owns,
  pushed per batch and every 30 min, never deleted or overwritten; originals out, hashes recorded. (L40)
- A comment that asserts behaviour at an edge comes with the test that visits that edge.
- A defect you find outside the task: report it. A one-file mechanical fix that blocks you may
  ride this PR, declared under Scope in the PR body.
- Update any document your change makes wrong, in this PR. Never write status into a document.
- PR body: Closes #<issue>; Scope (files and why); a fenced block with each Done-when command and
  the tail of its output; Docs changed.
```


FULL INDEPENDENT REVIEW:
T35 review (Claude Sonnet High)
approve after named fixes

DW1: ran `npx vitest run tests/core/geographic-board.test.ts` → 1 file, 12/12 tests passed in 11.9s.
DW2: ran `node docs/prototypes/new-game/T35/sweep.mjs` once → 100/100 successes, `failingSeeds=[]`, `invalidSeeds=[]`, `targetMet=true`. The maximum was 36 of 50 attempts. Route counts were 14 on 13 seeds and 15 on 87 seeds, all within 14–18. A 1-attempt budget exhausted on 87 seeds, and the zero-budget case was checked. All 100 per-seed hash sets (result, map, geography, failures, board RNG, deal, game RNG, bounded) equal the producer's retained `sweep-Ym4STu`, extracted from the verified final bundle.
DW3: ran `npm test` → 6 harness tests plus 46 Vitest files, 636/636 passed.
DW3: ran `npm run build` → `tsc` for `src/core` and for the app, then `vite build`, all succeeded.
DW3: ran `python3 docs/prototypes/new-game/T35/run-browser.py rev --suites tests/e2e/reference-complete-game.spec.ts,tests/e2e/reference-game.spec.ts,tests/e2e/versioned-match.spec.ts,tests/e2e/entry.spec.ts` → 24/24 passed sequentially in 2.1 min, exit 0, including the 1920x1080 entry-route case. Evidence is in `docs/prototypes/new-game/T35/evidence/rev-c0lp25nq`.

Where I worked:
- **Tree:** worktree at HEAD `caed7b2938936673ddc156c79a2716b4f1454d8f`, base `3b57a08dd8b4ee641a47ec3b3809cc0d17310e55`. The 61 changed files match `inventory.json`, and every one is within the task's Owns list.
- **Hashes:** the nine hash-listed source and test files match `implementation.json`.
- **Evidence bundles:** `verify-evidence.py` confirmed the initial bundle (105 members), the final bundle (584 members) and the parent-preflight bundle (897 members). The parent verifies the full archives independently.
- **Mutations:** I applied each mutation in place and restored the saved bytes afterwards. `git status` shows no tracked changes; my only additions are untracked `rev-*` and `sweep-*` evidence directories.
  - Dropping the entrance term from the bonus formula fails 6 tests.
  - Setting `seaLanes:[]` fails 7 tests.
  - Restarting the RNG in `createGeographicGame` fails the continuation test.
  - Removing the geographic dispatch in `deserializeVersionedMatch` fails the replay test.
  - Skipping the rules check for geographic saves, and skipping the action-schema check for them, both leave 13/13 passing (see R1).
- **Option probe:** I ran a scratch probe of 72 `createGeographicGame` variants (seeds 0–11, humanShare −4, 0 and 4, armies 1-2 and 1-4) with the default four seats. All succeeded with 46 countries and 9 islands, and I deleted the probe afterwards. Seat counts other than four were not probed.
- **Save refusals:** a probe confirmed a geographic save with the wrong rules, wrong action schema or an extra key is refused at runtime. Only the version-999 refusal is asserted by the PR's tests.
- **Retained browser failure:** the producer's 23/24 run failed at `entry.spec.ts:85` (`#generated-prototype` not found within 5000ms, 1920x1080 only). `git diff` shows no change under `src/ui` or `src/main.ts`, and that route does not import the new modules. My unchanged sequential run passed 24/24, so I could not reproduce it. The cause is unproven, which matches the producer's own statement.

Findings:

**R1 (blocking, `src/core/match-save.ts:95-110`, `tests/core/geographic-board.test.ts:134`).** Save-identity dispatch for `geographic/1` is only half-tested.
- `supportedIdentity` has a geographic-specific branch that requires `victory/1` and action schema 2. The README claims unknown combinations are refused. The only refusal test sets `boardGenerator.version = 999`.
- I confirmed by mutation that these two weakenings still pass 13/13 tests:
  - skipping the `rules` check when `expected===GEOGRAPHIC_MATCH_IDENTITY` (line 101)
  - skipping the `actionSchemaVersion` check for geographic (line 106)
- A geographic save with `rules=malpaco/1` or schema 1 would then load against the wrong replay semantics, which is the save-identity dispatch the brief asks to be checked.
- Fix: add refusal assertions for `geographic/1` with `malpaco/1` rules, with action schema 1, and with an extra identity key. Also assert that `fixed-reference/1` still loads, so the historical identity is pinned next to the new one.

**R2 (not blocking, `src/core/geographic-game.ts:25`).** The `if(!created.ok)` branch, a deal failure after accepted geography, is reached by no input I tried: the 100-seed sweep and my 72 option variants. It also loses the retry semantics that the 50-attempt budget gives geography. It is an inherited setup failure mode, so I rated it non-blocking.

**R3 (not blocking, `src/core/geographic-game.ts:20`).** The message says "Retry with another seed or a larger budget", but `generateIslandGeographyWithRng` clamps the budget to 50. A caller already at the cap cannot raise it.

**R4 (not blocking, `tests/core/geographic-board.test.ts:1`).** The stale header "Proposal: install at …; no producer is included" is now wrong. `acceptance.mjs` and `sweep.mjs` carry deliberate "Proposal/UNEXECUTED" headers, which the brief accepts.

**R5 (not blocking, `docs/prototypes/new-game/T35/implementation.json`).** The retained 23/24 browser failure is recorded honestly and the cause is unproven. My independent rerun passed 24/24.

Checks that came out clean:
- **Randomness:** there is no wall-clock or unseeded randomness in the new rule code, and `generateIslandGeography` is behaviour-identical through the new `WithRng` seam.
- **Geometry and constants:** all geometry is checked as safe integers (a fractional-coordinate test exists). The bonus formula is cited to C-BON-02 and the T24 contract, and `acceptance.mjs` reads the map's actual `borders`, `seaLanes` and `bonus` rather than recomputing them.
- **Budget and RNG:** exhaustion returns no `map` or `geography` and keeps `failures` and `rng`. The 50-attempt budget is shared, not 50x50. The RNG object continues through geography and the deal; the continuation test and the mutation both confirm it.
- **Existing tests:** no existing assertion was changed (the diff only adds files and lines). `RUN-NOTES.md` additions are append-only (0 deleted lines), `docs/spike.md` was updated and no UI or default changed.

FILE: RUN-NOTES.md
FILE: docs/prototypes/new-game/T35/README.md
FILE: docs/prototypes/new-game/T35/acceptance.mjs
FILE: docs/prototypes/new-game/T35/archive-evidence.py
FILE: docs/prototypes/new-game/T35/evidence/implementation-final-retained-py0avz4x/originals.tar.gz.part01
FILE: docs/prototypes/new-game/T35/evidence/implementation-final-retained-py0avz4x/originals.tar.gz.part02
FILE: docs/prototypes/new-game/T35/evidence/implementation-final-retained-py0avz4x/originals.tar.gz.part03
FILE: docs/prototypes/new-game/T35/evidence/implementation-final-retained-py0avz4x/originals.tar.gz.part04
FILE: docs/prototypes/new-game/T35/evidence/implementation-final-retained-py0avz4x/originals.tar.gz.part05
FILE: docs/prototypes/new-game/T35/evidence/implementation-initial-retained-ez45n7zq/originals.tar.gz.part01
FILE: docs/prototypes/new-game/T35/evidence/parent-preflight-20261018/parent-preflight.tar.gz.part01
FILE: docs/prototypes/new-game/T35/evidence/parent-preflight-20261018/parent-preflight.tar.gz.part02
FILE: docs/prototypes/new-game/T35/evidence/parent-preflight-20261018/parent-preflight.tar.gz.part03
FILE: docs/prototypes/new-game/T35/feasibility.mjs
FILE: docs/prototypes/new-game/T35/implementation.json
FILE: docs/prototypes/new-game/T35/run-browser.py
FILE: docs/prototypes/new-game/T35/run-command.py
FILE: docs/prototypes/new-game/T35/smoke.mjs
FILE: docs/prototypes/new-game/T35/sweep.mjs
FILE: docs/prototypes/new-game/T35/verify-evidence.py
FILE: docs/spike.md
FILE: src/core/geographic-board.ts
FILE: src/core/geographic-game.ts
FILE: src/core/index.ts
FILE: src/core/island-geography.ts
FILE: src/core/match-save.ts
FILE: tests/core/geographic-board.test.ts
FILE: tests/core/geographic-game.test.ts
EVIDENCE: docs/prototypes/new-game/T35/evidence/

For the multipart parts, I checked the receipt part hashes and the concatenated archive hash. I did not read the archived source snapshots, and the parent verifies every archive member separately. The generated `evidence/` directories were audited through their manifests, receipts and sampled outcomes: the initial and final bundles, the parent-preflight receipt, `current-parent-*`, `feasibility-2YSJDZ`, `parent-integration-8fb51e5` and `parent-preparation-20261017`.

SCOPE: complete

Final pass done

approve after named fixes
Concrete first scoped rework: native GPT-6 Luna High in existing .cache/t35-work branchPR160, under standingownerchoices. Main readfullreview, adoptedblockingR1 and amendedT35DW1 onmain0c9d7ad. Parent importedmain and froze six new tests in tests/core/geographic-match-identity.test.ts; they already pass baseline and allthreeexactsourceomissions now fail with exactrestoration in parent-identity-controls-cm55u2ql. Do NOT edit either frozen test file or originalacceptance/sweep; get SHA256atstart/end. Originaltwelve-casefile8bcf16370bc0807d0abb636bcec191b2018a630f20f46fc722855f05dabf5836 unchanged. Newidentityfilehashrecordedinparent-assessment.json. Codealreadycorrectlyrefusesbadtuples; no validatorlogicchange needed.
Implement onlyR3 messagecorrection in src/core/geographic-game.ts: exhaustion should recommendanotherseed, not largerbudgetatcap. Preserve RNG/map/deal/codec/numericbudgets. R4 frozenheader cannotchange; clarifyhistoricalacceptanceheadersinREADME, no assertionbytes changed. R2unreacheddefensivebranch/R5unprovenstartup timeout remainnonblockingfollowups; do not rewritecoredeal or timingtests.
Rerun exactDW1 amendedcommand(18tests), focusedwithgeographic-game.test(19tests), npmtest(642units+6harness expected), build usingretainingwrappers sequentially. Producer neednot repeat unchangedgeometry100sweep oroldUI24browsers: priorindependentfullpositiveevidence coversidenticalalgorithms/UI; parentfollowupSonnetMedium will re-run all DWcommands including100+24. Prove allpreviouscode/test hashes unchanged exceptoneerrormessage, newfrozenparentfile, ownedmetadata/docs; no defaultUIchange.
Update README/currentimplementation.json+PRbody/appendonlynotes toaccuratecurrenttests/head/sourcehashes, retainingoriginalrecords/clarifyingolderruns. Verifyoldreview1158membersarchiveandallinheritedevidence unchanged. Measurementoutputs freshdirectories, source/rawsnapshots archivedhashverified <=24MiB partsiflarge; preserve looseoriginals. Includeparentcontrols source/rawarchivesalreadytracked, do notduplicateoldhundredsMB evidence. Everychangedfile reason. Commit/push [skipci] aftereachcheckpoint, updatePR160body--body-file. No review/CI/merge/labels/GitHubcomments. Send FULLFINAL afterpushproof, exacthead/hash/testcommands/outputs/times/docsandknownlimits.
Parent currentmain0c9d7adtaskamendmentsarealreadymergedintotaskbranch; ownnewreviewartifactstaskbranch5a9fb93. Onlyproductiononediagnosticstringchanges, parentalreadyaddedidentitytests. WorkonlyT35tree; T36prototypeagentwritesdifferenttreeandstillholdsheavytests forcoordination. Preserveallinheriteddirty/worktrees/evidence; no stash/reset/restore/prune.
