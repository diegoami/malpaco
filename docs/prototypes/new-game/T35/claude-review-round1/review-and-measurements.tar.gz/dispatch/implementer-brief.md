# T35 Sea crossings, bonuses and fair complete boards

- **Kind**: slice
- **Issue**: #80 · **Branch**: `task/T35-sea-crossings-bonuses-and-fair-complete-boards` · **Merge after**: T34.
- **Difficulty**: Very hard; estimate, not a model assignment.
- **Implementer**: owner-selected under rule 6; use an isolated worktree and record the choice before dispatch.
- **Reviewer**: owner-selected OpenCode model of another family under rule 6; record the choice before review.
- **Evidence**: [pinned core-rules design](https://github.com/diegoami/isle-wars-archaeology/blob/ae298e37c2f5177039e55767607f9345b6cb0e7a/design/core-rules.md), owner roadmap accepted 2026-10-15, and upstream task evidence. T23 resolves source anchors; new constants need citations or explicit [designed] provenance.
- **Owns**: src/core/**; tests/core/**; docs/prototypes/new-game/T35/**; docs/spike.md; append-only RUN-NOTES.md.
- **Scope**: Complete T34's joint coast/entrance construction with 14–18 ordinary inter-island edges and routes satisfying the owner-approved T62 attachment/traceability contract. Repair placement, entrance coasts and ports together rather than forcing long bypasses around frozen countries. Enforce degree 2–5, connected country/island graphs and all existing fairness rules. Recompute bonuses from island size and distinct entrance countries. Integrate the versioned generator and recoverable bounded exhaustion. Keep old-version generation available for supported saves.
- **Done when**:
  1. `npx vitest run tests/core/geographic-board.test.ts` — independently reconstructed shared-border and sea-edge sets equal declared adjacency; route endpoints/crossings, degrees, bonuses and each fairness invariant pass.
  2. `node docs/prototypes/new-game/T35/sweep.mjs` — seeds 0..99 meet the T24 approved success/attempt budget; retain counts, exact failing seeds and deterministic board/deal/RNG hashes including exhaustion.
  3. `npm test` and `npm run build` pass; affected pinned browser suites pass without weakening existing assertions. Retain measured outputs, screenshots where applicable, commands and hashes in the owned evidence path; report negative-before/positive-after checks and exact restoration.
- **Hazards**: Do not connect distant countries merely to satisfy counts or silently replace failed seeds. A topology change can change bonuses and strategic chokepoints. Main session preflights acceptance before dispatch; unresolved design conflicts stop implementation, never weaken a Done-when.



The brief is the task file pasted in full, then this block, then on a rework round the review's URL.
The `implementer` agent file repeats the run mechanics; this block is the contract, for the main
session implementing directly as much as for the subagent. A line that needs the user's machine outside the
worktree, or a cloud session, is the main session's (L26).

```text
You implement <T<nn>>. The task file above is the contract.
- Build only what the task asks for, even inside a file it requires; say why for each changed file. (L44)
- A Done-when you cannot meet: stop and report. Never weaken an assertion, skip a test or edit the task file.
- **Constraint-feasibility probe** (when the task names structural constraints and a target success
  rate): before any algorithmic change, run a small smoke test that confirms the constraint
  set alone is feasible at the target rate (often a wide-seed sweep of the existing generator
  body, plus the new constraints, with no algorithmic rewrite). If the probe shows the target
  is unreachable, STOP and report. Do not weaken a constraint to make the algorithm pass
  (rule 5); the user prefers a design amendment (preferred) over a quieter relaxation, and
  the probe surfaces the conflict one round earlier than a full implementation.
- Every new test fails before your change and passes after it; say how you checked.
- Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
  restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
  a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
  copy inside your worktree (`<file>.saved`, deleted afterwards) or in a `mktemp -d` folder under
  `/tmp`, never as a loose file elsewhere.
- If you measure: every output a finding or the PR may cite goes under a tracked path the task owns,
  pushed per batch and every 30 min, never deleted or overwritten; originals out, hashes recorded. (L40)
- A comment that asserts behaviour at an edge comes with the test that visits that edge.
- A defect you find outside the task: report it. A one-file mechanical fix that blocks you may
  ride this PR, declared under Scope in the PR body.
- Update any document your change makes wrong, in this PR. Never write status into a document.
- PR body: Closes #<issue>; Scope (files and why); a fenced block with each Done-when command and
  the tail of its output; Docs changed.
```


Concrete dispatch: implement T35 in /home/diego/projects/malpaco/.cache/t35-work, existing branch and PR160. Read worktree CLAUDE/process/latest RUN-NOTES first. Owner explicitly chose native Sol Medium implementers and Claude reviewers. Choice recorded before dispatch on PR160. No other worktree edits.
Parent-frozen acceptance tests/core/geographic-board.test.ts SHA2568bcf16370bc0807d0abb636bcec191b2018a630f20f46fc722855f05dabf5836, acceptance.mjs f622ee83946858e37ed416e566e938134884a24c18c13962f6903b5a41edade7 and sweep.mjs02327e1aae7e4219ab8f13399c294b46f2ae3a69720b0d82a8606d70be50a6e4. Never edit these or task file. Parent already preflighted absent negative and disposable positive (12 focused/618 units+6 harness/build/100seed/24 pinned browser) with exact restoration; archived at evidence/parent-preflight-20261018, loose original folders retained. Current main merged at858a4ff; only T35 owned paths differ. Root and other worktrees contain protected dirty files and evidence; do not touch them or clean/reset/stash/prune.
Use the proven simple conversion, no new topology/routing algorithm required. For feasible implementation examples inspect immutable mock-production.tar.gz within docs/prototypes/new-game/T35/evidence/mock-driver-vas799at/ and parent receipt. Parent probe was successful for broad accepted T34 family, not merely old narrow family. Keep geometry integers Q2048, one global 50 attempt budget, honest failure records, and continued actual RNG object through geography/deal/centres. Avoid using child routes only as sidecar while map seaLanes disagree. Support explicit geographic/1+victory/1+actionSchema2 alongside existing identities; unknown tuples rejected; old saves/fixtures unchanged. No default UI/rendering change (T36). Production/shared-RNG seam, conversion, version dispatch only; docs/spike update.
Before algorithmic change run bounded current-parent feasibility smoke from frozen snapshot or already retained diagnostic and record exact unchanged constraints; no algorithm rewrite necessary. New behavior tests need fail-before/pass-after evidence (absent failure retained; add narrowly meaningful tests only where needed). Run every Done-when with retained wrappers, plus pinned compatibility suites specified README. All measured originals kept, full source snapshots/hash verified, fresh output directories. Avoid committing hundreds of duplicate loose dumps: create verified lossless archives/parts <=25MB and manifest, preserve loose originals locally. Historical archival source snapshots are inert; label them accordingly. Update README to remove stale Proposal/UNEXECUTED annotations only for live newly executed top-level helpers if needed; frozen acceptance bytes cannot change so document header history instead.
All commits [skip ci], push each. No CI dispatch, paid review, merge, GitHub comments or label changes yourself. Update existing PR160 body with final Scope/commands+output tails/Docs changed using --body-file. Send parent a full final with commit IDs, exact retained outputs/hashes, all DW results, timing, files/reasons, risks/limitations and follow-ups. Stop/report any impossible criterion. Parent handles review/CI/delivery.
