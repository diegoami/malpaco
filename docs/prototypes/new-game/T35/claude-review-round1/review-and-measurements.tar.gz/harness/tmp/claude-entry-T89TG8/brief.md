T69 review (Claude)
You review PR #1 at 5a477d7078a6e75a1b7afbfb476237cc53937844.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
