T35 review (Claude Sonnet High)
You review PR #160 at caed7b2938936673ddc156c79a2716b4f1454d8f. You did not write it. The task file follows.
0. Prove the tree: HEAD is <sha> and the diff against origin/main is the PR's; findings name its files.
1. Re-run every Done-when line yourself, and account for each (L32). The PR's evidence is no proof.
2. [evidence-driven] Every constant traces to a fixture, report or investigation; a [designed] one says what was searched.
3. [seeded] No wall clock, unseeded random or order-dependent iteration in rule code.
4. Every changed file and behaviour is one the task asks for (L44); docs it makes wrong are updated.
5. Sweep the diff: tests that pass with the behaviour deleted (mutate, rebuild clean, re-take any
   negative result), branches no input reaches, edge comments without a test, RNG continuation, integer geometry, complete map/sidecar equality, sea adjacency, bonuses and save identity dispatch.
   Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
   restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
   a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
   copy inside your worktree (`<file>.saved`, deleted afterwards) or in a `mktemp -d` folder under
   `/tmp`, never as a loose file elsewhere.
6. Apply Blocking means and the one-pass section below.
Prove each finding (run it, or delete the behaviour and name the test that fails) or label it
unverified. Your final message is the review: the header; the verdict (approve | approve after
named fixes | rework | user decision); per Done-when line `DW<k>: ran <command> → <result>` or
`DW<k>: not run — <reason>`; the findings R1..Rn (file:line, blocking or not); the verdict again
last. Never post it: the script posts it and applies the label.

# T35 Sea crossings, bonuses and fair complete boards

- **Kind**: slice
- **Issue**: #80 · **Branch**: `task/T35-sea-crossings-bonuses-and-fair-complete-boards` · **Merge after**: T34.
- **Difficulty**: Very hard; estimate, not a model assignment.
- **Implementer**: owner-selected under rule 6; use an isolated worktree and record the choice before dispatch.
- **Reviewer**: owner-selected OpenCode model of another family under rule 6; record the choice before review.
- **Evidence**: [pinned core-rules design](https://github.com/diegoami/isle-wars-archaeology/blob/ae298e37c2f5177039e55767607f9345b6cb0e7a/design/core-rules.md), owner roadmap accepted 2026-10-15, and upstream task evidence. T23 resolves source anchors; new constants need citations or explicit [designed] provenance.
- **Owns**: src/core/**; tests/core/**; docs/prototypes/new-game/T35/**; docs/spike.md; append-only RUN-NOTES.md.
- **Scope**: Complete T34's joint coast/entrance construction with 14–18 ordinary inter-island edges and routes satisfying the owner-approved T62 attachment/traceability contract. Repair placement, entrance coasts and ports together rather than forcing long bypasses around frozen countries. Enforce degree 2–5, connected country/island graphs and all existing fairness rules. Recompute bonuses from island size and distinct entrance countries. Integrate the versioned generator and recoverable bounded exhaustion. Keep old-version generation available for supported saves.
- **Done when**:
  1. `npx vitest run tests/core/geographic-board.test.ts` — independently reconstructed shared-border and sea-edge sets equal declared adjacency; route endpoints/crossings, degrees, bonuses and each fairness invariant pass.
  2. `node docs/prototypes/new-game/T35/sweep.mjs` — seeds 0..99 meet the T24 approved success/attempt budget; retain counts, exact failing seeds and deterministic board/deal/RNG hashes including exhaustion.
  3. `npm test` and `npm run build` pass; affected pinned browser suites pass without weakening existing assertions. Retain measured outputs, screenshots where applicable, commands and hashes in the owned evidence path; report negative-before/positive-after checks and exact restoration.
- **Hazards**: Do not connect distant countries merely to satisfy counts or silently replace failed seeds. A topology change can change bonuses and strategic chokepoints. Main session preflights acceptance before dispatch; unresolved design conflicts stop implementation, never weaken a Done-when.

## Blocking means
Any one is enough; a blocking finding means rework.
1. A Done-when fails or cannot be run as written.
2. Accepted maps disagree with actual geography/adjacency/sea routes/bonuses or breach unchanged T24/T62 constraints; generator failures publish boards, lose failure history or exceed one global 50-attempt budget; RNG restarts instead of continuing through geography and deal; old saves change identity or cannot replay.
3. Unseeded randomness, fractional geometry in core, uncited constants, production UI/default change (reserved for T36), unrelated scope, weakened existing assertions, or acceptance surviving omission of its claimed behavior.
4. Incomplete inspection of changed executable files, or missing replay/refusal/compatibility checks required by DW.
Not blocking: wording/style, inherited unchanged defects, and unlikely issues a later run exposes loudly (rule22). T34 #157 lower-degree mutation boundary and artifact-index verifier enhancements are known unchanged follow-ups; T35 actual-board acceptance must still enforce every degree.

## Report every blocking finding in this one review

This review is your only pass before the author fixes. Do not stop at the first blocking
finding: finish reading the whole diff and the task file, check every Done-when line and
every item under "Blocking means", and report all blocking findings together.

- Before you write the verdict, make one last pass over the full diff for anything you have
  not yet rated, and say "Final pass done" as the last line before the verdict.
- Number the findings R1, R2, … in order of severity. A finding you held back because an
  earlier one was already blocking is a review defect: if two problems share a cause, list
  both and say so.
- Do not rely on a later round. The author fixes everything you list, and the next review
  checks those fixes and new code only, not anything you saw but did not report.
- If you ran out of time or context before covering the whole diff, say which files or
  sections you did not cover. Do not approve in that case.

Out of your depth: stop and hand back, with an ESCALATE block, when any of these happens:
two hypotheses for the same question have failed; you would rely on bytes, code or behaviour
you cannot explain; you are about to write a claim you cannot back with evidence; or you have
made three attempts at one step without progress. Push your branch first. The ESCALATE block
gives what you tried, the evidence so far, and the exact question you could not answer. Never
guess a format or a cause.

Practical review scope and commands:
- Inspect every changed live source/test/helper first; use full local diff/inventory, not GitHub oversized diff. Top-level T35 acceptance/sweep carry historical Proposal/UNEXECUTED headers; the immutable parent-preflight archive and current receipts document execution without altering frozen assertion bytes. Historical candidate snapshots/archives are inert evidence, not current executable implementation. Audit published manifests and sample actual outcomes; parent verifies all archival member hashes separately. Do not rerun old feasibility.mjs or original driver paths.
- Run DW1 focused tests; DW2 actual100seed sweep once; DW3 npm test/build and pinned affected browser suites via T35 run-browser.py: tests/e2e/reference-complete-game.spec.ts,tests/e2e/reference-game.spec.ts,tests/e2e/versioned-match.spec.ts,tests/e2e/entry.spec.ts. Core conversion/version dispatch changes justify these compatibility cases. No full222 browser sweep is needed before CI. Never weaken frozen acceptance.
- Prefer a few behavior-omission controls covering actual RNG continuation, sea adjacency/bonuses and explicit geographic save dispatch. Restore saved bytes in finally. Redundant code clauses do not each need independent tests when removing one does not bypass behavior.
- Verify exact actual claude-sonnet-5-5, High effort. No subagents, publication, global settings or external downloads. Worktree has installed dependencies; no npx missing-package installs. Keep scratch/evidence in your retained worktree; never reset/restore/stash/prune or touch inherited worktrees.
- Coverage final: each inspected live or executable helper uses standalone FILE: exact/path. EVIDENCE: docs/prototypes/new-game/T35/ can cover generated known-suffix data. Every multipart archive part (.part01 through the last numbered part) requires a standalone FILE line after inspecting corresponding receipt/hashes; state that parent independently verifies full archive. Do not claim reading all archival source snapshots. SCOPE: complete only after actual full current-code coverage. Every DW1..DW3 must account for every command including browsers; Final pass done before closing verdict.

Retained producer observation: one initial pinned run passed23/24, with the1920x1080 recognized-entry old prototype route absent after5000ms while build and seed sweep overlapped. Exact unchanged24 passed sequentially1.7min; source/assertions unchanged and cause not established. Inspect retained failure honestly and rerun24 independently; do not assume a flake or weaken timeouts.

Parent checked implementation.json; actual route counts are14/15 within14–18, not the producer final-message typo saying all15. Frozen acceptance hashes match.


---
OUTPUT RULES (from tools/harness/review.mjs; they override anything above that conflicts):
- Do not post to GitHub, commit, push, label or merge anything. The script posts your review.
  Edit nothing, but for a mutation made in place in your worktree and never committed.
  Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
  restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
  a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
  copy inside your worktree (`<file>.saved`, deleted afterwards) or in your own folder under
  `/tmp/opencode/`. Outside your worktree, write only under `/tmp/opencode/` (a
  `mktemp -d /tmp/opencode/mlp-review-XXXXXX` folder is the tidiest, removed afterwards; the reviewer
  agent file allows nothing else). Every other path outside your worktree is forbidden.
- Your final message is the review and nothing else. Line 1 is exactly: T35 review (Claude Sonnet High)
  Line 2 is the verdict, alone on its line: approve, approve after named fixes, rework, or user
  decision. Then any where-I-worked lines (worktree, HEAD, diff, the commands you ran), then the
  findings (R1, R2, ... with file and line, blocking or not), then the verdict again as the very
  last line. Nothing comes after it.
- A finding you proved that lets a forbidden action or a wrong result past what the task protects
  is blocking, and blocks an approve: never "follow-up hardening" or "outside the threat model"
  unless the task's text says so (L47).
- Report every blocking finding in this one review, not one per round: read the whole diff, then
  make a final pass and write "Final pass done" as the line before the closing verdict. Name any
  part you did not cover, and do not approve then (L49).
- The task has 3 Done-when lines. Right after the verdict line, account for each, one
  line per Done-when line, DW1 to DW3: "DW<k>: ran <command> → <result>", or
  "DW<k>: not run — <reason>". An approve with one missing, or one not run, is not applied. A review that does not end with its verdict, or that has a
  finding after it, is posted flagged and acted on by no one until the main session reads it.
- Your worktree is /home/diego/projects/malpaco/.cache/t35-claude-review/160-review-3f46a03e at caed7b2938936673ddc156c79a2716b4f1454d8f, and it is already your working directory. Run git
  there without -C, and never type that path: a mistyped path ends the run. This rule is about
  your own worktree only (L61): a Done-when line may send git at a pinned repository outside it
  (git -C <path> show <pin>:<file>); run that exactly as written — OpenCode does not path-check
  git -C — and read a granted outside path only with the L59 recipe.

CLAUDE BACKEND CONTRACT: The exact PR base is 3b57a08dd8b4ee641a47ec3b3809cc0d17310e55, head caed7b2938936673ddc156c79a2716b4f1454d8f. Do not use origin/main for a merged PR. Complete local diff: /home/diego/projects/malpaco/.cache/review-evidence/pr160-b299b31418c1/full.diff; bounded parts: /home/diego/projects/malpaco/.cache/review-evidence/pr160-b299b31418c1/diff-parts; full changed-file inventory: /home/diego/projects/malpaco/.cache/review-evidence/pr160-b299b31418c1/inventory.json. Read all executable changes. For generated evidence you may audit a group explicitly. Never claim a file you did not inspect. Before Final pass done, emit SCOPE: complete only if you covered all changes; otherwise SCOPE: incomplete plus UNCOVERED: paths/reasons. Emit FILE: <exact path> for each changed file inspected; EVIDENCE: <docs/prototypes/.../ prefix> may account for generated evidence only, never executable scripts. These are coverage claims, not independent proof. Every Done-when must be run; include exact DW lines. A missing scope acknowledgment prevents approval. No subagents or GitHub writes. Native Claude permission denials mirror OpenCode publishing restrictions; the trusted hook protects credential paths for Read/Grep/Glob. Bash is granted for tests and in-tree mutations. These are mistake safeguards, not an OS sandbox. Preserve scratch/evidence; do not clean up. Ignore obsolete OpenCode-only path restrictions above: your scratch is your retained worktree. No blanket permission bypass.

The read-only contract overrides the tripwire instruction to push: never push.
Out of your depth: stop and hand back, with an ESCALATE block, when any of these happens:
two hypotheses for the same question have failed; you would rely on bytes, code or behaviour
you cannot explain; you are about to write a claim you cannot back with evidence; or you have
made three attempts at one step without progress. Push your branch first. The ESCALATE block
gives what you tried, the evidence so far, and the exact question you could not answer. Never
guess a format or a cause.
