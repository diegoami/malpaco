import {it,expect} from 'vitest';
import {createGeographicGame} from '../../src/core/geographic-game';
import {defaultOptions} from '../../src/core/options';
import {deserializeVersionedMatch} from '../../src/core/match-save';
import {generateGeographicBoard} from '../../src/core/geographic-board';
it('option variants',()=>{
  const bad:any[]=[];let n=0;
  const d:any=defaultOptions();
  const seatsets=[ [ {kind:'human'},{kind:'computer'} ], [{kind:'human'},{kind:'human'},{kind:'computer'},{kind:'computer'}], [{kind:'computer'},{kind:'computer'},{kind:'computer'}] ];
  console.log(JSON.stringify(d.seats), JSON.stringify(d.computerStrengths));
  for(let seed=0;seed<40;seed++)for(const hs of [-4,0,4])for(const r of ['1-2','1-4'])for(const seats of [d.seats]){
    const o={...d,seed,humanShare:hs,startingArmiesRange:r};n++;
    const g=createGeographicGame(o);
    if(!g.ok)bad.push([seed,hs,r,(g as any).errors]);
  }
  console.log('variants',n,'bad',bad.length,JSON.stringify(bad.slice(0,5)));
  const b=generateGeographicBoard(3);if(b.ok)console.log('provinces',b.map.provinces.length,b.map.islands.length);
},300000);
it('refusals',()=>{
  const base=(bg:any,rules:any,sch:any)=>JSON.stringify({format:'malpaco-match',version:2,boardGenerator:bg,rules,actionSchemaVersion:sch,options:defaultOptions(),actions:[]});
  const tryit=(l:string,t:string)=>{try{const r=deserializeVersionedMatch(t);console.log(l,'LOADED',r.identity.boardGenerator.id);}catch(e:any){console.log(l,'refused',e.message);}};
  tryit('geo/malpaco',base({id:'geographic',version:1},{id:'malpaco',version:1},2));
  tryit('geo/victory/schema1',base({id:'geographic',version:1},{id:'victory',version:1},1));
  tryit('geo+extra key',base({id:'geographic',version:1,x:1},{id:'victory',version:1},2));
  tryit('fixed/victory/2',base({id:'fixed-reference',version:1},{id:'victory',version:1},2));
  tryit('geo ok',base({id:'geographic',version:1},{id:'victory',version:1},2));
  tryit('unknown',base({id:'generated',version:1},{id:'victory',version:1},2));
});
