# Generated geographic integration acceptance

This directory retains parent preflight candidates and measurements. The generator
algorithm and approved T24 limits are unchanged. `sweep.mjs` extends the measured
range to 0..999 plus the separate seed-1994 diagnostic, comparing two fresh complete
game replays and actual standalone board output. Full rejected candidates stay in
per-seed evidence files; lightweight metrics drive the representative corpus.

`corpus-selection.json` is the static browser fixture. During preparation it is
explicitly unmeasured; replace it only with the exact manifest of a passing measured
run, retaining report/source provenance. Normal and extracted-artifact browser
acceptance need no GEOGRAPHIC_CORPUS_FILE variable.

`parent-preflight/baseline` stores initial bytes and hashes. `source-state.py capture`
archives candidate source/tests/docs; `restore-baseline` restores saved production
bytes and removes only the three explicitly owned new source files, while keeping
acceptance/evidence and append-only notes. Never restore with Git reset/checkout.
Original proposal revisions are inert historical snapshots under parent-preflight.

Before freezing, verify real geometry/input/label paint, identity-aware replay and
T70 continuity at both desktop viewports. The geographic count baseline is labelAt
center plus five units; badge center and the 40px input probe use the actual source
labelAt center. This reconciles the draft with the existing reference font offset
without changing any approved geometry/hit/count/contrast constraint.

The mounted setup and pure refusal controller preserve typed result metadata. The
product alert presents an actionable generation failure and retry/change-seed
instruction. It deliberately does not dump fifty numeric constraint histories to
the player. Every refusal class/candidate remains in the sweep evidence; tests
check full typed reporting and real mounted-form retry/no-partial-mount behavior.
