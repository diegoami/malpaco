T69 review (Claude)
You review PR #1 at bbe55e2c223b89d4660f5887f4c74c1151303bc6.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
