import fs from 'node:fs';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {claudeSettings,runClaudeWatched,resolveClaude} from '../../tools/harness/lib/claude.mjs';
const root=process.cwd(),base=fs.mkdtempSync(path.join(root,'.cache/t36-dispatch/unlink-probe-'));
const prior=fs.readFileSync(path.join(root,'.cache/review-evidence/pr162-e839bfeeb4a0/stdout.jsonl'),'utf8').trim().split('\n').map(x=>JSON.parse(x));
const exact=prior.find(x=>x.type==='result').permission_denials[0].tool_input.command;
const outcomes=[];
for(const name of ['owned-directory']){
 const dir=path.join(base,name),work=path.join(dir,'work'),evidence=path.join(dir,'evidence');fs.mkdirSync(work,{recursive:true});fs.mkdirSync(evidence);
 fs.mkdirSync(path.join(work,'node_modules'));
 const settings=claudeSettings(path.join(root,'tools/harness/guard.mjs'));
 if(name==='exact-grant')settings.permissions.allow.push('Bash(rm node_modules)');
 const settingsPath=path.join(dir,'settings.json');fs.writeFileSync(settingsPath,JSON.stringify(settings,null,2));
 const id=randomUUID(),prompt='Permission regression probe, authorized by the repository owner\'s workflow repair. Your cwd contains only this newly created trial-owned node_modules symlink. Execute the EXACT following command as ONE Bash tool call, with no other tools/commands or cleanup. It only reads Git then removes this trial-owned symlink, and must never remove its target. Do not change the command. Return succeeded or denied, honestly.\n'+exact;
 fs.writeFileSync(path.join(evidence,'prompt.md'),prompt);
 let failure=null;
 try{await runClaudeWatched({command:resolveClaude(),args:['-p',prompt,'--model','claude-sonnet-5-5','--effort','medium','--setting-sources','','--settings',settingsPath,'--permission-mode','dontAsk','--permission-prompts','none','--tools','Bash','--strict-mcp-config','--disable-slash-commands','--no-chrome','--verbose','--output-format','stream-json','--session-id',id],workDir:work,evidenceDir:evidence,model:'claude-sonnet-5-5',sessionId:id,totalTimeoutMs:150000,idleTimeoutMs:90000,log:s=>process.stdout.write(name+': '+s+'\n')});}catch(e){failure=e.message;}
 const events=fs.readFileSync(path.join(evidence,'stdout.jsonl'),'utf8').trim().split('\n').filter(Boolean).map(x=>JSON.parse(x));
 const calls=events.flatMap(x=>Array.isArray(x.message?.content)?x.message.content:[]).filter(x=>x.type==='tool_use');
 const row={name,sessionId:id,failure,linkRemoved:!fs.existsSync(path.join(work,'node_modules')),targetStillDirectory:fs.statSync(path.join(root,'node_modules')).isDirectory(),exactSingleBashCall:calls.length===1&&calls[0].name==='Bash'&&calls[0].input.command===exact};outcomes.push(row);console.log(JSON.stringify(row));
}
fs.writeFileSync(path.join(base,'outcomes.json'),JSON.stringify(outcomes,null,2));console.log(JSON.stringify({probe:base,outcomes}));
