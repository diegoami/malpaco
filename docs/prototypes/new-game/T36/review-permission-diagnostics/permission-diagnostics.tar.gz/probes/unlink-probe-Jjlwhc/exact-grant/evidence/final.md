**Denied.** I ran the exact command as one Bash call. Claude Code is in "don't ask" mode, and it refused permission to use Bash. Nothing ran, so the git diff checks did not execute and the `node_modules` symlink was not removed.

I haven't tried any workaround. If you want the probe to run, change the permission mode or allow this command, then tell me to retry.