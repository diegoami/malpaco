@echo off
cd /d "%~dp0malpaco-playable"
node serve.mjs --port 4176
pause
