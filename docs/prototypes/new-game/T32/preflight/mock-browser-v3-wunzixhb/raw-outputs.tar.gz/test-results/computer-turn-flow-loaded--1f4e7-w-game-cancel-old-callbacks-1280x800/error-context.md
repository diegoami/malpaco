# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: computer-turn-flow.spec.ts >> loaded computer capture resolves without a click; replacement and new game cancel old callbacks
- Location: tests/e2e/computer-turn-flow.spec.ts:27:1

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 2 human seats · Seed 1994
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]: 23 provinces · 57 armies
      - generic [ref=e16]:
        - generic [ref=e17]: Seat 2
        - generic [ref=e18]: 23 provinces · 58 armies
    - contentinfo [ref=e19]:
      - button "New game" [ref=e20] [cursor=pointer]
    - generic [ref=e21]:
      - button "Save game" [active] [ref=e22] [cursor=pointer]
      - generic [ref=e23]:
        - generic [ref=e24]: Load game
        - button "Load game" [ref=e25]
  - main [ref=e26]:
    - img "Nine Isles reference map" [ref=e28]:
      - button "River gate, Seat 1, 4 armies" [ref=e53] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: 1 · 4
      - button "New port, Seat 2, 3 armies" [ref=e55] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: 2 · 3
      - button "North rest, Seat 1, 1 armies" [ref=e57] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: 1 · 1
      - button "River keep, Seat 2, 2 armies" [ref=e59] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: 2 · 2
      - button "North town, Seat 1, 2 armies" [ref=e61] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: 1 · 2
      - button "Dark ford, Seat 2, 2 armies" [ref=e63] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: 2 · 2
      - button "Iron point, Seat 1, 2 armies" [ref=e65] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: 1 · 2
      - button "South rest, Seat 2, 3 armies" [ref=e67] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: 2 · 3
      - button "High shore, Seat 1, 1 armies" [ref=e69] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: 1 · 1
      - button "Wind town, Seat 1, 2 armies" [ref=e71] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: 1 · 2
      - button "New glen, Seat 2, 3 armies" [ref=e73] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: 2 · 3
      - button "Old rock, Seat 1, 2 armies" [ref=e75] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: 1 · 2
      - button "Blue peak, Seat 1, 4 armies" [ref=e77] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: 1 · 4
      - button "West haven, Seat 1, 3 armies" [ref=e79] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: 1 · 3
      - button "Stone watch, Seat 1, 2 armies" [ref=e81] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: 1 · 2
      - button "Upper ridge, Seat 2, 2 armies" [ref=e83] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: 2 · 2
        - generic [ref=e85]: ★
      - button "Marsh keep, Seat 2, 2 armies" [ref=e86] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: 2 · 2
      - button "New fell, Seat 2, 3 armies" [ref=e88] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: 2 · 3
      - button "Moon point, Seat 1, 1 armies" [ref=e90] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: 1 · 1
      - button "South fell, Seat 2, 2 armies" [ref=e92] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: 2 · 2
      - button "High ridge, Seat 1, 2 armies" [ref=e94] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: 1 · 2
      - button "Bay ford, Seat 1, 3 armies" [ref=e96] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: 1 · 3
      - button "Low moor, Seat 2, 3 armies" [ref=e98] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: 2 · 3
      - button "Lower field, Seat 2, 2 armies" [ref=e100] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: 2 · 2
        - generic [ref=e102]: ★
      - button "Wind gate, Seat 1, 4 armies" [ref=e103] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: 1 · 4
      - button "Silver shore, Seat 2, 2 armies" [ref=e105] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: 2 · 2
      - button "Low peak, Seat 1, 2 armies" [ref=e107] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: 1 · 2
      - button "Wind port, Seat 2, 2 armies" [ref=e109] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: 2 · 2
      - button "Gold point, Seat 1, 4 armies" [ref=e111] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: 1 · 4
      - button "Rock moor, Seat 2, 4 armies" [ref=e113] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: 2 · 4
      - button "Marsh rest, Seat 1, 3 armies" [ref=e115] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: 1 · 3
      - button "Wind dale, Seat 2, 3 armies" [ref=e117] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: 2 · 3
      - button "Silver ford, Seat 2, 2 armies" [ref=e119] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: 2 · 2
      - button "Iron field, Seat 2, 1 armies" [ref=e121] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: 2 · 1
      - button "North wood, Seat 2, 2 armies" [ref=e123] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: 2 · 2
      - button "Fort town, Seat 1, 3 armies" [ref=e125] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: 1 · 3
      - button "Red field, Seat 1, 2 armies" [ref=e127] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: 1 · 2
      - button "South ridge, Seat 2, 4 armies" [ref=e129] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: 2 · 4
      - button "Rock bay, Seat 1, 4 armies" [ref=e131] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: 1 · 4
      - button "North ford, Seat 2, 3 armies" [ref=e133] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: 2 · 3
      - button "Port ridge, Seat 1, 3 armies" [ref=e135] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: 1 · 3
      - button "New rock, Seat 2, 3 armies" [ref=e137] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: 2 · 3
        - generic [ref=e139]: ★
      - button "South reach, Seat 1, 2 armies" [ref=e140] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: 1 · 2
      - button "Silver point, Seat 1, 1 armies" [ref=e142] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: 1 · 1
      - button "East ford, Seat 2, 2 armies" [ref=e144] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: 2 · 2
      - button "Gold town, Seat 2, 3 armies" [ref=e146] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: 2 · 3
      - generic [ref=e178]: North Isle +3
      - generic [ref=e179]: East Isle +3
      - generic [ref=e180]: West Isle +3
      - generic [ref=e181]: South Isle +3
      - generic [ref=e182]: Central Isle +5
      - generic [ref=e183]: Harbor Isle +5
      - generic [ref=e184]: Palm Isle +6
      - generic [ref=e185]: Cliff Isle +5
      - generic [ref=e186]: Great Isle +9
    - complementary [ref=e187]:
      - generic [ref=e191]:
        - generic [ref=e192]: Seat 2's turn
        - generic [ref=e193]: Round 1 · Reinforcement
      - generic [ref=e194]:
        - generic [ref=e195]:
          - generic [ref=e196]:
            - generic [ref=e197]: Province income
            - strong [ref=e198]: "7"
          - generic [ref=e199]:
            - generic [ref=e200]: Island income
            - strong [ref=e201]: "0"
          - generic [ref=e202]:
            - generic [ref=e203]: Armies to place
            - strong [ref=e204]: "6"
        - paragraph [ref=e205]: Place your armies on your countries, then start combat.
        - generic [ref=e206]:
          - button "Start combat" [disabled] [ref=e207]
          - button "End turn" [disabled] [ref=e208]
      - generic [ref=e209]:
        - heading "Battle log" [level=3] [ref=e210]
        - list "Battle log"
```

# Test source

```ts
  1  | import { expect, test } from "@playwright/test";
  2  | import type { Page } from "@playwright/test";
  3  | import { mkdirSync, mkdtempSync, readFileSync } from "node:fs";
  4  | import { join } from "node:path";
  5  | import { activePlayer, apply } from "../../src/core";
  6  | import type { GameState } from "../../src/core";
  7  | import { deserializeVersionedMatch, serializeVersionedMatch, REFERENCE_MATCH_IDENTITY } from "../../src/core/match-save";
  8  | import { pinned } from "../core/versioned-match-fixture";
  9  | async function save(page:Page){const p=page.waitForEvent("download");await page.getByRole("button",{name:"Save game",exact:true}).click();return readFileSync((await (await p).path())!,"utf8");}
  10 | async function load(page:Page,text:string){await page.getByLabel("Load game",{exact:true}).setInputFiles({name:"resume.json",mimeType:"application/json",buffer:Buffer.from(text)});await expect(page.locator("[data-country]")).toHaveCount(46);}
  11 | async function begin(page:Page){await page.clock.install();await page.clock.pauseAt(new Date());await page.goto("/?view=reference-game");}
  12 | async function capture(page:Page,name:string,project:string){const dir=process.env["COMPUTER_FLOW_EVIDENCE_DIR"]??"screenshots";mkdirSync(dir,{recursive:true});expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);await page.screenshot({path:join(mkdtempSync(join(dir,"flow-")),`${name}-${project}.png`)});}
  13 | function computerCapture(){const f=pinned("human-loss");let s=deserializeVersionedMatch(serializeVersionedMatch(f.options,[],REFERENCE_MATCH_IDENTITY)).state;for(const a of f.actions){const r=apply(s,a);if(!r.ok)throw Error(r.error);s=r.state;if(s.phase==="capture"&&activePlayer(s)!.kind==="computer")return serializeVersionedMatch(f.options,s.history,REFERENCE_MATCH_IDENTITY);}throw Error("No computer capture");}
  14 | async function runToHuman(page:Page){for(let i=0;i<400;i++){if(await page.locator("#reference-computer-status").isHidden())return;await page.clock.runFor(525);}throw Error("Computer did not hand back control");}
  15 | 
  16 | test("untouched setup starts one human and three Normal computers and consecutive turns return",async({page},info)=>{
  17 |  await begin(page);await expect(page.locator("#reference-seats")).toHaveValue("4");for(let i=1;i<=4;i++)await expect(page.getByLabel(`Seat ${i} control`)).toHaveValue(i===1?"human":"computer");
  18 |  await page.getByRole("button",{name:"Start game",exact:true}).click();let text=await save(page),loaded=deserializeVersionedMatch(text),s=loaded.state;
  19 |  expect(loaded.options.computerStrengths).toEqual(["Normal","Normal","Normal"]);expect(loaded.options.seats.map(p=>p.kind)).toEqual(["human","computer","computer","computer"]);
  20 |  await runToHuman(page);s=deserializeVersionedMatch(await save(page)).state;expect(activePlayer(s)!.kind).toBe("human");const priorHandoffs=s.history.filter(a=>a.kind==="endTurn"||a.kind==="friendlyMove").length;
  21 |  const own=s.map.provinces.find(p=>s.ownerOf[p.id]===activePlayer(s)!.id)!.id;
  22 |  for(let i=0;i<s.reinforcementPool;i++)await page.locator(`[data-country="${own}"]`).press("Enter");await page.locator("#start-combat-button").click();await page.locator("#end-turn-button").click();
  23 |  await expect(page.locator("#reference-computer-status")).toBeVisible();await expect(page.locator("#end-turn-button")).toBeDisabled();await capture(page,"computer-turn",info.project.name);
  24 |  const during=await save(page);await page.locator(`[data-country="${own}"]`).press("Enter");await page.keyboard.press("Escape");expect(await save(page)).toBe(during);
  25 |  await runToHuman(page);s=deserializeVersionedMatch(await save(page)).state;expect(activePlayer(s)!.kind).toBe("human");expect(s.currentPlayer).toBe(0);expect(s.history.filter(a=>a.kind==="endTurn"||a.kind==="friendlyMove")).toHaveLength(priorHandoffs+4);await capture(page,"human-return",info.project.name);
  26 | });
  27 | test("loaded computer capture resolves without a click; replacement and new game cancel old callbacks",async({page},info)=>{
  28 |  await page.addInitScript(()=>{const original=window.setTimeout.bind(window);const callbacks:(()=>void)[]=[];Reflect.set(window,"oldComputerCallbacks",callbacks);window.setTimeout=((fn:TimerHandler,delay?:number,...args:unknown[])=>{if(typeof fn==="function"&&[175,350,525].includes(delay??0))callbacks.push(fn as ()=>void);return original(fn,delay,...args);}) as typeof window.setTimeout;});
  29 |  await begin(page);const pending=computerCapture();await load(page,pending);await expect(page.locator("#confirm-capture-button")).toBeDisabled();await capture(page,"pending-computer",info.project.name);
  30 |  const before=deserializeVersionedMatch(pending).state.history.length;await page.clock.runFor(350);let s=deserializeVersionedMatch(await save(page)).state;expect(s.history[before]?.kind).toBe("captureMove");await runToHuman(page);
  31 |  await load(page,pending);const restored=pinned("placement").text;await load(page,restored);const fresh=await save(page);
> 32 |  expect(await page.evaluate(()=>(Reflect.get(window,"oldComputerCallbacks") as unknown[]).length)).toBeGreaterThan(0);
     |                                                                                                    ^ Error: expect(received).toBeGreaterThan(expected)
  33 |  await page.evaluate(()=>{for(const cb of Reflect.get(window,"oldComputerCallbacks") as (()=>void)[])cb();});await page.clock.runFor(2000);expect(await save(page)).toBe(fresh);
  34 |  await load(page,pending);await page.getByRole("button",{name:"New game",exact:true}).click();await page.evaluate(()=>{for(const cb of Reflect.get(window,"oldComputerCallbacks") as (()=>void)[])cb();});await page.clock.runFor(2000);await expect(page.getByRole("heading",{name:"New reference game",exact:true})).toBeVisible();
  35 | });
  36 | test("loss waits for Watch or Stop; finished game schedules no play; manual route stays manual",async({page},info)=>{
  37 |  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));await begin(page);await load(page,pinned("human-loss").text);const loss=await save(page);await page.clock.runFor(10000);expect(await save(page)).toBe(loss);
  38 |  await page.locator("#watch-computers-button").click();await expect(page.locator("#reference-computer-status")).toBeVisible();await page.clock.runFor(1050);expect(deserializeVersionedMatch(await save(page)).state.history.length).toBeGreaterThan(deserializeVersionedMatch(loss).state.history.length+1);
  39 |  await load(page,loss);await page.locator("#stop-game-button").click();const stopped=await save(page);await page.clock.runFor(10000);expect(await save(page)).toBe(stopped);await capture(page,"stopped",info.project.name);
  40 |  await page.goto("/?view=reference-game&control=manual");await expect(page.locator("#reference-seats")).toHaveValue("2");await load(page,computerCapture());const manual=await save(page);await page.clock.runFor(10000);expect(await save(page)).toBe(manual);await expect(page.locator("#confirm-capture-button")).toBeEnabled();expect(errors).toEqual([]);
  41 | });
  42 | 
```