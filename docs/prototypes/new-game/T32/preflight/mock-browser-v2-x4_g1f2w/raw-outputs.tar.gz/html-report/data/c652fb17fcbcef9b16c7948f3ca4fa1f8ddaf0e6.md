# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: computer-turn-flow.spec.ts >> untouched setup starts one human and three Normal computers and consecutive turns return
- Location: tests/e2e/computer-turn-flow.spec.ts:16:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('#start-combat-button')
    - locator resolved to <button disabled type="button" class="primary" id="start-combat-button">Start combat</button>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is not enabled
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is not enabled
    - retrying click action
      - waiting 100ms
    58 × waiting for element to be visible, enabled and stable
       - element is not enabled
     - retrying click action
       - waiting 500ms

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 1 human / 3 computer seats · Computer play · Seed 1994
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]: 11 provinces · 22 armies
      - generic [ref=e16]:
        - generic [ref=e17]: Seat 2 · Computer
        - generic [ref=e18]: 12 provinces · 24 armies
      - generic [ref=e22]:
        - generic [ref=e23]: Seat 3 · Computer
        - generic [ref=e24]: 12 provinces · 24 armies
      - generic [ref=e28]:
        - generic [ref=e29]: Seat 4 · Computer
        - generic [ref=e30]: 11 provinces · 22 armies
    - contentinfo [ref=e31]:
      - button "New game" [ref=e32] [cursor=pointer]
    - generic [ref=e33]:
      - button "Save game" [ref=e34] [cursor=pointer]
      - generic [ref=e35]:
        - generic [ref=e36]: Load game
        - button "Load game" [ref=e37]
  - main [ref=e38]:
    - img "Nine Isles reference map" [ref=e40]:
      - button "River gate, Seat 3, 2 armies" [ref=e65] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: 3 · 2
      - button "New port, Seat 1, 2 armies" [ref=e67] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: 1 · 2
      - button "North rest, Seat 2, 1 armies" [ref=e69] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: 2 · 1
      - button "River keep, Seat 2, 1 armies" [ref=e71] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: 2 · 1
      - button "North town, Seat 2, 1 armies" [ref=e73] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: 2 · 1
      - button "Dark ford, Seat 3, 1 armies" [ref=e75] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: 3 · 1
      - button "Iron point, Seat 3, 1 armies" [ref=e77] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: 3 · 1
      - button "South rest, Seat 3, 3 armies" [ref=e79] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: 3 · 3
      - button "High shore, Seat 1, 2 armies" [ref=e81] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: 1 · 2
      - button "Wind town, Seat 2, 3 armies" [ref=e83] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: 2 · 3
      - button "New glen, Seat 4, 2 armies" [active] [ref=e85] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: 4 · 2
      - button "Old rock, Seat 3, 2 armies" [ref=e87] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: 3 · 2
      - button "Blue peak, Seat 2, 3 armies" [ref=e89] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: 2 · 3
      - button "West haven, Seat 2, 1 armies" [ref=e91] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: 2 · 1
      - button "Stone watch, Seat 2, 3 armies" [ref=e93] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: 2 · 3
      - button "Upper ridge, Seat 4, 2 armies" [ref=e95] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: 4 · 2
      - button "Marsh keep, Seat 1, 3 armies" [ref=e97] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: 1 · 3
      - button "New fell, Seat 4, 2 armies" [ref=e99] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: 4 · 2
      - button "Moon point, Seat 2, 2 armies" [ref=e101] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: 2 · 2
      - button "South fell, Seat 1, 3 armies" [ref=e103] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: 1 · 3
      - button "High ridge, Seat 2, 2 armies" [ref=e105] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: 2 · 2
      - button "Bay ford, Seat 2, 3 armies" [ref=e107] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: 2 · 3
      - button "Low moor, Seat 1, 2 armies" [ref=e109] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: 1 · 2
      - button "Lower field, Seat 1, 1 armies" [ref=e111] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: 1 · 1
      - button "Wind gate, Seat 3, 1 armies" [ref=e113] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: 3 · 1
      - button "Silver shore, Seat 4, 1 armies" [ref=e115] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: 4 · 1
      - button "Low peak, Seat 4, 1 armies" [ref=e117] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: 4 · 1
      - button "Wind port, Seat 4, 3 armies" [ref=e119] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: 4 · 3
      - button "Gold point, Seat 3, 2 armies" [ref=e121] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: 3 · 2
        - generic [ref=e123]: ★
      - button "Rock moor, Seat 1, 2 armies" [ref=e124] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: 1 · 2
      - button "Marsh rest, Seat 3, 2 armies" [ref=e126] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: 3 · 2
      - button "Wind dale, Seat 4, 1 armies" [ref=e128] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: 4 · 1
      - button "Silver ford, Seat 4, 2 armies" [ref=e130] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: 4 · 2
      - button "Iron field, Seat 4, 2 armies" [ref=e132] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: 4 · 2
      - button "North wood, Seat 1, 1 armies" [ref=e134] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: 1 · 1
      - button "Fort town, Seat 3, 2 armies" [ref=e136] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: 3 · 2
        - generic [ref=e138]: ★
      - button "Red field, Seat 2, 3 armies" [ref=e139] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: 2 · 3
        - generic [ref=e141]: ★
      - button "South ridge, Seat 1, 2 armies" [ref=e142] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: 1 · 2
      - button "Rock bay, Seat 2, 1 armies" [ref=e144] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: 2 · 1
      - button "North ford, Seat 4, 3 armies" [ref=e146] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: 4 · 3
      - button "Port ridge, Seat 3, 3 armies" [ref=e148] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: 3 · 3
      - button "New rock, Seat 1, 1 armies" [ref=e150] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: 1 · 1
      - button "South reach, Seat 3, 3 armies" [ref=e152] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: 3 · 3
      - button "Silver point, Seat 3, 2 armies" [ref=e154] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: 3 · 2
      - button "East ford, Seat 1, 3 armies" [ref=e156] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: 1 · 3
      - button "Gold town, Seat 4, 3 armies" [ref=e158] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: 4 · 3
      - generic [ref=e190]: North Isle +3
      - generic [ref=e191]: East Isle +3
      - generic [ref=e192]: West Isle +3
      - generic [ref=e193]: South Isle +3
      - generic [ref=e194]: Central Isle +5
      - generic [ref=e195]: Harbor Isle +5
      - generic [ref=e196]: Palm Isle +6
      - generic [ref=e197]: Cliff Isle +5
      - generic [ref=e198]: Great Isle +9
    - complementary [ref=e199]:
      - generic [ref=e203]:
        - generic [ref=e204]: Seat 4's turn
        - generic [ref=e205]: Computer · Normal · Round 1 · Reinforcement
      - generic [ref=e206]:
        - generic [ref=e207]:
          - generic [ref=e208]:
            - generic [ref=e209]: Province income
            - strong [ref=e210]: "3"
          - generic [ref=e211]:
            - generic [ref=e212]: Island income
            - strong [ref=e213]: "0"
          - generic [ref=e214]:
            - generic [ref=e215]: Armies to place
            - strong [ref=e216]: "3"
        - paragraph [ref=e217]: Computer turn. Save, load or start a new game at any time.
        - generic [ref=e218]:
          - button "Start combat" [disabled] [ref=e219]
          - button "End turn" [disabled] [ref=e220]
        - status [ref=e221]: Seat 4 is playing…
      - generic [ref=e222]:
        - heading "Battle log" [level=3] [ref=e223]
        - list "Battle log"
```

# Test source

```ts
  1  | import { expect, test } from "@playwright/test";
  2  | import type { Page } from "@playwright/test";
  3  | import { mkdirSync, mkdtempSync, readFileSync } from "node:fs";
  4  | import { join } from "node:path";
  5  | import { activePlayer, apply } from "../../src/core";
  6  | import type { GameState } from "../../src/core";
  7  | import { deserializeVersionedMatch, serializeVersionedMatch, REFERENCE_MATCH_IDENTITY } from "../../src/core/match-save";
  8  | import { pinned } from "../core/versioned-match-fixture";
  9  | async function save(page:Page){const p=page.waitForEvent("download");await page.getByRole("button",{name:"Save game",exact:true}).click();return readFileSync((await (await p).path())!,"utf8");}
  10 | async function load(page:Page,text:string){await page.getByLabel("Load game",{exact:true}).setInputFiles({name:"resume.json",mimeType:"application/json",buffer:Buffer.from(text)});await expect(page.locator("[data-country]")).toHaveCount(46);}
  11 | async function begin(page:Page){await page.clock.install();await page.clock.pauseAt(new Date());await page.goto("/?view=reference-game");}
  12 | async function capture(page:Page,name:string,project:string){const dir=process.env["COMPUTER_FLOW_EVIDENCE_DIR"]??"screenshots";mkdirSync(dir,{recursive:true});expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);await page.screenshot({path:join(mkdtempSync(join(dir,"flow-")),`${name}-${project}.png`)});}
  13 | function computerCapture(){const f=pinned("human-loss");let s=deserializeVersionedMatch(serializeVersionedMatch(f.options,[],REFERENCE_MATCH_IDENTITY)).state;for(const a of f.actions){const r=apply(s,a);if(!r.ok)throw Error(r.error);s=r.state;if(s.phase==="capture"&&activePlayer(s)!.kind==="computer")return serializeVersionedMatch(f.options,s.history,REFERENCE_MATCH_IDENTITY);}throw Error("No computer capture");}
  14 | async function runToHuman(page:Page){for(let i=0;i<400;i++){if(await page.locator("#reference-computer-status").isHidden())return;await page.clock.runFor(525);}throw Error("Computer did not hand back control");}
  15 | 
  16 | test("untouched setup starts one human and three Normal computers and consecutive turns return",async({page},info)=>{
  17 |  await begin(page);await expect(page.locator("#reference-seats")).toHaveValue("4");for(let i=1;i<=4;i++)await expect(page.getByLabel(`Seat ${i} control`)).toHaveValue(i===1?"human":"computer");
  18 |  await page.getByRole("button",{name:"Start game",exact:true}).click();let text=await save(page),loaded=deserializeVersionedMatch(text),s=loaded.state;
  19 |  expect(loaded.options.computerStrengths).toEqual(["Normal","Normal","Normal"]);expect(loaded.options.seats.map(p=>p.kind)).toEqual(["human","computer","computer","computer"]);
  20 |  const own=s.map.provinces.find(p=>s.ownerOf[p.id]===activePlayer(s)!.id)!.id;
> 21 |  for(let i=0;i<s.reinforcementPool;i++)await page.locator(`[data-country="${own}"]`).press("Enter");await page.locator("#start-combat-button").click();await page.locator("#end-turn-button").click();
     |                                                                                                                                                ^ Error: locator.click: Test timeout of 30000ms exceeded.
  22 |  await expect(page.locator("#reference-computer-status")).toBeVisible();await expect(page.locator("#end-turn-button")).toBeDisabled();await capture(page,"computer-turn",info.project.name);
  23 |  const during=await save(page);await page.locator(`[data-country="${own}"]`).press("Enter");await page.keyboard.press("Escape");expect(await save(page)).toBe(during);
  24 |  await runToHuman(page);s=deserializeVersionedMatch(await save(page)).state;expect(activePlayer(s)!.kind).toBe("human");expect(s.currentPlayer).toBe(0);expect(s.history.filter(a=>a.kind==="endTurn"||a.kind==="friendlyMove")).toHaveLength(4);await capture(page,"human-return",info.project.name);
  25 | });
  26 | test("loaded computer capture resolves without a click; replacement and new game cancel old callbacks",async({page},info)=>{
  27 |  await page.addInitScript(()=>{const original=window.setTimeout.bind(window);const callbacks:(()=>void)[]=[];Reflect.set(window,"oldComputerCallbacks",callbacks);window.setTimeout=((fn:TimerHandler,delay?:number,...args:unknown[])=>{if(typeof fn==="function"&&[175,350,525].includes(delay??0))callbacks.push(fn as ()=>void);return original(fn,delay,...args);}) as typeof window.setTimeout;});
  28 |  await begin(page);const pending=computerCapture();await load(page,pending);await expect(page.locator("#confirm-capture-button")).toBeDisabled();await capture(page,"pending-computer",info.project.name);
  29 |  const before=deserializeVersionedMatch(pending).state.history.length;await page.clock.runFor(350);let s=deserializeVersionedMatch(await save(page)).state;expect(s.history[before]?.kind).toBe("captureMove");await runToHuman(page);
  30 |  await load(page,pending);const restored=pinned("placement").text;await load(page,restored);const fresh=await save(page);
  31 |  await page.evaluate(()=>{for(const cb of Reflect.get(window,"oldComputerCallbacks") as (()=>void)[])cb();});await page.clock.runFor(2000);expect(await save(page)).toBe(fresh);
  32 |  await load(page,pending);await page.getByRole("button",{name:"New game",exact:true}).click();await page.evaluate(()=>{for(const cb of Reflect.get(window,"oldComputerCallbacks") as (()=>void)[])cb();});await page.clock.runFor(2000);await expect(page.getByRole("heading",{name:"New reference game",exact:true})).toBeVisible();
  33 | });
  34 | test("loss waits for Watch or Stop; finished game schedules no play; manual route stays manual",async({page},info)=>{
  35 |  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));await begin(page);await load(page,pinned("human-loss").text);const loss=await save(page);await page.clock.runFor(10000);expect(await save(page)).toBe(loss);
  36 |  await page.locator("#watch-computers-button").click();await expect(page.locator("#reference-computer-status")).toBeVisible();await page.clock.runFor(1050);expect(deserializeVersionedMatch(await save(page)).state.history.length).toBeGreaterThan(deserializeVersionedMatch(loss).state.history.length+1);
  37 |  await load(page,loss);await page.locator("#stop-game-button").click();const stopped=await save(page);await page.clock.runFor(10000);expect(await save(page)).toBe(stopped);await capture(page,"stopped",info.project.name);
  38 |  await page.goto("/?view=reference-game&control=manual");await expect(page.locator("#reference-seats")).toHaveValue("2");await load(page,computerCapture());const manual=await save(page);await page.clock.runFor(10000);expect(await save(page)).toBe(manual);await expect(page.locator("#confirm-capture-button")).toBeEnabled();expect(errors).toEqual([]);
  39 | });
  40 | 
```