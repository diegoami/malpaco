# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: computer-turn-flow.spec.ts >> loss waits for Watch or Stop; finished game schedules no play; manual route stays manual
- Location: tests/e2e/computer-turn-flow.spec.ts:36:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('#reference-computer-status')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('#reference-computer-status') with timeout 5000ms
  - waiting for locator('#reference-computer-status')

```

```yaml
- banner:
  - heading "Malpaco" [level=1]
  - text: Nine Isles · 1 human / 2 computer seats · Manual play · Seed 1994 Seat 1 0 provinces · 0 armies Seat 2 · Computer 22 provinces · 48 armies Seat 3 · Computer 24 provinces · 46 armies
  - contentinfo:
    - button "New game"
  - button "Save game"
  - text: Load game
  - button "Load game"
- main:
  - img "Nine Isles reference map":
    - button "River gate, Seat 3, 1 armies": River gate 3 · 1
    - button "New port, Seat 2, 8 armies": New port 2 · 8
    - button "North rest, Seat 2, 1 armies": North rest 2 · 1
    - button "River keep, Seat 2, 1 armies": River keep 2 · 1
    - button "North town, Seat 2, 1 armies": North town 2 · 1
    - button "Dark ford, Seat 2, 1 armies": Dark ford 2 · 1
    - button "Iron point, Seat 3, 2 armies": Iron point 3 · 2
    - button "South rest, Seat 3, 2 armies": South rest 3 · 2
    - button "High shore, Seat 2, 2 armies": High shore 2 · 2
    - button "Wind town, Seat 3, 1 armies": Wind town 3 · 1
    - button "New glen, Seat 2, 8 armies": New glen 2 · 8
    - button "Old rock, Seat 3, 1 armies": Old rock 3 · 1
    - button "Blue peak, Seat 2, 1 armies": Blue peak 2 · 1
    - button "West haven, Seat 3, 1 armies": West haven 3 · 1
    - button "Stone watch, Seat 2, 1 armies": Stone watch 2 · 1
    - button "Upper ridge, Seat 2, 6 armies": Upper ridge 2 · 6
    - button "Marsh keep, Seat 2, 3 armies": Marsh keep 2 · 3
    - button "New fell, Seat 2, 1 armies": New fell 2 · 1
    - button "Moon point, Seat 3, 1 armies": Moon point 3 · 1
    - button "South fell, Seat 2, 1 armies": South fell 2 · 1
    - button "High ridge, Seat 2, 1 armies": High ridge 2 · 1
    - button "Bay ford, Seat 2, 1 armies": Bay ford 2 · 1
    - button "Low moor, Seat 3, 1 armies": Low moor 3 · 1
    - button "Lower field, Seat 3, 1 armies": Lower field 3 · 1
    - button "Wind gate, Seat 3, 1 armies": Wind gate 3 · 1
    - button "Silver shore, Seat 3, 4 armies": Silver shore 3 · 4
    - button "Low peak, Seat 3, 1 armies": Low peak 3 · 1
    - button "Wind port, Seat 3, 1 armies": Wind port 3 · 1
    - button "Gold point, Seat 3, 1 armies": Gold point 3 · 1 ★
    - button "Rock moor, Seat 2, 1 armies": Rock moor 2 · 1
    - button "Marsh rest, Seat 3, 1 armies": Marsh rest 3 · 1
    - button "Wind dale, Seat 3, 11 armies": Wind dale 3 · 11
    - button "Silver ford, Seat 2, 1 armies": Silver ford 2 · 1
    - button "Iron field, Seat 2, 1 armies": Iron field 2 · 1
    - button "North wood, Seat 2, 1 armies": North wood 2 · 1
    - button "Fort town, Seat 3, 1 armies": Fort town 3 · 1 ★
    - button "Red field, Seat 2, 3 armies": Red field 2 · 3 ★
    - button "South ridge, Seat 2, 2 armies": South ridge 2 · 2
    - button "Rock bay, Seat 3, 1 armies": Rock bay 3 · 1
    - button "North ford, Seat 3, 1 armies": North ford 3 · 1
    - button "Port ridge, Seat 3, 1 armies": Port ridge 3 · 1
    - button "New rock, Seat 2, 2 armies": New rock 2 · 2
    - button "South reach, Seat 3, 3 armies": South reach 3 · 3
    - button "Silver point, Seat 3, 1 armies": Silver point 3 · 1
    - button "East ford, Seat 3, 1 armies": East ford 3 · 1
    - button "Gold town, Seat 3, 6 armies": Gold town 3 · 6
    - text: North Isle +3 East Isle +3 West Isle +3 South Isle +3 Central Isle +5 Harbor Isle +5 Palm Isle +6 Cliff Isle +5 Great Isle +9
  - complementary:
    - text: Seat 2's turn Computer · Normal · Round 6 · Reinforcement Province income
    - strong: "7"
    - text: Island income
    - strong: "3"
    - text: Armies to place
    - strong: "10"
    - paragraph: Place your armies on your countries, then start combat.
    - button "Start combat" [disabled]
    - button "End turn" [disabled]
    - heading "Battle log" [level=3]
    - list "Battle log":
      - listitem: T5 Seat 3 ends the turn
      - listitem: Seat 1 is eliminated
      - listitem: "T5 Seat 3: East ford → Gold town, took Gold town"
      - listitem: "T5 Seat 3: East ford → Gold town, -0 / -1"
      - listitem: "T5 Seat 3: East ford → Gold town, -1 / -0"
      - listitem: "T5 Seat 3: East ford → Gold town, -1 / -0"
      - listitem: "T5 Seat 3: East ford → Gold town, -1 / -0"
```

# Test source

```ts
  1  | import { expect, test } from "@playwright/test";
  2  | import type { Page } from "@playwright/test";
  3  | import { mkdirSync, mkdtempSync, readFileSync } from "node:fs";
  4  | import { join } from "node:path";
  5  | import { activePlayer, apply } from "../../src/core";
  6  | import type { GameState } from "../../src/core";
  7  | import { deserializeVersionedMatch, serializeVersionedMatch, REFERENCE_MATCH_IDENTITY } from "../../src/core/match-save";
  8  | import { pinned } from "../core/versioned-match-fixture";
  9  | async function save(page:Page){const p=page.waitForEvent("download");await page.getByRole("button",{name:"Save game",exact:true}).click();return readFileSync((await (await p).path())!,"utf8");}
  10 | async function load(page:Page,text:string){await page.getByLabel("Load game",{exact:true}).setInputFiles({name:"resume.json",mimeType:"application/json",buffer:Buffer.from(text)});await expect(page.locator("[data-country]")).toHaveCount(46);}
  11 | async function begin(page:Page){await page.clock.install();await page.clock.pauseAt(new Date());await page.goto("/?view=reference-game");}
  12 | async function capture(page:Page,name:string,project:string){const dir=process.env["COMPUTER_FLOW_EVIDENCE_DIR"]??"screenshots";mkdirSync(dir,{recursive:true});expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);await page.screenshot({path:join(mkdtempSync(join(dir,"flow-")),`${name}-${project}.png`)});}
  13 | function computerCapture(){const f=pinned("human-loss");let s=deserializeVersionedMatch(serializeVersionedMatch(f.options,[],REFERENCE_MATCH_IDENTITY)).state;for(const a of f.actions){const r=apply(s,a);if(!r.ok)throw Error(r.error);s=r.state;if(s.phase==="capture"&&activePlayer(s)!.kind==="computer")return serializeVersionedMatch(f.options,s.history,REFERENCE_MATCH_IDENTITY);}throw Error("No computer capture");}
  14 | async function runToHuman(page:Page){for(let i=0;i<400;i++){if(await page.locator("#reference-computer-status").isHidden())return;await page.clock.runFor(525);}throw Error("Computer did not hand back control");}
  15 | 
  16 | test("untouched setup starts one human and three Normal computers and consecutive turns return",async({page},info)=>{
  17 |  await begin(page);await expect(page.locator("#reference-seats")).toHaveValue("4");for(let i=1;i<=4;i++)await expect(page.getByLabel(`Seat ${i} control`)).toHaveValue(i===1?"human":"computer");
  18 |  await page.getByRole("button",{name:"Start game",exact:true}).click();let text=await save(page),loaded=deserializeVersionedMatch(text),s=loaded.state;
  19 |  expect(loaded.options.computerStrengths).toEqual(["Normal","Normal","Normal"]);expect(loaded.options.seats.map(p=>p.kind)).toEqual(["human","computer","computer","computer"]);
  20 |  await runToHuman(page);s=deserializeVersionedMatch(await save(page)).state;expect(activePlayer(s)!.kind).toBe("human");const priorHandoffs=s.history.filter(a=>a.kind==="endTurn"||a.kind==="friendlyMove").length;
  21 |  const own=s.map.provinces.find(p=>s.ownerOf[p.id]===activePlayer(s)!.id)!.id;
  22 |  for(let i=0;i<s.reinforcementPool;i++)await page.locator(`[data-country="${own}"]`).press("Enter");await page.locator("#start-combat-button").click();await page.locator("#end-turn-button").click();
  23 |  await expect(page.locator("#reference-computer-status")).toBeVisible();await expect(page.locator("#end-turn-button")).toBeDisabled();await capture(page,"computer-turn",info.project.name);
  24 |  const during=await save(page);await page.locator(`[data-country="${own}"]`).press("Enter");await page.keyboard.press("Escape");expect(await save(page)).toBe(during);
  25 |  await runToHuman(page);s=deserializeVersionedMatch(await save(page)).state;expect(activePlayer(s)!.kind).toBe("human");expect(s.currentPlayer).toBe(0);expect(s.history.filter(a=>a.kind==="endTurn"||a.kind==="friendlyMove")).toHaveLength(priorHandoffs+4);await capture(page,"human-return",info.project.name);
  26 | });
  27 | test("loaded computer capture resolves without a click; replacement and new game cancel old callbacks",async({page},info)=>{
  28 |  await begin(page);await page.evaluate(()=>{const original=window.setTimeout.bind(window);const callbacks:(()=>void)[]=[];Reflect.set(window,"oldComputerCallbacks",callbacks);window.setTimeout=((fn:TimerHandler,delay?:number,...args:unknown[])=>{if(typeof fn==="function"&&[175,350,525].includes(delay??0))callbacks.push(fn as ()=>void);return original(fn,delay,...args);}) as typeof window.setTimeout;});
  29 |  const pending=computerCapture();await load(page,pending);await expect(page.locator("#confirm-capture-button")).toBeDisabled();await capture(page,"pending-computer",info.project.name);
  30 |  const before=deserializeVersionedMatch(pending).state.history.length;await page.clock.runFor(350);let s=deserializeVersionedMatch(await save(page)).state;expect(s.history[before]?.kind).toBe("captureMove");await runToHuman(page);
  31 |  await load(page,pending);const restored=pinned("placement").text;await load(page,restored);const fresh=await save(page);
  32 |  expect(await page.evaluate(()=>(Reflect.get(window,"oldComputerCallbacks") as unknown[]).length)).toBeGreaterThan(0);
  33 |  await page.evaluate(()=>{for(const cb of Reflect.get(window,"oldComputerCallbacks") as (()=>void)[])cb();});await page.clock.runFor(2000);expect(await save(page)).toBe(fresh);
  34 |  await load(page,pending);await page.getByRole("button",{name:"New game",exact:true}).click();await page.evaluate(()=>{for(const cb of Reflect.get(window,"oldComputerCallbacks") as (()=>void)[])cb();});await page.clock.runFor(2000);await expect(page.getByRole("heading",{name:"New reference game",exact:true})).toBeVisible();
  35 | });
  36 | test("loss waits for Watch or Stop; finished game schedules no play; manual route stays manual",async({page},info)=>{
  37 |  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));await begin(page);await load(page,pinned("human-loss").text);const loss=await save(page);await page.clock.runFor(10000);expect(await save(page)).toBe(loss);
> 38 |  await page.locator("#watch-computers-button").click();await expect(page.locator("#reference-computer-status")).toBeVisible();await page.clock.runFor(1050);expect(deserializeVersionedMatch(await save(page)).state.history.length).toBeGreaterThan(deserializeVersionedMatch(loss).state.history.length+1);
     |                                                                                                                 ^ Error: expect(locator).toBeVisible() failed
  39 |  await load(page,loss);await page.locator("#stop-game-button").click();const stopped=await save(page);await page.clock.runFor(10000);expect(await save(page)).toBe(stopped);await capture(page,"stopped",info.project.name);
  40 |  await page.goto("/?view=reference-game&control=manual");await expect(page.locator("#reference-seats")).toHaveValue("2");await load(page,computerCapture());const manual=await save(page);await page.clock.runFor(10000);expect(await save(page)).toBe(manual);await expect(page.locator("#confirm-capture-button")).toBeEnabled();expect(errors).toEqual([]);
  41 | });
  42 | 
```