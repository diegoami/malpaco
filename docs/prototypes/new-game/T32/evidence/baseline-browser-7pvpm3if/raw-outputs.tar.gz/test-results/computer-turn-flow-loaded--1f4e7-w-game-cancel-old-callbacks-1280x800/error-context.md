# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: computer-turn-flow.spec.ts >> loaded computer capture resolves without a click; replacement and new game cancel old callbacks
- Location: tests/e2e/computer-turn-flow.spec.ts:26:1

# Error details

```
Error: expect(locator).toBeDisabled() failed

Locator:  locator('#confirm-capture-button')
Expected: disabled
Received: enabled
Timeout:  5000ms

Call log:
  - Expect "toBeDisabled" locator('#confirm-capture-button') with timeout 5000ms
  - waiting for locator('#confirm-capture-button')
    14 × locator resolved to <button type="button" class="primary" id="confirm-capture-button">Confirm move-in</button>
       - unexpected value "enabled"

```

```yaml
- button "Confirm move-in"
```

# Test source

```ts
  1  | import { expect, test } from "@playwright/test";
  2  | import type { Page } from "@playwright/test";
  3  | import { mkdirSync, mkdtempSync, readFileSync } from "node:fs";
  4  | import { join } from "node:path";
  5  | import { activePlayer, apply } from "../../src/core";
  6  | import type { GameState } from "../../src/core";
  7  | import { deserializeVersionedMatch, serializeVersionedMatch, REFERENCE_MATCH_IDENTITY } from "../../src/core/match-save";
  8  | import { pinned } from "../core/versioned-match-fixture";
  9  | async function save(page:Page){const p=page.waitForEvent("download");await page.getByRole("button",{name:"Save game",exact:true}).click();return readFileSync((await (await p).path())!,"utf8");}
  10 | async function load(page:Page,text:string){await page.getByLabel("Load game",{exact:true}).setInputFiles({name:"resume.json",mimeType:"application/json",buffer:Buffer.from(text)});await expect(page.locator("[data-country]")).toHaveCount(46);}
  11 | async function begin(page:Page){await page.clock.install();await page.clock.pauseAt(new Date());await page.goto("/?view=reference-game");}
  12 | async function capture(page:Page,name:string,project:string){const dir=process.env["COMPUTER_FLOW_EVIDENCE_DIR"]??"screenshots";mkdirSync(dir,{recursive:true});expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);await page.screenshot({path:join(mkdtempSync(join(dir,"flow-")),`${name}-${project}.png`)});}
  13 | function computerCapture(){const f=pinned("human-loss");let s=deserializeVersionedMatch(serializeVersionedMatch(f.options,[],REFERENCE_MATCH_IDENTITY)).state;for(const a of f.actions){const r=apply(s,a);if(!r.ok)throw Error(r.error);s=r.state;if(s.phase==="capture"&&activePlayer(s)!.kind==="computer")return serializeVersionedMatch(f.options,s.history,REFERENCE_MATCH_IDENTITY);}throw Error("No computer capture");}
  14 | async function runToHuman(page:Page){for(let i=0;i<400;i++){if(await page.locator("#reference-computer-status").isHidden())return;await page.clock.runFor(525);}throw Error("Computer did not hand back control");}
  15 | 
  16 | test("untouched setup starts one human and three Normal computers and consecutive turns return",async({page},info)=>{
  17 |  await begin(page);await expect(page.locator("#reference-seats")).toHaveValue("4");for(let i=1;i<=4;i++)await expect(page.getByLabel(`Seat ${i} control`)).toHaveValue(i===1?"human":"computer");
  18 |  await page.getByRole("button",{name:"Start game",exact:true}).click();let text=await save(page),loaded=deserializeVersionedMatch(text),s=loaded.state;
  19 |  expect(loaded.options.computerStrengths).toEqual(["Normal","Normal","Normal"]);expect(loaded.options.seats.map(p=>p.kind)).toEqual(["human","computer","computer","computer"]);
  20 |  const own=s.map.provinces.find(p=>s.ownerOf[p.id]===activePlayer(s)!.id)!.id;
  21 |  for(let i=0;i<s.reinforcementPool;i++)await page.locator(`[data-country="${own}"]`).click();await page.locator("#start-combat-button").click();await page.locator("#end-turn-button").click();
  22 |  await expect(page.locator("#reference-computer-status")).toBeVisible();await expect(page.locator("#end-turn-button")).toBeDisabled();await capture(page,"computer-turn",info.project.name);
  23 |  const during=await save(page);await page.locator(`[data-country="${own}"]`).click();await page.keyboard.press("Escape");expect(await save(page)).toBe(during);
  24 |  await runToHuman(page);s=deserializeVersionedMatch(await save(page)).state;expect(activePlayer(s)!.kind).toBe("human");expect(s.currentPlayer).toBe(0);expect(s.history.filter(a=>a.kind==="endTurn"||a.kind==="friendlyMove")).toHaveLength(4);await capture(page,"human-return",info.project.name);
  25 | });
  26 | test("loaded computer capture resolves without a click; replacement and new game cancel old callbacks",async({page},info)=>{
  27 |  await page.addInitScript(()=>{const original=window.setTimeout.bind(window);const callbacks:(()=>void)[]=[];Reflect.set(window,"oldComputerCallbacks",callbacks);window.setTimeout=((fn:TimerHandler,delay?:number,...args:unknown[])=>{if(typeof fn==="function"&&[175,350,525].includes(delay??0))callbacks.push(fn as ()=>void);return original(fn,delay,...args);}) as typeof window.setTimeout;});
> 28 |  await begin(page);const pending=computerCapture();await load(page,pending);await expect(page.locator("#confirm-capture-button")).toBeDisabled();await capture(page,"pending-computer",info.project.name);
     |                                                                                                                                   ^ Error: expect(locator).toBeDisabled() failed
  29 |  const before=deserializeVersionedMatch(pending).state.history.length;await page.clock.runFor(350);let s=deserializeVersionedMatch(await save(page)).state;expect(s.history[before]?.kind).toBe("captureMove");await runToHuman(page);
  30 |  await load(page,pending);const restored=pinned("placement").text;await load(page,restored);const fresh=await save(page);
  31 |  await page.evaluate(()=>{for(const cb of Reflect.get(window,"oldComputerCallbacks") as (()=>void)[])cb();});await page.clock.runFor(2000);expect(await save(page)).toBe(fresh);
  32 |  await load(page,pending);await page.getByRole("button",{name:"New game",exact:true}).click();await page.evaluate(()=>{for(const cb of Reflect.get(window,"oldComputerCallbacks") as (()=>void)[])cb();});await page.clock.runFor(2000);await expect(page.getByRole("heading",{name:"New reference game",exact:true})).toBeVisible();
  33 | });
  34 | test("loss waits for Watch or Stop; finished game schedules no play; manual route stays manual",async({page},info)=>{
  35 |  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));await begin(page);await load(page,pinned("human-loss").text);const loss=await save(page);await page.clock.runFor(10000);expect(await save(page)).toBe(loss);
  36 |  await page.locator("#watch-computers-button").click();await expect(page.locator("#reference-computer-status")).toBeVisible();await page.clock.runFor(1050);expect(deserializeVersionedMatch(await save(page)).state.history.length).toBeGreaterThan(deserializeVersionedMatch(loss).state.history.length+1);
  37 |  await load(page,loss);await page.locator("#stop-game-button").click();const stopped=await save(page);await page.clock.runFor(10000);expect(await save(page)).toBe(stopped);await capture(page,"stopped",info.project.name);
  38 |  await page.goto("/?view=reference-game&control=manual");await expect(page.locator("#reference-seats")).toHaveValue("2");await load(page,computerCapture());const manual=await save(page);await page.clock.runFor(10000);expect(await save(page)).toBe(manual);await expect(page.locator("#confirm-capture-button")).toBeEnabled();expect(errors).toEqual([]);
  39 | });
  40 | 
```