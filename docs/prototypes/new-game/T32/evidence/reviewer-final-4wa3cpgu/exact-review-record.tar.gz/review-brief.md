T32 review (MiniMax M3), PR #135 at b38110183a310303b1f9357272870817f166a16a.

Use the PINNED browser commands below. Do not run host Chromium, headed mode, ad hoc host Playwright retries or alternate drivers: T31 showed unrelated host stable-click timeouts in old Start/Save controls; the required Playwright v1.63.0-noble image passes. This is an environment instruction, not permission to skip browser coverage. Commands below retain all raw outputs, sources and screenshots under owned T32 evidence. Run them sequentially. Never leave a live server behind.

1. python3 docs/prototypes/new-game/T32/run-command.py reviewer-core npx vitest run tests/core/computer-turn-flow.test.ts
2. python3 docs/prototypes/new-game/T32/run-browser.py reviewer-flow
3. python3 docs/prototypes/new-game/T32/run-command.py reviewer-unit npm test
4. python3 docs/prototypes/new-game/T32/run-command.py reviewer-build npm run build
5. python3 docs/prototypes/new-game/T32/run-browser.py reviewer-all --suites tests/e2e
6. python3 docs/prototypes/new-game/T32/parent-audit.py reviewer-inherited
7. python3 docs/prototypes/new-game/T32/verify-evidence.py artifacts.review.json

Review scope: main session implements; you are the independent reviewer. Runtime changed only computer.ts, battleController.ts, new computerTurnLoop.ts, reference host/setup, loss guidance and a tiny status style. The T18 legacy policy retains N attacks and generated old rules; T32 adds default capture, deterministic interior-to-frontier move, null at human-loss. Modern default is 1 human + 3 Normal computers. Explicit control=manual drives prior mixed/all-human fixtures; legacy routes and goldens remain. Old fixture changes are EXACT URL/manual and modern total-count label substitutions, validated against T31 by parent-audit.py (175 inherited files, including 87 frozen T31 JSON files). No old assertions removed.

The core acceptance uses pure controlled positions only to isolate movement and budget reset; seed matrix and browsers use ordinary generated histories/save codecs. Browser clock remains UI-only; no engine snapshot injection. Timer spy is installed after fake clock, asserts scheduled callbacks existed and queued ids were actually cleared, then invokes stale callbacks. Review cancellation, capture/handoff, input gating and RNG/replay especially. Author eight real production deletions are retained with restoration receipts; audit them and probe any additional issue you suspect. Never claim you personally performed mutations if you only inspected author evidence.

Evidence handling: leave every fresh measurement/output in owned T32 paths. Harness retains fresh untracked owned files before cleanup, but ignored raw directories are not retained automatically: wrappers archive their raw bytes. Do not duplicate entire author evidence trees in outer archives. Read JSON/archives selectively; binary screenshots and raw logs are evidence, not source needing line-by-line reading. Preserve existing files; do not overwrite reports/indexes. New receipts will be imported by main before final CI. No source edits except saved-byte/finally-restored independent probes. Do not commit/push/post findings yourself.


# T32 Basic computer through the complete ordinary turn

- **Kind**: feature
- **Issue**: #77 · **Branch**: `task/T32-basic-computer-through-the-complete-ordinary-turn` · **Merge after**: T31.
- **Difficulty**: Medium; estimate, not a model assignment.
- **Implementer**: owner-selected under rule 6; use an isolated worktree and record the choice before dispatch.
- **Reviewer**: owner-selected OpenCode model of another family under rule 6; record the choice before review.
- **Evidence**: [pinned computer design](https://github.com/diegoami/isle-wars-archaeology/blob/ae298e37c2f5177039e55767607f9345b6cb0e7a/design/computer.md), owner roadmap accepted 2026-10-15, and upstream task evidence. T23 resolves source anchors; new constants need citations or explicit [designed] provenance.
- **Owns**: src/core/**; tests/core/**; src/ui/**; src/styles.css; tests/ui/**; tests/e2e/**; docs/prototypes/new-game/T32/**; docs/spike.md; append-only RUN-NOTES.md.
- **Scope**: Adapt the existing baseline opponent to explicit capture choices, optional moves and new victory flow. Make the reference setup default to one human and three Normal computer players (owner reaffirmed 2026-10-16); retain an explicit all-human testing mode. Choose only ordinary engine actions, terminate each turn within a documented policy budget and retain exact action replay. Keep computer decisions separate from UI pacing; cancel scheduled work on load, replacement and finished games. This task supplies a usable baseline rather than claiming the strategic Normal/Easy/Hard design is complete.
- **Done when**:
  1. `npx vitest run tests/core/computer-turn-flow.test.ts` — seeds 1/42/1994 with 2/3/4 seats produce legal bounded turns through capture/move/victory, and continuation after save equals uninterrupted play.
  2. `npx playwright test tests/e2e/computer-turn-flow.spec.ts` — the untouched reference setup starts one human versus three Normal computers; consecutive computer turns return control, pending choices need no human clicks, human moves are gated and replacement cancels old timers at both desktop sizes.
  3. `npm test` and `npm run build` pass; affected pinned browser suites pass without weakening existing assertions. Retain measured outputs, screenshots where applicable, commands and hashes in the owned evidence path; report negative-before/positive-after checks and exact restoration.
- **Hazards**: A computer budget is policy, not an engine attack limit. Never consume the game RNG merely to choose an action. Main session preflights acceptance before dispatch; unresolved design conflicts stop implementation, never weaken a Done-when.

T32 review (MiniMax M3)
You review PR #135 at b38110183a310303b1f9357272870817f166a16a. You did not write it. The task file follows.
0. Prove the tree: HEAD is b38110183a310303b1f9357272870817f166a16a and the diff against origin/main is the PR's; findings name its files.
1. Re-run every Done-when line yourself, and account for each (L32). The PR's evidence is no proof.
2. [evidence-driven] Every constant traces to a fixture, report or investigation; a [designed] one says what was searched.
3. [seeded] No wall clock, unseeded random or order-dependent iteration in rule code.
4. Every changed file and behaviour is one the task asks for (L44); docs it makes wrong are updated.
5. Sweep the diff: tests that pass with the behaviour deleted (mutate, rebuild clean, re-take any
   negative result), branches no input reaches, edge comments without a test, capture choices, policy budget/handoff, RNG/replay, input guard, stale timers, finished/loss consent.
   Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
   restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
   a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
   copy inside your worktree (`<file>.saved`, deleted afterwards) or in a `mktemp -d` folder under
   `/tmp`, never as a loose file elsewhere.
6. The task-specific Blocking means and one-pass sections pasted below apply (L47, L49).
Prove each finding (run it, or delete the behaviour and name the test that fails) or label it
unverified. Your final message is the review: the header; the verdict (approve | approve after
named fixes | rework | user decision); per Done-when line `DW<k>: ran <command> → <result>` or
`DW<k>: not run — <reason>`; the findings R1..Rn (file:line, blocking or not); the verdict again
last. Never post it: the script posts it and applies the label.

## Blocking means

Any one is enough; a blocking finding means rework, never approve.
1. A Done-when line fails, or cannot be run as written.
2. What this task protects can be got past: ordinary legal computer actions, bounded turn termination, deterministic replay, human input gating and cancellation across replacement/finished games. A bypass you proved is blocking, even when it
   looks like an edge case. Never "follow-up hardening" or "outside the threat model" unless the
   task says so; if it does, quote the line. (L47)
3. Behaviour the task forbids, or behaviour nobody asked for, inside a file the task requires. (L44)
4. a new undocumented rule constant, unseeded RNG in core, a new test that stays green when the behaviour it claims is deleted, or copied predecessor material
Not blocking: wording, style, and defects in code the PR did not change: file those as follow-ups.
When unsure, say how likely the problem is. Rate it blocking only if it is likely and would get
past what the task protects; otherwise it is a follow-up. (L53)

## Report every blocking finding in this one review

This review is your only pass before the author fixes. Do not stop at the first blocking
finding: finish reading the whole diff and the task file, check every Done-when line and
every item under "Blocking means", and report all blocking findings together.

- Before you write the verdict, make one last pass over the full diff for anything you have
  not yet rated, and say "Final pass done" as the last line before the verdict.
- Number the findings R1, R2, … in order of severity. A finding you held back because an
  earlier one was already blocking is a review defect: if two problems share a cause, list
  both and say so.
- Do not rely on a later round. The author fixes everything you list, and the next review
  checks those fixes and new code only, not anything you saw but did not report.
- If you ran out of time or context before covering the whole diff, say which files or
  sections you did not cover. Do not approve in that case.

