from pathlib import Path
import subprocess,json,hashlib,os,time,traceback
root=Path.cwd();out=Path(__file__).resolve().parent;css=root/'src/styles.css'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=css.read_bytes();mode=css.stat().st_mode;assert original==(out/'styles.original.css').read_bytes()
manifest=json.loads((out/'source-before.json').read_text());frozen={}
for p in ['docs/prototypes/new-game/T40/parent-acceptance/FROZEN-ACCEPTANCE.json','docs/prototypes/new-game/T40/result-layout-parent/FROZEN-RESULT-LAYOUT.json']:
 frozen.update(json.loads((root/p).read_text()))
assert all(sha(root/p)==v for p,v in manifest.items());assert all(sha(root/p)==v for p,v in frozen.items())
receipt={'head':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'originalCSS':sha(css),'proposedCSS':sha(out/'styles.proposed.css'),'mode':mode,'runs':[]}
try:
 css.write_bytes((out/'styles.proposed.css').read_bytes())
 for name in ['loss','cards','t71']:
  cmd=['docker','run','--rm','--network','none','--cpus=2','--memory=6g','--shm-size=1g','--user','1000:1000','-v',str(root)+':/work','-w','/work','-e','HOME=/tmp','-e','COMPACT_PANEL_RESULTS_DIR=/work/'+str(out.relative_to(root))+'/t71-results','-e','COMPACT_PANEL_EVIDENCE_DIR=/work/'+str(out.relative_to(root))+'/t71-evidence','mcr.microsoft.com/playwright:v1.63.0-noble','node_modules/.bin/playwright','test','--config','/work/'+str(out.relative_to(root))+'/'+name+'.config.ts','--workers=2']
  if name=='t71':cmd+=['--grep','reference (compact|detailed): human-loss choices fit and remain usable']
  print('Starting '+name,flush=True);start=time.monotonic()
  with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(cmd,stdout=stdout,stderr=stderr)
  receipt['runs'].append({'name':name,'command':cmd,'exit':result.returncode,'seconds':time.monotonic()-start});(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
  print('Completed '+name+' exit '+str(result.returncode),flush=True)
  if result.returncode:break
except BaseException as e:
 receipt['exception']=traceback.format_exc();raise
finally:
 css.write_bytes(original);os.chmod(css,mode)
 receipt['restoredCSS']=sha(css);receipt['restoredMode']=css.stat().st_mode;receipt['exactCSSRestoration']=css.read_bytes()==original and css.stat().st_mode==mode
 receipt['sourceMismatches']=[p for p,v in manifest.items() if sha(root/p)!=v];receipt['frozenMismatches']=[p for p,v in frozen.items() if sha(root/p)!=v];receipt['frozenCount']=len(frozen)
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('Restoration '+str(receipt['exactCSSRestoration'])+' source mismatches '+str(receipt['sourceMismatches']),flush=True)
