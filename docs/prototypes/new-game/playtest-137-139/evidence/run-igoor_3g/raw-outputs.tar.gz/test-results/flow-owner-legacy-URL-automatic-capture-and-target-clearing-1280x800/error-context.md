# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: flow.spec.ts >> owner legacy URL automatic capture and target clearing
- Location: docs/prototypes/new-game/playtest-137-139/flow.spec.ts:38:37

# Error details

```
TimeoutError: page.waitForEvent: Timeout 15000ms exceeded while waiting for event "download"
=========================== logs ===========================
waiting for event "download"
============================================================
```

```
Error: locator.click: Test ended.
Call log:
  - waiting for getByRole('button', { name: 'Save game', exact: true })
    - locator resolved to <button type="button">Save game</button>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <dialog open="" id="result-dialog" data-outcome="won" data-attacker-losses="0" data-defender-losses="1" aria-labelledby="result-title">…</dialog> intercepts pointer events
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <dialog open="" id="result-dialog" data-outcome="won" data-attacker-losses="0" data-defender-losses="1" aria-labelledby="result-title">…</dialog> intercepts pointer events
    - retrying click action
      - waiting 100ms
    29 × waiting for element to be visible, enabled and stable
       - element is visible, enabled and stable
       - scrolling into view if needed
       - done scrolling
       - <dialog open="" id="result-dialog" data-outcome="won" data-attacker-losses="0" data-defender-losses="1" aria-labelledby="result-title">…</dialog> intercepts pointer events
     - retrying click action
       - waiting 500ms

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic "Map legend" [ref=e5]:
      - generic [ref=e6]: Seat · armies
      - generic [ref=e7]: Land
      - generic [ref=e9]: Sea
    - generic [ref=e11]:
      - generic [ref=e12]: Seed
      - spinbutton "Seed" [ref=e13]: "1994"
      - button "Generate" [ref=e14] [cursor=pointer]
    - generic [ref=e15]:
      - button "Save game" [ref=e16] [cursor=pointer]
      - generic [ref=e17]:
        - generic [ref=e18]: Load game
        - button "Load game" [ref=e19]
  - main [ref=e20]:
    - generic [ref=e21]:
      - 'group "Generated archipelago: 46 countries on 9 islands" [ref=e22]':
        - generic [aria-hidden] [ref=e24]:
          - generic [ref=e26]: North Isle / +3
          - generic [ref=e28]: East Isle / +3
          - generic [ref=e30]: West Isle / +3
          - generic [ref=e32]: South Isle / +3
          - generic [ref=e34]: Central Isle / +5
          - generic [ref=e36]: Harbor Isle / +4
          - generic [ref=e38]: Palm Isle / +5
          - generic [ref=e40]: Cliff Isle / +5
          - generic [ref=e42]: Great Isle / +7
        - generic [ref=e43]:
          - button "River gate, Seat 3, 1 armies" [ref=e44] [cursor=pointer]:
            - generic: River gate
            - generic: 3 · 1
          - button "New port, Seat 2, 1 armies" [ref=e46] [cursor=pointer]:
            - generic: New port
            - generic: 2 · 1
          - button "North rest, Seat 4, 1 armies" [ref=e48] [cursor=pointer]:
            - generic: North rest
            - generic: 4 · 1
          - button "River keep, Seat 2, 3 armies" [ref=e50] [cursor=pointer]:
            - generic: River keep
            - generic: 2 · 3
          - button "North town, Seat 3, 1 armies" [ref=e52] [cursor=pointer]:
            - generic: North town
            - generic: 3 · 1
          - button "Dark ford, Seat 3, 1 armies" [ref=e54] [cursor=pointer]:
            - generic: Dark ford
            - generic: 3 · 1
          - button "Iron point, Seat 3, 1 armies" [ref=e56] [cursor=pointer]:
            - generic: Iron point
            - generic: 3 · 1
          - button "South rest, Seat 2, 3 armies" [ref=e58] [cursor=pointer]:
            - generic: South rest
            - generic: 2 · 3
          - button "High shore, Seat 1, 5 armies" [pressed] [ref=e60] [cursor=pointer]:
            - generic: High shore
            - generic: 1 · 5
          - button "Wind town, Seat 3, 1 armies" [ref=e62] [cursor=pointer]:
            - generic: Wind town
            - generic: 3 · 1
          - button "New glen, Seat 1, 2 armies" [ref=e64] [cursor=pointer]:
            - generic: New glen
            - generic: 1 · 2
          - button "Old rock, Seat 3, 1 armies" [ref=e66] [cursor=pointer]:
            - generic: Old rock
            - generic: 3 · 1
          - button "Blue peak, Seat 2, 2 armies" [ref=e68] [cursor=pointer]:
            - generic: Blue peak
            - generic: 2 · 2
          - button "West haven, Seat 1, 2 armies" [ref=e70] [cursor=pointer]:
            - generic: West haven
            - generic: 1 · 2
          - button "Stone watch, Seat 3, 2 armies" [ref=e72] [cursor=pointer]:
            - generic: Stone watch
            - generic: 3 · 2
          - button "Upper ridge, Seat 3, 2 armies" [ref=e74] [cursor=pointer]:
            - generic: Upper ridge
            - generic: 3 · 2
          - button "Marsh keep, Seat 3, 1 armies" [ref=e76] [cursor=pointer]:
            - generic: Marsh keep
            - generic: 3 · 1
          - button "New fell, Seat 4, 1 armies" [ref=e78] [cursor=pointer]:
            - generic: New fell
            - generic: 4 · 1
          - button "Moon point, Seat 1, 3 armies" [ref=e80] [cursor=pointer]:
            - generic: Moon point
            - generic: 1 · 3
          - button "South fell, Seat 4, 2 armies" [ref=e82] [cursor=pointer]:
            - generic: South fell
            - generic: 4 · 2
          - button "High ridge, Seat 4, 3 armies" [ref=e84] [cursor=pointer]:
            - generic: High ridge
            - generic: 4 · 3
          - button "Bay ford, Seat 1, 3 armies" [ref=e86] [cursor=pointer]:
            - generic: Bay ford
            - generic: 1 · 3
          - button "Low moor, Seat 2, 3 armies" [ref=e88] [cursor=pointer]:
            - generic: Low moor
            - generic: 2 · 3
          - button "Lower field, Seat 4, 1 armies" [ref=e90] [cursor=pointer]:
            - generic: Lower field
            - generic: 4 · 1
          - button "Wind gate, Seat 4, 1 armies" [ref=e92] [cursor=pointer]:
            - generic: Wind gate
            - generic: 4 · 1
          - button "Silver shore, Seat 4, 2 armies" [ref=e94] [cursor=pointer]:
            - generic: Silver shore
            - generic: 4 · 2
          - button "Low peak, Seat 4, 3 armies" [ref=e96] [cursor=pointer]:
            - generic: Low peak
            - generic: 4 · 3
          - button "Wind port, Seat 4, 1 armies" [ref=e98] [cursor=pointer]:
            - generic: Wind port
            - generic: 4 · 1
          - button "Gold point, Seat 1, 3 armies" [ref=e100] [cursor=pointer]:
            - generic: Gold point
            - generic: 1 · 3
          - button "Rock moor, Seat 4, 1 armies" [ref=e102] [cursor=pointer]:
            - generic: Rock moor
            - generic: 4 · 1
          - button "Marsh rest, Seat 4, 1 armies" [ref=e104] [cursor=pointer]:
            - generic: Marsh rest
            - generic: 4 · 1
          - button "Wind dale, Seat 2, 2 armies" [ref=e106] [cursor=pointer]:
            - generic: Wind dale
            - generic: 2 · 2
          - button "Silver ford, Seat 3, 1 armies" [ref=e108] [cursor=pointer]:
            - generic: Silver ford
            - generic: 3 · 1
          - button "Iron field, Seat 3, 1 armies" [ref=e110] [cursor=pointer]:
            - generic: Iron field
            - generic: 3 · 1
          - button "North wood, Seat 2, 2 armies" [ref=e112] [cursor=pointer]:
            - generic: North wood
            - generic: 2 · 2
          - button "Fort town, Seat 1, 2 armies" [ref=e114] [cursor=pointer]:
            - generic: Fort town
            - generic: 1 · 2
          - button "Red field, Seat 2, 2 armies" [ref=e116] [cursor=pointer]:
            - generic: Red field
            - generic: 2 · 2
          - button "South ridge, Seat 1, 2 armies" [ref=e118] [cursor=pointer]:
            - generic: South ridge
            - generic: 1 · 2
          - button "Rock bay, Seat 4, 1 armies" [ref=e120] [cursor=pointer]:
            - generic: Rock bay
            - generic: 4 · 1
          - button "North ford, Seat 4, 1 armies" [ref=e122] [cursor=pointer]:
            - generic: North ford
            - generic: 4 · 1
          - button "Port ridge, Seat 1, 1 armies" [ref=e124] [cursor=pointer]:
            - generic: Port ridge
            - generic: 1 · 1
          - button "New rock, Seat 3, 1 armies" [ref=e126] [cursor=pointer]:
            - generic: New rock
            - generic: 3 · 1
          - button "South reach, Seat 2, 2 armies" [ref=e128] [cursor=pointer]:
            - generic: South reach
            - generic: 2 · 2
          - button "Silver point, Seat 1, 1 armies" [ref=e130] [cursor=pointer]:
            - generic: Silver point
            - generic: 1 · 1
          - button "East ford, Seat 4, 1 armies" [ref=e132] [cursor=pointer]:
            - generic: East ford
            - generic: 4 · 1
          - button "Gold town, Seat 4, 2 armies" [ref=e134] [cursor=pointer]:
            - generic: Gold town
            - generic: 4 · 2
      - generic: Seat 1's turn
    - complementary [ref=e136]:
      - generic [ref=e140]:
        - generic [ref=e141]: Seat 1's turn
        - generic [ref=e142]: Round 2 · Attack
      - generic [ref=e143]:
        - generic [ref=e147]:
          - generic [ref=e148]: Seat 1
          - generic [ref=e149]: 10 provinces · 24 armies
        - generic [ref=e153]:
          - generic [ref=e154]: Seat 2 · Computer
          - generic [ref=e155]: 9 provinces · 20 armies
        - generic [ref=e159]:
          - generic [ref=e160]: Seat 3 · Computer
          - generic [ref=e161]: 12 provinces · 14 armies
        - generic [ref=e165]:
          - generic [ref=e166]: Seat 4 · Computer
          - generic [ref=e167]: 15 provinces · 22 armies
      - generic [ref=e168]:
        - list [ref=e170]:
          - listitem [ref=e171]:
            - generic [ref=e172]: "1"
            - generic [ref=e173]: From
            - generic [ref=e174]: High shore (5)
          - listitem [ref=e175]:
            - generic [ref=e176]: "2"
            - generic [ref=e177]: Target
            - generic [ref=e178]: adjacent enemy
          - listitem [ref=e179]:
            - generic [ref=e180]: "3"
            - generic [ref=e181]: Then
            - generic [ref=e182]: —
        - paragraph
        - generic [ref=e183]:
          - button "Attack" [disabled] [ref=e184]
          - button "End turn" [ref=e185] [cursor=pointer]
        - paragraph [ref=e186]: "Dashed outline on every target, and a marker where one fits: provinces you can attack from the selected one."
      - generic [ref=e190]:
        - heading "Battle log" [level=3] [ref=e191]
        - list "Battle log" [ref=e192]:
          - listitem [ref=e193]: "T2 Seat 1: High shore → Iron point, -0 / -1"
          - listitem [ref=e194]: T1 Seat 4 ends the turn
          - listitem [ref=e195]: "T1 Seat 4: Gold town → Red field, -1 / -0"
          - listitem [ref=e196]: "T1 Seat 4: Rock moor → Iron field, -1 / -0"
          - listitem [ref=e197]: "T1 Seat 4: Wind gate → Lower field, took Lower field"
          - listitem [ref=e198]: "T1 Seat 4: New fell → South fell, took South fell"
          - listitem [ref=e199]: "T1 Seat 4: Rock bay → Gold town, took Gold town"
      - generic [ref=e200]:
        - button "New game" [ref=e201] [cursor=pointer]
        - generic [ref=e202]: seed 1994
        - button "How to play" [ref=e203] [cursor=pointer]: Help
  - dialog [ref=e204]:
    - generic [ref=e205]:
      - heading "High shore attacks Iron point" [level=2] [ref=e206]
      - generic [ref=e207]:
        - generic [ref=e208]: Seat 1 · High shore
        - img "3" [ref=e210]
        - generic [ref=e220]: ▲ wins
        - generic [ref=e222]: Seat 3 · Iron point
        - img "2" [ref=e224]
      - paragraph [ref=e234]: Attacker gains ground
      - paragraph [ref=e235]: Seat 1 loses 0 armies, Seat 3 loses 1 army.
    - button "Continue" [active] [ref=e237] [cursor=pointer]
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test";
  2   | import type { Page } from "@playwright/test";
  3   | import { mkdirSync, mkdtempSync, readFileSync, writeFileSync } from "node:fs";
  4   | import { join } from "node:path";
  5   | import { activePlayer, apply, computerAction } from "../../../../src/core";
  6   | import type { Action, GameState } from "../../../../src/core";
  7   | import { deserializeMatch, deserializeVersionedMatch } from "../../../../src/core/match-save";
  8   | 
  9   | const country = (page: Page, id: string) => page.locator(`[data-country="${id}"]`);
  10  | function step(state: GameState, action: Action) {
  11  |   const result = apply(state, action);
  12  |   if (!result.ok) throw Error(JSON.stringify(action) + ": " + result.error);
  13  |   return result.state;
  14  | }
  15  | async function save(page: Page) {
  16  |   // Avoid Chromium download-rate throttling in this download-heavy investigation.
  17  |   await new Promise(resolve => setTimeout(resolve, 150));
  18  |   const event = page.waitForEvent("download", {timeout: 15_000});
> 19  |   await page.getByRole("button", {name: "Save game", exact: true}).click();
      |                                                                    ^ Error: locator.click: Test ended.
  20  |   return readFileSync((await (await event).path())!, "utf8");
  21  | }
  22  | function capturePlan(state: GameState, repeats = false) {
  23  |   for (const source of state.map.provinces.filter(p => state.ownerOf[p.id] === activePlayer(state)!.id)) {
  24  |     let ready = state;
  25  |     for (let i = 0; i < state.reinforcementPool; i++) ready = step(ready, {kind: "reinforce", province: source.id, amount: 1});
  26  |     ready = step(ready, {kind: "endReinforcement"});
  27  |     for (const to of [...source.borders, ...source.seaLanes]) {
  28  |       if (ready.ownerOf[to] === activePlayer(ready)!.id) continue;
  29  |       let next = ready, exchanges = 0;
  30  |       while (next.phase === "attack" && next.ownerOf[to] !== activePlayer(ready)!.id && next.armies[source.id]! > 1 && exchanges < 50) {
  31  |         next = step(next, {kind: "attack", from: source.id, to}); exchanges++;
  32  |       }
  33  |       if (exchanges >= (repeats ? 2 : 1) && (next.phase === "capture" ? next.pendingCapture!.max : next.armies[to]!) >= 3 && (next.phase === "capture" || next.ownerOf[to] === activePlayer(ready)!.id)) return {from: source.id, to, placements: state.reinforcementPool, ready, exchanges};
  34  |     }
  35  |   }
  36  |   throw Error("No bounded ordinary-action capture with three exchanges and three move-in amounts");
  37  | }
  38  | for (const modern of [true, false]) test(modern ? "root repeat, Stop, capture choice and real save/resume" : "owner legacy URL automatic capture and target clearing", async ({page}, info) => {
  39  |   test.setTimeout(120_000);
  40  |   const evidence = process.env["PLAYTEST_EVIDENCE_DIR"];
  41  |   if (!evidence) throw Error("Use run.py to retain the playtest");
  42  |   const dir = mkdtempSync(join(evidence, `${modern ? "root" : "legacy"}-${info.project.name}-`));
  43  |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  44  |   page.on("console", m => { if (m.type() === "error") errors.push(m.text()); });
  45  |   const read = (text: string) => modern ? deserializeVersionedMatch(text).state : deserializeMatch(text).state;
  46  |   let sequence = 0;
  47  |   async function checkpoint(name: string) {
  48  |     const text = await save(page); writeFileSync(join(dir, `${sequence++}-${name}.json`), text); return read(text);
  49  |   }
  50  |   async function screenshot(name: string) { await page.mouse.move(0, 0); await page.screenshot({path: join(dir, name + ".png"), fullPage: true}); }
  51  |   await page.clock.install(); await page.clock.pauseAt(new Date("2026-10-17T12:00:00Z"));
  52  |   await page.goto(modern ? "/" : "/?view=generated-game&seed=1994&seats=4&opponents=computer");
  53  |   if (modern) {
  54  |     for (let seat = 1; seat <= 4; seat++) await expect(page.getByLabel(`Seat ${seat} control`, {exact: true})).toHaveValue(seat === 1 ? "human" : "computer");
  55  |     await page.getByRole("button", {name: "Start game", exact: true}).click();
  56  |   }
  57  |   let state = await checkpoint("opening");
  58  |   expect(state.rules.combat.capture).toBe(modern ? "choice" : "all");
  59  |   let expectedHuman = state, computerSteps = 0;
  60  |   while (activePlayer(expectedHuman)!.kind === "computer" && computerSteps < 400) {
  61  |     const action = computerAction(expectedHuman); if (!action) throw Error("No computer action");
  62  |     expectedHuman = step(expectedHuman, action); computerSteps++;
  63  |   }
  64  |   expect(activePlayer(expectedHuman)!.kind).toBe("human");
  65  |   await page.clock.runFor(computerSteps * 350);
  66  |   state = await checkpoint("after-computer-opener");
  67  |   expect(state.history).toEqual(expectedHuman.history);
  68  |   expect(activePlayer(state)!.kind).toBe("human");
  69  |   await checkpoint("human-turn"); await screenshot("opening");
  70  |   const plan = capturePlan(state);
  71  |   for (let i = 0; i < plan.placements; i++) await country(page, plan.from).click();
  72  |   await page.locator("#start-combat-button").click();
  73  |   expect((await checkpoint("ready")).history).toEqual(plan.ready.history); state = plan.ready;
  74  |   await country(page, plan.from).click(); await country(page, plan.to).click();
  75  |   await country(page, plan.to).click(); await country(page, plan.to).press("Enter");
  76  |   expect((await checkpoint("repeated-map-selection-no-attack")).history).toEqual(state.history);
  77  |   await screenshot("selected-target");
  78  |   const attack: Action = {kind: "attack", from: plan.from, to: plan.to};
  79  |   if (modern) {
  80  |     // Use a second enemy with a longer battle for repeat/Stop when available.
  81  |     // Seed 1994's concentrated capture is a one-exchange win; do not pretend it proves repetition.
  82  |     const readyText = await save(page);
  83  |     const repeated = state.map.provinces.flatMap(p => [...p.borders, ...p.seaLanes].map(to => ({kind: "attack" as const, from: p.id, to}))).find(action => {
  84  |       const first = apply(state, action); if (!first.ok || first.state.phase !== "attack") return false;
  85  |       return apply(first.state, action).ok;
  86  |     });
  87  |     if (!repeated) throw Error("No legal repeat pair in actual concentrated deal");
  88  |     await country(page, repeated.from).click(); await country(page, repeated.to).click();
  89  |     let repeatedState = state;
  90  |     for (let i = 0; i < 2; i++) {
  91  |       await page.locator("#single-exchange-button").click(); repeatedState = step(repeatedState, repeated);
  92  |       expect((await checkpoint("repeated-single")).history).toEqual(repeatedState.history);
  93  |       await expect(country(page, repeated.from)).toHaveAttribute("aria-pressed", "true");
  94  |       await expect(page.locator("#battle-target-name")).toHaveText(state.map.provinces.find(p => p.id === repeated.to)!.name);
  95  |     }
  96  |     await page.getByLabel("Load game", {exact: true}).setInputFiles({name: "ready.json", mimeType: "application/json", buffer: Buffer.from(readyText)});
  97  |     await expect(page.locator("#battle-source-name")).toHaveText("Choose your country");
  98  |     await country(page, repeated.from).click(); await country(page, repeated.to).click();
  99  |     await page.locator("#battle-stop-threshold").fill("1"); await page.locator("#battle-stop-threshold").press("Tab");
  100 |     await page.locator("#fight-on-button").click();
  101 |     const stopped = step(state, repeated);
  102 |     await page.locator("#stop-battle-button").click(); await page.clock.runFor(4000);
  103 |     expect((await checkpoint("stopped")).history).toEqual(stopped.history); await screenshot("stopped");
  104 |     await page.getByLabel("Load game", {exact: true}).setInputFiles({name: "ready.json", mimeType: "application/json", buffer: Buffer.from(readyText)});
  105 |     await expect(page.locator("#battle-source-name")).toHaveText("Choose your country");
  106 |     await country(page, plan.from).click(); await country(page, plan.to).click();
  107 |     await page.locator("#battle-stop-threshold").fill("1"); await page.locator("#battle-stop-threshold").press("Tab");
  108 |     await page.locator("#fight-on-button").click(); state = step(state, attack);
  109 |     for (let i = 1; i < plan.exchanges; i++) { await page.clock.runFor(350); state = step(state, attack); }
  110 |     expect((await checkpoint("capture-interrupted-fight")).history).toEqual(state.history);
  111 |     expect(state.phase).toBe("capture");
  112 |     await expect(page.locator("#confirm-capture-button")).toBeVisible();
  113 |     const pendingText = await save(page), pending = state.pendingCapture!;
  114 |     writeFileSync(join(dir, "pending-save.json"), pendingText);
  115 |     await screenshot("pending-capture");
  116 |     await country(page, plan.to).click(); await country(page, plan.to).press("Enter"); await page.clock.runFor(4000);
  117 |     expect((await checkpoint("capture-not-auto-confirmed")).history).toEqual(state.history);
  118 |     const quantities = [pending.min, Math.floor((pending.min + pending.max) / 2), pending.max];
  119 |     expect(new Set(quantities).size).toBe(3);
```