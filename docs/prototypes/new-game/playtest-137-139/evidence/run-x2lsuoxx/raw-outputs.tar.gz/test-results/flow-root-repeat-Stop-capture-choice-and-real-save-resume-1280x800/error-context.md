# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: flow.spec.ts >> root repeat, Stop, capture choice and real save/resume
- Location: docs/prototypes/new-game/playtest-137-139/flow.spec.ts:38:37

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 0
+ Received  + 4

@@ -116,6 +116,10 @@
    Object {
      "from": "province_30",
      "kind": "attack",
      "to": "province_8",
    },
+   Object {
+     "amount": 3,
+     "kind": "captureMove",
+   },
  ]
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 1 human / 3 computer seats · Computer play · Seed 1994
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]: 9 provinces · 19 armies
      - generic [ref=e16]:
        - generic [ref=e17]: Seat 2 · Computer
        - generic [ref=e18]: 9 provinces · 21 armies
      - generic [ref=e22]:
        - generic [ref=e23]: Seat 3 · Computer
        - generic [ref=e24]: 12 provinces · 23 armies
      - generic [ref=e28]:
        - generic [ref=e29]: Seat 4 · Computer
        - generic [ref=e30]: 16 provinces · 18 armies
    - contentinfo [ref=e31]:
      - button "New game" [ref=e32] [cursor=pointer]
    - generic [ref=e33]:
      - button "Save game" [active] [ref=e34] [cursor=pointer]
      - generic [ref=e35]:
        - generic [ref=e36]: Load game
        - button "Load game" [ref=e37]
  - main [ref=e38]:
    - img "Nine Isles reference map" [ref=e40]:
      - button "River gate, Seat 3, 2 armies" [ref=e65] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: 3 · 2
      - button "New port, Seat 1, 1 armies" [pressed] [ref=e67] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: 1 · 1
      - button "North rest, Seat 1, 3 armies" [ref=e69] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: 1 · 3
      - button "River keep, Seat 2, 1 armies" [ref=e71] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: 2 · 1
      - button "North town, Seat 2, 1 armies" [ref=e73] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: 2 · 1
      - button "Dark ford, Seat 3, 1 armies" [ref=e75] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: 3 · 1
      - button "Iron point, Seat 3, 1 armies" [ref=e77] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: 3 · 1
      - button "South rest, Seat 3, 3 armies" [ref=e79] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: 3 · 3
      - button "High shore, Seat 1, 2 armies" [ref=e81] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: 1 · 2
      - button "Wind town, Seat 2, 3 armies" [ref=e83] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: 2 · 3
      - button "New glen, Seat 4, 2 armies" [ref=e85] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: 4 · 2
      - button "Old rock, Seat 3, 2 armies" [ref=e87] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: 3 · 2
      - button "Blue peak, Seat 2, 3 armies" [ref=e89] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: 2 · 3
      - button "West haven, Seat 4, 1 armies" [ref=e91] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: 4 · 1
      - button "Stone watch, Seat 2, 3 armies" [ref=e93] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: 2 · 3
      - button "Upper ridge, Seat 4, 1 armies" [ref=e95] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: 4 · 1
      - button "Marsh keep, Seat 1, 3 armies" [ref=e97] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: 1 · 3
      - button "New fell, Seat 4, 1 armies" [ref=e99] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: 4 · 1
      - button "Moon point, Seat 2, 2 armies" [ref=e101] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: 2 · 2
      - button "South fell, Seat 1, 3 armies" [ref=e103] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: 1 · 3
      - button "High ridge, Seat 2, 2 armies" [ref=e105] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: 2 · 2
      - button "Bay ford, Seat 2, 3 armies" [ref=e107] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: 2 · 3
      - button "Low moor, Seat 1, 2 armies" [ref=e109] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: 1 · 2
      - button "Lower field, Seat 4, 1 armies" [ref=e111] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: 4 · 1
      - button "Wind gate, Seat 3, 1 armies" [ref=e113] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: 3 · 1
      - button "Silver shore, Seat 4, 1 armies" [ref=e115] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: 4 · 1
      - button "Low peak, Seat 4, 1 armies" [ref=e117] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: 4 · 1
      - button "Wind port, Seat 4, 1 armies" [ref=e119] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: 4 · 1
      - button "Gold point, Seat 3, 2 armies" [ref=e121] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: 3 · 2
        - generic [ref=e123]: ★
      - button "Rock moor, Seat 1, 2 armies" [ref=e124] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: 1 · 2
      - button "Marsh rest, Seat 3, 2 armies" [ref=e126] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: 3 · 2
      - button "Wind dale, Seat 4, 1 armies" [ref=e128] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: 4 · 1
      - button "Silver ford, Seat 4, 2 armies" [ref=e130] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: 4 · 2
      - button "Iron field, Seat 4, 1 armies" [ref=e132] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: 4 · 1
      - button "North wood, Seat 4, 1 armies" [ref=e134] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: 4 · 1
      - button "Fort town, Seat 3, 2 armies" [ref=e136] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: 3 · 2
        - generic [ref=e138]: ★
      - button "Red field, Seat 2, 3 armies" [ref=e139] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: 2 · 3
        - generic [ref=e141]: ★
      - button "South ridge, Seat 1, 2 armies" [ref=e142] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: 1 · 2
      - button "Rock bay, Seat 4, 1 armies" [ref=e144] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: 4 · 1
      - button "North ford, Seat 4, 1 armies" [ref=e146] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: 4 · 1
      - button "Port ridge, Seat 3, 3 armies" [ref=e148] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: 3 · 3
      - button "New rock, Seat 1, 1 armies" [ref=e150] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: 1 · 1
      - button "South reach, Seat 3, 3 armies" [ref=e152] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: 3 · 3
      - button "Silver point, Seat 3, 1 armies" [ref=e154] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: 3 · 1
      - button "East ford, Seat 4, 1 armies" [ref=e156] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: 4 · 1
      - button "Gold town, Seat 4, 1 armies" [ref=e158] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: 4 · 1
      - generic [ref=e190]: North Isle +3
      - generic [ref=e191]: East Isle +3
      - generic [ref=e192]: West Isle +3
      - generic [ref=e193]: South Isle +3
      - generic [ref=e194]: Central Isle +5
      - generic [ref=e195]: Harbor Isle +5
      - generic [ref=e196]: Palm Isle +6
      - generic [ref=e197]: Cliff Isle +5
      - generic [ref=e198]: Great Isle +9
    - complementary [ref=e199]:
      - generic [ref=e203]:
        - generic [ref=e204]: Seat 1's turn
        - generic [ref=e205]: Round 1 · Attack
      - generic [ref=e206]:
        - generic [ref=e207]:
          - button "End turn" [ref=e208] [cursor=pointer]
          - button "Move armies" [ref=e209] [cursor=pointer]
        - region "Battle controls" [ref=e210]:
          - heading "Battle" [level=2] [ref=e211]
          - generic [ref=e212]:
            - generic [ref=e213]:
              - generic [ref=e214]: From
              - strong [ref=e215]: New port
              - generic "Source armies" [ref=e216]: "1"
            - generic [ref=e217]:
              - generic [ref=e218]: Target
              - strong [ref=e219]: North rest
              - generic "Target armies" [ref=e220]: "3"
          - generic [ref=e221]:
            - generic [ref=e222]:
              - text: Stop at armies
              - spinbutton "Stop at armies" [ref=e223]: "1"
            - generic [ref=e224]:
              - text: Battle speed
              - combobox "Battle speed" [ref=e225]:
                - option "Slow"
                - option "Normal" [selected]
                - option "Fast"
          - paragraph [ref=e226]: This battle stops at 1 army, or on capture.
          - generic [ref=e227]:
            - button "Fight on" [disabled] [ref=e228]
            - button "Stop" [disabled] [ref=e229]
            - button "Single exchange" [disabled] [ref=e230]
          - generic [ref=e231]:
            - strong [ref=e232]: Target captured
            - paragraph [ref=e233]: 3 armies move into the captured country.
          - paragraph [ref=e234]:
            - text: Won 1 · Lost 0 · Ties
            - strong [ref=e235]: "0"
          - list "Latest exchange dice" [ref=e236]:
            - listitem [ref=e237]:
              - img "Attacker rolled 5" [ref=e238]: "5"
              - generic [ref=e239]: Attacker wins
              - img "Defender rolled 1" [ref=e240]: "1"
      - generic [ref=e241]:
        - heading "Battle log" [level=3] [ref=e242]
        - list "Battle log" [ref=e243]:
          - listitem [ref=e244]: "T1 Seat 1: New port → North rest, took North rest"
          - listitem [ref=e245]: T1 Seat 4 ends the turn
          - listitem [ref=e246]: "T1 Seat 4: East ford → Silver point, -1 / -0"
          - listitem [ref=e247]: "T1 Seat 4: East ford → Silver point, -1 / -0"
          - listitem [ref=e248]: "T1 Seat 4: East ford → Silver point, -0 / -1"
          - listitem [ref=e249]: "T1 Seat 4: Gold town → East ford, took East ford"
          - listitem [ref=e250]: "T1 Seat 4: Gold town → East ford, -0 / -1"
```

# Test source

```ts
  10  | function step(state: GameState, action: Action) {
  11  |   const result = apply(state, action);
  12  |   if (!result.ok) throw Error(JSON.stringify(action) + ": " + result.error);
  13  |   return result.state;
  14  | }
  15  | async function save(page: Page) {
  16  |   // Pace downloads; this investigation does not measure download throughput.
  17  |   await new Promise(resolve => setTimeout(resolve, 150));
  18  |   const event = page.waitForEvent("download", {timeout: 15_000});
  19  |   await page.getByRole("button", {name: "Save game", exact: true}).click();
  20  |   return readFileSync((await (await event).path())!, "utf8");
  21  | }
  22  | function capturePlan(state: GameState, repeats = false) {
  23  |   for (const source of state.map.provinces.filter(p => state.ownerOf[p.id] === activePlayer(state)!.id)) {
  24  |     let ready = state;
  25  |     for (let i = 0; i < state.reinforcementPool; i++) ready = step(ready, {kind: "reinforce", province: source.id, amount: 1});
  26  |     ready = step(ready, {kind: "endReinforcement"});
  27  |     for (const to of [...source.borders, ...source.seaLanes]) {
  28  |       if (ready.ownerOf[to] === activePlayer(ready)!.id) continue;
  29  |       let next = ready, exchanges = 0;
  30  |       while (next.phase === "attack" && next.ownerOf[to] !== activePlayer(ready)!.id && next.armies[source.id]! > 1 && exchanges < 50) {
  31  |         next = step(next, {kind: "attack", from: source.id, to}); exchanges++;
  32  |       }
  33  |       if (exchanges >= (repeats ? 2 : 1) && (next.phase === "capture" ? next.pendingCapture!.max : next.armies[to]!) >= 3 && (next.phase === "capture" || next.ownerOf[to] === activePlayer(ready)!.id)) return {from: source.id, to, placements: state.reinforcementPool, ready, exchanges};
  34  |     }
  35  |   }
  36  |   throw Error("No bounded ordinary-action capture matching repeat and move-in requirements");
  37  | }
  38  | for (const modern of [true, false]) test(modern ? "root repeat, Stop, capture choice and real save/resume" : "owner legacy URL automatic capture and target clearing", async ({page}, info) => {
  39  |   test.setTimeout(120_000);
  40  |   const evidence = process.env["PLAYTEST_EVIDENCE_DIR"];
  41  |   if (!evidence) throw Error("Use run.py to retain the playtest");
  42  |   const dir = mkdtempSync(join(evidence, `${modern ? "root" : "legacy"}-${info.project.name}-`));
  43  |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  44  |   page.on("console", m => { if (m.type() === "error") errors.push(m.text()); });
  45  |   const read = (text: string) => modern ? deserializeVersionedMatch(text).state : deserializeMatch(text).state;
  46  |   let sequence = 0;
  47  |   async function checkpoint(name: string) {
  48  |     const text = await save(page); writeFileSync(join(dir, `${sequence++}-${name}.json`), text); return read(text);
  49  |   }
  50  |   async function screenshot(name: string) { await page.mouse.move(0, 0); await page.screenshot({path: join(dir, name + ".png"), fullPage: true, animations: "disabled"}); }
  51  |   await page.clock.install(); await page.clock.pauseAt(new Date("2026-10-17T12:00:00Z"));
  52  |   await page.goto(modern ? "/" : "/?view=generated-game&seed=1994&seats=4&opponents=computer");
  53  |   if (modern) {
  54  |     for (let seat = 1; seat <= 4; seat++) await expect(page.getByLabel(`Seat ${seat} control`, {exact: true})).toHaveValue(seat === 1 ? "human" : "computer");
  55  |     await page.getByRole("button", {name: "Start game", exact: true}).click();
  56  |   }
  57  |   let state = await checkpoint("opening");
  58  |   expect(state.rules.combat.capture).toBe(modern ? "choice" : "all");
  59  |   let expectedHuman = state, computerSteps = 0;
  60  |   while (activePlayer(expectedHuman)!.kind === "computer" && computerSteps < 400) {
  61  |     const action = computerAction(expectedHuman); if (!action) throw Error("No computer action");
  62  |     expectedHuman = step(expectedHuman, action); computerSteps++;
  63  |   }
  64  |   expect(activePlayer(expectedHuman)!.kind).toBe("human");
  65  |   await page.clock.runFor(computerSteps * 350);
  66  |   state = await checkpoint("after-computer-opener");
  67  |   expect(state.history).toEqual(expectedHuman.history);
  68  |   expect(activePlayer(state)!.kind).toBe("human");
  69  |   await checkpoint("human-turn"); await screenshot("opening");
  70  |   const plan = capturePlan(state, !modern);
  71  |   for (let i = 0; i < plan.placements; i++) await country(page, plan.from).click();
  72  |   await page.locator("#start-combat-button").click();
  73  |   expect((await checkpoint("ready")).history).toEqual(plan.ready.history); state = plan.ready;
  74  |   await country(page, plan.from).click(); await country(page, plan.to).click();
  75  |   await country(page, plan.to).click(); await country(page, plan.to).press("Enter");
  76  |   expect((await checkpoint("repeated-map-selection-no-attack")).history).toEqual(state.history);
  77  |   await screenshot("selected-target");
  78  |   const attack: Action = {kind: "attack", from: plan.from, to: plan.to};
  79  |   if (modern) {
  80  |     // Use a second enemy with a longer battle for repeat/Stop when available.
  81  |     // Seed 1994's concentrated capture is a one-exchange win; do not pretend it proves repetition.
  82  |     const readyText = await save(page);
  83  |     const repeated = state.map.provinces.flatMap(p => [...p.borders, ...p.seaLanes].map(to => ({kind: "attack" as const, from: p.id, to}))).find(action => {
  84  |       const first = apply(state, action); if (!first.ok || first.state.phase !== "attack") return false;
  85  |       return apply(first.state, action).ok;
  86  |     });
  87  |     if (!repeated) throw Error("No legal repeat pair in actual concentrated deal");
  88  |     await country(page, repeated.from).click(); await country(page, repeated.to).click();
  89  |     let repeatedState = state;
  90  |     for (let i = 0; i < 2; i++) {
  91  |       await page.locator("#single-exchange-button").click(); repeatedState = step(repeatedState, repeated);
  92  |       expect((await checkpoint("repeated-single")).history).toEqual(repeatedState.history);
  93  |       await expect(country(page, repeated.from)).toHaveAttribute("aria-pressed", "true");
  94  |       await expect(page.locator("#battle-target-name")).toHaveText(state.map.provinces.find(p => p.id === repeated.to)!.name);
  95  |     }
  96  |     await page.getByLabel("Load game", {exact: true}).setInputFiles({name: "ready.json", mimeType: "application/json", buffer: Buffer.from(readyText)});
  97  |     await expect(page.locator("#battle-source-name")).toHaveText("Choose your country");
  98  |     await country(page, repeated.from).click(); await country(page, repeated.to).click();
  99  |     await page.locator("#battle-stop-threshold").fill("1"); await page.locator("#battle-stop-threshold").press("Tab");
  100 |     await page.locator("#fight-on-button").click();
  101 |     const stopped = step(state, repeated);
  102 |     await page.locator("#stop-battle-button").click(); await page.clock.runFor(4000);
  103 |     expect((await checkpoint("stopped")).history).toEqual(stopped.history); await screenshot("stopped");
  104 |     await page.getByLabel("Load game", {exact: true}).setInputFiles({name: "ready.json", mimeType: "application/json", buffer: Buffer.from(readyText)});
  105 |     await expect(page.locator("#battle-source-name")).toHaveText("Choose your country");
  106 |     await country(page, plan.from).click(); await country(page, plan.to).click();
  107 |     await page.locator("#battle-stop-threshold").fill("1"); await page.locator("#battle-stop-threshold").press("Tab");
  108 |     await page.locator("#fight-on-button").click(); state = step(state, attack);
  109 |     for (let i = 1; i < plan.exchanges; i++) { await page.clock.runFor(350); state = step(state, attack); }
> 110 |     expect((await checkpoint("capture-interrupted-fight")).history).toEqual(state.history);
      |                                                                     ^ Error: expect(received).toEqual(expected) // deep equality
  111 |     expect(state.phase).toBe("capture");
  112 |     await expect(page.locator("#confirm-capture-button")).toBeVisible();
  113 |     const pendingText = await save(page), pending = state.pendingCapture!;
  114 |     writeFileSync(join(dir, "pending-save.json"), pendingText);
  115 |     await screenshot("pending-capture");
  116 |     await country(page, plan.to).click(); await country(page, plan.to).press("Enter"); await page.clock.runFor(4000);
  117 |     expect((await checkpoint("capture-not-auto-confirmed")).history).toEqual(state.history);
  118 |     const quantities = [pending.min, Math.floor((pending.min + pending.max) / 2), pending.max];
  119 |     expect(new Set(quantities).size).toBe(3);
  120 |     for (const amount of quantities) {
  121 |       await page.getByLabel("Load game", {exact: true}).setInputFiles({name: "pending.json", mimeType: "application/json", buffer: Buffer.from(pendingText)});
  122 |       await expect(page.locator("#capture-amount")).toHaveAttribute("min", String(pending.min));
  123 |       await expect(page.locator("#capture-amount")).toHaveAttribute("max", String(pending.max));
  124 |       expect((await checkpoint("resumed-pending")).history).toEqual(state.history);
  125 |       await page.locator("#capture-amount").fill(String(amount)); await page.locator("#confirm-capture-button").click();
  126 |       const resolved = await checkpoint(`confirmed-${amount}`), expected = step(state, {kind: "captureMove", amount});
  127 |       expect(resolved.history).toEqual(expected.history); expect(resolved.armies).toEqual(expected.armies);
  128 |       expect(resolved.armies[plan.from]).toBeGreaterThanOrEqual(1);
  129 |       await screenshot(`confirmed-${amount}`);
  130 |     }
  131 |   } else {
  132 |     for (let i = 0; i < plan.exchanges; i++) {
  133 |       if (i) await country(page, plan.to).click();
  134 |       await page.locator("#attack-button").click(); state = step(state, attack);
  135 |       await expect(page.locator("#result-dialog")).toBeVisible();
  136 |       if (i === plan.exchanges - 1) {
  137 |         await expect(page.locator("#result-dialog")).toContainText("armies move in");
  138 |         await expect(page.locator("#capture-amount")).toHaveCount(0);
  139 |         await screenshot("automatic-capture-result");
  140 |       }
  141 |       await page.getByRole("button", {name: "Continue", exact: true}).click();
  142 |       expect((await checkpoint("legacy-exchange")).history).toEqual(state.history);
  143 |       await expect(page.locator("#attack-button")).toBeDisabled();
  144 |     }
  145 |     expect(state.ownerOf[plan.to]).toBe(activePlayer(state)!.id); expect(state.pendingCapture).toBeUndefined();
  146 |     await checkpoint("automatic-transfer-complete");
  147 |   }
  148 |   writeFileSync(join(dir, "observations.json"), JSON.stringify({url: page.url(), modern, seed: 1994, plan, errors, annotations: await page.locator(".army-count").allTextContents()}, null, 2));
  149 |   expect(errors).toEqual([]);
  150 | });
  151 | 
```