# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: flow.spec.ts >> owner legacy URL automatic capture and target clearing
- Location: docs/prototypes/new-game/playtest-137-139/flow.spec.ts:36:37

# Error details

```
Test timeout of 120000ms exceeded.
```

```
Error: page.waitForEvent: Test timeout of 120000ms exceeded.
=========================== logs ===========================
waiting for event "download"
============================================================
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic "Map legend" [ref=e5]:
      - generic [ref=e6]: Seat · armies
      - generic [ref=e7]: Land
      - generic [ref=e9]: Sea
    - generic [ref=e11]:
      - generic [ref=e12]: Seed
      - spinbutton "Seed" [ref=e13]: "1994"
      - button "Generate" [ref=e14] [cursor=pointer]
    - generic [ref=e15]:
      - button "Save game" [active] [ref=e16] [cursor=pointer]
      - generic [ref=e17]:
        - generic [ref=e18]: Load game
        - button "Load game" [ref=e19]
  - main [ref=e20]:
    - 'group "Generated archipelago: 46 countries on 9 islands" [ref=e22]':
      - generic [aria-hidden] [ref=e24]:
        - generic [ref=e26]: North Isle / +3
        - generic [ref=e28]: East Isle / +3
        - generic [ref=e30]: West Isle / +3
        - generic [ref=e32]: South Isle / +3
        - generic [ref=e34]: Central Isle / +5
        - generic [ref=e36]: Harbor Isle / +4
        - generic [ref=e38]: Palm Isle / +5
        - generic [ref=e40]: Cliff Isle / +5
        - generic [ref=e42]: Great Isle / +7
      - generic [ref=e43]:
        - button "River gate, Seat 3, 1 armies" [ref=e44] [cursor=pointer]:
          - generic: River gate
          - generic: 3 · 1
        - button "New port, Seat 2, 1 armies" [ref=e46] [cursor=pointer]:
          - generic: New port
          - generic: 2 · 1
        - button "North rest, Seat 4, 1 armies" [ref=e48] [cursor=pointer]:
          - generic: North rest
          - generic: 4 · 1
        - button "River keep, Seat 2, 3 armies" [ref=e50] [cursor=pointer]:
          - generic: River keep
          - generic: 2 · 3
        - button "North town, Seat 3, 1 armies" [ref=e52] [cursor=pointer]:
          - generic: North town
          - generic: 3 · 1
        - button "Dark ford, Seat 3, 1 armies" [ref=e54] [cursor=pointer]:
          - generic: Dark ford
          - generic: 3 · 1
        - button "Iron point, Seat 3, 2 armies" [ref=e56] [cursor=pointer]:
          - generic: Iron point
          - generic: 3 · 2
        - button "South rest, Seat 2, 3 armies" [ref=e58] [cursor=pointer]:
          - generic: South rest
          - generic: 2 · 3
        - button "High shore, Seat 1, 2 armies" [ref=e60] [cursor=pointer]:
          - generic: High shore
          - generic: 1 · 2
        - button "Wind town, Seat 3, 1 armies" [ref=e62] [cursor=pointer]:
          - generic: Wind town
          - generic: 3 · 1
        - button "New glen, Seat 1, 2 armies" [ref=e64] [cursor=pointer]:
          - generic: New glen
          - generic: 1 · 2
        - button "Old rock, Seat 3, 1 armies" [ref=e66] [cursor=pointer]:
          - generic: Old rock
          - generic: 3 · 1
        - button "Blue peak, Seat 2, 2 armies" [ref=e68] [cursor=pointer]:
          - generic: Blue peak
          - generic: 2 · 2
        - button "West haven, Seat 1, 2 armies" [ref=e70] [cursor=pointer]:
          - generic: West haven
          - generic: 1 · 2
        - button "Stone watch, Seat 3, 2 armies" [ref=e72] [cursor=pointer]:
          - generic: Stone watch
          - generic: 3 · 2
        - button "Upper ridge, Seat 3, 2 armies" [ref=e74] [cursor=pointer]:
          - generic: Upper ridge
          - generic: 3 · 2
        - button "Marsh keep, Seat 3, 1 armies" [ref=e76] [cursor=pointer]:
          - generic: Marsh keep
          - generic: 3 · 1
        - button "New fell, Seat 4, 3 armies" [ref=e78] [cursor=pointer]:
          - generic: New fell
          - generic: 4 · 3
        - button "Moon point, Seat 1, 3 armies" [ref=e80] [cursor=pointer]:
          - generic: Moon point
          - generic: 1 · 3
        - button "South fell, Seat 3, 1 armies" [ref=e82] [cursor=pointer]:
          - generic: South fell
          - generic: 3 · 1
        - button "High ridge, Seat 4, 3 armies" [ref=e84] [cursor=pointer]:
          - generic: High ridge
          - generic: 4 · 3
        - button "Bay ford, Seat 1, 3 armies" [ref=e86] [cursor=pointer]:
          - generic: Bay ford
          - generic: 1 · 3
        - button "Low moor, Seat 2, 3 armies" [ref=e88] [cursor=pointer]:
          - generic: Low moor
          - generic: 2 · 3
        - button "Lower field, Seat 3, 1 armies" [ref=e90] [cursor=pointer]:
          - generic: Lower field
          - generic: 3 · 1
        - button "Wind gate, Seat 4, 2 armies" [ref=e92] [cursor=pointer]:
          - generic: Wind gate
          - generic: 4 · 2
        - button "Silver shore, Seat 4, 2 armies" [ref=e94] [cursor=pointer]:
          - generic: Silver shore
          - generic: 4 · 2
        - button "Low peak, Seat 4, 3 armies" [ref=e96] [cursor=pointer]:
          - generic: Low peak
          - generic: 4 · 3
        - button "Wind port, Seat 4, 1 armies" [ref=e98] [cursor=pointer]:
          - generic: Wind port
          - generic: 4 · 1
        - button "Gold point, Seat 1, 3 armies" [ref=e100] [cursor=pointer]:
          - generic: Gold point
          - generic: 1 · 3
        - button "Rock moor, Seat 4, 2 armies" [ref=e102] [cursor=pointer]:
          - generic: Rock moor
          - generic: 4 · 2
        - button "Marsh rest, Seat 4, 1 armies" [ref=e104] [cursor=pointer]:
          - generic: Marsh rest
          - generic: 4 · 1
        - button "Wind dale, Seat 2, 2 armies" [ref=e106] [cursor=pointer]:
          - generic: Wind dale
          - generic: 2 · 2
        - button "Silver ford, Seat 3, 1 armies" [ref=e108] [cursor=pointer]:
          - generic: Silver ford
          - generic: 3 · 1
        - button "Iron field, Seat 3, 1 armies" [ref=e110] [cursor=pointer]:
          - generic: Iron field
          - generic: 3 · 1
        - button "North wood, Seat 2, 2 armies" [ref=e112] [cursor=pointer]:
          - generic: North wood
          - generic: 2 · 2
        - button "Fort town, Seat 1, 2 armies" [ref=e114] [cursor=pointer]:
          - generic: Fort town
          - generic: 1 · 2
        - button "Red field, Seat 2, 2 armies" [ref=e116] [cursor=pointer]:
          - generic: Red field
          - generic: 2 · 2
        - button "South ridge, Seat 1, 2 armies" [ref=e118] [cursor=pointer]:
          - generic: South ridge
          - generic: 1 · 2
        - button "Rock bay, Seat 3, 1 armies" [ref=e120] [cursor=pointer]:
          - generic: Rock bay
          - generic: 3 · 1
        - button "North ford, Seat 4, 1 armies" [ref=e122] [cursor=pointer]:
          - generic: North ford
          - generic: 4 · 1
        - button "Port ridge, Seat 1, 1 armies" [ref=e124] [cursor=pointer]:
          - generic: Port ridge
          - generic: 1 · 1
        - button "New rock, Seat 3, 1 armies" [ref=e126] [cursor=pointer]:
          - generic: New rock
          - generic: 3 · 1
        - button "South reach, Seat 2, 2 armies" [ref=e128] [cursor=pointer]:
          - generic: South reach
          - generic: 2 · 2
        - button "Silver point, Seat 1, 1 armies" [ref=e130] [cursor=pointer]:
          - generic: Silver point
          - generic: 1 · 1
        - button "East ford, Seat 4, 3 armies" [ref=e132] [cursor=pointer]:
          - generic: East ford
          - generic: 4 · 3
        - button "Gold town, Seat 3, 1 armies" [ref=e134] [cursor=pointer]:
          - generic: Gold town
          - generic: 3 · 1
    - complementary [ref=e136]:
      - generic [ref=e140]:
        - generic [ref=e141]: Seat 3's turn
        - generic [ref=e142]: Computer · Normal · Round 1 · Attack
      - generic [ref=e143]:
        - generic [ref=e147]:
          - generic [ref=e148]: Seat 1
          - generic [ref=e149]: 10 provinces · 21 armies
        - generic [ref=e153]:
          - generic [ref=e154]: Seat 2 · Computer
          - generic [ref=e155]: 9 provinces · 20 armies
        - generic [ref=e159]:
          - generic [ref=e160]: Seat 3 · Computer
          - generic [ref=e161]: 16 provinces · 19 armies
        - generic [ref=e165]:
          - generic [ref=e166]: Seat 4 · Computer
          - generic [ref=e167]: 11 provinces · 22 armies
      - generic [ref=e168]:
        - list [ref=e170]:
          - listitem [ref=e171]:
            - generic [ref=e172]: "1"
            - generic [ref=e173]: From
            - generic [ref=e174]: your province
          - listitem [ref=e175]:
            - generic [ref=e176]: "2"
            - generic [ref=e177]: Target
            - generic [ref=e178]: adjacent enemy
          - listitem [ref=e179]:
            - generic [ref=e180]: "3"
            - generic [ref=e181]: Then
            - generic [ref=e182]: —
        - paragraph [ref=e183]: Computer is playing. Save, load or start a new game at any time.
        - generic [ref=e184]:
          - button "Attack" [disabled] [ref=e185]
          - button "End turn" [disabled] [ref=e186]
        - paragraph [ref=e187]: "Dashed outline on every target, and a marker where one fits: provinces you can attack from the selected one."
      - generic [ref=e191]:
        - heading "Battle log" [level=3] [ref=e192]
        - list "Battle log" [ref=e193]:
          - listitem [ref=e194]: "T1 Seat 3: Marsh keep → Stone watch, took Stone watch"
          - listitem [ref=e195]: "T1 Seat 3: Marsh keep → Stone watch, -0 / -1"
          - listitem [ref=e196]: "T1 Seat 3: North town → Dark ford, took Dark ford"
          - listitem [ref=e197]: "T1 Seat 3: North town → Dark ford, -1 / -0"
          - listitem [ref=e198]: "T1 Seat 3: North town → Dark ford, -1 / -0"
          - listitem [ref=e199]: "T1 Seat 3: North town → Dark ford, -0 / -1"
          - listitem [ref=e200]: "T1 Seat 3: North town → Dark ford, -1 / -0"
      - generic [ref=e201]:
        - button "New game" [ref=e202] [cursor=pointer]
        - generic [ref=e203]: seed 1994
        - button "How to play" [ref=e204] [cursor=pointer]: Help
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test";
  2   | import type { Page } from "@playwright/test";
  3   | import { mkdirSync, mkdtempSync, readFileSync, writeFileSync } from "node:fs";
  4   | import { join } from "node:path";
  5   | import { activePlayer, apply } from "../../../../src/core";
  6   | import type { Action, GameState } from "../../../../src/core";
  7   | import { deserializeMatch, deserializeVersionedMatch } from "../../../../src/core/match-save";
  8   | 
  9   | const country = (page: Page, id: string) => page.locator(`[data-country="${id}"]`);
  10  | function step(state: GameState, action: Action) {
  11  |   const result = apply(state, action);
  12  |   if (!result.ok) throw Error(JSON.stringify(action) + ": " + result.error);
  13  |   return result.state;
  14  | }
  15  | async function save(page: Page) {
> 16  |   const event = page.waitForEvent("download");
      |                      ^ Error: page.waitForEvent: Test timeout of 120000ms exceeded.
  17  |   await page.getByRole("button", {name: "Save game", exact: true}).click();
  18  |   return readFileSync((await (await event).path())!, "utf8");
  19  | }
  20  | function capturePlan(state: GameState) {
  21  |   for (const source of state.map.provinces.filter(p => state.ownerOf[p.id] === activePlayer(state)!.id)) {
  22  |     let ready = state;
  23  |     for (let i = 0; i < state.reinforcementPool; i++) ready = step(ready, {kind: "reinforce", province: source.id, amount: 1});
  24  |     ready = step(ready, {kind: "endReinforcement"});
  25  |     for (const to of [...source.borders, ...source.seaLanes]) {
  26  |       if (ready.ownerOf[to] === activePlayer(ready)!.id) continue;
  27  |       let next = ready, exchanges = 0;
  28  |       while (next.phase === "attack" && next.ownerOf[to] !== activePlayer(ready)!.id && next.armies[source.id]! > 1 && exchanges < 50) {
  29  |         next = step(next, {kind: "attack", from: source.id, to}); exchanges++;
  30  |       }
  31  |       if (exchanges >= 4 && (next.phase === "capture" ? next.pendingCapture!.max : next.armies[to]!) >= 3 && (next.phase === "capture" || next.ownerOf[to] === activePlayer(ready)!.id)) return {from: source.id, to, placements: state.reinforcementPool, ready, exchanges};
  32  |     }
  33  |   }
  34  |   throw Error("No bounded ordinary-action capture with three exchanges and three move-in amounts");
  35  | }
  36  | for (const modern of [true, false]) test(modern ? "root repeat, Stop, capture choice and real save/resume" : "owner legacy URL automatic capture and target clearing", async ({page}, info) => {
  37  |   test.setTimeout(120_000);
  38  |   const evidence = process.env["PLAYTEST_EVIDENCE_DIR"];
  39  |   if (!evidence) throw Error("Use run.py to retain the playtest");
  40  |   const dir = mkdtempSync(join(evidence, `${modern ? "root" : "legacy"}-${info.project.name}-`));
  41  |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  42  |   page.on("console", m => { if (m.type() === "error") errors.push(m.text()); });
  43  |   const read = (text: string) => modern ? deserializeVersionedMatch(text).state : deserializeMatch(text).state;
  44  |   let sequence = 0;
  45  |   async function checkpoint(name: string) {
  46  |     const text = await save(page); writeFileSync(join(dir, `${sequence++}-${name}.json`), text); return read(text);
  47  |   }
  48  |   async function screenshot(name: string) { await page.mouse.move(0, 0); await page.screenshot({path: join(dir, name + ".png"), fullPage: true}); }
  49  |   await page.clock.install(); await page.clock.pauseAt(new Date("2026-10-17T12:00:00Z"));
  50  |   await page.goto(modern ? "/" : "/?view=generated-game&seed=1994&seats=4&opponents=computer");
  51  |   if (modern) {
  52  |     for (let seat = 1; seat <= 4; seat++) await expect(page.getByLabel(`Seat ${seat} control`, {exact: true})).toHaveValue(seat === 1 ? "human" : "computer");
  53  |     await page.getByRole("button", {name: "Start game", exact: true}).click();
  54  |   }
  55  |   let state = await checkpoint("opening");
  56  |   expect(state.rules.combat.capture).toBe(modern ? "choice" : "all");
  57  |   for (let i = 0; activePlayer(state)!.kind !== "human" && i < 400; i++) { await page.clock.runFor(525); state = read(await save(page)); }
  58  |   expect(activePlayer(state)!.kind).toBe("human");
  59  |   await checkpoint("human-turn"); await screenshot("opening");
  60  |   const plan = capturePlan(state);
  61  |   for (let i = 0; i < plan.placements; i++) await country(page, plan.from).click();
  62  |   await page.locator("#start-combat-button").click();
  63  |   expect((await checkpoint("ready")).history).toEqual(plan.ready.history); state = plan.ready;
  64  |   await country(page, plan.from).click(); await country(page, plan.to).click();
  65  |   await country(page, plan.to).click(); await country(page, plan.to).press("Enter");
  66  |   expect((await checkpoint("repeated-map-selection-no-attack")).history).toEqual(state.history);
  67  |   await screenshot("selected-target");
  68  |   const attack: Action = {kind: "attack", from: plan.from, to: plan.to};
  69  |   if (modern) {
  70  |     const once = async () => { await page.locator("#single-exchange-button").click(); state = step(state, attack); expect((await checkpoint("single")).history).toEqual(state.history); await expect(country(page, plan.from)).toHaveAttribute("aria-pressed", "true"); await expect(page.locator("#battle-target-name")).toHaveText(state.map.provinces.find(p => p.id === plan.to)!.name); };
  71  |     await once(); await once();
  72  |     await page.locator("#battle-stop-threshold").fill("1"); await page.locator("#battle-stop-threshold").press("Tab");
  73  |     await page.locator("#fight-on-button").click(); state = step(state, attack);
  74  |     if (state.phase === "attack") {
  75  |       await page.locator("#stop-battle-button").click(); await page.clock.runFor(4000);
  76  |       expect((await checkpoint("stopped")).history).toEqual(state.history);
  77  |       await screenshot("stopped"); await page.locator("#fight-on-button").click(); state = step(state, attack);
  78  |     }
  79  |     while (state.phase === "attack") { await page.clock.runFor(525); state = read(await save(page)); }
  80  |     expect(state.phase).toBe("capture");
  81  |     await expect(page.locator("#confirm-capture-button")).toBeVisible();
  82  |     const pendingText = await save(page), pending = state.pendingCapture!;
  83  |     writeFileSync(join(dir, "pending-save.json"), pendingText);
  84  |     await screenshot("pending-capture");
  85  |     await country(page, plan.to).click(); await country(page, plan.to).press("Enter"); await page.clock.runFor(4000);
  86  |     expect((await checkpoint("capture-not-auto-confirmed")).history).toEqual(state.history);
  87  |     const quantities = [pending.min, Math.floor((pending.min + pending.max) / 2), pending.max];
  88  |     expect(new Set(quantities).size).toBe(3);
  89  |     for (const amount of quantities) {
  90  |       await page.getByLabel("Load game", {exact: true}).setInputFiles({name: "pending.json", mimeType: "application/json", buffer: Buffer.from(pendingText)});
  91  |       await expect(page.locator("#capture-amount")).toHaveAttribute("min", String(pending.min));
  92  |       await expect(page.locator("#capture-amount")).toHaveAttribute("max", String(pending.max));
  93  |       expect((await checkpoint("resumed-pending")).history).toEqual(state.history);
  94  |       await page.locator("#capture-amount").fill(String(amount)); await page.locator("#confirm-capture-button").click();
  95  |       const resolved = await checkpoint(`confirmed-${amount}`), expected = step(state, {kind: "captureMove", amount});
  96  |       expect(resolved.history).toEqual(expected.history); expect(resolved.armies).toEqual(expected.armies);
  97  |       expect(resolved.armies[plan.from]).toBeGreaterThanOrEqual(1);
  98  |       await screenshot(`confirmed-${amount}`);
  99  |     }
  100 |   } else {
  101 |     for (let i = 0; i < plan.exchanges; i++) {
  102 |       if (i) await country(page, plan.to).click();
  103 |       await page.locator("#attack-button").click(); state = step(state, attack);
  104 |       await expect(page.locator("#result-dialog")).toBeVisible();
  105 |       expect((await checkpoint("legacy-exchange")).history).toEqual(state.history);
  106 |       if (i === plan.exchanges - 1) {
  107 |         await expect(page.locator("#result-dialog")).toContainText("armies move in");
  108 |         await expect(page.locator("#capture-amount")).toHaveCount(0);
  109 |         await screenshot("automatic-capture-result");
  110 |       }
  111 |       await page.getByRole("button", {name: "Continue", exact: true}).click();
  112 |       await expect(page.locator("#attack-button")).toBeDisabled();
  113 |     }
  114 |     expect(state.ownerOf[plan.to]).toBe(activePlayer(state)!.id); expect(state.pendingCapture).toBeUndefined();
  115 |     await checkpoint("automatic-transfer-complete");
  116 |   }
```