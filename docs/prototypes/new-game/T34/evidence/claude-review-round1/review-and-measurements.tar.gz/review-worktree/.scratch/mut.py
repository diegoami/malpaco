import sys,subprocess,os
from pathlib import Path
core=Path('src/core/island-geography.ts');saved=Path('src/core/island-geography.ts.saved')
orig=core.read_bytes();saved.write_bytes(orig)
label=sys.argv[1];pairs=[(sys.argv[i].encode(),sys.argv[i+1].encode()) for i in range(2,len(sys.argv)-1,2)]
cmd=sys.argv[-1].split()
try:
  m=orig
  for b,a in pairs:
    assert b in m,('missing',b);m=m.replace(b,a)
  core.write_bytes(m)
  p=subprocess.run(cmd,capture_output=True,text=True,env={**os.environ,'TMPDIR':os.path.abspath('.scratch/tmp')})
  out=p.stdout+p.stderr
  print(label,'exit',p.returncode);print('\n'.join(l for l in out.splitlines() if any(k in l for k in ('FAIL','Tests ','✗','×','AssertionError','targetMet','"successes"')))[:3000])
finally:
  core.write_bytes(orig);assert core.read_bytes()==saved.read_bytes();saved.unlink()
