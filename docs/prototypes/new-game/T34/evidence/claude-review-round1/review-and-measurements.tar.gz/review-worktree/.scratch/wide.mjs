import fs from 'node:fs';import path from 'node:path';import {registerHooks,stripTypeScriptTypes} from 'node:module';
const repo=process.cwd();
registerHooks({resolve(s,c,n){return n(s.startsWith('.')&&c.parentURL?.endsWith('.ts')&&!path.extname(s)?s+'.ts':s,c);},load(u,c,n){if(u.endsWith('.ts'))return {format:'module',source:stripTypeScriptTypes(fs.readFileSync(new URL(u),'utf8')),shortCircuit:true};return n(u,c);}});
const {generateIslandGeography}=await import(path.join(repo,'src/core/island-geography.ts'));
const {inspectGeography}=await import(path.join(repo,'docs/prototypes/new-game/T34/acceptance.mjs'));
const [lo,hi]=process.argv.slice(2).map(Number);
let ok=0,bad=[],exh=[],maxA=0,plans={};
for(let s=lo;s<hi;s++){const r=generateIslandGeography(s);
 if(!r.ok){exh.push(s);continue;}
 const e=inspectGeography(r.geography);maxA=Math.max(maxA,r.attempts);
 if(e.length)bad.push({s,e:e.slice(0,3)});else ok++;}
console.log(JSON.stringify({lo,hi,ok,exhausted:exh,invalidExported:bad,maxAttempts:maxA}));
