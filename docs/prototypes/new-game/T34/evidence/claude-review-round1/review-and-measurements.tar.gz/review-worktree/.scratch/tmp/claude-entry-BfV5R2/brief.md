T69 review (Claude)
You review PR #1 at 84e34e7a0678bcaf735a53ba73568aad8ad3b532.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
