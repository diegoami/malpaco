from pathlib import Path
import tarfile,json,hashlib,subprocess
root=Path('/home/diego/projects/malpaco'); tree=root/'.cache/t34-claude-review/150-review-5ed199dc'; src=root/'.cache/review-evidence/pr150-e9268fcc06ed'; out=root/'.cache/t34-work/docs/prototypes/new-game/T34/evidence/claude-review-round1';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tracked=set(subprocess.check_output(['git','ls-files'],cwd=tree,text=True).splitlines()); files={}
for p in src.rglob('*'):
 if p.is_file():files['harness/'+str(p.relative_to(src))]=p
for parent in [tree/'.scratch',tree/'docs/prototypes/new-game/T34/evidence']:
 for p in parent.rglob('*'):
  if p.is_file() and str(p.relative_to(tree)) not in tracked:files['review-worktree/'+str(p.relative_to(tree))]=p
files['archive-review.py']=Path(__file__)
# The reviewer wrote one scratch inventory outside its worktree. Retain it without cleanup.
external=Path('/tmp/x')
if external.is_file():files['external-scratch/tmp-x']=external
hashes={n:sha(p) for n,p in files.items()}
a=out/'review-and-measurements.tar.gz'
with tarfile.open(a,'w:gz',compresslevel=1) as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(a) as t:actual={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}
assert actual==hashes
(out/'archive-manifest.json').write_text(json.dumps({'archive':a.name,'sha256':sha(a),'members':hashes,'originalsPreserved':True},indent=2)+'\n')
for name in ['final.md','receipt.json','inventory.json']:(out/name).write_bytes((src/name).read_bytes())
(out/'ASSESSMENT.md').write_text('Claude Sonnet5.5 High; actual init and assistant identities match. CLI exit0,1311.443seconds, zero denials; shared harness exit4 because explicitly incomplete scope, no approval. Full final read by main; all findings relayed at PR150comment6238034015. R1 test coverage rework accepted; no invalid exports found in700seeds. R2 provenance clarification and R5 inert historical-script labeling will be addressed; R3 owner visual judgment remains T36 and R4 prototype witness dependency noted. Follow-up must cover unread historical code plus current fixes. Main independently verified100finalrecords,952artifacthashes and75codeinventoryhashes before review. Reviewer wrote /tmp/x despite retained-worktree scratch instruction; copied into archive, external file left untouched. Native permissions are mistakes-only safeguards, not confinement. Initial monitor watched startup log only and issued false idle warning; main confirmed live transcript/tool activity and replaced its own monitor with log+transcript inputs; review never restarted. No CI.\n')
print(json.dumps({'out':str(out),'members':len(hashes),'archiveBytes':a.stat().st_size}))
