# T34 Seeded island silhouettes and province subdivisions

- **Kind**: slice
- **Issue**: #79 · **Branch**: `task/T34-seeded-island-silhouettes-and-province-subdivisions` · **Merge after**: T33, T24, T62, T63.
- **Difficulty**: Very hard; estimate, not a model assignment.
- **Implementer**: owner-selected under rule 6; use an isolated worktree and record the choice before dispatch.
- **Reviewer**: owner-selected OpenCode model of another family under rule 6; record the choice before review.
- **Evidence**: [pinned core-rules design](https://github.com/diegoami/isle-wars-archaeology/blob/ae298e37c2f5177039e55767607f9345b6cb0e7a/design/core-rules.md), owner roadmap accepted 2026-10-15, and upstream task evidence. T23 resolves source anchors; new constants need citations or explicit [designed] provenance.
- **Owns**: src/core/**; tests/core/**; docs/prototypes/new-game/T34/**; docs/spike.md; append-only RUN-NOTES.md.
- **Scope**: Build seeded geography using the owner-selected A construction direction and T62 coast-entry contract alongside unchanged T24 structural limits. Jointly reserve entrance-country coast opportunities, island placement/orientation, water corridors and real label space; do not freeze arbitrary subdivisions before considering links. Derive land adjacency from positive shared boundaries. Rules never read positions. Export partial geography and entrance reservations for T35 inspection, never incomplete playable boards. Start with retained feasible witnesses and preserve failures; a single reference does not prove generality. Owner decision of 2026-10-17 requires broader island shapes and layouts before proceeding: subpixel perturbations and whole-board reflections of one witness do not suffice. Preserve the approved geographic visual direction and unchanged numeric constraints while measuring independent silhouette and placement variation.
- **Done when**:
  1. `npx vitest run tests/core/island-geography.test.ts` — prescribed island sizes, connected valid cells, no interior overlaps/gaps, symmetric shared-boundary adjacency and contract land-degree headroom hold for all exported successes. Exercise rejected candidates, retry history and bounded exhaustion with real failure records; omission of failure recording must fail acceptance. A retained seeds0..31 corpus must place the10-country island both within the middle vertical third and outside it (invariant under whole-board reflections), and vary at least one island's bounding-box aspect ratio by5% or more. These [designed] breadth measurements operationalize the owner's broader-layout decision; numeric play/display constraints remain unchanged.
  2. `node docs/prototypes/new-game/T34/sweep.mjs` — enumerate seeds 0..99 with fixed bounded attempts; report valid subdivisions/100, per-constraint failures and replay hashes against the approved T24 budget, with no discarded failures. Retain a seed gallery and shape/layout diversity measurements that factor out whole-board reflection and incidental fixed-point jitter.
  3. `npm test` and `npm run build` pass; affected pinned browser suites pass without weakening existing assertions. Retain measured outputs, screenshots where applicable, commands and hashes in the owned evidence path; report negative-before/positive-after checks and exact restoration.
- **Hazards**: Run the feasibility smoke before algorithm changes. If the approved target is unreachable, stop; do not relax degree, label or shape constraints. Main session preflights acceptance before dispatch; unresolved design conflicts stop implementation, never weaken a Done-when.



The brief is the task file pasted in full, then this block, then on a rework round the review's URL.
The `implementer` agent file repeats the run mechanics; this block is the contract, for the main
session implementing directly as much as for the subagent. A line that needs the user's machine outside the
worktree, or a cloud session, is the main session's (L26).

```text
You implement <T<nn>>. The task file above is the contract.
- Build only what the task asks for, even inside a file it requires; say why for each changed file. (L44)
- A Done-when you cannot meet: stop and report. Never weaken an assertion, skip a test or edit the task file.
- **Constraint-feasibility probe** (when the task names structural constraints and a target success
  rate): before any algorithmic change, run a small smoke test that confirms the constraint
  set alone is feasible at the target rate (often a wide-seed sweep of the existing generator
  body, plus the new constraints, with no algorithmic rewrite). If the probe shows the target
  is unreachable, STOP and report. Do not weaken a constraint to make the algorithm pass
  (rule 5); the user prefers a design amendment (preferred) over a quieter relaxation, and
  the probe surfaces the conflict one round earlier than a full implementation.
- Every new test fails before your change and passes after it; say how you checked.
- Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
  restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
  a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
  copy inside your worktree (`<file>.saved`, deleted afterwards) or in a `mktemp -d` folder under
  `/tmp`, never as a loose file elsewhere.
- If you measure: every output a finding or the PR may cite goes under a tracked path the task owns,
  pushed per batch and every 30 min, never deleted or overwritten; originals out, hashes recorded. (L40)
- A comment that asserts behaviour at an edge comes with the test that visits that edge.
- A defect you find outside the task: report it. A one-file mechanical fix that blocks you may
  ride this PR, declared under Scope in the PR body.
- Update any document your change makes wrong, in this PR. Never write status into a document.
- PR body: Closes #<issue>; Scope (files and why); a fenced block with each Done-when command and
  the tail of its output; Docs changed.
```



Owner now authorizes Luna High for simpler tasks, Sol Low/Medium for harder implementation tasks, and Claude CLI Sonnet Medium/High or Opus Low independent review by difficulty. T34 is difficult: you are GPT-6.1 Sol Medium implementer, main coordinates. Work ONLY /home/diego/projects/malpaco/.cache/t34-work on existing task/T34-seeded-island-silhouettes-and-province-subdivisions, draft PR150 issue79. No new checkout/reset/stash/prune. Preserve inherited untracked evidence, all worktrees and source originals. Never change task contract. Read CLAUDE.md/docs/process.md and recent worktree RUN-NOTES. No CI until main final approved receipt; all your commits [skip ci], push each batch. No reviewer dispatch, merge, global config or other task work.
Rework sources: https://github.com/diegoami/malpaco/pull/150#issuecomment-6233951448 and owner breadth decision issue79 comment6234031951; frozen acceptance PR150comment6234472321. Original MiniMax approval superseded by owner-required broader shapes/layouts.
Current branch f3d190c has locked 13 focused tests; original production core intentionally fails two breadth tests. Original core SHA256 e73e399e89a74fe939def6a2b1f551d94c9d59a63e57f1ae0e106d58d18cf2de. Candidate untracked docs/prototypes/new-game/T34/family-candidate.ts SHA2561bfe1823e72b9502fc98da7794cbf590ebe03d580367bd7ab715c0b19424b62f. Temporary candidate preflight completed then exact original restored. Read preflight/r2-mock-swmbla_b/report.json plus r2-preflight.py. 13 focused/606 units/build/24 browsers/100-seed sweep passed candidate. Sweep-Y38ssy middle38/outer62,100geometries/4graphs/replay/source stable. Old production absent r2 evidence middle0/outer100, fails breadth.
First integrate latest origin/main (e38aa52, merged T69 Claude backend) carefully. RUN-NOTES incoming main exact prefix plus all own T34 notes, preserve both sides of any conflicts. Main dirty checkout is OFF LIMITS. node_modules symlink main exists. Global /tmp FULL: use worktree .cache/tmp via TMPDIR on all commands/units. Never delete inherited temp/evidence.
Adopt and finish candidate, not another rewrite. It adds 3 true island placement plans, global piecewise warp, joint label/entrance repair. Related true placement prototypes in .cache/t34-breadth-work/docs/prototypes/new-game/T34/breadth; may read/copy evidence, do not mutate that tree. Original fixed-nine-slot global warp was rejected even though numerical sweep passed.
Assess concrete guard gaps practically, do not chase speculative edge cases:
1 sweep target currently >=99 permits one returned-success-invalid result. Must distinguish explicit exhaustion from invalid exported successes: record exported=result.ok and require every exported success independent-oracle errorfree. Prove source omission via seed98 invalid success (e.g duplicate entrance), retain before/after/source restoration. Main contract unchanged: all exported successes valid.
2 Evaluate candidate candidateErrors against unchanged T24 fortress fairness: bonuses max(2,floor(size/2)+distinct entrance countries)<=size; single-entry count<=3; no singleentry island size>=7; singleentry bonus*4<=totalbonus. Add missing necessary integer guards with real tests/controls if within partial geography constraints; do not duplicate future complete-board scope gratuitously. Connected island graph/maxdegree4/remoteness may already remain invariant under plans; verify.
3 Adopt only after feasible smoke using retained candidate. New guards change hash/RNG so run current13focused/sweep/fulltests/build/pinned24browsers on final source. Add meaningful omission controls for actual placement/shape behavior and new guards, preserve existing R1 retry-history controls.
4 Retain normalized gallery across all3 true plans (factor global mirrors via fixed island7position), use sweep data. Main will view generated gallery. Existing renderer in breadth-joint-r8ghb3fn. All evidence tracked owned T34, compress large text/source sets losslessly (raw trailing whitespace can use gzip), originals preserved. Use archive-evidence.py and verify-evidence.py, refresh artifact index as appropriate, no overwritten measurements.
5 Update T34 README/CONTRACT/provenance, docs/spike and RUN-NOTES accurately. Explain bounded family, not arbitrary planar generation. Update PR body to current passing counts, remove stale MiniMax role choice; main records Claude review choice. No generated UI/default changes (T35 fullboards, T36 UI/default1000seeds, then cards37–41).
All long processes tools/harness/run-unit.sh + one watch.sh monitor; report progress/session IDs to main. Commit/push per batch and >=every30min. Return full final with hashes, tests, negatives, remaining concerns and exact HEAD; main independently reviews results and launches Claude.
