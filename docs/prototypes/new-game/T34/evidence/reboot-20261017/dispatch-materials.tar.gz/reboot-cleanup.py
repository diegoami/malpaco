from pathlib import Path
import os,stat,hashlib,json,tarfile,shutil,datetime
root=Path('/home/diego/projects/malpaco'); tmp=Path('/tmp'); out=root/'.cache/t34-work/docs/prototypes/new-game/T34/evidence/reboot-20261017';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
selected={}
known=['make-t34-swap-probe.py','t33-merge-main.py','t34-before-t68-merge-RUN-NOTES.md','t34-build-family-candidate.py','t34-gallery-metrics.py','t65-final.sh','t65-final3.sh','t65-install.py','t65-integrate.py','t65-lock.py','t65-mock.py','t68-controls-final.py','t68-docwrite.py']
for p in tmp.iterdir():
 if p.name.startswith('malpaco-'):selected[p]='repository-prefixed malpaco session artifact'
 elif p.name.startswith('T64-') and p.is_file():selected[p]='coastline T64 session artifacts named in retained run history'
 elif p.name in known:selected[p]='exact known malpaco temporary helper/receipt'
 elif p.name.startswith('claude-entry-'):
  b=p/'brief.md';d=datetime.datetime.fromtimestamp(p.stat().st_mtime,datetime.timezone.utc)
  if b.is_file() and 'T69 fixture' in b.read_text():selected[p]='T69 Claude entry-point fixture, task marker verified'
  elif p.name=='claude-entry-QTS8NF' and d.strftime('%Y-%m-%dT%H:%M')=='2026-10-17T14:36' and sorted(q.name for q in p.iterdir())==['repo']:selected[p]='partial ENOSPC T69 fixture, paired with same-time T69 harness fixture'
 elif p.name.startswith('claude-harness-'):
  f=p/'fake.mjs'
  if f.is_file() and 'T69 review (Claude)' in f.read_text():selected[p]='T69 watched-subprocess fixture, task marker verified'
shared=tmp/'claude-1000'
if shared.is_dir():
 for p in shared.iterdir():
  if p.name.startswith('-home-diego-projects-malpaco'):selected[p]='Claude CLI temp directory names exact malpaco worktree'
x=tmp/'x'; review=json.loads((root/'.cache/t34-work/docs/prototypes/new-game/T34/evidence/claude-review-round1/archive-manifest.json').read_text())
if x.is_file() and sha(x)==review['members'].get('external-scratch/tmp-x'):selected[x]='exact hash matches this review external scratch inventory'
files={}; links={}; total=0
for p in selected:
 entries=[p]+(list(p.rglob('*')) if p.is_dir() and not p.is_symlink() else [])
 for q in entries:
  n=str(q.relative_to(tmp))
  if q.is_symlink():links[n]=os.readlink(q)
  elif q.is_file():files[n]=sha(q);total+=q.stat().st_size
archive=out/'owned-tmp.tar.gz'
with tarfile.open(archive,'x:gz',compresslevel=1,dereference=False) as t:
 for p in sorted(selected):t.add(p,arcname=str(p.relative_to(tmp)),recursive=True)
with tarfile.open(archive) as t:
 actual={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}
 actual_links={m.name:m.linkname for m in t if m.issym()}
assert actual==files and actual_links==links
manifest={'archive':archive.name,'sha256':sha(archive),'members':files,'symlinks':links,'authorizedBy':'Owner: finish all work for reboot and delete all /tmp that belongs to you','selectedRoots':{str(p):why for p,why in selected.items()},'originalBytes':total,'archiveVerifiedBeforeDeletion':True}
(out/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for p in sorted(selected,key=lambda x:len(x.parts),reverse=True):
 if p.is_symlink() or p.is_file():p.unlink()
 elif p.is_dir():shutil.rmtree(p)
assert all(not p.exists() and not p.is_symlink() for p in selected)
receipt={'selectedRootsDeleted':len(selected),'filesArchived':len(files),'bytesArchivedBeforeDeletion':total,'archiveBytes':archive.stat().st_size,'allSelectedRootsAbsent':True,'unrelatedAndUnattributedTempPreserved':True,'sharedClaudeParentPreserved':shared.exists()}
(out/'cleanup-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
