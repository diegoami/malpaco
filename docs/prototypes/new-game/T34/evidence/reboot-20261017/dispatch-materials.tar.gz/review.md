T34 review (Claude Sonnet High)
You review PR #150 at a842967717584549e58b10d37869c1fe4dd461d6. You did not write it. The task file follows.
0. Prove the tree: HEAD is a842967717584549e58b10d37869c1fe4dd461d6 and the diff against origin/main is the PR's; findings name its files.
1. Re-run every Done-when line yourself, and account for each (L32). The PR's evidence is no proof.
2. [evidence-driven] Every constant traces to a fixture, report or investigation; a [designed] one says what was searched.
3. [seeded] No wall clock, unseeded random or order-dependent iteration in rule code.
4. Every changed file and behaviour is one the task asks for (L44); docs it makes wrong are updated.
5. Sweep the diff: tests that pass with the behaviour deleted (mutate, rebuild clean, re-take any
   negative result), branches no input reaches, edge comments without a test, integer geometry, valid exported successes, retry histories, bounded exhaustion, real shape/layout diversity and save compatibility.
   Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
   restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
   a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
   copy inside your worktree (`<file>.saved`, deleted afterwards) or in a `mktemp -d` folder under
   `/tmp`, never as a loose file elsewhere.
6. Apply the following review criteria.
## Blocking means

Any one is enough; a blocking finding means rework, never approve.
1. A Done-when line fails, or cannot be run as written.
2. What this task protects can be got past: valid deterministic partial geography, unchanged T24/T62 constraints, bounded retry/history and nontrivial independent shape/layout variation. A bypass you proved is blocking, even when it
   looks like an edge case. Never "follow-up hardening" or "outside the threat model" unless the
   task says so; if it does, quote the line. (L47)
3. Behaviour the task forbids, or behaviour nobody asked for, inside a file the task requires. (L44)
4. uncited constants, acceptance surviving deletion of protected behavior, impure rule code or weakened assertions
Not blocking: wording, style, and defects in code the PR did not change: file those as follow-ups.
When unsure, say how likely the problem is. Rate it blocking only if it is likely and would get
past what the task protects; otherwise it is a follow-up. (L53)

## Report every blocking finding in this one review

This review is your only pass before the author fixes. Do not stop at the first blocking
finding: finish reading the whole diff and the task file, check every Done-when line and
every item under "Blocking means", and report all blocking findings together.

- Before you write the verdict, make one last pass over the full diff for anything you have
  not yet rated, and say "Final pass done" as the last line before the verdict.
- Number the findings R1, R2, … in order of severity. A finding you held back because an
  earlier one was already blocking is a review defect: if two problems share a cause, list
  both and say so.
- Do not rely on a later round. The author fixes everything you list, and the next review
  checks those fixes and new code only, not anything you saw but did not report.
- If you ran out of time or context before covering the whole diff, say which files or
  sections you did not cover. Do not approve in that case.

Prove each finding (run it, or delete the behaviour and name the test that fails) or label it
unverified. Your final message is the review: the header; the verdict (approve | approve after
named fixes | rework | user decision); per Done-when line `DW<k>: ran <command> → <result>` or
`DW<k>: not run — <reason>`; the findings R1..Rn (file:line, blocking or not); the verdict again
last. Never post it: the script posts it and applies the label.

# T34 Seeded island silhouettes and province subdivisions

- **Kind**: slice
- **Issue**: #79 · **Branch**: `task/T34-seeded-island-silhouettes-and-province-subdivisions` · **Merge after**: T33, T24, T62, T63.
- **Difficulty**: Very hard; estimate, not a model assignment.
- **Implementer**: owner-selected under rule 6; use an isolated worktree and record the choice before dispatch.
- **Reviewer**: owner-selected OpenCode model of another family under rule 6; record the choice before review.
- **Evidence**: [pinned core-rules design](https://github.com/diegoami/isle-wars-archaeology/blob/ae298e37c2f5177039e55767607f9345b6cb0e7a/design/core-rules.md), owner roadmap accepted 2026-10-15, and upstream task evidence. T23 resolves source anchors; new constants need citations or explicit [designed] provenance.
- **Owns**: src/core/**; tests/core/**; docs/prototypes/new-game/T34/**; docs/spike.md; append-only RUN-NOTES.md.
- **Scope**: Build seeded geography using the owner-selected A construction direction and T62 coast-entry contract alongside unchanged T24 structural limits. Jointly reserve entrance-country coast opportunities, island placement/orientation, water corridors and real label space; do not freeze arbitrary subdivisions before considering links. Derive land adjacency from positive shared boundaries. Rules never read positions. Export partial geography and entrance reservations for T35 inspection, never incomplete playable boards. Start with retained feasible witnesses and preserve failures; a single reference does not prove generality. Owner decision of 2026-10-17 requires broader island shapes and layouts before proceeding: subpixel perturbations and whole-board reflections of one witness do not suffice. Preserve the approved geographic visual direction and unchanged numeric constraints while measuring independent silhouette and placement variation.
- **Done when**:
  1. `npx vitest run tests/core/island-geography.test.ts` — prescribed island sizes, connected valid cells, no interior overlaps/gaps, symmetric shared-boundary adjacency and contract land-degree headroom hold for all exported successes. Exercise rejected candidates, retry history and bounded exhaustion with real failure records; omission of failure recording must fail acceptance. A retained seeds0..31 corpus must place the10-country island both within the middle vertical third and outside it (invariant under whole-board reflections), and vary at least one island's bounding-box aspect ratio by5% or more. These [designed] breadth measurements operationalize the owner's broader-layout decision; numeric play/display constraints remain unchanged.
  2. `node docs/prototypes/new-game/T34/sweep.mjs` — enumerate seeds 0..99 with fixed bounded attempts; report valid subdivisions/100, per-constraint failures and replay hashes against the approved T24 budget, with no discarded failures. Retain a seed gallery and shape/layout diversity measurements that factor out whole-board reflection and incidental fixed-point jitter.
  3. `npm test` and `npm run build` pass; affected pinned browser suites pass without weakening existing assertions. Retain measured outputs, screenshots where applicable, commands and hashes in the owned evidence path; report negative-before/positive-after checks and exact restoration.
- **Hazards**: Run the feasibility smoke before algorithm changes. If the approved target is unreachable, stop; do not relax degree, label or shape constraints. Main session preflights acceptance before dispatch; unresolved design conflicts stop implementation, never weaken a Done-when.


This is the owner-requested broadened T34 rework. Earlier narrow-layout approval is superseded. Review whole current PR, with particular attention to changed implementation, seed0..31 breadth acceptance and unchanged independent T24/T62 oracle. Current game/default remain fixed reference; T35 completes boards and T36 integrates UI. Partial geography is intentional. Historical failed probes are evidence, not present behavior. Account for runtime/scripts individually via FILE lines; group generated-data evidence only as permitted by launcher. Re-run the affected pinned browser wrapper (instructions in T34 README/run-browser.py). Use project/evidence-local TMPDIR, not global /tmp. Do not launch historical model/benchmark dispatchers. Existing retained review full findings: PR150comment6233951448.

Out of your depth: stop and hand back, with an ESCALATE block, when any of these happens:
two hypotheses for the same question have failed; you would rely on bytes, code or behaviour
you cannot explain; you are about to write a claim you cannot back with evidence; or you have
made three attempts at one step without progress. Push your branch first. The ESCALATE block
gives what you tried, the evidence so far, and the exact question you could not answer. Never
guess a format or a cause.

Current implementation receipt:
- 14 focused tests, 607 Vitest cases +6 harness groups, build and24 affected pinned browser cases passed.
-100/100 sweep-JPXDhX valid/replay/source-stable; max36attempts, middle38/outer62, aspect ranges1.215–1.401.
- Ten actual source controls, including old-gate invalid seed98 acceptance then corrected rejection, byte-exact restoration.
- Main inspected normalized gallery. This is bounded3plans, not arbitrary planar generation and not final owner visual approval.
- Review every executable path listed in docs/prototypes/new-game/T34/file-inventory.json (75 entries); some are frozen historical copies/probes. Read them, do not execute historical dispatchers. For each emit FILE:path, and also account for RUN-NOTES.md, docs/spike.md and generated HTML. EVIDENCE: docs/prototypes/new-game/T34/ can group generated data only. The inventory itself is a convenience, not proof.
- Current commands: npx vitest run tests/core/island-geography.test.ts; node docs/prototypes/new-game/T34/sweep.mjs; npm test; npm run build; python3 docs/prototypes/new-game/T34/run-browser.py reviewer-current --suites tests/e2e/reference-complete-game.spec.ts,tests/e2e/reference-game.spec.ts,tests/e2e/versioned-match.spec.ts,tests/e2e/entry.spec.ts . Keep wrapper output and source archives. The wrapper uses pinned Docker; inspect it before running.
- Read README for current evidence verification and archive policy. No need rerun all historical probes. Focus adversarial tests on actual new constructor/retry/breadth/valid-success protections.
