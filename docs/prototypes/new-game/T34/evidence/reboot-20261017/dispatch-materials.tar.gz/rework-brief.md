# T34 Seeded island silhouettes and province subdivisions

- **Kind**: slice
- **Issue**: #79 · **Branch**: `task/T34-seeded-island-silhouettes-and-province-subdivisions` · **Merge after**: T33, T24, T62, T63.
- **Difficulty**: Very hard; estimate, not a model assignment.
- **Implementer**: owner-selected under rule 6; use an isolated worktree and record the choice before dispatch.
- **Reviewer**: owner-selected OpenCode model of another family under rule 6; record the choice before review.
- **Evidence**: [pinned core-rules design](https://github.com/diegoami/isle-wars-archaeology/blob/ae298e37c2f5177039e55767607f9345b6cb0e7a/design/core-rules.md), owner roadmap accepted 2026-10-15, and upstream task evidence. T23 resolves source anchors; new constants need citations or explicit [designed] provenance.
- **Owns**: src/core/**; tests/core/**; docs/prototypes/new-game/T34/**; docs/spike.md; append-only RUN-NOTES.md.
- **Scope**: Build seeded geography using the owner-selected A construction direction and T62 coast-entry contract alongside unchanged T24 structural limits. Jointly reserve entrance-country coast opportunities, island placement/orientation, water corridors and real label space; do not freeze arbitrary subdivisions before considering links. Derive land adjacency from positive shared boundaries. Rules never read positions. Export partial geography and entrance reservations for T35 inspection, never incomplete playable boards. Start with retained feasible witnesses and preserve failures; a single reference does not prove generality. Owner decision of 2026-10-17 requires broader island shapes and layouts before proceeding: subpixel perturbations and whole-board reflections of one witness do not suffice. Preserve the approved geographic visual direction and unchanged numeric constraints while measuring independent silhouette and placement variation.
- **Done when**:
  1. `npx vitest run tests/core/island-geography.test.ts` — prescribed island sizes, connected valid cells, no interior overlaps/gaps, symmetric shared-boundary adjacency and contract land-degree headroom hold for all exported successes. Exercise rejected candidates, retry history and bounded exhaustion with real failure records; omission of failure recording must fail acceptance. A retained seeds0..31 corpus must place the10-country island both within the middle vertical third and outside it (invariant under whole-board reflections), and vary at least one island's bounding-box aspect ratio by5% or more. These [designed] breadth measurements operationalize the owner's broader-layout decision; numeric play/display constraints remain unchanged.
  2. `node docs/prototypes/new-game/T34/sweep.mjs` — enumerate seeds 0..99 with fixed bounded attempts; report valid subdivisions/100, per-constraint failures and replay hashes against the approved T24 budget, with no discarded failures. Retain a seed gallery and shape/layout diversity measurements that factor out whole-board reflection and incidental fixed-point jitter.
  3. `npm test` and `npm run build` pass; affected pinned browser suites pass without weakening existing assertions. Retain measured outputs, screenshots where applicable, commands and hashes in the owned evidence path; report negative-before/positive-after checks and exact restoration.
- **Hazards**: Run the feasibility smoke before algorithm changes. If the approved target is unreachable, stop; do not relax degree, label or shape constraints. Main session preflights acceptance before dispatch; unresolved design conflicts stop implementation, never weaken a Done-when.



The brief is the task file pasted in full, then this block, then on a rework round the review's URL.
The `implementer` agent file repeats the run mechanics; this block is the contract, for the main
session implementing directly as much as for the subagent. A line that needs the user's machine outside the
worktree, or a cloud session, is the main session's (L26).

```text
You implement <T<nn>>. The task file above is the contract.
- Build only what the task asks for, even inside a file it requires; say why for each changed file. (L44)
- A Done-when you cannot meet: stop and report. Never weaken an assertion, skip a test or edit the task file.
- **Constraint-feasibility probe** (when the task names structural constraints and a target success
  rate): before any algorithmic change, run a small smoke test that confirms the constraint
  set alone is feasible at the target rate (often a wide-seed sweep of the existing generator
  body, plus the new constraints, with no algorithmic rewrite). If the probe shows the target
  is unreachable, STOP and report. Do not weaken a constraint to make the algorithm pass
  (rule 5); the user prefers a design amendment (preferred) over a quieter relaxation, and
  the probe surfaces the conflict one round earlier than a full implementation.
- Every new test fails before your change and passes after it; say how you checked.
- Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
  restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
  a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
  copy inside your worktree (`<file>.saved`, deleted afterwards) or in a `mktemp -d` folder under
  `/tmp`, never as a loose file elsewhere.
- If you measure: every output a finding or the PR may cite goes under a tracked path the task owns,
  pushed per batch and every 30 min, never deleted or overwritten; originals out, hashes recorded. (L40)
- A comment that asserts behaviour at an edge comes with the test that visits that edge.
- A defect you find outside the task: report it. A one-file mechanical fix that blocks you may
  ride this PR, declared under Scope in the PR body.
- Update any document your change makes wrong, in this PR. Never write status into a document.
- PR body: Closes #<issue>; Scope (files and why); a fenced block with each Done-when command and
  the tail of its output; Docs changed.
```



Owner now authorizes Luna High for simpler tasks, Sol Low/Medium for harder implementation tasks, and Claude CLI Sonnet Medium/High or Opus Low independent review by difficulty. T34 is difficult: you are GPT-6.1 Sol Medium implementer, main coordinates. Work ONLY /home/diego/projects/malpaco/.cache/t34-work on existing task/T34-seeded-island-silhouettes-and-province-subdivisions, draft PR150 issue79. No new checkout/reset/stash/prune. Preserve inherited untracked evidence, all worktrees and source originals. Never change task contract. Read CLAUDE.md/docs/process.md and recent worktree RUN-NOTES. No CI until main final approved receipt; all your commits [skip ci], push each batch. No reviewer dispatch, merge, global config or other task work.
Rework sources: https://github.com/diegoami/malpaco/pull/150#issuecomment-6233951448 and owner breadth decision issue79 comment6234031951; frozen acceptance PR150comment6234472321. Original MiniMax approval superseded by owner-required broader shapes/layouts.
Current branch f3d190c has locked 13 focused tests; original production core intentionally fails two breadth tests. Original core SHA256 e73e399e89a74fe939def6a2b1f551d94c9d59a63e57f1ae0e106d58d18cf2de. Candidate untracked docs/prototypes/new-game/T34/family-candidate.ts SHA2561bfe1823e72b9502fc98da7794cbf590ebe03d580367bd7ab715c0b19424b62f. Temporary candidate preflight completed then exact original restored. Read preflight/r2-mock-swmbla_b/report.json plus r2-preflight.py. 13 focused/606 units/build/24 browsers/100-seed sweep passed candidate. Sweep-Y38ssy middle38/outer62,100geometries/4graphs/replay/source stable. Old production absent r2 evidence middle0/outer100, fails breadth.
First integrate latest origin/main (e38aa52, merged T69 Claude backend) carefully. RUN-NOTES incoming main exact prefix plus all own T34 notes, preserve both sides of any conflicts. Main dirty checkout is OFF LIMITS. node_modules symlink main exists. Global /tmp FULL: use worktree .cache/tmp via TMPDIR on all commands/units. Never delete inherited temp/evidence.
Adopt and finish candidate, not another rewrite. It adds 3 true island placement plans, global piecewise warp, joint label/entrance repair. Related true placement prototypes in .cache/t34-breadth-work/docs/prototypes/new-game/T34/breadth; may read/copy evidence, do not mutate that tree. Original fixed-nine-slot global warp was rejected even though numerical sweep passed.
Assess concrete guard gaps practically, do not chase speculative edge cases:
1 sweep target currently >=99 permits one returned-success-invalid result. Must distinguish explicit exhaustion from invalid exported successes: record exported=result.ok and require every exported success independent-oracle errorfree. Prove source omission via seed98 invalid success (e.g duplicate entrance), retain before/after/source restoration. Main contract unchanged: all exported successes valid.
2 Evaluate candidate candidateErrors against unchanged T24 fortress fairness: bonuses max(2,floor(size/2)+distinct entrance countries)<=size; single-entry count<=3; no singleentry island size>=7; singleentry bonus*4<=totalbonus. Add missing necessary integer guards with real tests/controls if within partial geography constraints; do not duplicate future complete-board scope gratuitously. Connected island graph/maxdegree4/remoteness may already remain invariant under plans; verify.
3 Adopt only after feasible smoke using retained candidate. New guards change hash/RNG so run current13focused/sweep/fulltests/build/pinned24browsers on final source. Add meaningful omission controls for actual placement/shape behavior and new guards, preserve existing R1 retry-history controls.
4 Retain normalized gallery across all3 true plans (factor global mirrors via fixed island7position), use sweep data. Main will view generated gallery. Existing renderer in breadth-joint-r8ghb3fn. All evidence tracked owned T34, compress large text/source sets losslessly (raw trailing whitespace can use gzip), originals preserved. Use archive-evidence.py and verify-evidence.py, refresh artifact index as appropriate, no overwritten measurements.
5 Update T34 README/CONTRACT/provenance, docs/spike and RUN-NOTES accurately. Explain bounded family, not arbitrary planar generation. Update PR body to current passing counts, remove stale MiniMax role choice; main records Claude review choice. No generated UI/default changes (T35 fullboards, T36 UI/default1000seeds, then cards37–41).
All long processes tools/harness/run-unit.sh + one watch.sh monitor; report progress/session IDs to main. Commit/push per batch and >=every30min. Return full final with hashes, tests, negatives, remaining concerns and exact HEAD; main independently reviews results and launches Claude.


REWORK after Claude review https://github.com/diegoami/malpaco/pull/150#issuecomment-6238034015
T34 review (Claude Sonnet High)
rework
DW1: ran `npx vitest run tests/core/island-geography.test.ts` → 14/14 passed (37.9 s). The seeds0..31 corpus puts the 10-country island in the middle third and outside it. At least one island's aspect ratio varies by 5% or more. Mutating the source to drop layout, warp or failure recording fails the matching tests (details under R1).
DW2: ran `node docs/prototypes/new-game/T34/sweep.mjs` → 100/100 valid, `targetMet:true`. Output is `evidence/sweep-AHN9CY`.
- Replay hashes are identical, with 100 geometry hashes and 4 land graphs.
- The largest island sits in the middle third in 38 seeds and outside it in 62.
- Failure counts: labels 926, attachment 584, water 120, degree 41, traceability 11.
- Every seed's result and failures are retained; none are discarded.
- Per-island aspect max/min runs from 1.215 to 1.401, matching the receipt.
DW3: ran `npm test` → 607 Vitest passed plus 6 harness tests, exit 0. Ran `npm run build` → exit 0. Ran `python3 docs/prototypes/new-game/T34/run-browser.py reviewer-current --suites reference-complete-game,reference-game,versioned-match,entry` → 24 passed, exit 0, `sourcesUnchangedDuringRun:true` (`evidence/reviewer-current-4fnisiwu`). I did not re-run the author's negative-before/positive-after record. I ran my own source mutations, and every mutation was restored byte-exact (`git diff` is empty).

Where I worked
- Worktree HEAD is a842967717584549e58b10d37869c1fe4dd461d6. The diff against base 7ce8911 is 957 files, of which only 4 are outside T34: `RUN-NOTES.md`, `docs/spike.md`, `src/core/island-geography.ts` and `tests/core/island-geography.test.ts`. T24 and T62 are untouched. All 40 frozen T24/T62 copies under `evidence/feasibility-*/sources` are byte-equal to the live files.
- `prepare-witness.mjs` reproduces `witness.json` byte-exactly from T64/board.json, whose sha256 matches `witness-provenance.json`.
- I ran seeds 100..699 through the independent oracle (scratch script `.scratch/wide.mjs`). 599 were valid, 0 exports were invalid, and seed 398 exhausted (the maximum was 44 attempts). Together with seeds 0..99 that is 699 valid out of 700.
- The rule code has no clock, no random source and no order-dependent iteration. `rng.shuffled` and Map/Set insertion order are deterministic.

Findings

**R1 — BLOCKING** (`src/core/island-geography.ts:181,185,189,192,199,249`; `tests/core/island-geography.test.ts`). Acceptance survives deleting protected behaviour. I mutated the real source and ran the real acceptance commands.

| Guard removed | Line | Result |
|---|---|---|
| The three `cells:` guards (non-simple polygon, outside frame, island touch/overlap) | 189, 199 | DW1: 14/14 pass. DW2 sweep with these plus the next two guards removed: `targetMet:true`, 100/100. |
| `crossings: duplicate reserved country pair` | 181 | Same as above. |
| `crossings: insufficient bonus headroom` | 185 | Same as above. |
| The `degree:` guard (`borders<2`, `borders>4`, `+lanes>5`, `lanes>2`) | 192 | DW1 passes 14/14 and the DW2 sweep passes 100/100 (`evidence/sweep-2CjENm`). The 41 degree rejections in the real sweep all co-occur with other failure classes. |
| `Math.max(0,…)` in the budget clamp | 249 | DW1: 14/14 pass. A negative budget would return a negative `attempts`. |
| `Math.floor(raw)` in the budget clamp | 249 | DW1: 14/14 pass. A fractional budget would return a fractional `attempts`. |

- **What is missing:** no input in 700 seeds ever triggers the `cells:`, duplicate-pair or bonus-headroom branches, and no mocked witness exercises them. The task protects "connected valid cells, no interior overlaps/gaps", unique crossings, land-degree headroom and bounded exhaustion.
- **Why it matters:** the only thing that currently catches these is the oracle, and only if the constructor ever exports such a result. The constructor's own refusal of those candidates is unprotected.
- **Fix:** add a mocked-witness test per guard, in the style of the existing fortress test at `tests/core/island-geography.test.ts:83`. Each test should assert the exact constraint string in the failure records. Also test negative and fractional budgets.
- **Protected, for the record:** these mutations were caught.
  - Omitting layout fails the middle-third test.
  - Omitting warp fails the aspect test.
  - Omitting the failure push fails 10 tests.
  - Omitting flip fails the topology test.
  - Omitting the label-hit guard fails 3 tests.
  - Omitting the fortress/concentration guards fails the mock test.
  - Omitting the water/attachment corridor guards fails 6 tests.
  - Restricting layout to plans 0 and 1 fails the middle-third test, so plan 2 is required.

**R2 — non-blocking (follow-up)**
- `family-provenance.json` and CONTRACT.md name the [designed] plan translations (306/−303, 26/155, −75/−167) but say only "reviewed T24/T62/T63 and T64/T65 geometry studies". They do not say what was searched. The in-code comment "Approved 14-route plan" (`src/core/island-geography.ts:242`) names no approver. The 48px, 24px and three-pass values do trace to retained probes (`breadth-amplitude-m02i9_al`, `breadth-joint-r8ghb3fn`).
- Likelihood is moderate that the owner wants the search described, but the numbers are retained and traceable.

**R3 — non-blocking (owner judgement).**
- The gallery PNG (`family-gallery-pi361ktz`) shows the same nine silhouettes and internal seams. They are stretched, moved between two swapped slots, and flipped once per island. The seed-3, 6 and 10 boards look near-identical.
- The Done-when measures pass literally, and per-island aspect ratios are only weakly correlated (median −0.11 across 100 seeds), so this is not one global stretch.
- The PR says it is not owner visual approval. The owner should judge whether this meets "broader shapes".

**R4 — non-blocking.**
- `src/core/island-geography.ts:22` imports `docs/prototypes/new-game/T34/witness.json`. Production core depends on a prototype docs path. It is allowed under Owns, but pruning docs breaks core.

**R5 — non-blocking.**
- `review-tools/retention-runner.mjs` (15.8 KB) is a modified copy of `tools/harness/review.mjs`. It imports `./lib/*`, which is absent, so it cannot run. It also contains `git worktree remove --force` and `fs.rmSync` on a T34-specific path. `review-tools/reviewer150.md` is an agent definition copy. The task did not ask for either, and I suggest dropping them or labelling them inert.
- `evidence/breadth-joint-r8ghb3fn/gallery-metrics.py` hard-codes `/home/diego/projects/malpaco/.cache/t34-work` paths.
- Several RUN-NOTES.md entries have their spaces stripped, for example "keepsmapgenerationbeforecards". The file is append-only as required.

**R6 — informational.**
- The sweep's target-met gate holds, but seed 398 exhausts 50 attempts. That is 1 in 700 seeds, which is within the T24 99% target.

Coverage
FILE: src/core/island-geography.ts
FILE: tests/core/island-geography.test.ts
FILE: RUN-NOTES.md
FILE: docs/spike.md
FILE: docs/prototypes/new-game/T34/acceptance.mjs
FILE: docs/prototypes/new-game/T34/sweep.mjs
FILE: docs/prototypes/new-game/T34/run-browser.py
FILE: docs/prototypes/new-game/T34/run-command.py
FILE: docs/prototypes/new-game/T34/r2-controls.py
FILE: docs/prototypes/new-game/T34/r1-controls.py
FILE: docs/prototypes/new-game/T34/r2-final.py
FILE: docs/prototypes/new-game/T34/r2-preflight.py
FILE: docs/prototypes/new-game/T34/controls.py
FILE: docs/prototypes/new-game/T34/preflight.py
FILE: docs/prototypes/new-game/T34/full-preflight.py
FILE: docs/prototypes/new-game/T34/prepare-witness.mjs
FILE: docs/prototypes/new-game/T34/verify-evidence.py
FILE: docs/prototypes/new-game/T34/archive-captures.py
FILE: docs/prototypes/new-game/T34/archive-evidence.py
FILE: docs/prototypes/new-game/T34/family-smoke.mjs
FILE: docs/prototypes/new-game/T34/family-smoke.py
FILE: docs/prototypes/new-game/T34/family-gallery.py
FILE: docs/prototypes/new-game/T34/feasibility-smoke.mjs
FILE: docs/prototypes/new-game/T34/feasibility-wide.mjs
FILE: docs/prototypes/new-game/T34/flip-probe.mjs
FILE: docs/prototypes/new-game/T34/CONTRACT.md
FILE: docs/prototypes/new-game/T34/README.md
FILE: docs/prototypes/new-game/T34/witness-provenance.json
FILE: docs/prototypes/new-game/T34/family-provenance.json
FILE: docs/prototypes/new-game/T34/witness.json
FILE: docs/prototypes/new-game/T34/family-candidate.ts

I read `family-candidate.ts` only as a diff against the installed core. I read `RUN-NOTES.md` with lines cut at 900 characters.

EVIDENCE: docs/prototypes/new-game/T34/evidence/sweep-AHN9CY/ (fresh run, plus my own mutation sweeps in `sweep-GwTA7u` and `sweep-2CjENm`)
EVIDENCE: docs/prototypes/new-game/T34/evidence/reviewer-current-4fnisiwu/
EVIDENCE: docs/prototypes/new-game/T34/evidence/family-gallery-pi361ktz/ (PNG viewed)
EVIDENCE: docs/prototypes/new-game/T34/evidence/feasibility-QiwWlL/ and feasibility-zjVwJN/ (frozen T24/T62 copies compared byte-equal to live; `flip-probe-Tg7Pmr/flip-probe.mjs` is byte-equal to `flip-probe.mjs`)

SCOPE: incomplete
UNCOVERED:
- `docs/prototypes/new-game/T34/candidate.ts`: historical first-family copy, only grepped for Date/Math.random.
- `docs/prototypes/new-game/T34/review-tools/retention-runner.mjs` and `reviewer150.md`: read in part only.
- The scripts under `evidence/breadth-amplitude-m02i9_al`, `evidence/breadth-joint-r8ghb3fn` and `evidence/clock-fix-49d9ipkk`: first about 40 lines at 260 columns only.
- The 749 `evidence/` files, 172 `preflight/` files, `artifacts.json` and `file-inventory.json`: not individually audited. I checked only that the inventory's 75 paths match the changed executable files exactly.

Final pass done
rework

Main decision: full final has been read. Address R1 with direct mocked-witness refusal tests per listed class (cells non-simple/outside/touch; duplicate pair; bonus headroom; degree), and negative/fractional attempt budgets, each exact constraint string and real source omission fail-before/after. Current runtime is correct; prefer TEST-ONLY coverage with source byte-identical. Do not invent production APIs just to test; existing vi.doMock witness mechanism or scoped source module-copy test hook acceptable if needed, report design difficulties early. Runtime only if necessary real bug proven. Preserve all prior tests/assertions/task contract. Add real rejection cases that survive label/port repairs and test specific failure constraints; record failed fixture development without deletion. R2 clarify searched evidence and call plan14 designed/validated rather than unnamed approved. R5 mark historical retention-runner/agent copies explicitly inert archival invocation snapshots (NOT runnable canonical workflow), hardcoded oldprobe historical, no deletion or broad cleanup. R3 final owner visuals remain T36; no new design decision or claim. R4 prototype witness dependency acknowledge bounded scope, avoid moving production input in test-only rework. R6 exhaustion withinbudget allowed.
Main archived round1 fully under evidence/claude-review-round1:6896members/62MBgzip, final/receipt/inventory/ASSESSMENT. Preserve files and include this new owned path in eventual staging/index; original reviewer tree/evidence must stay untouched. Main verified all952 preexisting hashes plus75 inventoryhashes. Review actual CLIexit0/1311.443s, harness4 due explicit incomplete coverage. Do not claim approve. Trialcomment6238059354. No CI.
Rework should be narrow and practical. Tests now14, whole607+6harness. For test/docs-only changes rerun focused, npmtest, type/build and actual omissions. No need repeat100sweep/24browsers unchanged runtime unless new concern; reviewer already independently ran both. Final parent focused rerun will follow approval. New test counts/added sources in inventory and evidence hashes accurately update; artifact index generated last. Commit and push everybatch [skip ci]. Full final before main nextreview. Reliable duration record start now. No further agents/paidreview/CI/merge byyou.
