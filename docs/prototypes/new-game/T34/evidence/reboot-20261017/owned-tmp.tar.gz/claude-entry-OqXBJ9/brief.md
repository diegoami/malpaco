T69 review (Claude)
You review PR #1 at 5d85c5fa546787d66921e8c5ba1039c9d1cdd983.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
