T69 review (Claude)
You review PR #1 at 2e895b0c1a36e37b0c592bc51c3d6aa3998ccfc7.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
