T69 review (Claude)
You review PR #1 at 642c950bc634b585f37af7e78921669249438470.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
