T69 review (Claude)
You review PR #1 at 3f8a5afe0b8f39a8e48b7296b9656fa854389f5d.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
