Closes #134.

Completed original watched outcomes now publish once through a private candidate and one-use token. Publication carries complete returned Memory, countries/squad words, players and both RNG words, without applying quick Python effects. Stale/duplicate/wrong-input/incomplete completions reject before the active-state swap.

Watched results use explicit accepted engine/schema identities and application save version3. Existing quick-friendly v1 and campaign v2 meanings remain intact. Watched world rows account for original fixture/year setup reseeding separately from the quick affine RNG chain. Mixed watched→quick saves retain watched history and validate its returned memory. Workers and desktop controls remain T65/T66.

Scope: watched_publication.py/private jobs and atomic swap; watched_schema.py/result and continuation validation; campaign.py/campaign_rounds.py/watched ledgers; session_save.py/explicit version3 compatibility; focused tests and tools/prove_watched_publication.py; docs/watched-kit-acceptance.md. No vendored engine/original bytes changed.

Validation (runtime0e9938f; final9fb725a only records measured evidence):
```text
python3 -m unittest goal2.tests.test_watched_publication -v
6 tests,275.625s,OK; all10 strict T63 seed cases match direct original returned Memory
python3 -m unittest goal2.tests.test_watched_save -v
5 tests,111.077s,OK
python3 -m unittest discover -s goal2/tests
473 tests,868.141s,OK;no skips
python3 tools/prove_watched_publication.py
PASS12 mutation controls; all saved source bytes restored
python3 tools/check_provenance.py
16files OK
python3 tools/check_links.py
links/JSON OK
python3 tools/check_premerge.py --expected-head 9fb725ac914afabfdaa830198fc3a514c87c243f
PASS35harness hashes; original exclusion; local premerge at exact head
```
All6 retained browser scenarios and2 relevant offscreen Qt management/campaign-friendly flows pass on final runtime source. Baseline DW1/DW2 modules absent before implementation. Regressions/mutations prove tail completion, full Memory/countries/squad retention, input-image binding, no duplicate effects/completion/token reuse, watched-history/identity and returned-RNG save checks. Actual1990 executes the second friendly identically after reload; actual1992 retains its source kind2 next fixture and identical atomic unsupported refusal. No schedule invented.

Implementer: owner-selected native GPT-6.1 Sol low. Reviewer: owner-selected independent MiniMax M3 thinking (main dispatches). Branch/worktree/caches and Windows saves retained.
