T69 review (Claude)
You review PR #1 at ae20fb12c239fd185bee4c18f6fe590634d98c2e.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
