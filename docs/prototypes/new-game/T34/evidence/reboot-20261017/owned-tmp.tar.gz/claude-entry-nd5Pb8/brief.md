T69 review (Claude)
You review PR #1 at 00df8c0d33b2b8624c69caa18d5a12ce0e12cfe9.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
