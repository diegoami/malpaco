T69 review (Claude)
You review PR #1 at efbded2896194952ab3c2011f3fa730445031296.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
