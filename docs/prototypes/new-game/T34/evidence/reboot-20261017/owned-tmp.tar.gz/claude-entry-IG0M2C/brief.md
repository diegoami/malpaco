T69 review (Claude)
You review PR #1 at c42341ac5b9649aa87cacb2ab78bd9b139718f2f.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
