T69 review (Claude)
You review PR #1 at c8581872f149ae9ee609130f30c298d187745af3.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
