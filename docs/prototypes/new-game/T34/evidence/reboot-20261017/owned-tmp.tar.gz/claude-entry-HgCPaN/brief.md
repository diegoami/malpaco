T69 review (Claude)
You review PR #1 at 75ea9b49a08d017fe2688d8e692b049b41b9c016.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
