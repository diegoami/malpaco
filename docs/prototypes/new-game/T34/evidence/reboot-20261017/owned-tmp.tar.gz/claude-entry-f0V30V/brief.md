T69 review (Claude)
You review PR #1 at 7a01ed00fede88a8bc59ae640d5eb2cfd62cb4cc.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
