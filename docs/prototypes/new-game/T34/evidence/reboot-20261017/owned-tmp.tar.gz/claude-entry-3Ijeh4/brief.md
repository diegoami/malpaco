T69 review (Claude)
You review PR #1 at 01437bd34c8d6a66217386b3530d6e747681ece6.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
