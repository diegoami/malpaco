T69 review (Claude)
You review PR #1 at 1b0f5db94e068a754c1db32d9086bc7ba39f499a.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
