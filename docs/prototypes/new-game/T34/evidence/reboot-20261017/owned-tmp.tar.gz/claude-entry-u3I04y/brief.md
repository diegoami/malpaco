T69 review (Claude)
You review PR #1 at fa54f92afc2a47ddab46c953ddfda6e515cd4a0d.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
