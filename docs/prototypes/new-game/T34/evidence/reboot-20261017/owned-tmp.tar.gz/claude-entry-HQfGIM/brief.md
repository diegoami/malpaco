T69 review (Claude)
You review PR #1 at ba5e4d0b10d1ee8aaf478347c148b88f8b7be7aa.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
