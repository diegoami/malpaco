T64 review (MiniMax M3)
You review PR #171 at 9fb725ac914afabfdaa830198fc3a514c87c243f. You did not implement it. Native GPT-6.1 Sol low implemented; independent family minimax reviews.
0. Prove HEAD, worktree and diff against origin/main.
1. Rerun every Done-when yourself and account for DW1,DW2,DW3. No claimed author run substitutes for yours.
2. Trace behavior/constants to accepted source3656a2d; distinguish designed save/publication choices.
3. Audit seeded deterministic rules, scope, compatible old v1/v2 meanings and completed-result boundary.
4. Sweep the entire diff and edge tests. Prove findings, or label unverified.
5. Final format: first line EXACTLY `T64 review (MiniMax M3)`; next verdict; DW1/DW2/DW3 commands → results; numbered R findings if any, with changed file/line and severity; `Final pass done`; verdict last. Never post; harness posts your complete final.

FULL TASK:
# T64 Commit watched results atomically and preserve saves

- **Kind**: slice · **Difficulty**: Medium
- **Issue**: [#134](https://github.com/diegoami/goal2/issues/134) · **Repository**: diegoami/goal2 · **Branch**: `task/T64-watched-engine` · **Merge after**: T63.
- **Implementer**: owner chooses before dispatch; no follow-on model selected by this planning update.
- **Reviewer**: owner chooses an eligible independent OpenCode model after a concrete validated PR exists.
- **Evidence**: [designed: owner #97/#130, T67] [derived: proposed PR #251, archaeology `c5b5402bf74a1592a8bbb799942839f41ad79361`, README/E033; PR #243 strict E032 records]. Candidate is planning evidence; consumption requires approved, merged source.
- **Owns**: watched-result publication, campaign completion/history, `session_save.py` and focused publication/save tests.
- **Scope**: [designed] Publish a completed original outcome once: full memory component, countries/squad words, players, both RNG words, engine identity and result. Preserve goal2-only management/campaign metadata while rebuilding known fields from returned memory. Reuse T41's candidate/one-use-token pattern and atomically append the result plus its scheduled completion. Persist explicit engine identity and a compatible result schema. Preserve quick and watched meanings.
- **Done when**:
  1. Run proposed `python3 -m unittest goal2.tests.test_watched_publication -v`: all ten T63 cases publish exactly direct-runner deltas, including energy/form/confidence once and computer country records. Observe kit completion after the post-match tail and successful `result()`; `full_time` alone must not publish. Duplicate/stale completion cannot reapply state, append history or add a second `completed_fixture_ids` entry; wrong scheduled identity and unsupported kinds reject atomically.
  2. Run proposed `python3 -m unittest goal2.tests.test_watched_save -v`: injected failures before final publication preserve complete active state. Save/reload preserves engine identity, returned memory/countries, results, campaign queue/history, management choices and deterministic next-fixture continuation. Both legacy v1 quick-friendly and v2 campaign saves (including T41 history) retain their meaning; malformed watched data rejects atomically.
  3. Relevant Python/browser regressions, provenance, asset exclusion and exact-head local premerge checks pass; mutations removing the tail or duplicating effects/completion must fail a focused test.
- **Hazards**: [derived: proposed E033] Original setup changes the computer's records and the player-update tail performs match effects. Never copy only player bytes or run quick/Python energy/form updates over them. T42 separately scopes any evidenced between-fixture effect outside that tail. In-progress kit `Match.save()` blobs are not automatically a goal2 session-save schema or a new desktop mid-match save feature.
- **Before dispatch**: Main pins accepted source/full resource hashes and exact commands, proves behavioral baselines and splits oversized work. Proposed goal2 commands are future contracts. Original bytes stay ignored; vendored files stay unchanged.

[designed: owner dispatch, 2026-10-17] Native GPT-6.1 Sol low implements; MiniMax M3 reviews the validated PR. [confirmed: T62/T63] Consume the accepted friendly kit at archaeology `3656a2d26e0f57a410d648edeaa6cd9eb7d1f607`, with resource hashes and full-memory/year context in docs/watched-kit-acceptance.md. This task does not re-vendor the later competitive kit. Baseline publication/save test modules are absent on main; prove each new assertion fails without its behavior, including full-time-before-tail, one-use completion and malformed saved data.

[designed: dispatch commands] DW1 `python3 -m unittest goal2.tests.test_watched_publication -v`; DW2 `python3 -m unittest goal2.tests.test_watched_save -v`; DW3 `python3 -m unittest discover -s goal2/tests`, all retained browser scenarios (`node tools/browser-ui/acceptance.mjs --scenario <scenario>`), `python3 tools/check_provenance.py`, `python3 tools/check_links.py`, and `python3 tools/check_premerge.py --expected-head <full-head-sha>`. Use the ten strict T63 reference seeds plus actual fresh1990/1992 campaign inputs. Reuse T41/T48 atomic campaign round publication without applying quick-only energy/confidence effects on watched memory. Existing v1/v2 saves keep their meaning; version/schema changes must be explicit and reject unsupported engine identities.

## Blocking means

Any one is enough; a blocking finding means rework, never approve.
1. A Done-when line fails, or cannot be run as written.
2. What this task protects can be got past: atomic once-only full-original watched publication, source/RNG identity, and compatible save continuation. A bypass you proved is blocking, even when it
   looks like an edge case. Never "follow-up hardening" or "outside the threat model" unless the
   task says so; if it does, quote the line. (L47)
3. Behaviour the task forbids, or behaviour nobody asked for, inside a file the task requires. (L44)
4. an untagged behavior claim, edited vendor bytes, original bytes committed, a test that passes with protected behavior deleted, or status in documents
Not blocking: wording, style, and defects in code the PR did not change: file those as follow-ups.
When unsure, say how likely the problem is. Rate it blocking only if it is likely and would get
past what the task protects; otherwise it is a follow-up. (L53)

## Report every blocking finding in this one review

This review is your only pass before the author fixes. Do not stop at the first blocking
finding: finish reading the whole diff and the task file, check every Done-when line and
every item under "Blocking means", and report all blocking findings together.

- Before you write the verdict, make one last pass over the full diff for anything you have
  not yet rated, and say "Final pass done" as the last line before the verdict.
- Number the findings R1, R2, … in order of severity. A finding you held back because an
  earlier one was already blocking is a review defect: if two problems share a cause, list
  both and say so.
- Do not rely on a later round. The author fixes everything you list, and the next review
  checks those fixes and new code only, not anything you saw but did not report.
- If you ran out of time or context before covering the whole diff, say which files or
  sections you did not cover. Do not approve in that case.

Practical run contract:
- Use only the harness-created review worktree, not author/main checkout. NEVER remove worktrees or delete caches/logs/artifacts. Do not git stash/reset/restore/forcepush or change task/vendor/source files except saved-byte scratch mutants restored in finally. No original bytes committed. Keep every measured output.
- PythonPATH/bin: prepend `/home/diego/projects/goal2/.cache/validation-venv/bin` (Py3.12.14,Qt6.12,Unicorn2.1.4). Copy required verified `.sav` and GOAL.DAT from /tmp/goal2-review-fixtures into ignored .cache. Upstream source at /home/diego/projects/goal2-archaeology readonly.
- Browser tooling /tmp/goal2-browser-tooling/node_modules/playwright/index.js; PLAYWRIGHT_BROWSERS_PATH=/tmp/goal2-browser-tooling/browser-cache. Inspect actual acceptance flags; all6 retained scenarios. Qt `QT_QPA_PLATFORM=offscreen`.
- Run DW1 and DW2 once each; full suite once. Main needed all tests/no skips. The unchanged terminal PTY test has existing #163 flake; if that alone occurs, inspect unchanged diff and rerun its module, report exact full result honestly. Do not repeatedly rerun the full expensive suite for it.
- Actual fresh1990 exercises next-friendly watched and quick continuation; actual1992 nextkind2 is unsupported and must refuse atomically identically after reload, without inventing/replacing source schedule. New worker/UI routing is T65/T66. Original full Memory precedes separate T48 silent suffix primary RNG advancement; no quick energy/form/confidence overlay on original records.
- Review author proof `python3 tools/prove_watched_publication.py`; run targeted mutation controls relevant to protected tail, identity, one-use completion and saved-schema behaviors. Whole-class audit in one review. Do not exhaustively search new original seeds/fixtures or repeat T62 upstream investigations.
- No single tool call >60s. Long commands as owned detached jobs/logs; poll short calls and retain evidence. Finish the whole review before final, or explicitly say uncovered scope and rework.
