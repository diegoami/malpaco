from pathlib import Path
import subprocess,json,hashlib
D=Path(__file__).resolve().parent;R=D.parents[4];core=R/'src/core/island-geography.ts';original=core.read_bytes()
p=[p.parent for p in D.glob('sample-*/report.json') if json.loads(p.read_text())['variant']=='global-label-fortyeight'][0];candidate=(p/'sources/src/core/island-geography.ts').read_text()
start=candidate.index('function repairReservations(');stop=candidate.index(' for(const r of rng.shuffled(g.entranceReservations)){',start)
header=candidate[start:stop].replace('function repairReservations(', 'function repairLayoutReservations(')
body="""
 for(let pass=0;pass<3;pass++)for(const r of rng.shuffled(g.entranceReservations)){
  const ids=(id:string)=>g.islands.find(i=>i.id===g.provinces.find(p=>p.id===id)!.island)!.provinces;
  const count=(id:string)=>g.entranceReservations.filter(q=>q!==r&&(q.from===id||q.to===id)).length;
  const available=(id:string)=>count(id)<2&&g.provinces.find(p=>p.id===id)!.borders.length+count(id)+1<=5;
  if(corridorErrors(g,r).length===0&&available(r.from)&&available(r.to))continue;
  const previous={from:r.from,to:r.to,points:r.points},choices=ids(r.from).filter(available).flatMap(from=>ids(r.to).filter(available).flatMap(to=>ports(from).flatMap(a=>ports(to).filter(b=>norm2(a,b)>=(20*Q)**2).map(b=>({from,to,a,b,cost:norm2(a,previous.points[0]!)+norm2(b,previous.points.at(-1)!)}))))).sort((a,b)=>a.cost-b.cost);
  let accepted=false;
  for(const c of choices){r.from=c.from;r.to=c.to;r.points=[[...c.a],[...c.b]];if(corridorErrors(g,r).length===0){accepted=true;break;}}
  if(!accepted){r.from=previous.from;r.to=previous.to;r.points=previous.points;}
 }
}
function swapLayout(g:IslandGeography):void {
 const swap=new Map([["island_0","island_8"],["island_8","island_0"]]);
 for(const r of g.entranceReservations)for(const side of ["from","to"]as const){const old=g.provinces.find(p=>p.id===r[side])!.island,target=swap.get(old);if(target)r[side]=g.islands.find(i=>i.id===target)!.provinces[0]!;}
 for(const [id,dy]of [["island_0",306*Q],["island_8",-303*Q]]as const){const move=(p:GeoPoint):GeoPoint=>[p[0],p[1]+dy];const island=g.islands.find(i=>i.id===id)!;island.polygon=island.polygon.map(move);for(const p of g.provinces.filter(p=>p.island===id)){p.polygon=p.polygon.map(move);p.labelAt=move(p.labelAt);}}
}
"""
candidate=candidate.replace('export function generateIslandGeography',header+body+'export function generateIslandGeography').replace('const geography=newWitness(rng.seed);flipSubdivisions','const geography=newWitness(rng.seed);swapLayout(geography);flipSubdivisions').replace('repairLabels(geography);repairReservations(geography,rng);','repairLabels(geography);repairLayoutReservations(geography,rng);')
assert 'swapLayout(geography)'in candidate and 'repairLayoutReservations(geography,rng)'in candidate
try:
 core.write_text(candidate)
 with (D/'swap-probe.txt').open('w')as f:r=subprocess.run(['node',str(D/'smoke.mjs'),'independent-slot-swap'],cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=900)
finally:core.write_bytes(original)
(D/'swap-probe-report.json').write_text(json.dumps({'exit':r.returncode,'core_restored':core.read_bytes()==original,'candidate_sha256':hashlib.sha256(candidate.encode()).hexdigest(),'scope':'Fixed independent3/10country-island placement exchange feasibility only; not production'},indent=2)+'\n');print('independent slot exchange probe exit',r.returncode,flush=True)
