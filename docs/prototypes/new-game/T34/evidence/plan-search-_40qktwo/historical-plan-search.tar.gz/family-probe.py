from pathlib import Path
import subprocess,json,hashlib
D=Path(__file__).resolve().parent;R=D.parents[4];core=R/'src/core/island-geography.ts';original=core.read_bytes();candidate=(D/'family-candidate.ts').read_bytes()
try:
 core.write_bytes(candidate)
 with (D/'family-probe.txt').open('w')as f:r=subprocess.run(['node',str(D/'smoke.mjs'),'three-plan-family'],cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=900)
finally:core.write_bytes(original)
(D/'family-probe-report.json').write_text(json.dumps({'exit':r.returncode,'core_restored':core.read_bytes()==original,'candidate_sha256':hashlib.sha256(candidate).hexdigest()},indent=2)+'\n');print('family feasibility exit',r.returncode,flush=True)
