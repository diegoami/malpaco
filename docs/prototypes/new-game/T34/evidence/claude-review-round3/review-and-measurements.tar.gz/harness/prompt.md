T34 review (Claude Sonnet High)
You review PR #150 at 05780526ba23cbbc8268c3f7975db145e179ff67. You did not write it. The task file follows.
0. Prove the tree: HEAD is 05780526ba23cbbc8268c3f7975db145e179ff67 and the diff against origin/main is the PR's; findings name its files.
1. Re-run every Done-when line yourself, and account for each (L32). The PR's evidence is no proof.
2. [evidence-driven] Every constant traces to a fixture, report or investigation; a [designed] one says what was searched.
3. [seeded] No wall clock, unseeded random or order-dependent iteration in rule code.
4. Every changed file and behaviour is one the task asks for (L44); docs it makes wrong are updated.
5. Sweep the diff: tests that pass with the behaviour deleted (mutate, rebuild clean, re-take any
   negative result), branches no input reaches, edge comments without a test, integer geometry, valid exported successes, retry histories, bounded exhaustion, real shape/layout diversity and save compatibility.
   Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
   restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
   a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
   copy inside your worktree (`<file>.saved`, deleted afterwards) or in a `mktemp -d` folder under
   `/tmp`, never as a loose file elsewhere.
6. Apply the following review criteria.
## Blocking means

Any one is enough; a blocking finding means rework, never approve.
1. A Done-when line fails, or cannot be run as written.
2. What this task protects can be got past: valid deterministic partial geography, unchanged T24/T62 constraints, bounded retry/history and nontrivial independent shape/layout variation. A bypass you proved is blocking, even when it
   looks like an edge case. Never "follow-up hardening" or "outside the threat model" unless the
   task says so; if it does, quote the line. (L47)
3. Behaviour the task forbids, or behaviour nobody asked for, inside a file the task requires. (L44)
4. uncited constants, acceptance surviving deletion of protected behavior, impure rule code or weakened assertions
Not blocking: wording, style, and defects in code the PR did not change: file those as follow-ups.
When unsure, say how likely the problem is. Rate it blocking only if it is likely and would get
past what the task protects; otherwise it is a follow-up. (L53)

## Report every blocking finding in this one review

This review is your only pass before the author fixes. Do not stop at the first blocking
finding: finish reading the whole diff and the task file, check every Done-when line and
every item under "Blocking means", and report all blocking findings together.

- Before you write the verdict, make one last pass over the full diff for anything you have
  not yet rated, and say "Final pass done" as the last line before the verdict.
- Number the findings R1, R2, … in order of severity. A finding you held back because an
  earlier one was already blocking is a review defect: if two problems share a cause, list
  both and say so.
- Do not rely on a later round. The author fixes everything you list, and the next review
  checks those fixes and new code only, not anything you saw but did not report.
- If you ran out of time or context before covering the whole diff, say which files or
  sections you did not cover. Do not approve in that case.

Prove each finding (run it, or delete the behaviour and name the test that fails) or label it
unverified. Your final message is the review: the header; the verdict (approve | approve after
named fixes | rework | user decision); per Done-when line `DW<k>: ran <command> → <result>` or
`DW<k>: not run — <reason>`; the findings R1..Rn (file:line, blocking or not); the verdict again
last. Never post it: the script posts it and applies the label.

# T34 Seeded island silhouettes and province subdivisions

- **Kind**: slice
- **Issue**: #79 · **Branch**: `task/T34-seeded-island-silhouettes-and-province-subdivisions` · **Merge after**: T33, T24, T62, T63.
- **Difficulty**: Very hard; estimate, not a model assignment.
- **Implementer**: owner-selected under rule 6; use an isolated worktree and record the choice before dispatch.
- **Reviewer**: owner-selected OpenCode model of another family under rule 6; record the choice before review.
- **Evidence**: [pinned core-rules design](https://github.com/diegoami/isle-wars-archaeology/blob/ae298e37c2f5177039e55767607f9345b6cb0e7a/design/core-rules.md), owner roadmap accepted 2026-10-15, and upstream task evidence. T23 resolves source anchors; new constants need citations or explicit [designed] provenance.
- **Owns**: src/core/**; tests/core/**; docs/prototypes/new-game/T34/**; docs/spike.md; append-only RUN-NOTES.md.
- **Scope**: Build seeded geography using the owner-selected A construction direction and T62 coast-entry contract alongside unchanged T24 structural limits. Jointly reserve entrance-country coast opportunities, island placement/orientation, water corridors and real label space; do not freeze arbitrary subdivisions before considering links. Derive land adjacency from positive shared boundaries. Rules never read positions. Export partial geography and entrance reservations for T35 inspection, never incomplete playable boards. Start with retained feasible witnesses and preserve failures; a single reference does not prove generality. Owner decision of 2026-10-17 requires broader island shapes and layouts before proceeding: subpixel perturbations and whole-board reflections of one witness do not suffice. Preserve the approved geographic visual direction and unchanged numeric constraints while measuring independent silhouette and placement variation.
- **Done when**:
  1. `npx vitest run tests/core/island-geography.test.ts` — prescribed island sizes, connected valid cells, no interior overlaps/gaps, symmetric shared-boundary adjacency and contract land-degree headroom hold for all exported successes. Exercise rejected candidates, retry history and bounded exhaustion with real failure records; omission of failure recording must fail acceptance. A retained seeds0..31 corpus must place the10-country island both within the middle vertical third and outside it (invariant under whole-board reflections), and vary at least one island's bounding-box aspect ratio by5% or more. These [designed] breadth measurements operationalize the owner's broader-layout decision; numeric play/display constraints remain unchanged.
  2. `node docs/prototypes/new-game/T34/sweep.mjs` — enumerate seeds 0..99 with fixed bounded attempts; report valid subdivisions/100, per-constraint failures and replay hashes against the approved T24 budget, with no discarded failures. Retain a seed gallery and shape/layout diversity measurements that factor out whole-board reflection and incidental fixed-point jitter.
  3. `npm test` and `npm run build` pass; affected pinned browser suites pass without weakening existing assertions. Retain measured outputs, screenshots where applicable, commands and hashes in the owned evidence path; report negative-before/positive-after checks and exact restoration.
- **Hazards**: Run the feasibility smoke before algorithm changes. If the approved target is unreachable, stop; do not relax degree, label or shape constraints. Main session preflights acceptance before dispatch; unresolved design conflicts stop implementation, never weaken a Done-when.



Second test-only rework, final follow-up after full earlier reviews. Read complete previous findings below. Core/sweep unchanged since a842967; new behavior is three isolated degree subcondition tests and their controls, plus documentation/evidence. Check fixes and new code; do not reopen unchanged issues already investigated. All original/full-finals/evidence preserved. Another blocking rework goes to owner under rule7. Never manufacture approval to avoid that limit.

FIRST FINISH COVERAGE, BEFORE ANY TEST OR MUTATION:
Read /home/diego/projects/malpaco/.cache/t34-dispatch/coverage/README.md, manifest.json and EVERY numbered packet. Packet contents are lossless numbered JSON string fragments (source line/character offset), avoiding the line-column truncation in your earlier runs. Verify original file SHA256 values and all byte-identical aliases against your own review tree. These are reading aids, not trusted execution inputs. Historical scripts/runner/agent snapshots are inert: inspect without executing. Your prior finals must not be used to pretend that unread files were covered.

The manifest enumerates all required FILE paths (including .gitignore files). Most numeric evidence is grouped; every non-generated suffix requires FILE. Identical paths share one actual-content read only after exact byte-equality proof. HTML galleries are ~100–164KB of mostly SVG coordinate data: parse ALL markup/attributes/styles and any scripts/URLs/events, check generated data structurally against the inspected renderer and applicable hash/oracle receipts, and view the gallery image. You need not hand-read every numeric coordinate as program logic, but cannot claim coverage from grep alone. Read full own RUN-NOTES diff (no cut), docs/spike diff, current README/CONTRACT/family-provenance, and the task. If output truncates, split into bounded packets/chunks and continue; do not use cut/grep as full reading. This is the central unresolved review problem; complete it before spending time on checks.

After coverage: run focused25case acceptance,100seed sweep,npmtest/build,24 pinned browsers as current README instructs. Check the THREE new degree-clause omissions using targeted -t patterns rather than rerunning the full25case file for every mutation. Previous nine guard/budget classes and layout/warp/history already have independent measured omission proof on unchanged runtime; no need to repeat them. Existing r4-controls may also run units/build; inspect before deciding. Retain outputs in your tree and restore originals from saved bytes in finally. All scratch MUST stay inside your review tree; never /tmp/x/shared paths. Use project-local TMPDIR. No CI, publishing, new agents or model dispatch.

Final: full findings, each DW command/result, exact standalone SCOPE: complete ONLY if honest; exactly FILE: path for EVERY manifest required path, plus RUN-NOTES.md and docs/spike.md. EVIDENCE: docs/prototypes/new-game/T34/ on its own line may cover known generated data suffixes, not code/HTML/.gitignore. No bold/bullets/comments on these parser lines. Do not emit UNCOVERED unless genuinely incomplete; incomplete cannot approve. Full previous rounds follow for continuity.

ROUND1 FULL FINAL:
T34 review (Claude Sonnet High)
rework
DW1: ran `npx vitest run tests/core/island-geography.test.ts` → 14/14 passed (37.9 s). The seeds0..31 corpus puts the 10-country island in the middle third and outside it. At least one island's aspect ratio varies by 5% or more. Mutating the source to drop layout, warp or failure recording fails the matching tests (details under R1).
DW2: ran `node docs/prototypes/new-game/T34/sweep.mjs` → 100/100 valid, `targetMet:true`. Output is `evidence/sweep-AHN9CY`.
- Replay hashes are identical, with 100 geometry hashes and 4 land graphs.
- The largest island sits in the middle third in 38 seeds and outside it in 62.
- Failure counts: labels 926, attachment 584, water 120, degree 41, traceability 11.
- Every seed's result and failures are retained; none are discarded.
- Per-island aspect max/min runs from 1.215 to 1.401, matching the receipt.
DW3: ran `npm test` → 607 Vitest passed plus 6 harness tests, exit 0. Ran `npm run build` → exit 0. Ran `python3 docs/prototypes/new-game/T34/run-browser.py reviewer-current --suites reference-complete-game,reference-game,versioned-match,entry` → 24 passed, exit 0, `sourcesUnchangedDuringRun:true` (`evidence/reviewer-current-4fnisiwu`). I did not re-run the author's negative-before/positive-after record. I ran my own source mutations, and every mutation was restored byte-exact (`git diff` is empty).

Where I worked
- Worktree HEAD is a842967717584549e58b10d37869c1fe4dd461d6. The diff against base 7ce8911 is 957 files, of which only 4 are outside T34: `RUN-NOTES.md`, `docs/spike.md`, `src/core/island-geography.ts` and `tests/core/island-geography.test.ts`. T24 and T62 are untouched. All 40 frozen T24/T62 copies under `evidence/feasibility-*/sources` are byte-equal to the live files.
- `prepare-witness.mjs` reproduces `witness.json` byte-exactly from T64/board.json, whose sha256 matches `witness-provenance.json`.
- I ran seeds 100..699 through the independent oracle (scratch script `.scratch/wide.mjs`). 599 were valid, 0 exports were invalid, and seed 398 exhausted (the maximum was 44 attempts). Together with seeds 0..99 that is 699 valid out of 700.
- The rule code has no clock, no random source and no order-dependent iteration. `rng.shuffled` and Map/Set insertion order are deterministic.

Findings

**R1 — BLOCKING** (`src/core/island-geography.ts:181,185,189,192,199,249`; `tests/core/island-geography.test.ts`). Acceptance survives deleting protected behaviour. I mutated the real source and ran the real acceptance commands.

| Guard removed | Line | Result |
|---|---|---|
| The three `cells:` guards (non-simple polygon, outside frame, island touch/overlap) | 189, 199 | DW1: 14/14 pass. DW2 sweep with these plus the next two guards removed: `targetMet:true`, 100/100. |
| `crossings: duplicate reserved country pair` | 181 | Same as above. |
| `crossings: insufficient bonus headroom` | 185 | Same as above. |
| The `degree:` guard (`borders<2`, `borders>4`, `+lanes>5`, `lanes>2`) | 192 | DW1 passes 14/14 and the DW2 sweep passes 100/100 (`evidence/sweep-2CjENm`). The 41 degree rejections in the real sweep all co-occur with other failure classes. |
| `Math.max(0,…)` in the budget clamp | 249 | DW1: 14/14 pass. A negative budget would return a negative `attempts`. |
| `Math.floor(raw)` in the budget clamp | 249 | DW1: 14/14 pass. A fractional budget would return a fractional `attempts`. |

- **What is missing:** no input in 700 seeds ever triggers the `cells:`, duplicate-pair or bonus-headroom branches, and no mocked witness exercises them. The task protects "connected valid cells, no interior overlaps/gaps", unique crossings, land-degree headroom and bounded exhaustion.
- **Why it matters:** the only thing that currently catches these is the oracle, and only if the constructor ever exports such a result. The constructor's own refusal of those candidates is unprotected.
- **Fix:** add a mocked-witness test per guard, in the style of the existing fortress test at `tests/core/island-geography.test.ts:83`. Each test should assert the exact constraint string in the failure records. Also test negative and fractional budgets.
- **Protected, for the record:** these mutations were caught.
  - Omitting layout fails the middle-third test.
  - Omitting warp fails the aspect test.
  - Omitting the failure push fails 10 tests.
  - Omitting flip fails the topology test.
  - Omitting the label-hit guard fails 3 tests.
  - Omitting the fortress/concentration guards fails the mock test.
  - Omitting the water/attachment corridor guards fails 6 tests.
  - Restricting layout to plans 0 and 1 fails the middle-third test, so plan 2 is required.

**R2 — non-blocking (follow-up)**
- `family-provenance.json` and CONTRACT.md name the [designed] plan translations (306/−303, 26/155, −75/−167) but say only "reviewed T24/T62/T63 and T64/T65 geometry studies". They do not say what was searched. The in-code comment "Approved 14-route plan" (`src/core/island-geography.ts:242`) names no approver. The 48px, 24px and three-pass values do trace to retained probes (`breadth-amplitude-m02i9_al`, `breadth-joint-r8ghb3fn`).
- Likelihood is moderate that the owner wants the search described, but the numbers are retained and traceable.

**R3 — non-blocking (owner judgement).**
- The gallery PNG (`family-gallery-pi361ktz`) shows the same nine silhouettes and internal seams. They are stretched, moved between two swapped slots, and flipped once per island. The seed-3, 6 and 10 boards look near-identical.
- The Done-when measures pass literally, and per-island aspect ratios are only weakly correlated (median −0.11 across 100 seeds), so this is not one global stretch.
- The PR says it is not owner visual approval. The owner should judge whether this meets "broader shapes".

**R4 — non-blocking.**
- `src/core/island-geography.ts:22` imports `docs/prototypes/new-game/T34/witness.json`. Production core depends on a prototype docs path. It is allowed under Owns, but pruning docs breaks core.

**R5 — non-blocking.**
- `review-tools/retention-runner.mjs` (15.8 KB) is a modified copy of `tools/harness/review.mjs`. It imports `./lib/*`, which is absent, so it cannot run. It also contains `git worktree remove --force` and `fs.rmSync` on a T34-specific path. `review-tools/reviewer150.md` is an agent definition copy. The task did not ask for either, and I suggest dropping them or labelling them inert.
- `evidence/breadth-joint-r8ghb3fn/gallery-metrics.py` hard-codes `/home/diego/projects/malpaco/.cache/t34-work` paths.
- Several RUN-NOTES.md entries have their spaces stripped, for example "keepsmapgenerationbeforecards". The file is append-only as required.

**R6 — informational.**
- The sweep's target-met gate holds, but seed 398 exhausts 50 attempts. That is 1 in 700 seeds, which is within the T24 99% target.

Coverage
FILE: src/core/island-geography.ts
FILE: tests/core/island-geography.test.ts
FILE: RUN-NOTES.md
FILE: docs/spike.md
FILE: docs/prototypes/new-game/T34/acceptance.mjs
FILE: docs/prototypes/new-game/T34/sweep.mjs
FILE: docs/prototypes/new-game/T34/run-browser.py
FILE: docs/prototypes/new-game/T34/run-command.py
FILE: docs/prototypes/new-game/T34/r2-controls.py
FILE: docs/prototypes/new-game/T34/r1-controls.py
FILE: docs/prototypes/new-game/T34/r2-final.py
FILE: docs/prototypes/new-game/T34/r2-preflight.py
FILE: docs/prototypes/new-game/T34/controls.py
FILE: docs/prototypes/new-game/T34/preflight.py
FILE: docs/prototypes/new-game/T34/full-preflight.py
FILE: docs/prototypes/new-game/T34/prepare-witness.mjs
FILE: docs/prototypes/new-game/T34/verify-evidence.py
FILE: docs/prototypes/new-game/T34/archive-captures.py
FILE: docs/prototypes/new-game/T34/archive-evidence.py
FILE: docs/prototypes/new-game/T34/family-smoke.mjs
FILE: docs/prototypes/new-game/T34/family-smoke.py
FILE: docs/prototypes/new-game/T34/family-gallery.py
FILE: docs/prototypes/new-game/T34/feasibility-smoke.mjs
FILE: docs/prototypes/new-game/T34/feasibility-wide.mjs
FILE: docs/prototypes/new-game/T34/flip-probe.mjs
FILE: docs/prototypes/new-game/T34/CONTRACT.md
FILE: docs/prototypes/new-game/T34/README.md
FILE: docs/prototypes/new-game/T34/witness-provenance.json
FILE: docs/prototypes/new-game/T34/family-provenance.json
FILE: docs/prototypes/new-game/T34/witness.json
FILE: docs/prototypes/new-game/T34/family-candidate.ts

I read `family-candidate.ts` only as a diff against the installed core. I read `RUN-NOTES.md` with lines cut at 900 characters.

EVIDENCE: docs/prototypes/new-game/T34/evidence/sweep-AHN9CY/ (fresh run, plus my own mutation sweeps in `sweep-GwTA7u` and `sweep-2CjENm`)
EVIDENCE: docs/prototypes/new-game/T34/evidence/reviewer-current-4fnisiwu/
EVIDENCE: docs/prototypes/new-game/T34/evidence/family-gallery-pi361ktz/ (PNG viewed)
EVIDENCE: docs/prototypes/new-game/T34/evidence/feasibility-QiwWlL/ and feasibility-zjVwJN/ (frozen T24/T62 copies compared byte-equal to live; `flip-probe-Tg7Pmr/flip-probe.mjs` is byte-equal to `flip-probe.mjs`)

SCOPE: incomplete
UNCOVERED:
- `docs/prototypes/new-game/T34/candidate.ts`: historical first-family copy, only grepped for Date/Math.random.
- `docs/prototypes/new-game/T34/review-tools/retention-runner.mjs` and `reviewer150.md`: read in part only.
- The scripts under `evidence/breadth-amplitude-m02i9_al`, `evidence/breadth-joint-r8ghb3fn` and `evidence/clock-fix-49d9ipkk`: first about 40 lines at 260 columns only.
- The 749 `evidence/` files, 172 `preflight/` files, `artifacts.json` and `file-inventory.json`: not individually audited. I checked only that the inventory's 75 paths match the changed executable files exactly.

Final pass done
rework
ROUND2 FULL FINAL:
T34 review (Claude Sonnet Medium)
rework

**Where I worked**
- Worktree HEAD is `d59e33fd5e4d3e759fdc82cceeb0945305644d61`. The diff against base `7ce8911` is the PR's.
- `git diff a842967 HEAD -- src` is empty, so `src/core/island-geography.ts` is byte-identical to the previously reviewed core.
- T24, T62 and T63 are untouched against the base.
- Since `a842967`, the only executable or test changes are `tests/core/island-geography.test.ts` (+53 lines, appended after the original tests), `verify-evidence.py` (one line), and the new `r3-controls.py` and `r3-integrity.py`. I also saw `CONTRACT.md`, `README.md`, `family-provenance.json`, `review-tools/README.md`, `RUN-NOTES.md`, `artifacts.json` and `file-inventory.json` change. `docs/spike.md` is unchanged since `a842967`.
- Evidence checks:
  - `file-inventory.json` hashes match the files (0 mismatches).
  - All 1031 `artifacts.json` hashes match, with none missing.
  - `verify-evidence.py` ran and verified 117 reports (`evidence/integrity-mokjmps2`).
  - The 40 frozen T24/T62/T64/T65 copies in `evidence/feasibility-QiwWlL` and `feasibility-zjVwJN` are byte-equal to the live files.
  - `feasibility-wide.mjs`, `feasibility-smoke.mjs` and `flip-probe.mjs` each have a byte-equal retained copy.
- Scratch lives in `.scratch/` in my worktree. Each mutation was restored byte-exact (`cmp` against the saved copy, `git status` clean for `src`).

**DW lines**
DW1: ran `npx vitest run tests/core/island-geography.test.ts` → 22/22 passed, exit 0. The 8 added tests (6 refusals, negative budget, fractional budget) all pass.
DW2: ran `node docs/prototypes/new-game/T34/sweep.mjs` → exit 0, 100/100 valid, `targetMet:true`.
- Output is `evidence/sweep-IFkC7M`: 100 geometry hashes, 4 topology hashes, middle band 38 and outer band 62.
- Failure counts: labels 926, attachment 584, water 120, degree 41, traceability 11. This matches the previous sweep exactly, so replay is stable.
DW3: ran `npm test` → 42 files, 615 Vitest passed, exit 0. Ran `npm run build` → exit 0. Ran `python3 docs/prototypes/new-game/T34/run-browser.py reviewer-r3 --suites tests/e2e/reference-complete-game.spec.ts,tests/e2e/reference-game.spec.ts,tests/e2e/versioned-match.spec.ts,tests/e2e/entry.spec.ts` → 24 passed, exit 0 (`evidence/reviewer-r3-8r7dour4`). I did not run `r3-controls.py`, because it needs no re-run of what I mutated myself.

**Mutation results on the new tests**
I changed the real core in place and ran the focused test file each time.

| Guard removed | Result |
|---|---|
| `cells: non-simple polygon` | caught by the new non-simple test |
| `cells: outside frame` | caught |
| `cells: islands touch/overlap` | caught |
| `crossings: duplicate reserved country pair` | caught |
| `crossings: insufficient bonus headroom` | caught |
| `p.borders.length<2` | caught |
| `Math.max(0,…)` in the budget clamp | caught |
| `Math.floor(raw)` in the budget clamp | caught |
| `Math.min(MAX_ATTEMPTS,…)` cap | caught |
| **`p.borders.length>4`** | **22/22 pass, survives** |
| **`p.borders.length+lanes>5`** | **22/22 pass, survives** |
| **`lanes>2`** | **22/22 pass, survives** |

**Findings**

**R1 — BLOCKING** (`src/core/island-geography.ts:192`, `tests/core/island-geography.test.ts` degree case). Three of the four sub-conditions of the land-degree headroom guard are unprotected.
- The guard is `p.borders.length<2||p.borders.length>4||p.borders.length+lanes>5||lanes>2`. The only degree test uses a detached cell with zero neighbours, which exercises only `borders<2`.
- Deleting `borders>4`, `borders+lanes>5` or `lanes>2` leaves the 22 focused tests green.
- I also removed all three together and ran the real DW2 sweep. It still exits 0 with `targetMet:true`, 100/100 valid, and the same 100 geometry hashes and 4 topology hashes.
- No test input or sweep seed reaches those branches. The task names "contract land-degree headroom" as protected, and the constructor's refusal of an over-degree or over-lane candidate can be deleted without any acceptance failing.
- This is the same defect class as round-1 R1, fixed only for the zero-neighbour case.
- `r3-controls.py` removes the whole `degree:` `fail.add` line, so it cannot show this gap.
- Fix: add one mocked-witness case per sub-condition, each asserting `degree: insufficient entrance headroom` in every failure record.
  - Five or more shared-boundary neighbours.
  - Four neighbours plus two lanes, which gives more than five.
  - Three reserved lanes on one country.
- Extend `r3-controls.py` to remove each sub-condition separately.

**R2 — non-blocking.** The README says `artifacts.json` indexes 1025 hashes. The file holds 1031 entries, all matching. This is a count in the docs only.

**R3 — non-blocking (owner judgement, unchanged).** The earlier gallery observation still stands: the nine silhouettes are warped and swapped variants of one witness. The DW1 breadth measures pass literally. This round does not change that.

**R4 — non-blocking, resolved.** The round-1 documentation items are fixed as narrow documentation. `family-provenance.json` and `CONTRACT.md` now say what the manual placement search covered. The "Approved 14-route plan" comment is explained as a locally validated plan, not a separate approval. `review-tools/README.md` labels the runner and agent snapshots inert. Both snapshot files are byte-identical to `a842967`. The core still imports `witness.json` from the docs path, which is documented.

**SCOPE: incomplete**
UNCOVERED:
- I did not read `r3-controls.py` past about 500 columns per line, `run-browser.py` past about 200 columns per line, or the clock-fix wrapper past about 700 columns per line.
- I did not read `candidate.ts` in full. I diffed it against the live core, and it is not imported by anything outside the evidence and inventory files.
- I did not read `retention-runner.mjs` or `reviewer150.md` in full. I grepped them, and both are byte-identical to `a842967`.
- I did not read `RUN-NOTES.md` beyond the diff, which I saw with lines cut at 600 characters.
- I did not individually read the other root scripts, which are unchanged since `a842967`: `acceptance.mjs`, `sweep.mjs`, `run-command.py`, `r1-controls.py`, `r2-controls.py`, `r2-final.py`, `r2-preflight.py`, `controls.py`, `preflight.py`, `full-preflight.py`, `prepare-witness.mjs`, `archive-captures.py`, `archive-evidence.py`, `family-smoke.mjs`, `family-smoke.py`, `family-gallery.py`, `family-candidate.ts`. I ran `acceptance.mjs`, `sweep.mjs` and `run-browser.py` by executing them.
- I did not read the three gallery HTML files. I only grepped them for scripts and links and found none.
- I did not read the remaining scripts under `evidence/` and `preflight/`.

FILE: src/core/island-geography.ts
FILE: tests/core/island-geography.test.ts
FILE: docs/prototypes/new-game/T34/verify-evidence.py
FILE: docs/prototypes/new-game/T34/r3-integrity.py
FILE: docs/prototypes/new-game/T34/feasibility-smoke.mjs
FILE: docs/prototypes/new-game/T34/feasibility-wide.mjs
FILE: docs/prototypes/new-game/T34/flip-probe.mjs
FILE: docs/prototypes/new-game/T34/evidence/breadth-amplitude-m02i9_al/run-probe.py
FILE: docs/prototypes/new-game/T34/evidence/breadth-amplitude-m02i9_al/smoke.mjs
FILE: docs/prototypes/new-game/T34/evidence/breadth-joint-r8ghb3fn/run-probe.py
FILE: docs/prototypes/new-game/T34/evidence/breadth-joint-r8ghb3fn/smoke.mjs
FILE: docs/prototypes/new-game/T34/evidence/breadth-joint-r8ghb3fn/candidate-sweep.py
FILE: docs/prototypes/new-game/T34/evidence/breadth-joint-r8ghb3fn/global-probe.py
FILE: docs/prototypes/new-game/T34/evidence/breadth-joint-r8ghb3fn/global-label-probe.py
FILE: docs/prototypes/new-game/T34/evidence/breadth-joint-r8ghb3fn/gallery-metrics.py
FILE: docs/prototypes/new-game/T34/evidence/breadth-joint-r8ghb3fn/render-gallery.cjs
EVIDENCE: docs/prototypes/new-game/T34/

Final pass done
rework

---
OUTPUT RULES (from tools/harness/review.mjs; they override anything above that conflicts):
- Do not post to GitHub, commit, push, label or merge anything. The script posts your review.
  Edit nothing, but for a mutation made in place in your worktree and never committed.
  Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
  restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
  a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
  copy inside your worktree (`<file>.saved`, deleted afterwards) or in your own folder under
  `/tmp/opencode/`. Outside your worktree, write only under `/tmp/opencode/` (a
  `mktemp -d /tmp/opencode/mlp-review-XXXXXX` folder is the tidiest, removed afterwards; the reviewer
  agent file allows nothing else). Every other path outside your worktree is forbidden.
- Your final message is the review and nothing else. Line 1 is exactly: T34 review (Claude Sonnet High)
  Line 2 is the verdict, alone on its line: approve, approve after named fixes, rework, or user
  decision. Then any where-I-worked lines (worktree, HEAD, diff, the commands you ran), then the
  findings (R1, R2, ... with file and line, blocking or not), then the verdict again as the very
  last line. Nothing comes after it.
- A finding you proved that lets a forbidden action or a wrong result past what the task protects
  is blocking, and blocks an approve: never "follow-up hardening" or "outside the threat model"
  unless the task's text says so (L47).
- Report every blocking finding in this one review, not one per round: read the whole diff, then
  make a final pass and write "Final pass done" as the line before the closing verdict. Name any
  part you did not cover, and do not approve then (L49).
- The task has 3 Done-when lines. Right after the verdict line, account for each, one
  line per Done-when line, DW1 to DW3: "DW<k>: ran <command> → <result>", or
  "DW<k>: not run — <reason>". An approve with one missing, or one not run, is not applied. A review that does not end with its verdict, or that has a
  finding after it, is posted flagged and acted on by no one until the main session reads it.
- Your worktree is /home/diego/projects/malpaco/.cache/t34-claude-review/150-review-d31cffda at 05780526ba23cbbc8268c3f7975db145e179ff67, and it is already your working directory. Run git
  there without -C, and never type that path: a mistyped path ends the run. This rule is about
  your own worktree only (L61): a Done-when line may send git at a pinned repository outside it
  (git -C <path> show <pin>:<file>); run that exactly as written — OpenCode does not path-check
  git -C — and read a granted outside path only with the L59 recipe.

CLAUDE BACKEND CONTRACT: The exact PR base is 7ce8911a20beb6c096186b93af0737966c1b8f4a, head 05780526ba23cbbc8268c3f7975db145e179ff67. Do not use origin/main for a merged PR. Complete local diff: /home/diego/projects/malpaco/.cache/review-evidence/pr150-6902a91f6ab9/full.diff; bounded parts: /home/diego/projects/malpaco/.cache/review-evidence/pr150-6902a91f6ab9/diff-parts; full changed-file inventory: /home/diego/projects/malpaco/.cache/review-evidence/pr150-6902a91f6ab9/inventory.json. Read all executable changes. For generated evidence you may audit a group explicitly. Never claim a file you did not inspect. Before Final pass done, emit SCOPE: complete only if you covered all changes; otherwise SCOPE: incomplete plus UNCOVERED: paths/reasons. Emit FILE: <exact path> for each changed file inspected; EVIDENCE: <docs/prototypes/.../ prefix> may account for generated evidence only, never executable scripts. These are coverage claims, not independent proof. Every Done-when must be run; include exact DW lines. A missing scope acknowledgment prevents approval. No subagents or GitHub writes. Native Claude permission denials mirror OpenCode publishing restrictions; the trusted hook protects credential paths for Read/Grep/Glob. Bash is granted for tests and in-tree mutations. These are mistake safeguards, not an OS sandbox. Preserve scratch/evidence; do not clean up. Ignore obsolete OpenCode-only path restrictions above: your scratch is your retained worktree. No blanket permission bypass.

The read-only contract overrides the tripwire instruction to push: never push.
Out of your depth: stop and hand back, with an ESCALATE block, when any of these happens:
two hypotheses for the same question have failed; you would rely on bytes, code or behaviour
you cannot explain; you are about to write a claim you cannot back with evidence; or you have
made three attempts at one step without progress. Push your branch first. The ESCALATE block
gives what you tried, the evidence so far, and the exact question you could not answer. Never
guess a format or a cause.
