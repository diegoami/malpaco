import fs from 'node:fs';import path from 'node:path';import {registerHooks,stripTypeScriptTypes} from 'node:module';
registerHooks({resolve(s,c,n){return n(s.startsWith('.')&&c.parentURL?.endsWith('.ts')&&!path.extname(s)?s+'.ts':s,c)},load(u,c,n){if(u.endsWith('.ts'))return{format:'module',source:stripTypeScriptTypes(fs.readFileSync(new URL(u),'utf8')),shortCircuit:true};return n(u,c)}});
const {generateIslandGeography}=await import(path.resolve('src/core/island-geography.ts'));
let one=0,cand=0,onlyDeg=0,failsWithOne=0,exportedOne=0;
for(let seed=0;seed<100;seed++){
 const r=generateIslandGeography(seed);
 for(const f of r.failures){cand++;const has1=f.candidate.provinces.some(p=>p.borders.length===1);if(has1){failsWithOne++;if(f.constraints.length===1&&f.constraints[0].startsWith('degree'))onlyDeg++;}}
 if(r.ok&&r.geography.provinces.some(p=>p.borders.length<2))exportedOne++;
}
console.log(JSON.stringify({candidates:cand,rejectedWithOneNeighbourCountry:failsWithOne,degreeOnlyWithOne:onlyDeg,exportedOne}));
