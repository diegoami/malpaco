T69 review (Claude)
You review PR #1 at 0133d294e9f5c4deda1c9deb17c63b5f6bc7e5c7.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
