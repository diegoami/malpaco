import sys,collections,re
from html.parser import HTMLParser
class P(HTMLParser):
    def __init__(s):
        super().__init__(convert_charrefs=True); s.tags=collections.Counter(); s.attrs=collections.Counter(); s.events=[]; s.urls=[]; s.text=[]; s.styles=[]; s.in_style=False; s.scripts=0; s.comments=0; s.decl=[]
    def handle_starttag(s,t,a):
        s.tags[t]+=1
        if t=='script': s.scripts+=1
        if t=='style': s.in_style=True
        for k,v in a:
            s.attrs[(t,k)]+=1
            if k.startswith('on'): s.events.append((t,k,v))
            if v and re.search(r'(https?:|//|javascript:|data:|url\()',v): s.urls.append((t,k,v[:80]))
            if k=='style': s.styles.append(v)
    def handle_endtag(s,t):
        if t=='style': s.in_style=False
    def handle_data(s,d):
        if s.in_style: s.styles.append(d)
        elif d.strip(): s.text.append(d.strip())
    def handle_comment(s,d): s.comments+=1
    def handle_decl(s,d): s.decl.append(d)
for f in sys.argv[1:]:
    p=P(); p.feed(open(f,encoding='utf8').read())
    print('==',f); print('tags',dict(p.tags)); print('attrs',sorted(set(k for (t,k) in p.attrs)))
    print('scripts',p.scripts,'events',p.events,'urls',p.urls,'comments',p.comments,'decl',p.decl)
    print('style blocks',[s[:300] for s in p.styles][:3]); print('text',p.text[:30] if len(p.text)<40 else (len(p.text),p.text[:12]))
