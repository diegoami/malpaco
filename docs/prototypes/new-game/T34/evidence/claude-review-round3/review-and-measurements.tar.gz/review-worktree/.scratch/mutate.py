import subprocess,os,sys,hashlib,json
from pathlib import Path
R=Path.cwd(); core=R/'src/core/island-geography.ts'; saved=R/'src/core/island-geography.ts.saved'
orig=core.read_bytes(); saved.write_bytes(orig)
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(orig)=='ddf63b0aaee80d85ec2422c8048d2c49ee5d164a07483c21600ff5a839f7e369'
env=dict(os.environ,TMPDIR=str(R/'.scratch/tmp'))
cases=[
 ('omit-land-upper','||p.borders.length>4','','refuses more than four land neighbours'),
 ('omit-combined-upper','||p.borders.length+lanes>5','','refuses four land neighbours plus two lanes'),
 ('omit-lanes-upper','||lanes>2','','refuses more than two reserved lanes'),
 ('land>5','p.borders.length>4','p.borders.length>5','refuses more than four land neighbours'),
 ('combined>6','p.borders.length+lanes>5','p.borders.length+lanes>6','refuses four land neighbours plus two lanes'),
 ('lanes>3','||lanes>2','||lanes>3','refuses more than two reserved lanes'),
 ('lower<1','p.borders.length<2','p.borders.length<1','insufficient country degree'),
 ('omit-all-three','||p.borders.length>4||p.borders.length+lanes>5||lanes>2','','refuses'),
]
res=[]
try:
    for label,a,b,t in cases:
        a=a.encode();b=b.encode(); assert orig.count(a)==1,(label,orig.count(a))
        try:
            core.write_bytes(orig.replace(a,b))
            p=subprocess.run(['npx','vitest','run','tests/core/island-geography.test.ts','-t',t],cwd=R,capture_output=True,text=True,env=env)
            out=p.stdout+p.stderr
            (R/f'.scratch/mut-{label}.txt').write_text(out)
            import re
            m=re.findall(r'Tests\s+([^\n]+)',out)
            res.append((label,p.returncode,m[-1] if m else None))
            print(res[-1],flush=True)
        finally:
            core.write_bytes(orig)
        assert core.read_bytes()==orig
finally:
    core.write_bytes(orig)
    assert sha(core.read_bytes())==sha(orig)
    saved.unlink()
print('restored',sha(core.read_bytes()))
