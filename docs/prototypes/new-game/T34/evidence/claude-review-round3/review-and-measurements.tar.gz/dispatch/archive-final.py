"""Retain the completed Claude follow-up without altering originals."""
from pathlib import Path
import hashlib, json, subprocess, tarfile

ROOT = Path('/home/diego/projects/malpaco')
TREE = ROOT / '.cache/t34-claude-review/150-review-d31cffda'
SOURCE = ROOT / '.cache/review-evidence/pr150-6902a91f6ab9'
OUT = ROOT / '.cache/t34-work/docs/prototypes/new-game/T34/evidence/claude-review-round3'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

assert (SOURCE / 'receipt.json').is_file(), 'Review must finish first'
assert (SOURCE / 'final.md').is_file(), 'Read full final before retaining'
OUT.mkdir(exist_ok=False)
tracked = set(subprocess.check_output(['git', 'ls-files'], cwd=TREE, text=True).splitlines())
files = {}
for p in SOURCE.rglob('*'):
    if p.is_file() and not p.is_symlink():
        files['harness/' + str(p.relative_to(SOURCE))] = p
for parent in [TREE / '.scratch', TREE / 'docs/prototypes/new-game/T34/evidence']:
    for p in parent.rglob('*'):
        if p.is_file() and not p.is_symlink() and str(p.relative_to(TREE)) not in tracked:
            files['review-worktree/' + str(p.relative_to(TREE))] = p
for name in ['review-final.md', 'final-review-decision.md', 'review-final.log', 'archive-final.py', 'make-coverage-packets.py']:
    files['dispatch/' + name] = ROOT / '.cache/t34-dispatch' / name
for p in (ROOT / '.cache/t34-dispatch/coverage').rglob('*'):
    if p.is_file():
        files['dispatch/coverage/' + str(p.relative_to(ROOT / '.cache/t34-dispatch/coverage'))] = p
hashes = {name: sha(p) for name, p in files.items()}
archive = OUT / 'review-and-measurements.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=1) as t:
    for name, p in sorted(files.items()):
        t.add(p, arcname=name, recursive=False)
with tarfile.open(archive) as t:
    actual = {m.name: hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}
assert actual == hashes
(OUT / 'archive-manifest.json').write_text(json.dumps({
    'archive': archive.name, 'sha256': sha(archive), 'members': hashes,
    'originalsPreserved': True,
}, indent=2) + '\n')
for name in ['final.md', 'receipt.json', 'inventory.json']:
    (OUT / name).write_bytes((SOURCE / name).read_bytes())
print(json.dumps({'output': str(OUT), 'members': len(hashes), 'archiveBytes': archive.stat().st_size}))
