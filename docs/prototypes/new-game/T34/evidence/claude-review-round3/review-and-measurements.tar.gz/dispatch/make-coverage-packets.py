"""Prepare bounded, lossless code-reading packets for the next independent review."""
from pathlib import Path
import hashlib, json, subprocess

ROOT = Path('/home/diego/projects/malpaco')
TREE = ROOT / '.cache/t34-work'
OUT = ROOT / '.cache/t34-dispatch/coverage'
OUT.mkdir(exist_ok=False)
base = subprocess.check_output(['git', 'merge-base', 'origin/main', 'HEAD'], cwd=TREE, text=True).strip()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=TREE, text=True).strip()
paths = subprocess.check_output(['git', 'diff', '--name-only', base, head], cwd=TREE, text=True).splitlines()
generated = {'.json', '.jsonl', '.txt', '.log', '.md', '.png', '.jpg', '.jpeg', '.gif', '.webp', '.gz', '.zip', '.pdf'}
required = [p for p in paths if Path(p).suffix.lower() not in generated]
groups = {}
for name in required:
    data = (TREE / name).read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    groups.setdefault(digest, {'sha256': digest, 'bytes': len(data), 'paths': []})['paths'].append(name)
packets, pending = [], ''
html = []
for group in groups.values():
    name = group['paths'][0]
    if Path(name).suffix.lower() == '.html':
        html.append(group)
        continue
    data = (TREE / name).read_text()
    # Numbered JSON string fragments preserve every character, including line
    # endings. No source line exceeds Read's display-column limit in a packet.
    fragments = []
    restored = []
    for line_no, line in enumerate(data.splitlines(keepends=True), 1):
        for offset in range(0, len(line), 600):
            part = line[offset:offset + 600]
            fragments.append(f'L{line_no:06} C{offset + 1:06}: ' + json.dumps(part, ensure_ascii=False))
            restored.append(part)
    assert ''.join(restored) == data, name
    block = '\n## SHA256 ' + group['sha256'] + '\nIdentical paths (verify equivalence yourself):\n' + '\n'.join(group['paths']) + '\n\n```text\n' + '\n'.join(fragments) + '\n```\n'
    assert len(block) < 45000, name
    if len(pending) + len(block) > 45000:
        packets.append(pending)
        pending = ''
    pending += block
if pending:
    packets.append(pending)
for i, content in enumerate(packets, 1):
    (OUT / f'packet-{i:02}.md').write_text(content)
manifest = {'baseSha': base, 'headSha': head, 'requiredFilePaths': required, 'groups': list(groups.values()), 'html': html,
            'packets': {f'packet-{i:02}.md': hashlib.sha256(content.encode()).hexdigest() for i, content in enumerate(packets, 1)}}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(OUT / 'README.md').write_text('Independent coverage aid, not a replacement for source verification. Read all packets before tests. Verify each SHA against your own worktree, including every alias. L/C markers number source line and character offset; each following JSON string is a full fragment, with escapes preserving line endings. Concatenating decoded strings recovers exact source text. This avoids Read silently truncating long dense lines; no character is omitted. One read covers only proven byte-identical aliases. Historical scripts are inert: inspect without executing. HTML is separately listed: parse the entire file to inspect active markup, script/event/URL/style content and asset dependencies; generated numeric SVG geometry can be checked structurally and against its renderer/evidence, with the gallery image viewed. Do not pretend to read coordinate literals as program logic. Account for every required path with a standalone FILE line only after inspection/equivalence. Also read full changed RUN-NOTES diff and docs/spike diff, task contract, README, CONTRACT and provenance. Full previous reviews are supplied separately; unchanged earlier findings need no repeated investigation. If incomplete, say so.\n')
print(json.dumps({'head': head, 'paths': len(required), 'uniqueContents': len(groups), 'packets': len(packets), 'html': len(html)}))
