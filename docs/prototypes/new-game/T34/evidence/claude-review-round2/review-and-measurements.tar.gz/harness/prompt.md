T34 review (Claude Sonnet Medium)
You review PR #150 at d59e33fd5e4d3e759fdc82cceeb0945305644d61. You did not write it. The task file follows.
0. Prove the tree: HEAD is d59e33fd5e4d3e759fdc82cceeb0945305644d61 and the diff against origin/main is the PR's; findings name its files.
1. Re-run every Done-when line yourself, and account for each (L32). The PR's evidence is no proof.
2. [evidence-driven] Every constant traces to a fixture, report or investigation; a [designed] one says what was searched.
3. [seeded] No wall clock, unseeded random or order-dependent iteration in rule code.
4. Every changed file and behaviour is one the task asks for (L44); docs it makes wrong are updated.
5. Sweep the diff: tests that pass with the behaviour deleted (mutate, rebuild clean, re-take any
   negative result), branches no input reaches, edge comments without a test, integer geometry, valid exported successes, retry histories, bounded exhaustion, real shape/layout diversity and save compatibility.
   Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
   restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
   a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
   copy inside your worktree (`<file>.saved`, deleted afterwards) or in a `mktemp -d` folder under
   `/tmp`, never as a loose file elsewhere.
6. Apply the following review criteria.
## Blocking means

Any one is enough; a blocking finding means rework, never approve.
1. A Done-when line fails, or cannot be run as written.
2. What this task protects can be got past: valid deterministic partial geography, unchanged T24/T62 constraints, bounded retry/history and nontrivial independent shape/layout variation. A bypass you proved is blocking, even when it
   looks like an edge case. Never "follow-up hardening" or "outside the threat model" unless the
   task says so; if it does, quote the line. (L47)
3. Behaviour the task forbids, or behaviour nobody asked for, inside a file the task requires. (L44)
4. uncited constants, acceptance surviving deletion of protected behavior, impure rule code or weakened assertions
Not blocking: wording, style, and defects in code the PR did not change: file those as follow-ups.
When unsure, say how likely the problem is. Rate it blocking only if it is likely and would get
past what the task protects; otherwise it is a follow-up. (L53)

## Report every blocking finding in this one review

This review is your only pass before the author fixes. Do not stop at the first blocking
finding: finish reading the whole diff and the task file, check every Done-when line and
every item under "Blocking means", and report all blocking findings together.

- Before you write the verdict, make one last pass over the full diff for anything you have
  not yet rated, and say "Final pass done" as the last line before the verdict.
- Number the findings R1, R2, … in order of severity. A finding you held back because an
  earlier one was already blocking is a review defect: if two problems share a cause, list
  both and say so.
- Do not rely on a later round. The author fixes everything you list, and the next review
  checks those fixes and new code only, not anything you saw but did not report.
- If you ran out of time or context before covering the whole diff, say which files or
  sections you did not cover. Do not approve in that case.

Prove each finding (run it, or delete the behaviour and name the test that fails) or label it
unverified. Your final message is the review: the header; the verdict (approve | approve after
named fixes | rework | user decision); per Done-when line `DW<k>: ran <command> → <result>` or
`DW<k>: not run — <reason>`; the findings R1..Rn (file:line, blocking or not); the verdict again
last. Never post it: the script posts it and applies the label.

# T34 Seeded island silhouettes and province subdivisions

- **Kind**: slice
- **Issue**: #79 · **Branch**: `task/T34-seeded-island-silhouettes-and-province-subdivisions` · **Merge after**: T33, T24, T62, T63.
- **Difficulty**: Very hard; estimate, not a model assignment.
- **Implementer**: owner-selected under rule 6; use an isolated worktree and record the choice before dispatch.
- **Reviewer**: owner-selected OpenCode model of another family under rule 6; record the choice before review.
- **Evidence**: [pinned core-rules design](https://github.com/diegoami/isle-wars-archaeology/blob/ae298e37c2f5177039e55767607f9345b6cb0e7a/design/core-rules.md), owner roadmap accepted 2026-10-15, and upstream task evidence. T23 resolves source anchors; new constants need citations or explicit [designed] provenance.
- **Owns**: src/core/**; tests/core/**; docs/prototypes/new-game/T34/**; docs/spike.md; append-only RUN-NOTES.md.
- **Scope**: Build seeded geography using the owner-selected A construction direction and T62 coast-entry contract alongside unchanged T24 structural limits. Jointly reserve entrance-country coast opportunities, island placement/orientation, water corridors and real label space; do not freeze arbitrary subdivisions before considering links. Derive land adjacency from positive shared boundaries. Rules never read positions. Export partial geography and entrance reservations for T35 inspection, never incomplete playable boards. Start with retained feasible witnesses and preserve failures; a single reference does not prove generality. Owner decision of 2026-10-17 requires broader island shapes and layouts before proceeding: subpixel perturbations and whole-board reflections of one witness do not suffice. Preserve the approved geographic visual direction and unchanged numeric constraints while measuring independent silhouette and placement variation.
- **Done when**:
  1. `npx vitest run tests/core/island-geography.test.ts` — prescribed island sizes, connected valid cells, no interior overlaps/gaps, symmetric shared-boundary adjacency and contract land-degree headroom hold for all exported successes. Exercise rejected candidates, retry history and bounded exhaustion with real failure records; omission of failure recording must fail acceptance. A retained seeds0..31 corpus must place the10-country island both within the middle vertical third and outside it (invariant under whole-board reflections), and vary at least one island's bounding-box aspect ratio by5% or more. These [designed] breadth measurements operationalize the owner's broader-layout decision; numeric play/display constraints remain unchanged.
  2. `node docs/prototypes/new-game/T34/sweep.mjs` — enumerate seeds 0..99 with fixed bounded attempts; report valid subdivisions/100, per-constraint failures and replay hashes against the approved T24 budget, with no discarded failures. Retain a seed gallery and shape/layout diversity measurements that factor out whole-board reflection and incidental fixed-point jitter.
  3. `npm test` and `npm run build` pass; affected pinned browser suites pass without weakening existing assertions. Retain measured outputs, screenshots where applicable, commands and hashes in the owned evidence path; report negative-before/positive-after checks and exact restoration.
- **Hazards**: Run the feasibility smoke before algorithm changes. If the approved target is unreachable, stop; do not relax degree, label or shape constraints. Main session preflights acceptance before dispatch; unresolved design conflicts stop implementation, never weaken a Done-when.


This is the owner-requested broadened T34 rework. Earlier narrow-layout approval is superseded. Review whole current PR, with particular attention to changed implementation, seed0..31 breadth acceptance and unchanged independent T24/T62 oracle. Current game/default remain fixed reference; T35 completes boards and T36 integrates UI. Partial geography is intentional. Historical failed probes are evidence, not present behavior. Account for runtime/scripts individually via FILE lines; group generated-data evidence only as permitted by launcher. Re-run the affected pinned browser wrapper (instructions in T34 README/run-browser.py). Use project/evidence-local TMPDIR, not global /tmp. Do not launch historical model/benchmark dispatchers. Existing retained review full findings: PR150comment6233951448.

Out of your depth: stop and hand back, with an ESCALATE block, when any of these happens:
two hypotheses for the same question have failed; you would rely on bytes, code or behaviour
you cannot explain; you are about to write a claim you cannot back with evidence; or you have
made three attempts at one step without progress. Push your branch first. The ESCALATE block
gives what you tried, the evidence so far, and the exact question you could not answer. Never
guess a format or a cause.


Focused rework round2. Full round1 review follows below, at https://github.com/diegoami/malpaco/pull/150#issuecomment-6238034015 . It requested test coverage rework and explicitly incomplete historical-file coverage; no approval exists. Check R1 fixes/new test behavior, narrow R2/R5 documentation, and all previously unread paths. Do not repeat already completed adversarial investigations of unchanged runtime (layout/warp/history etc). Verify core bytes unchanged relative to previous reviewed commit a842967717584549e58b10d37869c1fe4dd461d6. Main retained round1 complete transcript/measurements under evidence/claude-review-round1 before rework.

Coverage efficiency without overstating it: file-inventory.json enumerates every changed executable path. Many frozen T24/T62 copies are byte-identical to live files you already inspected; prove those equivalences once, inspect their common source, then account for each identical copy explicitly. Read remaining historical probes fully in bounded batches; prior40line previews were not full coverage. Old review-tools snapshots are inert historical evidence; do not execute them. Audit grouped generated evidence using artifacts.json hashes and verify-evidence.py archive/source/member checks, plus applicable reports/receipts; do not read megabytes of JSON line-by-line. All original measurements remain preserved. Main already verified previous952artifacthashes/75inventoryhashes, but rerun current verification yourself.

Output syntax matters: each FILE line must be exactly FILE: path (no bullet, suffix or comment). EVIDENCE group line must end with slash and contain only the prefix, exactly:
```text
EVIDENCE: docs/prototypes/new-game/T34/
``` This can cover generated JSON/text/images/archives; it cannot cover code or HTML. Emit all current executable FILE acknowledgments, plus RUN-NOTES.md/docs/spike.md. State SCOPE: complete only after all previously covered unchanged files, fixes and unread files are accounted for. Never copy acknowledgments without reading/byte-equivalence verification. If incomplete say so and do not approve.

Required fresh checks: focused acceptance;100seed sweep; npmtest/build; affected pinned browser wrapper (see README). Root/main preserves CI gate; no CI or publishing by you. Restore mutation originals exactly; store all scratch inside your retained worktree, never /tmp/x or any shared path. Use only current r3-controls for newcoverage if that command is documented; do not execute historical trial/dispatch/control helpers.

Full previous findings:
T34 review (Claude Sonnet High)
rework
DW1: ran `npx vitest run tests/core/island-geography.test.ts` → 14/14 passed (37.9 s). The seeds0..31 corpus puts the 10-country island in the middle third and outside it. At least one island's aspect ratio varies by 5% or more. Mutating the source to drop layout, warp or failure recording fails the matching tests (details under R1).
DW2: ran `node docs/prototypes/new-game/T34/sweep.mjs` → 100/100 valid, `targetMet:true`. Output is `evidence/sweep-AHN9CY`.
- Replay hashes are identical, with 100 geometry hashes and 4 land graphs.
- The largest island sits in the middle third in 38 seeds and outside it in 62.
- Failure counts: labels 926, attachment 584, water 120, degree 41, traceability 11.
- Every seed's result and failures are retained; none are discarded.
- Per-island aspect max/min runs from 1.215 to 1.401, matching the receipt.
DW3: ran `npm test` → 607 Vitest passed plus 6 harness tests, exit 0. Ran `npm run build` → exit 0. Ran `python3 docs/prototypes/new-game/T34/run-browser.py reviewer-current --suites reference-complete-game,reference-game,versioned-match,entry` → 24 passed, exit 0, `sourcesUnchangedDuringRun:true` (`evidence/reviewer-current-4fnisiwu`). I did not re-run the author's negative-before/positive-after record. I ran my own source mutations, and every mutation was restored byte-exact (`git diff` is empty).

Where I worked
- Worktree HEAD is a842967717584549e58b10d37869c1fe4dd461d6. The diff against base 7ce8911 is 957 files, of which only 4 are outside T34: `RUN-NOTES.md`, `docs/spike.md`, `src/core/island-geography.ts` and `tests/core/island-geography.test.ts`. T24 and T62 are untouched. All 40 frozen T24/T62 copies under `evidence/feasibility-*/sources` are byte-equal to the live files.
- `prepare-witness.mjs` reproduces `witness.json` byte-exactly from T64/board.json, whose sha256 matches `witness-provenance.json`.
- I ran seeds 100..699 through the independent oracle (scratch script `.scratch/wide.mjs`). 599 were valid, 0 exports were invalid, and seed 398 exhausted (the maximum was 44 attempts). Together with seeds 0..99 that is 699 valid out of 700.
- The rule code has no clock, no random source and no order-dependent iteration. `rng.shuffled` and Map/Set insertion order are deterministic.

Findings

**R1 — BLOCKING** (`src/core/island-geography.ts:181,185,189,192,199,249`; `tests/core/island-geography.test.ts`). Acceptance survives deleting protected behaviour. I mutated the real source and ran the real acceptance commands.

| Guard removed | Line | Result |
|---|---|---|
| The three `cells:` guards (non-simple polygon, outside frame, island touch/overlap) | 189, 199 | DW1: 14/14 pass. DW2 sweep with these plus the next two guards removed: `targetMet:true`, 100/100. |
| `crossings: duplicate reserved country pair` | 181 | Same as above. |
| `crossings: insufficient bonus headroom` | 185 | Same as above. |
| The `degree:` guard (`borders<2`, `borders>4`, `+lanes>5`, `lanes>2`) | 192 | DW1 passes 14/14 and the DW2 sweep passes 100/100 (`evidence/sweep-2CjENm`). The 41 degree rejections in the real sweep all co-occur with other failure classes. |
| `Math.max(0,…)` in the budget clamp | 249 | DW1: 14/14 pass. A negative budget would return a negative `attempts`. |
| `Math.floor(raw)` in the budget clamp | 249 | DW1: 14/14 pass. A fractional budget would return a fractional `attempts`. |

- **What is missing:** no input in 700 seeds ever triggers the `cells:`, duplicate-pair or bonus-headroom branches, and no mocked witness exercises them. The task protects "connected valid cells, no interior overlaps/gaps", unique crossings, land-degree headroom and bounded exhaustion.
- **Why it matters:** the only thing that currently catches these is the oracle, and only if the constructor ever exports such a result. The constructor's own refusal of those candidates is unprotected.
- **Fix:** add a mocked-witness test per guard, in the style of the existing fortress test at `tests/core/island-geography.test.ts:83`. Each test should assert the exact constraint string in the failure records. Also test negative and fractional budgets.
- **Protected, for the record:** these mutations were caught.
  - Omitting layout fails the middle-third test.
  - Omitting warp fails the aspect test.
  - Omitting the failure push fails 10 tests.
  - Omitting flip fails the topology test.
  - Omitting the label-hit guard fails 3 tests.
  - Omitting the fortress/concentration guards fails the mock test.
  - Omitting the water/attachment corridor guards fails 6 tests.
  - Restricting layout to plans 0 and 1 fails the middle-third test, so plan 2 is required.

**R2 — non-blocking (follow-up)**
- `family-provenance.json` and CONTRACT.md name the [designed] plan translations (306/−303, 26/155, −75/−167) but say only "reviewed T24/T62/T63 and T64/T65 geometry studies". They do not say what was searched. The in-code comment "Approved 14-route plan" (`src/core/island-geography.ts:242`) names no approver. The 48px, 24px and three-pass values do trace to retained probes (`breadth-amplitude-m02i9_al`, `breadth-joint-r8ghb3fn`).
- Likelihood is moderate that the owner wants the search described, but the numbers are retained and traceable.

**R3 — non-blocking (owner judgement).**
- The gallery PNG (`family-gallery-pi361ktz`) shows the same nine silhouettes and internal seams. They are stretched, moved between two swapped slots, and flipped once per island. The seed-3, 6 and 10 boards look near-identical.
- The Done-when measures pass literally, and per-island aspect ratios are only weakly correlated (median −0.11 across 100 seeds), so this is not one global stretch.
- The PR says it is not owner visual approval. The owner should judge whether this meets "broader shapes".

**R4 — non-blocking.**
- `src/core/island-geography.ts:22` imports `docs/prototypes/new-game/T34/witness.json`. Production core depends on a prototype docs path. It is allowed under Owns, but pruning docs breaks core.

**R5 — non-blocking.**
- `review-tools/retention-runner.mjs` (15.8 KB) is a modified copy of `tools/harness/review.mjs`. It imports `./lib/*`, which is absent, so it cannot run. It also contains `git worktree remove --force` and `fs.rmSync` on a T34-specific path. `review-tools/reviewer150.md` is an agent definition copy. The task did not ask for either, and I suggest dropping them or labelling them inert.
- `evidence/breadth-joint-r8ghb3fn/gallery-metrics.py` hard-codes `/home/diego/projects/malpaco/.cache/t34-work` paths.
- Several RUN-NOTES.md entries have their spaces stripped, for example "keepsmapgenerationbeforecards". The file is append-only as required.

**R6 — informational.**
- The sweep's target-met gate holds, but seed 398 exhausts 50 attempts. That is 1 in 700 seeds, which is within the T24 99% target.

Coverage
FILE: src/core/island-geography.ts
FILE: tests/core/island-geography.test.ts
FILE: RUN-NOTES.md
FILE: docs/spike.md
FILE: docs/prototypes/new-game/T34/acceptance.mjs
FILE: docs/prototypes/new-game/T34/sweep.mjs
FILE: docs/prototypes/new-game/T34/run-browser.py
FILE: docs/prototypes/new-game/T34/run-command.py
FILE: docs/prototypes/new-game/T34/r2-controls.py
FILE: docs/prototypes/new-game/T34/r1-controls.py
FILE: docs/prototypes/new-game/T34/r2-final.py
FILE: docs/prototypes/new-game/T34/r2-preflight.py
FILE: docs/prototypes/new-game/T34/controls.py
FILE: docs/prototypes/new-game/T34/preflight.py
FILE: docs/prototypes/new-game/T34/full-preflight.py
FILE: docs/prototypes/new-game/T34/prepare-witness.mjs
FILE: docs/prototypes/new-game/T34/verify-evidence.py
FILE: docs/prototypes/new-game/T34/archive-captures.py
FILE: docs/prototypes/new-game/T34/archive-evidence.py
FILE: docs/prototypes/new-game/T34/family-smoke.mjs
FILE: docs/prototypes/new-game/T34/family-smoke.py
FILE: docs/prototypes/new-game/T34/family-gallery.py
FILE: docs/prototypes/new-game/T34/feasibility-smoke.mjs
FILE: docs/prototypes/new-game/T34/feasibility-wide.mjs
FILE: docs/prototypes/new-game/T34/flip-probe.mjs
FILE: docs/prototypes/new-game/T34/CONTRACT.md
FILE: docs/prototypes/new-game/T34/README.md
FILE: docs/prototypes/new-game/T34/witness-provenance.json
FILE: docs/prototypes/new-game/T34/family-provenance.json
FILE: docs/prototypes/new-game/T34/witness.json
FILE: docs/prototypes/new-game/T34/family-candidate.ts

I read `family-candidate.ts` only as a diff against the installed core. I read `RUN-NOTES.md` with lines cut at 900 characters.

EVIDENCE: docs/prototypes/new-game/T34/evidence/sweep-AHN9CY/ (fresh run, plus my own mutation sweeps in `sweep-GwTA7u` and `sweep-2CjENm`)
EVIDENCE: docs/prototypes/new-game/T34/evidence/reviewer-current-4fnisiwu/
EVIDENCE: docs/prototypes/new-game/T34/evidence/family-gallery-pi361ktz/ (PNG viewed)
EVIDENCE: docs/prototypes/new-game/T34/evidence/feasibility-QiwWlL/ and feasibility-zjVwJN/ (frozen T24/T62 copies compared byte-equal to live; `flip-probe-Tg7Pmr/flip-probe.mjs` is byte-equal to `flip-probe.mjs`)

SCOPE: incomplete
UNCOVERED:
- `docs/prototypes/new-game/T34/candidate.ts`: historical first-family copy, only grepped for Date/Math.random.
- `docs/prototypes/new-game/T34/review-tools/retention-runner.mjs` and `reviewer150.md`: read in part only.
- The scripts under `evidence/breadth-amplitude-m02i9_al`, `evidence/breadth-joint-r8ghb3fn` and `evidence/clock-fix-49d9ipkk`: first about 40 lines at 260 columns only.
- The 749 `evidence/` files, 172 `preflight/` files, `artifacts.json` and `file-inventory.json`: not individually audited. I checked only that the inventory's 75 paths match the changed executable files exactly.

Final pass done
rework

---
OUTPUT RULES (from tools/harness/review.mjs; they override anything above that conflicts):
- Do not post to GitHub, commit, push, label or merge anything. The script posts your review.
  Edit nothing, but for a mutation made in place in your worktree and never committed.
  Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
  restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
  a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
  copy inside your worktree (`<file>.saved`, deleted afterwards) or in your own folder under
  `/tmp/opencode/`. Outside your worktree, write only under `/tmp/opencode/` (a
  `mktemp -d /tmp/opencode/mlp-review-XXXXXX` folder is the tidiest, removed afterwards; the reviewer
  agent file allows nothing else). Every other path outside your worktree is forbidden.
- Your final message is the review and nothing else. Line 1 is exactly: T34 review (Claude Sonnet Medium)
  Line 2 is the verdict, alone on its line: approve, approve after named fixes, rework, or user
  decision. Then any where-I-worked lines (worktree, HEAD, diff, the commands you ran), then the
  findings (R1, R2, ... with file and line, blocking or not), then the verdict again as the very
  last line. Nothing comes after it.
- A finding you proved that lets a forbidden action or a wrong result past what the task protects
  is blocking, and blocks an approve: never "follow-up hardening" or "outside the threat model"
  unless the task's text says so (L47).
- Report every blocking finding in this one review, not one per round: read the whole diff, then
  make a final pass and write "Final pass done" as the line before the closing verdict. Name any
  part you did not cover, and do not approve then (L49).
- The task has 3 Done-when lines. Right after the verdict line, account for each, one
  line per Done-when line, DW1 to DW3: "DW<k>: ran <command> → <result>", or
  "DW<k>: not run — <reason>". An approve with one missing, or one not run, is not applied. A review that does not end with its verdict, or that has a
  finding after it, is posted flagged and acted on by no one until the main session reads it.
- Your worktree is /home/diego/projects/malpaco/.cache/t34-claude-review/150-review-685d1432 at d59e33fd5e4d3e759fdc82cceeb0945305644d61, and it is already your working directory. Run git
  there without -C, and never type that path: a mistyped path ends the run. This rule is about
  your own worktree only (L61): a Done-when line may send git at a pinned repository outside it
  (git -C <path> show <pin>:<file>); run that exactly as written — OpenCode does not path-check
  git -C — and read a granted outside path only with the L59 recipe.

CLAUDE BACKEND CONTRACT: The exact PR base is 7ce8911a20beb6c096186b93af0737966c1b8f4a, head d59e33fd5e4d3e759fdc82cceeb0945305644d61. Do not use origin/main for a merged PR. Complete local diff: /home/diego/projects/malpaco/.cache/review-evidence/pr150-be95c9b9cefd/full.diff; bounded parts: /home/diego/projects/malpaco/.cache/review-evidence/pr150-be95c9b9cefd/diff-parts; full changed-file inventory: /home/diego/projects/malpaco/.cache/review-evidence/pr150-be95c9b9cefd/inventory.json. Read all executable changes. For generated evidence you may audit a group explicitly. Never claim a file you did not inspect. Before Final pass done, emit SCOPE: complete only if you covered all changes; otherwise SCOPE: incomplete plus UNCOVERED: paths/reasons. Emit FILE: <exact path> for each changed file inspected; EVIDENCE: <docs/prototypes/.../ prefix> may account for generated evidence only, never executable scripts. These are coverage claims, not independent proof. Every Done-when must be run; include exact DW lines. A missing scope acknowledgment prevents approval. No subagents or GitHub writes. Native Claude permission denials mirror OpenCode publishing restrictions; the trusted hook protects credential paths for Read/Grep/Glob. Bash is granted for tests and in-tree mutations. These are mistake safeguards, not an OS sandbox. Preserve scratch/evidence; do not clean up. Ignore obsolete OpenCode-only path restrictions above: your scratch is your retained worktree. No blanket permission bypass.

The read-only contract overrides the tripwire instruction to push: never push.
Out of your depth: stop and hand back, with an ESCALATE block, when any of these happens:
two hypotheses for the same question have failed; you would rely on bytes, code or behaviour
you cannot explain; you are about to write a claim you cannot back with evidence; or you have
made three attempts at one step without progress. Push your branch first. The ESCALATE block
gives what you tried, the evidence so far, and the exact question you could not answer. Never
guess a format or a cause.
