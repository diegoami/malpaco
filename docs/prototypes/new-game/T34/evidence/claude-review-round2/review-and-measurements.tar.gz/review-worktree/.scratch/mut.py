import subprocess,sys,os
f='src/core/island-geography.ts'
orig=open(f).read()
open(f+'.saved','w').write(orig)
muts={
'nonsimple':('if(!simple(land.polygon))fail.add("cells: non-simple polygon");',''),
'outside':('if(x<0||x>g.bounds.width||y<0||y>g.bounds.height)fail.add("cells: outside frame");','void 0;'),
'overlap':('fail.add("cells: islands touch/overlap");','void 0;'),
'dup':('if(pairs.has(pair))fail.add("crossings: duplicate reserved country pair");',''),
'bonus':('if(bonus>island.provinces.length)fail.add("crossings: insufficient bonus headroom");',''),
'deg_lt2':('p.borders.length<2||',''),
'deg_gt4':('||p.borders.length>4',''),
'deg_lanes5':('||p.borders.length+lanes>5',''),
'deg_lanes2':('||lanes>2',''),
'max0':('Math.max(0,Math.min(MAX_ATTEMPTS,Math.floor(raw)))','Math.min(MAX_ATTEMPTS,Math.floor(raw))'),
'floor':('Math.floor(raw)','raw'),
'cap':('Math.min(MAX_ATTEMPTS,','Math.min(1e9,'),
}
sel=sys.argv[1:] or list(muts)
try:
 for k in sel:
  a,b=muts[k]; assert orig.count(a)==1,(k,orig.count(a))
  open(f,'w').write(orig.replace(a,b))
  r=subprocess.run(['npx','vitest','run','tests/core/island-geography.test.ts'],capture_output=True,text=True)
  tail=[l for l in (r.stdout+r.stderr).splitlines() if 'Tests ' in l or 'FAIL' in l]
  print(k,'exit',r.returncode,tail[:4],flush=True)
finally:
 open(f,'w').write(orig)
