import subprocess
f='src/core/island-geography.ts'
orig=open(f).read();open(f+'.saved','w').write(orig)
try:
 s=orig.replace('||p.borders.length>4','').replace('||p.borders.length+lanes>5','').replace('||lanes>2','')
 assert s!=orig;open(f,'w').write(s)
 r=subprocess.run(['node','docs/prototypes/new-game/T34/sweep.mjs'],capture_output=True,text=True)
 print(r.returncode,r.stdout[-700:])
finally:
 open(f,'w').write(orig)
