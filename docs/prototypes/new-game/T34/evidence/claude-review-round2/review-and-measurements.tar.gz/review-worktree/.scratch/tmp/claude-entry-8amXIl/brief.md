T69 review (Claude)
You review PR #1 at d75ce6daf19e01c4891d110b06e084bdff4ba7fb.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
