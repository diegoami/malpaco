# Seeded island geography

`src/core/island-geography.ts` exports deterministic partial geography and entrance reservations. It adds no playable board, rule, save format or UI entry. Read [CONTRACT.md](CONTRACT.md) for the construction, unchanged constraints, designed sampling choices and limits of the witness-based family.

```sh
npx vitest run tests/core/island-geography.test.ts
node docs/prototypes/new-game/T34/sweep.mjs
npm test
npm run build
python3 docs/prototypes/new-game/T34/run-browser.py compatibility --suites tests/e2e/reference-complete-game.spec.ts,tests/e2e/reference-game.spec.ts,tests/e2e/versioned-match.spec.ts,tests/e2e/entry.spec.ts
python3 docs/prototypes/new-game/T34/controls.py
```

Use Node24, or Node22.15+ for the prototype TypeScript loader hooks. Every command wrapper writes a fresh owned directory with source hashes, exact source inputs and raw output archives. The sweep retains all100 outcomes, rejected candidates, constraint classes and replay hashes. Large raw seed/source sets are archived byte-exact with member hashes; loose originals remain local and are ignored rather than deleted.

The independent parent suite was locked before installation. The absent stub produces9 new-unit failures and0/100 sweep successes. Disposable positive `evidence/mock-preflight-8qho8jkt` and `evidence/sweep-t4EQcS` establish10 new tests and100/100 seeds with100 geometry hashes/four land topologies, identical replay and stable sources. `evidence/full-preflight-j1cgax17` adds603 units/build/24 pinned browser passes with exact stub restoration. The production module is byte-identical to that proven candidate.

`evidence/feasibility-zjVwJN` and `evidence/feasibility-QiwWlL` preserve the earlier6/100-seed unchanged-reference-constructor diagnostics. They vary drawing on one graph and are distinct from the new four-topology construction. `evidence/flip-probe-Tg7Pmr` preserves accepted and failed local exchanges. Broad placement failures and the unrepaired77/100 sweep remain, including an explicit source-drift note after a test assertion was added mid-run; that run is not the stable final acceptance.

A blocking one-line T33 test fix (#151, rule12) initializes its fake clock before the fixed pause timestamp. Both old cases failed after host time passed the pause; all809 actions, state assertions, fixture and timing limits remain unchanged. First browser evidence omitted15 hashed task inputs from its archive; an exact-hash-matched supplemental archive preserves them, and the wrapper now archives the complete input dictionary.

`preflight.py`, `full-preflight.py` and `candidate.ts` preserve the parent’s disposable-preflight procedure against the historical stub commit. Use the commands above for ordinary validation after installation. T35 constructs complete boards; T36 measures1,000 seeds, integrates UI and requires owner visual judgment. Cards follow those map tasks under the owner’s explicit roadmap decision.
