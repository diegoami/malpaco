# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: reference-complete-game.spec.ts >> real human/computer setup, friendly move, pending save/resume, elimination and conquest
- Location: tests/e2e/reference-complete-game.spec.ts:26:1

# Error details

```
Error: clock.pauseAt: Error: Cannot fast-forward to the past
    at ClockController._innerFastForwardTo (eval at evaluate (:311:30), <anonymous>:201:13)
    at ClockController.pauseAt (eval at evaluate (:311:30), <anonymous>:132:16)
    at async <anonymous>:337:30
```