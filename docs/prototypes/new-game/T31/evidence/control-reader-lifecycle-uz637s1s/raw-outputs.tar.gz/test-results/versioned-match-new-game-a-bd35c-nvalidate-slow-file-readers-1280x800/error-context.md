# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: versioned-match.spec.ts >> new game and a successful later load invalidate slow file readers
- Location: tests/e2e/versioned-match.spec.ts:146:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

- Expected  -  2
+ Received  + 61

@@ -24,11 +24,70 @@
      "humanShare": 0,
      "computerStrengths": [],
      "eventFrequency": "Normal",
      "dominationWin": true,
      "roundLimit": null,
-     "seed": 42,
+     "seed": 0,
      "animationSpeed": "normal",
      "sound": true
    },
-   "actions": []
+   "actions": [
+     {
+       "kind": "reinforce",
+       "province": "province_8",
+       "amount": 1
+     },
+     {
+       "kind": "reinforce",
+       "province": "province_8",
+       "amount": 1
+     },
+     {
+       "kind": "reinforce",
+       "province": "province_8",
+       "amount": 1
+     },
+     {
+       "kind": "reinforce",
+       "province": "province_8",
+       "amount": 1
+     },
+     {
+       "kind": "reinforce",
+       "province": "province_8",
+       "amount": 1
+     },
+     {
+       "kind": "reinforce",
+       "province": "province_8",
+       "amount": 1
+     },
+     {
+       "kind": "reinforce",
+       "province": "province_8",
+       "amount": 1
+     },
+     {
+       "kind": "endReinforcement"
+     },
+     {
+       "kind": "attack",
+       "from": "province_8",
+       "to": "province_38"
+     },
+     {
+       "kind": "attack",
+       "from": "province_8",
+       "to": "province_38"
+     },
+     {
+       "kind": "attack",
+       "from": "province_8",
+       "to": "province_38"
+     },
+     {
+       "kind": "attack",
+       "from": "province_8",
+       "to": "province_38"
+     }
+   ]
  }
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 2 human seats · Seed 0
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]: 24 provinces · 50 armies
      - generic [ref=e16]:
        - generic [ref=e17]: Seat 2
        - generic [ref=e18]: 22 provinces · 45 armies
    - contentinfo [ref=e19]:
      - button "New game" [ref=e20] [cursor=pointer]
    - generic [ref=e21]:
      - button "Save game" [active] [ref=e22] [cursor=pointer]
      - generic [ref=e23]:
        - generic [ref=e24]: Load game
        - button "Load game" [ref=e25]
  - main [ref=e26]:
    - img "Nine Isles reference map" [ref=e28]:
      - button "River gate, Seat 1, 3 armies" [ref=e53] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: 1 · 3
      - button "New port, Seat 2, 2 armies" [ref=e55] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: 2 · 2
      - button "North rest, Seat 1, 5 armies" [pressed] [ref=e57] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: 1 · 5
      - button "River keep, Seat 1, 1 armies" [ref=e59] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: 1 · 1
      - button "North town, Seat 1, 2 armies" [ref=e61] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: 1 · 2
      - button "Dark ford, Seat 1, 3 armies" [ref=e63] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: 1 · 3
      - button "Iron point, Seat 2, 2 armies" [ref=e65] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: 2 · 2
      - button "South rest, Seat 2, 3 armies" [ref=e67] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: 2 · 3
      - button "High shore, Seat 1, 3 armies" [ref=e69] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: 1 · 3
      - button "Wind town, Seat 1, 3 armies" [ref=e71] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: 1 · 3
      - button "New glen, Seat 1, 1 armies" [ref=e73] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: 1 · 1
      - button "Old rock, Seat 2, 1 armies" [ref=e75] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: 2 · 1
      - button "Blue peak, Seat 2, 1 armies" [ref=e77] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: 2 · 1
      - button "West haven, Seat 1, 2 armies" [ref=e79] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: 1 · 2
      - button "Stone watch, Seat 2, 3 armies" [ref=e81] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: 2 · 3
      - button "Upper ridge, Seat 1, 2 armies" [ref=e83] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: 1 · 2
      - button "Marsh keep, Seat 2, 2 armies" [ref=e85] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: 2 · 2
      - button "New fell, Seat 1, 1 armies" [ref=e87] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: 1 · 1
      - button "Moon point, Seat 2, 2 armies" [ref=e89] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: 2 · 2
      - button "South fell, Seat 2, 3 armies" [ref=e91] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: 2 · 3
      - button "High ridge, Seat 2, 1 armies" [ref=e93] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: 2 · 1
        - generic [ref=e95]: ★
      - button "Bay ford, Seat 1, 3 armies" [ref=e96] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: 1 · 3
      - button "Low moor, Seat 2, 2 armies" [ref=e98] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: 2 · 2
      - button "Lower field, Seat 1, 1 armies" [ref=e100] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: 1 · 1
      - button "Wind gate, Seat 2, 2 armies" [ref=e102] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: 2 · 2
      - button "Silver shore, Seat 1, 2 armies" [ref=e104] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: 1 · 2
      - button "Low peak, Seat 1, 1 armies" [ref=e106] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: 1 · 1
      - button "Wind port, Seat 2, 3 armies" [ref=e108] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: 2 · 3
      - button "Gold point, Seat 2, 3 armies" [ref=e110] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: 2 · 3
      - button "Rock moor, Seat 1, 1 armies" [ref=e112] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: 1 · 1
      - button "Marsh rest, Seat 1, 3 armies" [ref=e114] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: 1 · 3
        - generic [ref=e116]: ★
      - button "Wind dale, Seat 1, 2 armies" [ref=e117] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: 1 · 2
      - button "Silver ford, Seat 1, 1 armies" [ref=e119] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: 1 · 1
      - button "Iron field, Seat 2, 3 armies" [ref=e121] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: 2 · 3
      - button "North wood, Seat 2, 1 armies" [ref=e123] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: 2 · 1
      - button "Fort town, Seat 1, 2 armies" [ref=e125] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: 1 · 2
      - button "Red field, Seat 2, 1 armies" [ref=e127] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: 2 · 1
      - button "South ridge, Seat 2, 3 armies" [ref=e129] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: 2 · 3
      - button "Rock bay, Seat 1, 2 armies" [ref=e131] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: 1 · 2
      - button "North ford, Seat 2, 1 armies" [ref=e133] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: 2 · 1
      - button "Port ridge, Seat 1, 3 armies" [ref=e135] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: 1 · 3
      - button "New rock, Seat 2, 3 armies" [ref=e137] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: 2 · 3
      - button "South reach, Seat 2, 1 armies" [ref=e139] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: 2 · 1
        - generic [ref=e141]: ★
      - button "Silver point, Seat 1, 1 armies" [ref=e142] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: 1 · 1
      - button "East ford, Seat 1, 2 armies" [ref=e144] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: 1 · 2
      - button "Gold town, Seat 2, 2 armies" [ref=e146] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: 2 · 2
      - generic [ref=e178]: North Isle +3
      - generic [ref=e179]: East Isle +3
      - generic [ref=e180]: West Isle +3
      - generic [ref=e181]: South Isle +3
      - generic [ref=e182]: Central Isle +5
      - generic [ref=e183]: Harbor Isle +5
      - generic [ref=e184]: Palm Isle +6
      - generic [ref=e185]: Cliff Isle +5
      - generic [ref=e186]: Great Isle +9
    - complementary [ref=e187]:
      - generic [ref=e191]:
        - generic [ref=e192]: Seat 1's turn
        - generic [ref=e193]: Round 1 · Capture move-in
      - generic [ref=e194]:
        - button "End turn" [disabled] [ref=e196]
        - region "Battle controls" [ref=e197]:
          - heading "Battle" [level=2] [ref=e198]
          - generic [ref=e199]:
            - generic [ref=e200]:
              - generic [ref=e201]: From
              - strong [ref=e202]: North rest
              - generic "Source armies" [ref=e203]: "5"
            - generic [ref=e204]:
              - generic [ref=e205]: Target
              - strong [ref=e206]: River keep
              - generic "Target armies" [ref=e207]: "1"
          - generic [ref=e208]:
            - generic [ref=e209]:
              - text: Stop at armies
              - spinbutton "Stop at armies" [disabled] [ref=e210]: "2"
            - generic [ref=e211]:
              - text: Battle speed
              - combobox "Battle speed" [ref=e212]:
                - option "Slow"
                - option "Normal" [selected]
                - option "Fast"
          - paragraph [ref=e213]: This battle stops at 1 army, or on capture.
          - generic [ref=e214]:
            - button "Fight on" [disabled] [ref=e215]
            - button "Stop" [disabled] [ref=e216]
            - button "Single exchange" [disabled] [ref=e217]
          - generic [ref=e218]:
            - strong [ref=e219]: Ready for your choice
            - paragraph [ref=e220]: Select countries on the map.
          - paragraph [ref=e221]:
            - text: Won 0 · Lost 0 · Ties
            - strong [ref=e222]: "0"
          - region "Capture move-in" [ref=e223]:
            - heading "Move armies into the capture" [level=3] [ref=e224]
            - paragraph [ref=e225]: Choose 1–5 total armies. Leave at least one behind.
            - generic [ref=e226]:
              - text: Armies to move
              - spinbutton "Armies to move" [ref=e227]: "5"
            - generic [ref=e228]:
              - button "Minimum" [ref=e229] [cursor=pointer]
              - button "Move one fewer army" [ref=e230] [cursor=pointer]: −
              - button "Move one more army" [ref=e231] [cursor=pointer]: +
              - button "Maximum" [ref=e232] [cursor=pointer]
            - button "Confirm move-in" [ref=e233] [cursor=pointer]
      - generic [ref=e234]:
        - heading "Battle log" [level=3] [ref=e235]
        - list "Battle log" [ref=e236]:
          - listitem [ref=e237]: "T1 Seat 1: North rest → River keep, took River keep"
          - listitem [ref=e238]: "T1 Seat 1: North rest → River keep, -1 / -0"
          - listitem [ref=e239]: "T1 Seat 1: North rest → River keep, -1 / -0"
          - listitem [ref=e240]: "T1 Seat 1: North rest → River keep, -1 / -0"
```

# Test source

```ts
  66  |   await page.getByLabel("Seed", { exact: true }).fill("42");
  67  |   await upload(page, text); await check(page, fixture);
  68  |   const action = fixture.next!.action;
  69  |   if (action.kind !== "reinforce") throw Error("Pinned placement must continue reinforcement");
  70  |   await country(page, action.province).click();
  71  |   expect(logicalState(decode(await download(page)))).toEqual(fixture.next!.expected);
  72  |   await paint(page, fixture.next!.expected); expect(errors).toEqual([]);
  73  | });
  74  | 
  75  | test("pending capture reload keeps the choice and rejects a detached old confirm", async ({ page }, info) => {
  76  |   const errors = errorsOn(page), fixture = pinned("pending-capture");
  77  |   await setup(page); await upload(page, fixture.text); const text = await check(page, fixture);
  78  |   const pending = fixture.expected["pendingCapture"] as { defaultAmount: number };
  79  |   await expect(page.locator("#capture-amount")).toHaveValue(String(pending.defaultAmount));
  80  |   const oldConfirm = await page.locator("#confirm-capture-button").elementHandle();
  81  |   await upload(page, text); await check(page, fixture);
  82  |   await oldConfirm!.evaluate(n => n.dispatchEvent(new MouseEvent("click", { bubbles: true })));
  83  |   await check(page, fixture); await capture(page, "pending-capture", info.project.name);
  84  |   await page.locator("#capture-amount").fill("1"); await page.locator("#confirm-capture-button").click();
  85  |   expect(logicalState(decode(await download(page)))).toEqual(fixture.next!.expected);
  86  |   await paint(page, fixture.next!.expected); expect(errors).toEqual([]);
  87  | });
  88  | 
  89  | test("friendly move draft is transient; completed move restores exact next turn", async ({ page }, info) => {
  90  |   const errors = errorsOn(page), fixture = pinned("move-ready"), completed = pinned("move-completed");
  91  |   const action = fixture.next!.action;
  92  |   if (action.kind !== "friendlyMove") throw Error("Pinned move must be friendlyMove");
  93  |   await setup(page); await upload(page, fixture.text); await check(page, fixture);
  94  |   await page.locator("#start-friendly-move-button").click();
  95  |   await country(page, action.from).click(); await country(page, action.to).click();
  96  |   await page.locator("#friendly-move-amount").fill("1");
  97  |   const stale = await page.locator("#confirm-friendly-move-button").elementHandle();
  98  |   const draft = await check(page, fixture); await capture(page, "move-draft", info.project.name);
  99  |   await upload(page, draft); await check(page, fixture);
  100 |   await expect(page.locator("#start-friendly-move-button")).toBeVisible();
  101 |   await expect(page.locator("#confirm-friendly-move-button")).not.toBeVisible();
  102 |   await stale!.evaluate(n => n.dispatchEvent(new MouseEvent("click", { bubbles: true })));
  103 |   await check(page, fixture);
  104 |   await page.locator("#start-friendly-move-button").click();
  105 |   await country(page, action.from).click(); await country(page, action.to).click();
  106 |   await page.locator("#friendly-move-amount").fill("1"); await page.locator("#confirm-friendly-move-button").click();
  107 |   const moved = await check(page, completed);
  108 |   await page.reload(); await upload(page, moved); await check(page, completed);
  109 |   await capture(page, "move-completed", info.project.name); expect(errors).toEqual([]);
  110 | });
  111 | 
  112 | test("victory and human-loss choices survive real files and remain usable", async ({ page }, info) => {
  113 |   const errors = errorsOn(page);
  114 |   for (const name of ["domination", "round-limit", "stop"]) {
  115 |     const fixture = pinned(name); await setup(page); await upload(page, fixture.text);
  116 |     const text = await check(page, fixture); await expect(page.locator("#victory-reason")).toBeVisible();
  117 |     await page.reload(); await upload(page, text); await check(page, fixture);
  118 |     await expect(page.locator("#end-turn-button")).not.toBeVisible();
  119 |     await capture(page, name, info.project.name);
  120 |   }
  121 |   const loss = pinned("human-loss"); await setup(page); await upload(page, loss.text); await check(page, loss);
  122 |   await page.locator("#watch-computers-button").click(); await check(page, pinned("watch"));
  123 |   await upload(page, loss.text); await check(page, loss);
  124 |   await page.locator("#stop-game-button").click(); await check(page, pinned("stop"));
  125 |   expect(errors).toEqual([]);
  126 | });
  127 | 
  128 | test("bad loads and generated-map files preserve the live match, draft and controls", async ({ page }, info) => {
  129 |   const errors = errorsOn(page), fixture = pinned("move-ready");
  130 |   const action = fixture.next!.action;
  131 |   if (action.kind !== "friendlyMove") throw Error("Expected friendly move fixture");
  132 |   await setup(page); await upload(page, fixture.text); const before = await check(page, fixture);
  133 |   await page.locator("#start-friendly-move-button").click(); await country(page, action.from).click(); await country(page, action.to).click();
  134 |   const valid = envelope(fixture.options, fixture.actions);
  135 |   for (const invalid of ["{", JSON.stringify({ ...valid, version: 99 }), JSON.stringify({ ...valid, boardGenerator: { id: "fixed-reference", version: 99 } }), JSON.stringify({ ...valid, actions: [{ kind: "attack", from: "missing", to: "missing" }] }), pinned("legacy-progress").text]) {
  136 |     await upload(page, invalid); await expect(page.getByRole("alert")).toContainText(/Load failed:/i);
  137 |     if (invalid === pinned("legacy-progress").text) await expect(page.getByRole("alert")).toContainText(/generated.*map|map.*generated/i);
  138 |     expect(await download(page)).toBe(before); await paint(page, fixture.expected);
  139 |     await expect(page.locator("#confirm-friendly-move-button")).toBeEnabled();
  140 |   }
  141 |   await capture(page, "failed-load", info.project.name);
  142 |   await page.locator("#friendly-move-amount").fill("1"); await page.locator("#confirm-friendly-move-button").click();
  143 |   await check(page, pinned("move-completed")); expect(errors).toEqual([]);
  144 | });
  145 | 
  146 | test("new game and a successful later load invalidate slow file readers", async ({ page }) => {
  147 |   const errors = errorsOn(page);
  148 |   await page.addInitScript(() => {
  149 |     const original = File.prototype.text;
  150 |     File.prototype.text = function () {
  151 |       if (this.name !== "slow.json") return original.call(this);
  152 |       return new Promise<string>((resolve, reject) => {
  153 |         Reflect.set(window, "releaseT31Read", () => { original.call(this).then(resolve, reject); });
  154 |       });
  155 |     };
  156 |   });
  157 |   const placement = pinned("placement"), pending = pinned("pending-capture");
  158 |   await setup(page); await upload(page, placement.text); await check(page, placement);
  159 |   await upload(page, pending.text, "slow.json");
  160 |   await page.getByRole("button", { name: "New game", exact: true }).click();
  161 |   await page.getByLabel("Seed", { exact: true }).fill("42");
  162 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  163 |   const fresh = await download(page);
  164 |   await page.evaluate(() => (Reflect.get(window, "releaseT31Read") as () => void)());
  165 |   await page.evaluate(() => new Promise(resolve => setTimeout(resolve, 0)));
> 166 |   expect(await download(page)).toBe(fresh);
      |                                ^ Error: expect(received).toBe(expected) // Object.is equality
  167 |   await upload(page, pending.text, "slow.json"); await upload(page, placement.text); await check(page, placement);
  168 |   await page.evaluate(() => (Reflect.get(window, "releaseT31Read") as () => void)());
  169 |   await page.evaluate(() => new Promise(resolve => setTimeout(resolve, 0)));
  170 |   await check(page, placement); expect(errors).toEqual([]);
  171 | });
  172 | 
  173 | test("successful load cancels queued fight-on work from the prior match", async ({ page }) => {
  174 |   const errors = errorsOn(page), fixture = pinned("move-ready"), restored = pinned("placement");
  175 |   await page.clock.install(); await page.clock.pauseAt(new Date());
  176 |   await setup(page); await upload(page, fixture.text); await check(page, fixture);
  177 |   const state = decode(fixture.text), mover = state.players[state.currentPlayer]!.id;
  178 |   const attacks = state.map.provinces.filter(p => state.ownerOf[p.id] === mover && state.armies[p.id]! > 2).flatMap(p => [...p.borders, ...p.seaLanes].filter(id => state.ownerOf[id] !== mover).map(to => ({ kind: "attack" as const, from: p.id, to })));
  179 |   const queued = attacks.find(action => { const result = apply(state, action); return result.ok && result.state.phase === "attack" && result.state.armies[action.from]! > 1; });
  180 |   if (!queued) throw Error("Pinned move-ready must permit a queued exchange for stale-timer acceptance");
  181 |   await country(page, queued.from).click(); await country(page, queued.to).click();
  182 |   await page.locator("#battle-stop-threshold").fill("1"); await page.locator("#battle-stop-threshold").press("Tab");
  183 |   await page.locator("#fight-on-button").click();
  184 |   await expect(page.getByRole("region", { name: "Battle controls", exact: true })).toHaveAttribute("data-running", "true");
  185 |   await upload(page, restored.text); await check(page, restored);
  186 |   await page.clock.runFor(10000); await check(page, restored);
  187 |   const next = restored.next!.action;
  188 |   if (next.kind !== "reinforce") throw Error("Expected reinforcement continuation");
  189 |   const result = apply(decode(restored.text), next); expect(result.ok).toBe(true);
  190 |   await country(page, next.province).click();
  191 |   expect(logicalState(decode(await download(page)))).toEqual(restored.next!.expected);
  192 |   expect(errors).toEqual([]);
  193 | });
  194 | 
```