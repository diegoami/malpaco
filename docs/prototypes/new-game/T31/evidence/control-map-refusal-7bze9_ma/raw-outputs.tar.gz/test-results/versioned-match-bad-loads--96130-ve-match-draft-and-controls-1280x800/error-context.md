# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: versioned-match.spec.ts >> bad loads and generated-map files preserve the live match, draft and controls
- Location: tests/e2e/versioned-match.spec.ts:128:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('alert')
Expected pattern: /Load failed:/i
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" getByRole('alert') with timeout 5000ms
  - waiting for getByRole('alert')

```

```yaml
- banner:
  - heading "Malpaco" [level=1]
  - text: Nine Isles · 3 human seats · Seed 1994 Seat 1 15 provinces · 30 armies Seat 2 15 provinces · 30 armies Seat 3 16 provinces · 34 armies
  - contentinfo:
    - button "New game"
  - button "Save game"
  - text: Load game
  - button "Load game"
- main:
  - img "Nine Isles reference map":
    - button "River gate, Seat 3, 1 armies": River gate 3 · 1
    - button "New port, Seat 3, 5 armies": New port 3 · 5
    - button "North rest, Seat 1, 3 armies": North rest 1 · 3
    - button "River keep, Seat 2, 2 armies": River keep 2 · 2
    - button "North town, Seat 3, 1 armies": North town 3 · 1
    - button "Dark ford, Seat 2, 2 armies": Dark ford 2 · 2
    - button "Iron point, Seat 3, 2 armies": Iron point 3 · 2
    - button "South rest, Seat 2, 3 armies": South rest 2 · 3
    - button "High shore, Seat 2, 1 armies": High shore 2 · 1
    - button "Wind town, Seat 3, 3 armies": Wind town 3 · 3
    - button "New glen, Seat 2, 3 armies": New glen 2 · 3
    - button "Old rock, Seat 1, 3 armies": Old rock 1 · 3
    - button "Blue peak, Seat 2, 2 armies": Blue peak 2 · 2 ★
    - button "West haven, Seat 1, 1 armies": West haven 1 · 1
    - button "Stone watch, Seat 1, 3 armies": Stone watch 1 · 3
    - button "Upper ridge, Seat 3, 1 armies": Upper ridge 3 · 1
    - button "Marsh keep, Seat 3, 2 armies": Marsh keep 3 · 2
    - button "New fell, Seat 1, 2 armies": New fell 1 · 2
    - button "Moon point, Seat 1, 1 armies": Moon point 1 · 1 ★
    - button "South fell, Seat 3, 3 armies": South fell 3 · 3
    - button "High ridge, Seat 3, 2 armies": High ridge 3 · 2
    - button "Bay ford, Seat 1, 3 armies": Bay ford 1 · 3
    - button "Low moor, Seat 2, 2 armies": Low moor 2 · 2
    - button "Lower field, Seat 3, 3 armies": Lower field 3 · 3
    - button "Wind gate, Seat 1, 2 armies": Wind gate 1 · 2
    - button "Silver shore, Seat 1, 2 armies": Silver shore 1 · 2
    - button "Low peak, Seat 1, 1 armies": Low peak 1 · 1
    - button "Wind port, Seat 3, 1 armies": Wind port 3 · 1
    - button "Gold point, Seat 2, 1 armies": Gold point 2 · 1
    - button "Rock moor, Seat 1, 1 armies": Rock moor 1 · 1
    - button "Marsh rest, Seat 3, 1 armies": Marsh rest 3 · 1
    - button "Wind dale, Seat 2, 3 armies": Wind dale 2 · 3
    - button "Silver ford, Seat 3, 3 armies": Silver ford 3 · 3
    - button "Iron field, Seat 2, 1 armies": Iron field 2 · 1
    - button "North wood, Seat 2, 1 armies": North wood 2 · 1
    - button "Fort town, Seat 1, 3 armies": Fort town 1 · 3
    - button "Red field, Seat 2, 3 armies": Red field 2 · 3 ★
    - button "South ridge, Seat 1, 2 armies": South ridge 1 · 2
    - button "Rock bay, Seat 3, 2 armies": Rock bay 3 · 2
    - button "North ford, Seat 1, 1 armies": North ford 1 · 1
    - button "Port ridge, Seat 1, 2 armies": Port ridge 1 · 2
    - button "New rock, Seat 3, 3 armies": New rock 3 · 3
    - button "South reach, Seat 2, 2 armies": South reach 2 · 2
    - button "Silver point, Seat 2, 1 armies": Silver point 2 · 1
    - button "East ford, Seat 3, 1 armies": East ford 3 · 1
    - button "Gold town, Seat 2, 3 armies": Gold town 2 · 3
    - text: North Isle +3 East Isle +3 West Isle +3 South Isle +3 Central Isle +5 Harbor Isle +5 Palm Isle +6 Cliff Isle +5 Great Isle +9
  - complementary:
    - text: Seat 3's turn Round 1 · Attack
    - button "End turn"
    - button "Move armies" [disabled]
    - region "Battle controls":
      - heading "Battle" [level=2]
      - text: From
      - strong: Choose your country
      - text: — Target
      - strong: Choose an enemy neighbour
      - text: — Stop at armies
      - spinbutton "Stop at armies": "2"
      - text: Battle speed
      - combobox "Battle speed":
        - option "Slow"
        - option "Normal" [selected]
        - option "Fast"
      - paragraph: Choose a source and target to begin.
      - button "Fight on" [disabled]
      - button "Stop" [disabled]
      - button "Single exchange" [disabled]
      - strong: Ready for your choice
      - paragraph: Select countries on the map.
      - paragraph:
        - text: Won 0 · Lost 0 · Ties
        - strong: "0"
    - heading "Battle log" [level=3]
    - list "Battle log":
      - listitem: "T1 Seat 3: New port → North rest, -1 / -0"
      - listitem: "T1 Seat 3: River gate → New port, took New port"
      - listitem: "T1 Seat 3: River gate → New port, -0 / -1"
```

# Test source

```ts
  36  |   return text;
  37  | }
  38  | async function setup(page: Page) {
  39  |   await page.goto("/?view=reference-game&control=manual");
  40  |   await expect(page.getByRole("heading", { name: "New reference game", exact: true })).toBeVisible();
  41  | }
  42  | async function capture(page: Page, label: string, project: string) {
  43  |   const root = process.env["VERSIONED_MATCH_EVIDENCE_DIR"] ?? "screenshots";
  44  |   mkdirSync(root, { recursive: true });
  45  |   const selectors = "#reference-save-game,#reference-load-game-file,.match-error:not(:empty),#turn-title,#confirm-capture-button,#confirm-friendly-move-button,#victory-reason";
  46  |   const boxes = await page.locator(selectors).evaluateAll(nodes => nodes.filter(n => n.getClientRects().length).map(n => {
  47  |     const r = n.getBoundingClientRect(); return { id: n.id, font: parseFloat(getComputedStyle(n).fontSize), fits: r.left >= 0 && r.top >= 0 && r.right <= innerWidth + 1 && r.bottom <= innerHeight + 1 };
  48  |   }));
  49  |   expect(boxes.length).toBeGreaterThanOrEqual(3);
  50  |   expect(boxes.filter(b => !b.fits || b.font < 12)).toEqual([]);
  51  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  52  |   await page.screenshot({ path: join(mkdtempSync(join(root, "versioned-")), `${label}-${project}.png`) });
  53  | }
  54  | function errorsOn(page: Page) {
  55  |   const errors: string[] = [];
  56  |   page.on("pageerror", error => errors.push(error.message));
  57  |   page.on("console", message => { if (message.type() === "error") errors.push(message.text()); });
  58  |   return errors;
  59  | }
  60  | 
  61  | test("placement download/upload retains full original options and continues placement", async ({ page }, info) => {
  62  |   const errors = errorsOn(page), fixture = pinned("placement");
  63  |   await setup(page); await upload(page, fixture.text); const text = await check(page, fixture);
  64  |   await capture(page, "placement", info.project.name);
  65  |   await page.getByRole("button", { name: "New game", exact: true }).click();
  66  |   await page.getByLabel("Seed", { exact: true }).fill("42");
  67  |   await upload(page, text); await check(page, fixture);
  68  |   const action = fixture.next!.action;
  69  |   if (action.kind !== "reinforce") throw Error("Pinned placement must continue reinforcement");
  70  |   await country(page, action.province).click();
  71  |   expect(logicalState(decode(await download(page)))).toEqual(fixture.next!.expected);
  72  |   await paint(page, fixture.next!.expected); expect(errors).toEqual([]);
  73  | });
  74  | 
  75  | test("pending capture reload keeps the choice and rejects a detached old confirm", async ({ page }, info) => {
  76  |   const errors = errorsOn(page), fixture = pinned("pending-capture");
  77  |   await setup(page); await upload(page, fixture.text); const text = await check(page, fixture);
  78  |   const pending = fixture.expected["pendingCapture"] as { defaultAmount: number };
  79  |   await expect(page.locator("#capture-amount")).toHaveValue(String(pending.defaultAmount));
  80  |   const oldConfirm = await page.locator("#confirm-capture-button").elementHandle();
  81  |   await upload(page, text); await check(page, fixture);
  82  |   await oldConfirm!.evaluate(n => n.dispatchEvent(new MouseEvent("click", { bubbles: true })));
  83  |   await check(page, fixture); await capture(page, "pending-capture", info.project.name);
  84  |   await page.locator("#capture-amount").fill("1"); await page.locator("#confirm-capture-button").click();
  85  |   expect(logicalState(decode(await download(page)))).toEqual(fixture.next!.expected);
  86  |   await paint(page, fixture.next!.expected); expect(errors).toEqual([]);
  87  | });
  88  | 
  89  | test("friendly move draft is transient; completed move restores exact next turn", async ({ page }, info) => {
  90  |   const errors = errorsOn(page), fixture = pinned("move-ready"), completed = pinned("move-completed");
  91  |   const action = fixture.next!.action;
  92  |   if (action.kind !== "friendlyMove") throw Error("Pinned move must be friendlyMove");
  93  |   await setup(page); await upload(page, fixture.text); await check(page, fixture);
  94  |   await page.locator("#start-friendly-move-button").click();
  95  |   await country(page, action.from).click(); await country(page, action.to).click();
  96  |   await page.locator("#friendly-move-amount").fill("1");
  97  |   const stale = await page.locator("#confirm-friendly-move-button").elementHandle();
  98  |   const draft = await check(page, fixture); await capture(page, "move-draft", info.project.name);
  99  |   await upload(page, draft); await check(page, fixture);
  100 |   await expect(page.locator("#start-friendly-move-button")).toBeVisible();
  101 |   await expect(page.locator("#confirm-friendly-move-button")).not.toBeVisible();
  102 |   await stale!.evaluate(n => n.dispatchEvent(new MouseEvent("click", { bubbles: true })));
  103 |   await check(page, fixture);
  104 |   await page.locator("#start-friendly-move-button").click();
  105 |   await country(page, action.from).click(); await country(page, action.to).click();
  106 |   await page.locator("#friendly-move-amount").fill("1"); await page.locator("#confirm-friendly-move-button").click();
  107 |   const moved = await check(page, completed);
  108 |   await page.reload(); await upload(page, moved); await check(page, completed);
  109 |   await capture(page, "move-completed", info.project.name); expect(errors).toEqual([]);
  110 | });
  111 | 
  112 | test("victory and human-loss choices survive real files and remain usable", async ({ page }, info) => {
  113 |   const errors = errorsOn(page);
  114 |   for (const name of ["domination", "round-limit", "stop"]) {
  115 |     const fixture = pinned(name); await setup(page); await upload(page, fixture.text);
  116 |     const text = await check(page, fixture); await expect(page.locator("#victory-reason")).toBeVisible();
  117 |     await page.reload(); await upload(page, text); await check(page, fixture);
  118 |     await expect(page.locator("#end-turn-button")).not.toBeVisible();
  119 |     await capture(page, name, info.project.name);
  120 |   }
  121 |   const loss = pinned("human-loss"); await setup(page); await upload(page, loss.text); await check(page, loss);
  122 |   await page.locator("#watch-computers-button").click(); await check(page, pinned("watch"));
  123 |   await upload(page, loss.text); await check(page, loss);
  124 |   await page.locator("#stop-game-button").click(); await check(page, pinned("stop"));
  125 |   expect(errors).toEqual([]);
  126 | });
  127 | 
  128 | test("bad loads and generated-map files preserve the live match, draft and controls", async ({ page }, info) => {
  129 |   const errors = errorsOn(page), fixture = pinned("move-ready");
  130 |   const action = fixture.next!.action;
  131 |   if (action.kind !== "friendlyMove") throw Error("Expected friendly move fixture");
  132 |   await setup(page); await upload(page, fixture.text); const before = await check(page, fixture);
  133 |   await page.locator("#start-friendly-move-button").click(); await country(page, action.from).click(); await country(page, action.to).click();
  134 |   const valid = envelope(fixture.options, fixture.actions);
  135 |   for (const invalid of ["{", JSON.stringify({ ...valid, version: 99 }), JSON.stringify({ ...valid, boardGenerator: { id: "fixed-reference", version: 99 } }), JSON.stringify({ ...valid, actions: [{ kind: "attack", from: "missing", to: "missing" }] }), pinned("legacy-progress").text]) {
> 136 |     await upload(page, invalid); await expect(page.getByRole("alert")).toContainText(/Load failed:/i);
      |                                                                        ^ Error: expect(locator).toContainText(expected) failed
  137 |     if (invalid === pinned("legacy-progress").text) await expect(page.getByRole("alert")).toContainText(/generated.*map|map.*generated/i);
  138 |     expect(await download(page)).toBe(before); await paint(page, fixture.expected);
  139 |     await expect(page.locator("#confirm-friendly-move-button")).toBeEnabled();
  140 |   }
  141 |   await capture(page, "failed-load", info.project.name);
  142 |   await page.locator("#friendly-move-amount").fill("1"); await page.locator("#confirm-friendly-move-button").click();
  143 |   await check(page, pinned("move-completed")); expect(errors).toEqual([]);
  144 | });
  145 | 
  146 | test("new game and a successful later load invalidate slow file readers", async ({ page }) => {
  147 |   const errors = errorsOn(page);
  148 |   await page.addInitScript(() => {
  149 |     const original = File.prototype.text;
  150 |     File.prototype.text = function () {
  151 |       if (this.name !== "slow.json") return original.call(this);
  152 |       return new Promise<string>((resolve, reject) => {
  153 |         Reflect.set(window, "releaseT31Read", () => { original.call(this).then(resolve, reject); });
  154 |       });
  155 |     };
  156 |   });
  157 |   const placement = pinned("placement"), pending = pinned("pending-capture");
  158 |   await setup(page); await upload(page, placement.text); await check(page, placement);
  159 |   await upload(page, pending.text, "slow.json");
  160 |   await page.getByRole("button", { name: "New game", exact: true }).click();
  161 |   await page.getByLabel("Seed", { exact: true }).fill("42");
  162 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  163 |   const fresh = await download(page);
  164 |   await page.evaluate(() => (Reflect.get(window, "releaseT31Read") as () => void)());
  165 |   await page.evaluate(() => new Promise(resolve => setTimeout(resolve, 0)));
  166 |   expect(await download(page)).toBe(fresh);
  167 |   await upload(page, pending.text, "slow.json"); await upload(page, placement.text); await check(page, placement);
  168 |   await page.evaluate(() => (Reflect.get(window, "releaseT31Read") as () => void)());
  169 |   await page.evaluate(() => new Promise(resolve => setTimeout(resolve, 0)));
  170 |   await check(page, placement); expect(errors).toEqual([]);
  171 | });
  172 | 
  173 | test("successful load cancels queued fight-on work from the prior match", async ({ page }) => {
  174 |   const errors = errorsOn(page), fixture = pinned("move-ready"), restored = pinned("placement");
  175 |   await page.clock.install(); await page.clock.pauseAt(new Date());
  176 |   await setup(page); await upload(page, fixture.text); await check(page, fixture);
  177 |   const state = decode(fixture.text), mover = state.players[state.currentPlayer]!.id;
  178 |   const attacks = state.map.provinces.filter(p => state.ownerOf[p.id] === mover && state.armies[p.id]! > 2).flatMap(p => [...p.borders, ...p.seaLanes].filter(id => state.ownerOf[id] !== mover).map(to => ({ kind: "attack" as const, from: p.id, to })));
  179 |   const queued = attacks.find(action => { const result = apply(state, action); return result.ok && result.state.phase === "attack" && result.state.armies[action.from]! > 1; });
  180 |   if (!queued) throw Error("Pinned move-ready must permit a queued exchange for stale-timer acceptance");
  181 |   await country(page, queued.from).click(); await country(page, queued.to).click();
  182 |   await page.locator("#battle-stop-threshold").fill("1"); await page.locator("#battle-stop-threshold").press("Tab");
  183 |   await page.locator("#fight-on-button").click();
  184 |   await expect(page.getByRole("region", { name: "Battle controls", exact: true })).toHaveAttribute("data-running", "true");
  185 |   await upload(page, restored.text); await check(page, restored);
  186 |   await page.clock.runFor(10000); await check(page, restored);
  187 |   const next = restored.next!.action;
  188 |   if (next.kind !== "reinforce") throw Error("Expected reinforcement continuation");
  189 |   const result = apply(decode(restored.text), next); expect(result.ok).toBe(true);
  190 |   await country(page, next.province).click();
  191 |   expect(logicalState(decode(await download(page)))).toEqual(restored.next!.expected);
  192 |   expect(errors).toEqual([]);
  193 | });
  194 | 
```