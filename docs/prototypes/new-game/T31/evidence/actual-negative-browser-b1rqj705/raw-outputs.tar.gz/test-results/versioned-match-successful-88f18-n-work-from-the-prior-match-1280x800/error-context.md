# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: versioned-match.spec.ts >> successful load cancels queued fight-on work from the prior match
- Location: tests/e2e/versioned-match.spec.ts:173:1

# Error details

```
Test timeout of 7000ms exceeded.
```

```
Error: locator.setInputFiles: Test timeout of 7000ms exceeded.
Call log:
  - waiting for getByLabel('Load game', { exact: true })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - heading "New reference game" [level=1] [ref=e4]
  - paragraph [ref=e5]: Development reference game for manual play on Nine Isles. Choose each seat’s controller; computer seats are driven manually here. The seed changes the deal.
  - generic [ref=e6]: Seed
  - spinbutton "Seed" [ref=e7]: "1994"
  - generic [ref=e8]: Human seats
  - combobox "Human seats" [ref=e9]:
    - option "2" [selected]
    - option "3"
    - option "4"
  - generic [ref=e10]:
    - generic [ref=e11]:
      - generic [ref=e12]: Seat 1 control
      - combobox "Seat 1 control" [ref=e13]:
        - option "Human" [selected]
        - option "Computer"
    - generic [ref=e14]:
      - generic [ref=e15]: Seat 2 control
      - combobox "Seat 2 control" [ref=e16]:
        - option "Human" [selected]
        - option "Computer"
  - generic [ref=e17]:
    - generic [ref=e18]:
      - checkbox "Domination win" [checked] [ref=e19]
      - generic [ref=e20]: Domination win
    - generic [ref=e21]:
      - generic [ref=e22]: Round limit
      - combobox "Round limit" [ref=e23]:
        - option "Off" [selected]
        - option "20 rounds"
        - option "30 rounds"
        - option "40 rounds"
  - button "Start game" [ref=e24] [cursor=pointer]
  - alert
```

# Test source

```ts
  1   | import { expect, test } from "@playwright/test";
  2   | import type { Page } from "@playwright/test";
  3   | import { mkdirSync, mkdtempSync, readFileSync } from "node:fs";
  4   | import { join } from "node:path";
  5   | import * as codec from "../../src/core/match-save";
  6   | import { apply } from "../../src/core";
  7   | import type { GameState } from "../../src/core";
  8   | import { envelope, logicalState, pinned } from "../core/versioned-match-fixture";
  9   | import type { PinnedMatch } from "../core/versioned-match-fixture";
  10  | 
  11  | const country = (page: Page, id: string) => page.locator(`[data-country="${id}"]`);
  12  | const api = codec as typeof codec & { deserializeVersionedMatch?: (text: string) => { state: GameState } };
  13  | const decode = (text: string) => (api.deserializeVersionedMatch?.(text) ?? codec.deserializeMatch(text)).state;
  14  | async function download(page: Page) {
  15  |   const pending = page.waitForEvent("download");
  16  |   await page.getByRole("button", { name: "Save game", exact: true }).click();
  17  |   const file = await pending;
  18  |   expect(file.suggestedFilename()).toMatch(/^malpaco-\d+\.json$/);
  19  |   return readFileSync((await file.path())!, "utf8");
  20  | }
  21  | async function upload(page: Page, text: string, name = "resume.json") {
> 22  |   await page.getByLabel("Load game", { exact: true }).setInputFiles({ name, mimeType: "application/json", buffer: Buffer.from(text) });
      |   ^ Error: locator.setInputFiles: Test timeout of 7000ms exceeded.
  23  | }
  24  | async function paint(page: Page, expected: Record<string, unknown>) {
  25  |   const owners = expected["ownerOf"] as Record<string, string>, armies = expected["armies"] as Record<string, number>;
  26  |   const actual = await page.locator("[data-country]").evaluateAll(nodes => Object.fromEntries(nodes.map(n => [n.getAttribute("data-country"), [n.getAttribute("data-owner"), Number(n.getAttribute("data-armies"))]])));
  27  |   expect(actual).toEqual(Object.fromEntries(Object.keys(owners).map(id => [id, [owners[id], armies[id]]])));
  28  | }
  29  | async function check(page: Page, fixture: PinnedMatch) {
  30  |   await expect(page.locator("[data-country]")).toHaveCount(46);
  31  |   await expect.poll(async () => await page.locator("[data-country]").evaluateAll(nodes => Object.fromEntries(nodes.map(n => [n.getAttribute("data-country"), Number(n.getAttribute("data-armies"))])))).toEqual(fixture.expected["armies"]);
  32  |   await paint(page, fixture.expected);
  33  |   const text = await download(page);
  34  |   expect(JSON.parse(text)).toEqual(envelope(fixture.options, fixture.actions));
  35  |   expect(logicalState(decode(text))).toEqual(fixture.expected);
  36  |   return text;
  37  | }
  38  | async function setup(page: Page) {
  39  |   await page.goto("/?view=reference-game&control=manual");
  40  |   await expect(page.getByRole("heading", { name: "New reference game", exact: true })).toBeVisible();
  41  | }
  42  | async function capture(page: Page, label: string, project: string) {
  43  |   const root = process.env["VERSIONED_MATCH_EVIDENCE_DIR"] ?? "screenshots";
  44  |   mkdirSync(root, { recursive: true });
  45  |   const selectors = "#reference-save-game,#reference-load-game-file,.match-error:not(:empty),#turn-title,#confirm-capture-button,#confirm-friendly-move-button,#victory-reason";
  46  |   const boxes = await page.locator(selectors).evaluateAll(nodes => nodes.filter(n => n.getClientRects().length).map(n => {
  47  |     const r = n.getBoundingClientRect(); return { id: n.id, font: parseFloat(getComputedStyle(n).fontSize), fits: r.left >= 0 && r.top >= 0 && r.right <= innerWidth + 1 && r.bottom <= innerHeight + 1 };
  48  |   }));
  49  |   expect(boxes.length).toBeGreaterThanOrEqual(3);
  50  |   expect(boxes.filter(b => !b.fits || b.font < 12)).toEqual([]);
  51  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  52  |   await page.screenshot({ path: join(mkdtempSync(join(root, "versioned-")), `${label}-${project}.png`) });
  53  | }
  54  | function errorsOn(page: Page) {
  55  |   const errors: string[] = [];
  56  |   page.on("pageerror", error => errors.push(error.message));
  57  |   page.on("console", message => { if (message.type() === "error") errors.push(message.text()); });
  58  |   return errors;
  59  | }
  60  | 
  61  | test("placement download/upload retains full original options and continues placement", async ({ page }, info) => {
  62  |   const errors = errorsOn(page), fixture = pinned("placement");
  63  |   await setup(page); await upload(page, fixture.text); const text = await check(page, fixture);
  64  |   await capture(page, "placement", info.project.name);
  65  |   await page.getByRole("button", { name: "New game", exact: true }).click();
  66  |   await page.getByLabel("Seed", { exact: true }).fill("42");
  67  |   await upload(page, text); await check(page, fixture);
  68  |   const action = fixture.next!.action;
  69  |   if (action.kind !== "reinforce") throw Error("Pinned placement must continue reinforcement");
  70  |   await country(page, action.province).click();
  71  |   expect(logicalState(decode(await download(page)))).toEqual(fixture.next!.expected);
  72  |   await paint(page, fixture.next!.expected); expect(errors).toEqual([]);
  73  | });
  74  | 
  75  | test("pending capture reload keeps the choice and rejects a detached old confirm", async ({ page }, info) => {
  76  |   const errors = errorsOn(page), fixture = pinned("pending-capture");
  77  |   await setup(page); await upload(page, fixture.text); const text = await check(page, fixture);
  78  |   const pending = fixture.expected["pendingCapture"] as { defaultAmount: number };
  79  |   await expect(page.locator("#capture-amount")).toHaveValue(String(pending.defaultAmount));
  80  |   const oldConfirm = await page.locator("#confirm-capture-button").elementHandle();
  81  |   await upload(page, text); await check(page, fixture);
  82  |   await oldConfirm!.evaluate(n => n.dispatchEvent(new MouseEvent("click", { bubbles: true })));
  83  |   await check(page, fixture); await capture(page, "pending-capture", info.project.name);
  84  |   await page.locator("#capture-amount").fill("1"); await page.locator("#confirm-capture-button").click();
  85  |   expect(logicalState(decode(await download(page)))).toEqual(fixture.next!.expected);
  86  |   await paint(page, fixture.next!.expected); expect(errors).toEqual([]);
  87  | });
  88  | 
  89  | test("friendly move draft is transient; completed move restores exact next turn", async ({ page }, info) => {
  90  |   const errors = errorsOn(page), fixture = pinned("move-ready"), completed = pinned("move-completed");
  91  |   const action = fixture.next!.action;
  92  |   if (action.kind !== "friendlyMove") throw Error("Pinned move must be friendlyMove");
  93  |   await setup(page); await upload(page, fixture.text); await check(page, fixture);
  94  |   await page.locator("#start-friendly-move-button").click();
  95  |   await country(page, action.from).click(); await country(page, action.to).click();
  96  |   await page.locator("#friendly-move-amount").fill("1");
  97  |   const stale = await page.locator("#confirm-friendly-move-button").elementHandle();
  98  |   const draft = await check(page, fixture); await capture(page, "move-draft", info.project.name);
  99  |   await upload(page, draft); await check(page, fixture);
  100 |   await expect(page.locator("#start-friendly-move-button")).toBeVisible();
  101 |   await expect(page.locator("#confirm-friendly-move-button")).not.toBeVisible();
  102 |   await stale!.evaluate(n => n.dispatchEvent(new MouseEvent("click", { bubbles: true })));
  103 |   await check(page, fixture);
  104 |   await page.locator("#start-friendly-move-button").click();
  105 |   await country(page, action.from).click(); await country(page, action.to).click();
  106 |   await page.locator("#friendly-move-amount").fill("1"); await page.locator("#confirm-friendly-move-button").click();
  107 |   const moved = await check(page, completed);
  108 |   await page.reload(); await upload(page, moved); await check(page, completed);
  109 |   await capture(page, "move-completed", info.project.name); expect(errors).toEqual([]);
  110 | });
  111 | 
  112 | test("victory and human-loss choices survive real files and remain usable", async ({ page }, info) => {
  113 |   const errors = errorsOn(page);
  114 |   for (const name of ["domination", "round-limit", "stop"]) {
  115 |     const fixture = pinned(name); await setup(page); await upload(page, fixture.text);
  116 |     const text = await check(page, fixture); await expect(page.locator("#victory-reason")).toBeVisible();
  117 |     await page.reload(); await upload(page, text); await check(page, fixture);
  118 |     await expect(page.locator("#end-turn-button")).not.toBeVisible();
  119 |     await capture(page, name, info.project.name);
  120 |   }
  121 |   const loss = pinned("human-loss"); await setup(page); await upload(page, loss.text); await check(page, loss);
  122 |   await page.locator("#watch-computers-button").click(); await check(page, pinned("watch"));
```