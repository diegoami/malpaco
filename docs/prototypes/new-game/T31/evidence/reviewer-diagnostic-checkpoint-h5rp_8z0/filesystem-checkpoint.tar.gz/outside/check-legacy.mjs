import { readFileSync } from "node:fs";
import { deserializeVersionedMatch } from "./src/core/match-save.js";

const text = readFileSync("docs/prototypes/new-game/T31/fixtures/legacy-opening.json", "utf8");
const fixture = JSON.parse(text);
const textField = JSON.parse(fixture.text);
console.log("text field has", Object.keys(textField).length, "keys");
console.log("keys:", Object.keys(textField));

const result = deserializeVersionedMatch(fixture.text);
console.log("formatVersion:", result.formatVersion);
console.log("identity:", result.identity);
console.log("options.seats.length:", result.options.seats.length);
console.log("state.history.length:", result.state.history.length);
console.log("state.phase:", result.state.phase);
