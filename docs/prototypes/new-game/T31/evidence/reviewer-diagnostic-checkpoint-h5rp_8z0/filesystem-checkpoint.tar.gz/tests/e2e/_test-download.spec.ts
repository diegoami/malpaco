import { test, expect } from "@playwright/test";

test("download via blob URL works", async ({ page }) => {
  await page.goto("/?view=reference-game&control=manual");
  await expect(page.getByRole("heading", { name: "New reference game", exact: true })).toBeVisible();
  await page.getByLabel("Seed", { exact: true }).fill("1994");
  await page.getByRole("button", { name: "Start game", exact: true }).click();
  await expect(page.locator(".battle-reference")).toBeVisible();
  const pending = page.waitForEvent("download", { timeout: 5000 });
  await page.getByRole("button", { name: "Save game", exact: true }).click();
  const file = await pending;
  console.log("Download:", file.suggestedFilename());
  expect(file).toBeTruthy();
});
