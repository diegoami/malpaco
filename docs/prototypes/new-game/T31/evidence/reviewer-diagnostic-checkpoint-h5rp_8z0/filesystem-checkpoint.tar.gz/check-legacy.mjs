import { readFileSync } from "node:fs";
import { deserializeVersionedMatch, deserializeMatch } from "./src/core/match-save.js";

const text = readFileSync("docs/prototypes/new-game/T31/fixtures/legacy-opening.json", "utf8");
const fixture = JSON.parse(text);
console.log("fixture keys:", Object.keys(fixture));

// Check that text is a v1 file
const textField = JSON.parse(fixture.text);
console.log("text field has", Object.keys(textField).length, "keys");
console.log("keys:", Object.keys(textField));

// Try direct deserializeMatch first
try {
  const result = deserializeMatch(fixture.text);
  console.log("deserializeMatch format:", result.options.seats.length, "seats");
} catch (e) {
  console.log("deserializeMatch error:", e.message);
}

// Try deserializeVersionedMatch
try {
  const result = deserializeVersionedMatch(fixture.text);
  console.log("deserializeVersionedMatch formatVersion:", result.formatVersion);
  console.log("identity:", result.identity);
  console.log("options.seats.length:", result.options.seats.length);
} catch (e) {
  console.log("deserializeVersionedMatch error:", e.message);
}
