import { test, expect } from "@playwright/test";

test("save game triggers download", async ({ page }) => {
  await page.goto("/?view=reference-game&control=manual");
  await expect(page.getByRole("heading", { name: "New reference game", exact: true })).toBeVisible();
  await page.getByLabel("Seed", { exact: true }).fill("1994");
  await page.getByRole("button", { name: "Start game", exact: true }).click();
  await expect(page.getByRole("heading", { name: "Malpaco", exact: true })).toBeVisible();
  const downloadPromise = page.waitForEvent("download", { timeout: 5000 }).catch(e => null);
  await page.getByRole("button", { name: "Save game", exact: true }).click();
  const download = await downloadPromise;
  console.log("Download received:", download?.suggestedFilename());
  expect(download).not.toBeNull();
});
