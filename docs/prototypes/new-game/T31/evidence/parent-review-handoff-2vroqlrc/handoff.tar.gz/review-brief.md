T31 review (MiniMax M3)
You review PR #133 at acc9029f139b9e4f78d70c09d36b448acbe20ef2. You did not write it. The task file follows.
0. Prove the tree: HEAD is acc9029f139b9e4f78d70c09d36b448acbe20ef2 and the diff against origin/main is the PR's; findings name its files.
1. Re-run every Done-when line yourself, and account for each (L32). The PR's evidence is no proof.
2. [evidence-driven] Every constant traces to a fixture, report or investigation; a [designed] one says what was searched.
3. [seeded] No wall clock, unseeded random or order-dependent iteration in rule code.
4. Every changed file and behaviour is one the task asks for (L44); docs it makes wrong are updated.
5. Sweep the diff: tests that pass with the behaviour deleted (mutate, rebuild clean, re-take any
   negative result), branches no input reaches, edge comments without a test, version identities, original v1 compatibility, action replay and atomic UI lifecycle.
   Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
   restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
   a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
   copy inside your worktree (`<file>.saved`, deleted afterwards) or in a `mktemp -d` folder under
   `/tmp`, never as a loose file elsewhere.
6. Apply the Blocking means and one-pass sections below.
Prove each finding (run it, or delete the behaviour and name the test that fails) or label it
unverified. Your final message is the review: the header; the verdict (approve | approve after
named fixes | rework | user decision); per Done-when line `DW<k>: ran <command> → <result>` or
`DW<k>: not run — <reason>`; the findings R1..Rn (file:line, blocking or not); the verdict again
last. Never post it: the script posts it and applies the label.

# T31 Versioned deterministic match replay

- **Kind**: feature
- **Issue**: #76 · **Branch**: `task/T31-versioned-deterministic-match-replay` · **Merge after**: T30.
- **Difficulty**: Hard; estimate, not a model assignment.
- **Implementer**: owner-selected under rule 6; use an isolated worktree and record the choice before dispatch.
- **Reviewer**: owner-selected OpenCode model of another family under rule 6; record the choice before review.
- **Evidence**: [pinned core-rules design](https://github.com/diegoami/isle-wars-archaeology/blob/ae298e37c2f5177039e55767607f9345b6cb0e7a/design/core-rules.md), owner roadmap accepted 2026-10-15, and upstream task evidence. T23 resolves source anchors; new constants need citations or explicit [designed] provenance.
- **Owns**: src/core/**; tests/core/**; src/ui/**; src/styles.css; tests/ui/**; tests/e2e/**; docs/prototypes/new-game/T31/**; docs/spike.md; append-only RUN-NOTES.md.
- **Scope**: Version board generation, rules and action schema explicitly before topology/RNG ordering changes ship. Extend replay to capture choices and friendly moves, including pending choices and terminal states. Record computer policy actions rather than rerunning policy on load. Preserve supported old saves using their original versioned path or reject unsupported versions clearly before replacing the current match; never reinterpret the same seed under a new generator silently.
- **Done when**:
  1. `npx vitest run tests/core/versioned-match.test.ts` — old supported fixtures, new action histories, RNG continuation and exact resumed next actions match uninterrupted play; unknown versions and illegal histories fail atomically.
  2. `npx playwright test tests/e2e/versioned-match.spec.ts` — real download/upload during placement, pending capture, move and victory resumes correctly; failed load retains the live match and controls.
  3. `npm test` and `npm run build` pass; affected pinned browser suites pass without weakening existing assertions. Retain measured outputs, screenshots where applicable, commands and hashes in the owned evidence path; report negative-before/positive-after checks and exact restoration.
- **Hazards**: A seed and action list is insufficient without generator/rules identity. Preserve old algorithms only where compatibility is claimed; do not fake migrations. Main session preflights acceptance before dispatch; unresolved design conflicts stop implementation, never weaken a Done-when.

## Blocking means

Any one is enough; a blocking finding means rework, never approve.
1. A Done-when line fails, or cannot be run as written.
2. What this task protects can be got past: explicit board/rules/action version identity, exact supported replay/RNG continuation, and atomic live-game replacement. A bypass you proved is blocking, even when it
   looks like an edge case. Never "follow-up hardening" or "outside the threat model" unless the
   task says so; if it does, quote the line. (L47)
3. Behaviour the task forbids, or behaviour nobody asked for, inside a file the task requires. (L44)
4. A rule constant with no evidence, a behavioural test that remains green when its implementation is removed, original content imported, or task status written into documentation.
Not blocking: wording, style, and defects in code the PR did not change: file those as follow-ups.
When unsure, say how likely the problem is. Rate it blocking only if it is likely and would get
past what the task protects; otherwise it is a follow-up. (L53)

## Report every blocking finding in this one review

This review is your only pass before the author fixes. Do not stop at the first blocking
finding: finish reading the whole diff and the task file, check every Done-when line and
every item under "Blocking means", and report all blocking findings together.

- Before you write the verdict, make one last pass over the full diff for anything you have
  not yet rated, and say "Final pass done" as the last line before the verdict.
- Number the findings R1, R2, … in order of severity. A finding you held back because an
  earlier one was already blocking is a review defect: if two problems share a cause, list
  both and say so.
- Do not rely on a later round. The author fixes everything you list, and the next review
  checks those fixes and new code only, not anything you saw but did not report.
- If you ran out of time or context before covering the whole diff, say which files or
  sections you did not cover. Do not approve in that case.

Owner selected independent MiniMax M3 (`minimax/MiniMax-M3`, thinking). Main/native implementation is OpenAI; do not delegate or modify production. Main prepared and pushed parent acceptance before production; never edit or weaken it. Scope is only T31; T32 default AI automation and T33 packaging are separate tasks.

Use owned wrappers for every measurement: python3 docs/prototypes/new-game/T31/run-command.py review-unit npm test ; same for review-build npm run build ; focused core test; python3 docs/prototypes/new-game/T31/run-browser.py review-browser for the new real-file suite. For affected compatibility run the pinned image over all tests/e2e/*.spec.ts once (the wrapper takes --suites COMMA_SEPARATED_PATHS). List each DW command and actual results. Read source, not just author reports. Check frozen fixtures and original inherited assertions: parent-audit.py. Do not run package:playable for T31: its task does not require packaging.

Review practical production deletion controls for distinct protected classes, about6–10, rather than a large redundant matrix. Save every original runtime file as bytes before mutation; finally restore exact bytes. Archive mutant and restored source, all raw command outputs/screenshots, and hash manifests under owned T31 evidence. Never edit runtime/tests while a build/browser/mutator runs; await actual completion. Compare exact original v1 codec output/path and canonical fixed map, complete original options, omitted action defaults, unknown identities, illegal history, capture/friendly/Watch/Stop/result replay, no policy calls, next action RNG, failed-load draft/controls, file-reader generation and old timer cancellation. Decoder must never reinterpret a generated v1 save on fixed geography. Save should read authoritative current history without committing drafts or stopping work.

Mandatory artifact retention: every raw measurement must be losslessly archived under docs/prototypes/new-game/T31/evidence before final response. Fresh outputs must survive cleanup. The main runner also has an operational pre-cleanup copy hook for untracked owned files, but do not rely on it instead of archiving. Preserve failed probes and survivors honestly. Final review must distinguish each actually killed mutant from survivors/unsupported probes, and name any check not run. Never claim all probes failed merely because a summary did. No need new pixel goldens; compare existing protected goldens in pinned Playwright1.63.0-noble at both sizes. Plain nonblocking UI wording is a follow-up.

Read runtime/test/helper/tool diffs and the evidence README; verify the current implementation index with verify-evidence.py rather than dumping every historical archive or split index. Inspect targeted raw records where needed. Old preflight indexes intentionally describe restored pre-production source and are historical, not current-tree verifiers. Do not claim a stale historical index invalidates later production. No live database exports while OpenCode is running.

Current production index: artifacts.implementation.v1.json (789 files,6474members); main read the full native final before dispatch. Runtime code is commit3a0bdd2; later head changes are evidence/docs only. New pending-context tests independently showed2red before the fix. Reviewer must verify rather than trust these author claims.
