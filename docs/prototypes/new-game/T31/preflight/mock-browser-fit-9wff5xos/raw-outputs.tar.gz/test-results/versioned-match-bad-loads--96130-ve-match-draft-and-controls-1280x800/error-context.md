# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: versioned-match.spec.ts >> bad loads and generated-map files preserve the live match, draft and controls
- Location: tests/e2e/versioned-match.spec.ts:128:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   Object {
+     "fits": false,
+     "font": 12,
+     "id": "",
+   },
+ ]
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 2 human seats · Seed 0
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]: 23 provinces · 53 armies
      - generic [ref=e16]:
        - generic [ref=e17]: Seat 2
        - generic [ref=e18]: 23 provinces · 46 armies
    - contentinfo [ref=e19]:
      - button "New game" [ref=e20] [cursor=pointer]
    - generic [ref=e21]:
      - button "Save game" [active] [ref=e22] [cursor=pointer]
      - generic [ref=e23]:
        - generic [ref=e24]: Load game
        - button "Load game" [ref=e25]
      - alert [ref=e26]: "Load failed: This game uses a generated map; load it in the generated game view."
  - main [ref=e27]:
    - img "Nine Isles reference map" [ref=e29]:
      - button "River gate, Seat 1, 10 armies" [pressed] [ref=e54] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: 1 · 10
      - button "New port, Seat 2, 2 armies" [ref=e56] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: 2 · 2
      - button "North rest, Seat 1, 2 armies" [ref=e58] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: 1 · 2
      - button "River keep, Seat 2, 1 armies" [ref=e60] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: 2 · 1
      - button "North town, Seat 1, 2 armies" [ref=e62] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: 1 · 2
      - button "Dark ford, Seat 1, 3 armies" [ref=e64] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: 1 · 3
      - button "Iron point, Seat 2, 2 armies" [ref=e66] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: 2 · 2
      - button "South rest, Seat 2, 3 armies" [ref=e68] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: 2 · 3
      - button "High shore, Seat 1, 3 armies" [ref=e70] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: 1 · 3
      - button "Wind town, Seat 1, 3 armies" [ref=e72] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: 1 · 3
      - button "New glen, Seat 1, 1 armies" [ref=e74] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: 1 · 1
      - button "Old rock, Seat 2, 1 armies" [ref=e76] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: 2 · 1
      - button "Blue peak, Seat 2, 1 armies" [ref=e78] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: 2 · 1
      - button "West haven, Seat 1, 2 armies" [ref=e80] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: 1 · 2
      - button "Stone watch, Seat 2, 3 armies" [ref=e82] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: 2 · 3
      - button "Upper ridge, Seat 1, 2 armies" [ref=e84] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: 1 · 2
      - button "Marsh keep, Seat 2, 2 armies" [ref=e86] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: 2 · 2
      - button "New fell, Seat 1, 1 armies" [ref=e88] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: 1 · 1
      - button "Moon point, Seat 2, 2 armies" [ref=e90] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: 2 · 2
      - button "South fell, Seat 2, 3 armies" [ref=e92] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: 2 · 3
      - button "High ridge, Seat 2, 1 armies" [ref=e94] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: 2 · 1
        - generic [ref=e96]: ★
      - button "Bay ford, Seat 1, 3 armies" [ref=e97] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: 1 · 3
      - button "Low moor, Seat 2, 2 armies" [ref=e99] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: 2 · 2
      - button "Lower field, Seat 1, 1 armies" [ref=e101] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: 1 · 1
      - button "Wind gate, Seat 2, 2 armies" [ref=e103] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: 2 · 2
      - button "Silver shore, Seat 1, 2 armies" [ref=e105] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: 1 · 2
      - button "Low peak, Seat 1, 1 armies" [ref=e107] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: 1 · 1
      - button "Wind port, Seat 2, 3 armies" [ref=e109] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: 2 · 3
      - button "Gold point, Seat 2, 3 armies" [ref=e111] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: 2 · 3
      - button "Rock moor, Seat 1, 1 armies" [ref=e113] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: 1 · 1
      - button "Marsh rest, Seat 1, 3 armies" [ref=e115] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: 1 · 3
        - generic [ref=e117]: ★
      - button "Wind dale, Seat 1, 2 armies" [ref=e118] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: 1 · 2
      - button "Silver ford, Seat 1, 1 armies" [ref=e120] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: 1 · 1
      - button "Iron field, Seat 2, 3 armies" [ref=e122] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: 2 · 3
      - button "North wood, Seat 2, 1 armies" [ref=e124] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: 2 · 1
      - button "Fort town, Seat 1, 2 armies" [ref=e126] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: 1 · 2
      - button "Red field, Seat 2, 1 armies" [ref=e128] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: 2 · 1
      - button "South ridge, Seat 2, 3 armies" [ref=e130] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: 2 · 3
      - button "Rock bay, Seat 1, 2 armies" [ref=e132] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: 1 · 2
      - button "North ford, Seat 2, 1 armies" [ref=e134] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: 2 · 1
      - button "Port ridge, Seat 1, 3 armies" [ref=e136] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: 1 · 3
      - button "New rock, Seat 2, 3 armies" [ref=e138] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: 2 · 3
      - button "South reach, Seat 2, 1 armies" [ref=e140] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: 2 · 1
        - generic [ref=e142]: ★
      - button "Silver point, Seat 1, 1 armies" [ref=e143] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: 1 · 1
      - button "East ford, Seat 1, 2 armies" [ref=e145] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: 1 · 2
      - button "Gold town, Seat 2, 2 armies" [ref=e147] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: 2 · 2
      - generic [ref=e179]: North Isle +3
      - generic [ref=e180]: East Isle +3
      - generic [ref=e181]: West Isle +3
      - generic [ref=e182]: South Isle +3
      - generic [ref=e183]: Central Isle +5
      - generic [ref=e184]: Harbor Isle +5
      - generic [ref=e185]: Palm Isle +6
      - generic [ref=e186]: Cliff Isle +5
      - generic [ref=e187]: Great Isle +9
    - complementary [ref=e188]:
      - generic [ref=e192]:
        - generic [ref=e193]: Seat 1's turn
        - generic [ref=e194]: Round 1 · Friendly move
      - region "Friendly move" [ref=e196]:
        - heading "Friendly move" [level=2] [ref=e197]
        - generic [ref=e198]:
          - generic [ref=e199]:
            - generic [ref=e200]: From
            - strong [ref=e201]: River gate
            - generic [ref=e202]: "10"
          - generic [ref=e203]:
            - generic [ref=e204]: To
            - strong [ref=e205]: North rest
            - generic [ref=e206]: "2"
        - paragraph [ref=e207]: Move 1–9 armies. Leave at least one behind. This ends your turn.
        - generic [ref=e208]:
          - text: Armies to move
          - spinbutton "Armies to move" [ref=e209]: "9"
        - generic [ref=e210]:
          - button "Minimum" [ref=e211] [cursor=pointer]
          - button "Move one fewer army" [ref=e212] [cursor=pointer]: −
          - button "Move one more army" [ref=e213] [cursor=pointer]: +
          - button "Maximum" [ref=e214] [cursor=pointer]
        - button "Move and end turn" [ref=e215] [cursor=pointer]
        - generic [ref=e216]:
          - button "Cancel · back to attacks" [ref=e217] [cursor=pointer]
          - button "Skip move · end turn" [ref=e218] [cursor=pointer]
      - generic [ref=e219]:
        - heading "Battle log" [level=3] [ref=e220]
        - list "Battle log"
```

# Test source

```ts
  1   | import { expect, test } from "@playwright/test";
  2   | import type { Page } from "@playwright/test";
  3   | import { mkdirSync, mkdtempSync, readFileSync } from "node:fs";
  4   | import { join } from "node:path";
  5   | import * as codec from "../../src/core/match-save";
  6   | import { apply } from "../../src/core";
  7   | import type { GameState } from "../../src/core";
  8   | import { envelope, logicalState, pinned } from "../core/versioned-match-fixture";
  9   | import type { PinnedMatch } from "../core/versioned-match-fixture";
  10  | 
  11  | const country = (page: Page, id: string) => page.locator(`[data-country="${id}"]`);
  12  | const api = codec as typeof codec & { deserializeVersionedMatch?: (text: string) => { state: GameState } };
  13  | const decode = (text: string) => (api.deserializeVersionedMatch?.(text) ?? codec.deserializeMatch(text)).state;
  14  | async function download(page: Page) {
  15  |   const pending = page.waitForEvent("download");
  16  |   await page.getByRole("button", { name: "Save game", exact: true }).click();
  17  |   const file = await pending;
  18  |   expect(file.suggestedFilename()).toMatch(/^malpaco-\d+\.json$/);
  19  |   return readFileSync((await file.path())!, "utf8");
  20  | }
  21  | async function upload(page: Page, text: string, name = "resume.json") {
  22  |   await page.getByLabel("Load game", { exact: true }).setInputFiles({ name, mimeType: "application/json", buffer: Buffer.from(text) });
  23  | }
  24  | async function paint(page: Page, expected: Record<string, unknown>) {
  25  |   const owners = expected["ownerOf"] as Record<string, string>, armies = expected["armies"] as Record<string, number>;
  26  |   const actual = await page.locator("[data-country]").evaluateAll(nodes => Object.fromEntries(nodes.map(n => [n.getAttribute("data-country"), [n.getAttribute("data-owner"), Number(n.getAttribute("data-armies"))]])));
  27  |   expect(actual).toEqual(Object.fromEntries(Object.keys(owners).map(id => [id, [owners[id], armies[id]]])));
  28  | }
  29  | async function check(page: Page, fixture: PinnedMatch) {
  30  |   await expect(page.locator("[data-country]")).toHaveCount(46);
  31  |   await expect.poll(async () => await page.locator("[data-country]").evaluateAll(nodes => Object.fromEntries(nodes.map(n => [n.getAttribute("data-country"), Number(n.getAttribute("data-armies"))])))).toEqual(fixture.expected["armies"]);
  32  |   await paint(page, fixture.expected);
  33  |   const text = await download(page);
  34  |   expect(JSON.parse(text)).toEqual(envelope(fixture.options, fixture.actions));
  35  |   expect(logicalState(decode(text))).toEqual(fixture.expected);
  36  |   return text;
  37  | }
  38  | async function setup(page: Page) {
  39  |   await page.goto("/?view=reference-game&control=manual");
  40  |   await expect(page.getByRole("heading", { name: "New reference game", exact: true })).toBeVisible();
  41  | }
  42  | async function capture(page: Page, label: string, project: string) {
  43  |   const root = process.env["VERSIONED_MATCH_EVIDENCE_DIR"] ?? "screenshots";
  44  |   mkdirSync(root, { recursive: true });
  45  |   const selectors = "#reference-save-game,#reference-load-game-file,.match-error:not(:empty),#turn-title,#confirm-capture-button,#confirm-friendly-move-button,#victory-reason";
  46  |   const boxes = await page.locator(selectors).evaluateAll(nodes => nodes.filter(n => n.getClientRects().length).map(n => {
  47  |     const r = n.getBoundingClientRect(); return { id: n.id, font: parseFloat(getComputedStyle(n).fontSize), fits: r.left >= 0 && r.top >= 0 && r.right <= innerWidth + 1 && r.bottom <= innerHeight + 1 };
  48  |   }));
  49  |   expect(boxes.length).toBeGreaterThanOrEqual(3);
> 50  |   expect(boxes.filter(b => !b.fits || b.font < 12)).toEqual([]);
      |                                                     ^ Error: expect(received).toEqual(expected) // deep equality
  51  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  52  |   await page.screenshot({ path: join(mkdtempSync(join(root, "versioned-")), `${label}-${project}.png`) });
  53  | }
  54  | function errorsOn(page: Page) {
  55  |   const errors: string[] = [];
  56  |   page.on("pageerror", error => errors.push(error.message));
  57  |   page.on("console", message => { if (message.type() === "error") errors.push(message.text()); });
  58  |   return errors;
  59  | }
  60  | 
  61  | test("placement download/upload retains full original options and continues placement", async ({ page }, info) => {
  62  |   const errors = errorsOn(page), fixture = pinned("placement");
  63  |   await setup(page); await upload(page, fixture.text); const text = await check(page, fixture);
  64  |   await capture(page, "placement", info.project.name);
  65  |   await page.getByRole("button", { name: "New game", exact: true }).click();
  66  |   await page.getByLabel("Seed", { exact: true }).fill("42");
  67  |   await upload(page, text); await check(page, fixture);
  68  |   const action = fixture.next!.action;
  69  |   if (action.kind !== "reinforce") throw Error("Pinned placement must continue reinforcement");
  70  |   await country(page, action.province).click();
  71  |   expect(logicalState(decode(await download(page)))).toEqual(fixture.next!.expected);
  72  |   await paint(page, fixture.next!.expected); expect(errors).toEqual([]);
  73  | });
  74  | 
  75  | test("pending capture reload keeps the choice and rejects a detached old confirm", async ({ page }, info) => {
  76  |   const errors = errorsOn(page), fixture = pinned("pending-capture");
  77  |   await setup(page); await upload(page, fixture.text); const text = await check(page, fixture);
  78  |   const pending = fixture.expected["pendingCapture"] as { defaultAmount: number };
  79  |   await expect(page.locator("#capture-amount")).toHaveValue(String(pending.defaultAmount));
  80  |   const oldConfirm = await page.locator("#confirm-capture-button").elementHandle();
  81  |   await upload(page, text); await check(page, fixture);
  82  |   await oldConfirm!.evaluate(n => n.dispatchEvent(new MouseEvent("click", { bubbles: true })));
  83  |   await check(page, fixture); await capture(page, "pending-capture", info.project.name);
  84  |   await page.locator("#capture-amount").fill("1"); await page.locator("#confirm-capture-button").click();
  85  |   expect(logicalState(decode(await download(page)))).toEqual(fixture.next!.expected);
  86  |   await paint(page, fixture.next!.expected); expect(errors).toEqual([]);
  87  | });
  88  | 
  89  | test("friendly move draft is transient; completed move restores exact next turn", async ({ page }, info) => {
  90  |   const errors = errorsOn(page), fixture = pinned("move-ready"), completed = pinned("move-completed");
  91  |   const action = fixture.next!.action;
  92  |   if (action.kind !== "friendlyMove") throw Error("Pinned move must be friendlyMove");
  93  |   await setup(page); await upload(page, fixture.text); await check(page, fixture);
  94  |   await page.locator("#start-friendly-move-button").click();
  95  |   await country(page, action.from).click(); await country(page, action.to).click();
  96  |   await page.locator("#friendly-move-amount").fill("1");
  97  |   const stale = await page.locator("#confirm-friendly-move-button").elementHandle();
  98  |   const draft = await check(page, fixture); await capture(page, "move-draft", info.project.name);
  99  |   await upload(page, draft); await check(page, fixture);
  100 |   await expect(page.locator("#start-friendly-move-button")).toBeVisible();
  101 |   await expect(page.locator("#confirm-friendly-move-button")).not.toBeVisible();
  102 |   await stale!.evaluate(n => n.dispatchEvent(new MouseEvent("click", { bubbles: true })));
  103 |   await check(page, fixture);
  104 |   await page.locator("#start-friendly-move-button").click();
  105 |   await country(page, action.from).click(); await country(page, action.to).click();
  106 |   await page.locator("#friendly-move-amount").fill("1"); await page.locator("#confirm-friendly-move-button").click();
  107 |   const moved = await check(page, completed);
  108 |   await page.reload(); await upload(page, moved); await check(page, completed);
  109 |   await capture(page, "move-completed", info.project.name); expect(errors).toEqual([]);
  110 | });
  111 | 
  112 | test("victory and human-loss choices survive real files and remain usable", async ({ page }, info) => {
  113 |   const errors = errorsOn(page);
  114 |   for (const name of ["domination", "round-limit", "stop"]) {
  115 |     const fixture = pinned(name); await setup(page); await upload(page, fixture.text);
  116 |     const text = await check(page, fixture); await expect(page.locator("#victory-reason")).toBeVisible();
  117 |     await page.reload(); await upload(page, text); await check(page, fixture);
  118 |     await expect(page.locator("#end-turn-button")).not.toBeVisible();
  119 |     await capture(page, name, info.project.name);
  120 |   }
  121 |   const loss = pinned("human-loss"); await setup(page); await upload(page, loss.text); await check(page, loss);
  122 |   await page.locator("#watch-computers-button").click(); await check(page, pinned("watch"));
  123 |   await upload(page, loss.text); await check(page, loss);
  124 |   await page.locator("#stop-game-button").click(); await check(page, pinned("stop"));
  125 |   expect(errors).toEqual([]);
  126 | });
  127 | 
  128 | test("bad loads and generated-map files preserve the live match, draft and controls", async ({ page }, info) => {
  129 |   const errors = errorsOn(page), fixture = pinned("move-ready");
  130 |   const action = fixture.next!.action;
  131 |   if (action.kind !== "friendlyMove") throw Error("Expected friendly move fixture");
  132 |   await setup(page); await upload(page, fixture.text); const before = await check(page, fixture);
  133 |   await page.locator("#start-friendly-move-button").click(); await country(page, action.from).click(); await country(page, action.to).click();
  134 |   const valid = envelope(fixture.options, fixture.actions);
  135 |   for (const invalid of ["{", JSON.stringify({ ...valid, version: 99 }), JSON.stringify({ ...valid, boardGenerator: { id: "fixed-reference", version: 99 } }), JSON.stringify({ ...valid, actions: [{ kind: "attack", from: "missing", to: "missing" }] }), pinned("legacy-progress").text]) {
  136 |     await upload(page, invalid); await expect(page.getByRole("alert")).toContainText(/Load failed:/i);
  137 |     if (invalid === pinned("legacy-progress").text) await expect(page.getByRole("alert")).toContainText(/generated.*map|map.*generated/i);
  138 |     expect(await download(page)).toBe(before); await paint(page, fixture.expected);
  139 |     await expect(page.locator("#confirm-friendly-move-button")).toBeEnabled();
  140 |   }
  141 |   await capture(page, "failed-load", info.project.name);
  142 |   await page.locator("#friendly-move-amount").fill("1"); await page.locator("#confirm-friendly-move-button").click();
  143 |   await check(page, pinned("move-completed")); expect(errors).toEqual([]);
  144 | });
  145 | 
  146 | test("new game and a successful later load invalidate slow file readers", async ({ page }) => {
  147 |   const errors = errorsOn(page);
  148 |   await page.addInitScript(() => {
  149 |     const original = File.prototype.text;
  150 |     File.prototype.text = function () {
```