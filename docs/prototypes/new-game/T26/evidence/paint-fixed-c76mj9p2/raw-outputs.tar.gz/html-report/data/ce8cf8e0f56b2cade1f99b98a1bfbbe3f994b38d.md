# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: reference-game.spec.ts >> ordinary reference clicks place, attack, hand off and replay legally to a winner
- Location: tests/e2e/reference-game.spec.ts:31:1

# Error details

```
Error: [{"id":"province_41","classes":"country province neighbor","stroke":"rgb(36, 70, 84)","width":"0.9px","opacity":"1","focus":false},{"id":"province_1","classes":"country province neighbor","stroke":"rgb(36, 70, 84)","width":"0.9px","opacity":"1","focus":false},{"id":"province_18","classes":"country province neighbor","stroke":"rgb(36, 70, 84)","width":"0.9px","opacity":"1","focus":false}]

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 2 human seats · Seed 1994
  - main [ref=e6]:
    - generic [ref=e7]:
      - img "Nine Isles reference map" [ref=e8]:
        - button "River gate, Seat 1, 3 armies" [ref=e33] [cursor=pointer]:
          - generic:
            - generic: River
            - generic: gate
            - generic: 1 · 3
        - button "New port, Seat 2, 1 armies" [ref=e35] [cursor=pointer]:
          - generic:
            - generic: New
            - generic: port
            - generic: 2 · 1
        - button "North rest, Seat 1, 1 armies" [ref=e37] [cursor=pointer]:
          - generic:
            - generic: North
            - generic: rest
            - generic: 1 · 1
        - button "River keep, Seat 2, 2 armies" [ref=e39] [cursor=pointer]:
          - generic:
            - generic: River
            - generic: keep
            - generic: 2 · 2
        - button "North town, Seat 1, 2 armies" [ref=e41] [cursor=pointer]:
          - generic:
            - generic: North
            - generic: town
            - generic: 1 · 2
        - button "Dark ford, Seat 2, 1 armies" [ref=e43] [cursor=pointer]:
          - generic:
            - generic: Dark
            - generic: ford
            - generic: 2 · 1
        - button "Iron point, Seat 1, 3 armies" [ref=e45] [cursor=pointer]:
          - generic:
            - generic: Iron
            - generic: point
            - generic: 1 · 3
        - button "South rest, Seat 2, 2 armies" [active] [pressed] [ref=e47] [cursor=pointer]:
          - generic:
            - generic: South
            - generic: rest
            - generic: 2 · 2
        - button "High shore, Seat 2, 1 armies" [ref=e49] [cursor=pointer]:
          - generic:
            - generic: High
            - generic: shore
            - generic: 2 · 1
        - button "Wind town, Seat 1, 2 armies" [ref=e51] [cursor=pointer]:
          - generic:
            - generic: Wind
            - generic: town
            - generic: 1 · 2
        - button "New glen, Seat 2, 1 armies" [ref=e53] [cursor=pointer]:
          - generic:
            - generic: New
            - generic: glen
            - generic: 2 · 1
        - button "Old rock, Seat 1, 1 armies" [ref=e55] [cursor=pointer]:
          - generic:
            - generic: Old
            - generic: rock
            - generic: 1 · 1
        - button "Blue peak, Seat 1, 3 armies" [ref=e57] [cursor=pointer]:
          - generic:
            - generic: Blue
            - generic: peak
            - generic: 1 · 3
        - button "West haven, Seat 1, 2 armies" [ref=e59] [cursor=pointer]:
          - generic:
            - generic: West
            - generic: haven
            - generic: 1 · 2
        - button "Stone watch, Seat 1, 3 armies" [ref=e61] [cursor=pointer]:
          - generic:
            - generic: Stone
            - generic: watch
            - generic: 1 · 3
        - button "Upper ridge, Seat 2, 2 armies" [ref=e63] [cursor=pointer]:
          - generic:
            - generic: Upper
            - generic: ridge
            - generic: 2 · 2
        - button "Marsh keep, Seat 2, 3 armies" [ref=e65] [cursor=pointer]:
          - generic:
            - generic: Marsh
            - generic: keep
            - generic: 2 · 3
        - button "New fell, Seat 2, 10 armies" [ref=e67] [cursor=pointer]:
          - generic:
            - generic: New
            - generic: fell
            - generic: 2 · 10
        - button "Moon point, Seat 1, 2 armies" [ref=e69] [cursor=pointer]:
          - generic:
            - generic: Moon
            - generic: point
            - generic: 1 · 2
        - button "South fell, Seat 2, 2 armies" [ref=e71] [cursor=pointer]:
          - generic:
            - generic: South
            - generic: fell
            - generic: 2 · 2
        - button "High ridge, Seat 1, 2 armies" [ref=e73] [cursor=pointer]:
          - generic:
            - generic: High
            - generic: ridge
            - generic: 1 · 2
        - button "Bay ford, Seat 1, 2 armies" [ref=e75] [cursor=pointer]:
          - generic:
            - generic: Bay
            - generic: ford
            - generic: 1 · 2
        - button "Low moor, Seat 2, 2 armies" [ref=e77] [cursor=pointer]:
          - generic:
            - generic: Low
            - generic: moor
            - generic: 2 · 2
        - button "Lower field, Seat 2, 1 armies" [ref=e79] [cursor=pointer]:
          - generic:
            - generic: Lower
            - generic: field
            - generic: 2 · 1
        - button "Wind gate, Seat 1, 2 armies" [ref=e81] [cursor=pointer]:
          - generic:
            - generic: Wind
            - generic: gate
            - generic: 1 · 2
        - button "Silver shore, Seat 2, 1 armies" [ref=e83] [cursor=pointer]:
          - generic:
            - generic: Silver
            - generic: shore
            - generic: 2 · 1
        - button "Low peak, Seat 1, 2 armies" [ref=e85] [cursor=pointer]:
          - generic:
            - generic: Low
            - generic: peak
            - generic: 1 · 2
        - button "Wind port, Seat 2, 3 armies" [ref=e87] [cursor=pointer]:
          - generic:
            - generic: Wind
            - generic: port
            - generic: 2 · 3
        - button "Gold point, Seat 1, 3 armies" [ref=e89] [cursor=pointer]:
          - generic:
            - generic: Gold
            - generic: point
            - generic: 1 · 3
          - generic [ref=e91]: ★
        - button "Rock moor, Seat 2, 3 armies" [ref=e92] [cursor=pointer]:
          - generic:
            - generic: Rock
            - generic: moor
            - generic: 2 · 3
        - button "Marsh rest, Seat 1, 2 armies" [ref=e94] [cursor=pointer]:
          - generic:
            - generic: Marsh
            - generic: rest
            - generic: 1 · 2
        - button "Wind dale, Seat 2, 2 armies" [ref=e96] [cursor=pointer]:
          - generic:
            - generic: Wind
            - generic: dale
            - generic: 2 · 2
        - button "Silver ford, Seat 2, 3 armies" [ref=e98] [cursor=pointer]:
          - generic:
            - generic: Silver
            - generic: ford
            - generic: 2 · 3
        - button "Iron field, Seat 2, 1 armies" [ref=e100] [cursor=pointer]:
          - generic:
            - generic: Iron
            - generic: field
            - generic: 2 · 1
        - button "North wood, Seat 2, 2 armies" [ref=e102] [cursor=pointer]:
          - generic:
            - generic: North
            - generic: wood
            - generic: 2 · 2
        - button "Fort town, Seat 1, 1 armies" [ref=e104] [cursor=pointer]:
          - generic:
            - generic: Fort
            - generic: town
            - generic: 1 · 1
          - generic [ref=e106]: ★
        - button "Red field, Seat 1, 2 armies" [ref=e107] [cursor=pointer]:
          - generic:
            - generic: Red
            - generic: field
            - generic: 1 · 2
          - generic [ref=e109]: ★
        - button "South ridge, Seat 2, 2 armies" [ref=e110] [cursor=pointer]:
          - generic:
            - generic: South
            - generic: ridge
            - generic: 2 · 2
        - button "Rock bay, Seat 1, 1 armies" [ref=e112] [cursor=pointer]:
          - generic:
            - generic: Rock
            - generic: bay
            - generic: 1 · 1
        - button "North ford, Seat 2, 2 armies" [ref=e114] [cursor=pointer]:
          - generic:
            - generic: North
            - generic: ford
            - generic: 2 · 2
        - button "Port ridge, Seat 1, 3 armies" [ref=e116] [cursor=pointer]:
          - generic:
            - generic: Port
            - generic: ridge
            - generic: 1 · 3
        - button "New rock, Seat 2, 2 armies" [ref=e118] [cursor=pointer]:
          - generic:
            - generic: New
            - generic: rock
            - generic: 2 · 2
        - button "South reach, Seat 1, 1 armies" [ref=e120] [cursor=pointer]:
          - generic:
            - generic: South
            - generic: reach
            - generic: 1 · 1
        - button "Silver point, Seat 1, 2 armies" [ref=e122] [cursor=pointer]:
          - generic:
            - generic: Silver
            - generic: point
            - generic: 1 · 2
        - button "East ford, Seat 2, 2 armies" [ref=e124] [cursor=pointer]:
          - generic:
            - generic: East
            - generic: ford
            - generic: 2 · 2
        - button "Gold town, Seat 2, 2 armies" [ref=e126] [cursor=pointer]:
          - generic:
            - generic: Gold
            - generic: town
            - generic: 2 · 2
        - generic [ref=e158]: North Isle +3
        - generic [ref=e159]: East Isle +3
        - generic [ref=e160]: West Isle +3
        - generic [ref=e161]: South Isle +3
        - generic [ref=e162]: Central Isle +5
        - generic [ref=e163]: Harbor Isle +5
        - generic [ref=e164]: Palm Isle +6
        - generic [ref=e165]: Cliff Isle +5
        - generic [ref=e166]: Great Isle +9
      - tooltip "South rest Seat 2 · 2 armies West Isle · island bonus 3":
        - strong: South rest
        - generic: Seat 2 · 2 armies
        - generic: West Isle · island bonus 3
    - complementary [ref=e167]:
      - generic [ref=e171]:
        - generic [ref=e172]: Seat 2's turn
        - generic [ref=e173]: Round 1 · Attack
      - generic [ref=e174]:
        - generic [ref=e178]:
          - generic [ref=e179]: Seat 1
          - generic [ref=e180]: 22 provinces · 45 armies
        - generic [ref=e184]:
          - generic [ref=e185]: Seat 2
          - generic [ref=e186]: 24 provinces · 53 armies
      - generic [ref=e187]:
        - list [ref=e189]:
          - listitem [ref=e190]:
            - generic [ref=e191]: "1"
            - generic [ref=e192]: From
            - generic [ref=e193]: South rest (2)
          - listitem [ref=e194]:
            - generic [ref=e195]: "2"
            - generic [ref=e196]: Target
            - generic [ref=e197]: adjacent enemy
          - listitem [ref=e198]:
            - generic [ref=e199]: "3"
            - generic [ref=e200]: Then
            - generic [ref=e201]: —
        - paragraph [ref=e202]: South rest can attack 3 provinces. Pick a target.
        - generic [ref=e203]:
          - button "Attack" [disabled] [ref=e204]
          - button "End turn" [ref=e205] [cursor=pointer]
        - paragraph [ref=e206]: "Dashed outline on every target, and a marker where one fits: provinces you can attack from the selected one."
      - generic [ref=e210]:
        - heading "Battle log" [level=3] [ref=e211]
        - list "Battle log" [ref=e212]:
          - listitem [ref=e213]: "T1 Seat 2: Lower field → High shore, took High shore"
      - generic [ref=e214]:
        - button "New game" [ref=e215] [cursor=pointer]
        - generic [ref=e216]: seed 1994
```

# Test source

```ts
  1  | import {test,expect} from "@playwright/test";
  2  | import type {Page} from "@playwright/test";
  3  | import {mkdirSync,mkdtempSync,readFileSync} from "node:fs";
  4  | import {join} from "node:path";
  5  | import type fixtureData from "../../docs/prototypes/new-game/T63/board.json";
  6  | const raw:typeof fixtureData=JSON.parse(readFileSync(new URL("../../docs/prototypes/new-game/T63/board.json",import.meta.url),"utf8"));
  7  | import {createReferenceGame} from "../../src/core/reference-game";
  8  | import {defaultOptions,apply,attackTargets} from "../../src/core";
  9  | import type {GameMap,Province} from "../../src/core";
  10 | import {nextAction,policyFor,ACTION_BUDGET} from "../helpers/complete-game";
  11 | const map:GameMap={id:"reference-coast-first-a",name:"Nine Isles",bounds:raw.bounds,provinces:raw.provinces as unknown as readonly Province[],islands:raw.islands};
  12 | function opening(){const r=createReferenceGame(map,{...defaultOptions(),seed:1994,seats:[{kind:"human"},{kind:"human"}],computerStrengths:[]});if(!r.ok)throw Error(r.errors.join(";"));return r.state;}
  13 | const country=(page:Page,id:string)=>page.locator(`[data-country="${id}"]`);
  14 | async function setup(page:Page){await page.goto("/?view=reference-game");await expect(page.getByRole("heading",{name:"New reference game",exact:true})).toBeVisible();await page.getByLabel("Seed",{exact:true}).fill("1994");await page.getByLabel("Human seats").selectOption("2");await page.getByRole("button",{name:"Start game",exact:true}).click();await expect(page.locator("#reference-game")).toBeVisible();}
  15 | async function capture(page:Page,name:string,project:string){const root=process.env["REFERENCE_EVIDENCE_DIR"]??"screenshots";mkdirSync(root,{recursive:true});const dir=mkdtempSync(join(root,"reference-"));await page.mouse.move(0,0);await page.screenshot({path:join(dir,`${name}-${project}.png`)});}
  16 | test("reference setup paints exact A geometry, routes, live counts and reachable controls",async({page},info)=>{
  17 |  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));await setup(page);const state=opening();
  18 |  await expect(page.locator("[data-country]")).toHaveCount(46);
  19 |  for(const p of map.provinces){const n=country(page,p.id);await expect(n.locator(".country-shape")).toHaveAttribute("d","M"+p.polygon.map(q=>q.join(",")).join("L")+"Z");await expect(n).toHaveAttribute("data-owner",state.ownerOf[p.id]!);await expect(n).toHaveAttribute("data-armies",String(state.armies[p.id]));await expect(n.locator(".army-count")).toHaveText(`${state.players.findIndex(q=>q.id===state.ownerOf[p.id])+1} · ${state.armies[p.id]}`);}
  20 |  expect(await page.locator(".lane").evaluateAll(ns=>ns.map(n=>({edge:(n as SVGElement).dataset["edge"],points:n.getAttribute("points")})))).toEqual(raw.routes.map(r=>({edge:[r.from,r.to].sort().join("|"),points:r.points.map(p=>p.join(",")).join(" ")})));
  21 |  const text=await page.locator(".country-label").evaluateAll(ns=>ns.map(n=>{const b=n.getBoundingClientRect(),count=n.querySelector(".army-count")!,s=getComputedStyle(count),m=(count as SVGGraphicsElement).getScreenCTM()!;return {x:b.x,y:b.y,right:b.right,bottom:b.bottom,width:b.width,height:b.height,countPx:parseFloat(s.fontSize)*Math.hypot(m.a,m.b),display:s.display,opacity:s.opacity};}));
  22 |  const v=page.viewportSize()!;for(const t of text){expect(t.width).toBeGreaterThan(0);expect(t.height).toBeGreaterThan(0);expect(t.countPx).toBeGreaterThanOrEqual(14-.01);expect(t.display).not.toBe("none");expect(Number(t.opacity)).toBeGreaterThan(0);expect(t.x).toBeGreaterThanOrEqual(0);expect(t.y).toBeGreaterThanOrEqual(0);expect(t.right).toBeLessThanOrEqual(v.width);expect(t.bottom).toBeLessThanOrEqual(v.height);}
  23 |  for(let i=0;i<text.length;i++)for(let j=i+1;j<text.length;j++){const a=text[i]!,b=text[j]!;expect(a.right<=b.x||b.right<=a.x||a.bottom<=b.y||b.bottom<=a.y,"labels overlap").toBe(true);}
  24 |  for(const id of ["start-combat-button","end-turn-button","attack-button","new-game-button"]){await expect(page.locator(`#${id}`)).toBeVisible();const b=await page.locator(`#${id}`).boundingBox();expect(b).not.toBeNull();expect(b!.x+b!.width).toBeLessThanOrEqual(v.width);expect(b!.y+b!.height).toBeLessThanOrEqual(v.height);}
  25 |  const first=country(page,map.provinces[0]!.id),second=country(page,map.provinces[1]!.id);await first.focus();
  26 |  for(const[key,target]of [["ArrowRight",second],["ArrowLeft",first],["ArrowDown",second],["ArrowUp",first]] as const){await page.keyboard.press(key);await expect(target).toBeFocused();}await first.evaluate(n=>(n as SVGElement).blur());
  27 |  await capture(page,"opening",info.project.name);await expect(page.locator("#reference-game")).toHaveScreenshot("reference-game.png");
  28 |  for(const seats of [3,4]){await page.locator("#new-game-button").click();await page.getByLabel("Human seats").selectOption(String(seats));await page.getByRole("button",{name:"Start game",exact:true}).click();await expect(page.locator("[data-player]")).toHaveCount(seats);for(const id of ["start-combat-button","end-turn-button","attack-button","new-game-button"]){const b=await page.locator(`#${id}`).boundingBox();expect(b).not.toBeNull();expect(b!.x+b!.width).toBeLessThanOrEqual(v.width);expect(b!.y+b!.height).toBeLessThanOrEqual(v.height);}await capture(page,`${seats}-seats`,info.project.name);}
  29 |  expect(errors).toEqual([]);
  30 | });
  31 | test("ordinary reference clicks place, attack, hand off and replay legally to a winner",async({page},info)=>{
  32 |  test.setTimeout(240000);const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));await page.emulateMedia({reducedMotion:"reduce"});await setup(page);
  33 |  let state=opening();const policy=policyFor(state);let actions=0,attacks=0,handoffs=0,placements=0;
  34 |  while(state.phase!=="finished"&&actions<ACTION_BUDGET){
  35 |   const action=nextAction(state,policy),r=apply(state,action);if(!r.ok)throw Error(r.error);
  36 |   if(action.kind==="reinforce"){await country(page,action.province).click();placements++;await expect(page.locator("#reinforcement-pool")).toHaveText(String(r.state.reinforcementPool));await expect(country(page,action.province).locator(".army-count")).toHaveText(`${r.state.players.findIndex(p=>p.id===r.state.ownerOf[action.province])+1} · ${r.state.armies[action.province]}`);}
  37 |   else if(action.kind==="endReinforcement")await page.locator("#start-combat-button").click();
  38 |   else if(action.kind==="endTurn"){await page.locator("#end-turn-button").click();handoffs++;await expect(page.locator("#turn-title")).toHaveText(`${r.state.players[r.state.currentPlayer]!.name}'s turn`);}
  39 |   else{
  40 |    const from=country(page,action.from);if(attacks===0){await from.focus();await page.keyboard.press("Enter");await expect(from).toHaveAttribute("aria-pressed","true");}else if(await from.getAttribute("aria-pressed")!=="true")await from.click();
  41 |    expect(await page.locator('[data-target="true"]').evaluateAll(ns=>ns.map(n=>(n as SVGElement).dataset["country"]).sort())).toEqual([...attackTargets(state,action.from)].sort());
  42 |    // Integration guard: legal target markers must correspond to painted outlines.
  43 |    const paint=await page.locator('[data-target="true"] .cell').evaluateAll(ns=>ns.map(n=>{const s=getComputedStyle(n);return {id:(n.closest(".country") as SVGElement).dataset["country"],classes:n.closest(".country")!.getAttribute("class"),stroke:s.stroke,width:s.strokeWidth,opacity:s.opacity,focus:n.closest(".country")===document.activeElement};}));
> 44 |    expect(paint.every(s=>s.stroke==="rgb(245, 220, 130)"&&parseFloat(s.width)>=1.5&&Number(s.opacity)>0),JSON.stringify(paint)).toBe(true);
     |                                                                                                                                 ^ Error: [{"id":"province_41","classes":"country province neighbor","stroke":"rgb(36, 70, 84)","width":"0.9px","opacity":"1","focus":false},{"id":"province_1","classes":"country province neighbor","stroke":"rgb(36, 70, 84)","width":"0.9px","opacity":"1","focus":false},{"id":"province_18","classes":"country province neighbor","stroke":"rgb(36, 70, 84)","width":"0.9px","opacity":"1","focus":false}]
  45 |    await country(page,action.to).click();await page.locator("#attack-button").click();await expect(page.locator("#result-dialog")).toBeVisible();
  46 |    for(const id of [action.from,action.to]){await expect(country(page,id)).toHaveAttribute("data-owner",r.state.ownerOf[id]!);await expect(country(page,id)).toHaveAttribute("data-armies",String(r.state.armies[id]));await expect(country(page,id).locator(".army-count")).toHaveText(`${r.state.players.findIndex(p=>p.id===r.state.ownerOf[id])+1} · ${r.state.armies[id]}`);}
  47 |    if(attacks===0)await capture(page,"first-attack",info.project.name);attacks++;await page.getByRole("button",{name:"Continue",exact:true}).click();
  48 |   }
  49 |   state=r.state;actions++;
  50 |  }
  51 |  expect(actions).toBeLessThan(ACTION_BUDGET);expect(placements).toBeGreaterThan(0);expect(attacks).toBeGreaterThan(0);expect(handoffs).toBeGreaterThan(0);expect(state.phase).toBe("finished");expect(state.winner).toBe(policy.conqueror);
  52 |  const winner=state.players.find(p=>p.id===state.winner)!;await expect(page.locator("#turn-title")).toHaveText(`${winner.name} conquers the sea`);await expect(page.locator(`#attack-button`)).toBeDisabled();await expect(page.locator("#new-game-button")).toBeEnabled();await capture(page,"winner",info.project.name);
  53 |  await page.locator("#new-game-button").click();await expect(page.getByRole("heading",{name:"New reference game",exact:true})).toBeVisible();await expect(page.getByLabel("Seed",{exact:true})).toHaveValue("1994");
  54 |  console.log(JSON.stringify({project:info.project.name,actions,attacks,handoffs,placements,winner:state.winner}));expect(errors).toEqual([]);
  55 | });
  56 | 
```