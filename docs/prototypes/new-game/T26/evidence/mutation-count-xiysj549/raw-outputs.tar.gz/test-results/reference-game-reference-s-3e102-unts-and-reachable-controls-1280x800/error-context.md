# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: reference-game.spec.ts >> reference setup paints exact A geometry, routes, live counts and reachable controls
- Location: tests/e2e/reference-game.spec.ts:24:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  locator('[data-country="province_4"]').locator('.army-count')
Expected: "1 · 3"
Received: "1 · 2"
Timeout:  5000ms

Call log:
  - Expect "toHaveText" locator('[data-country="province_4"]').locator('.army-count') with timeout 5000ms
  - waiting for locator('[data-country="province_4"]').locator('.army-count')
    14 × locator resolved to <text y="66" x="374" class="count army-count">1 · 2</text>
       - unexpected value "1 · 2"

```

```yaml
- text: 1 · 2
```

# Test source

```ts
  1  | import {test,expect} from "@playwright/test";
  2  | import type {Page} from "@playwright/test";
  3  | import {mkdirSync,mkdtempSync,readFileSync} from "node:fs";
  4  | import {join} from "node:path";
  5  | import type fixtureData from "../../docs/prototypes/new-game/T63/board.json";
  6  | const raw:typeof fixtureData=JSON.parse(readFileSync(new URL("../../docs/prototypes/new-game/T63/board.json",import.meta.url),"utf8"));
  7  | import {createReferenceGame} from "../../src/core/reference-game";
  8  | import {defaultOptions,apply,attackTargets} from "../../src/core";
  9  | import type {GameMap,Province} from "../../src/core";
  10 | import {nextAction,policyFor,ACTION_BUDGET} from "../helpers/complete-game";
  11 | const map:GameMap={id:"reference-coast-first-a",name:"Nine Isles",bounds:raw.bounds,provinces:raw.provinces as unknown as readonly Province[],islands:raw.islands};
  12 | function opening(){const r=createReferenceGame(map,{...defaultOptions(),seed:1994,seats:[{kind:"human"},{kind:"human"}],computerStrengths:[]});if(!r.ok)throw Error(r.errors.join(";"));return r.state;}
  13 | const country=(page:Page,id:string)=>page.locator(`[data-country="${id}"]`);
  14 | async function setup(page:Page){await page.goto("/?view=reference-game");await expect(page.getByRole("heading",{name:"New reference game",exact:true})).toBeVisible();await page.getByLabel("Seed",{exact:true}).fill("1994");await page.getByLabel("Human seats").selectOption("2");await page.getByRole("button",{name:"Start game",exact:true}).click();await expect(page.locator("#reference-game")).toBeVisible();}
  15 | async function capture(page:Page,name:string,project:string){const root=process.env["REFERENCE_EVIDENCE_DIR"]??"screenshots";mkdirSync(root,{recursive:true});const dir=mkdtempSync(join(root,"reference-"));await page.mouse.move(0,0);await page.screenshot({path:join(dir,`${name}-${project}.png`)});}
  16 | async function panelTextFits(page:Page){
  17 |  // [designed] One CSS pixel for rectangle rounding, as in the existing complete-game fit guard.
  18 |  const boxes=await page.locator(".panel .score-num,.panel .score-name,.panel .turn-title,.panel .turn-sub,.panel .step-value,.panel button").evaluateAll(nodes=>nodes.map(n=>{
  19 |   const range=document.createRange();range.selectNodeContents(n);const lines=[...range.getClientRects()];const panel=n.closest(".panel")!.getBoundingClientRect(),card=(n.closest(".card")??n.parentElement)!.getBoundingClientRect();
  20 |   return {text:n.textContent,visible:lines.length>0,fits:lines.every(b=>b.left>=Math.max(0,panel.left,card.left)-1&&b.right<=Math.min(innerWidth,panel.right,card.right)+1&&b.top>=Math.max(0,panel.top,card.top)-1&&b.bottom<=Math.min(innerHeight,panel.bottom,card.bottom)+1)};
  21 |  })).then(rows=>rows.filter(r=>r.visible));
  22 |  expect(boxes.length).toBeGreaterThan(4);expect(boxes.filter(b=>!b.fits)).toEqual([]);
  23 | }
  24 | test("reference setup paints exact A geometry, routes, live counts and reachable controls",async({page},info)=>{
  25 |  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));await setup(page);const state=opening();
  26 |  await expect(page.locator("[data-country]")).toHaveCount(46);
> 27 |  for(const p of map.provinces){const n=country(page,p.id);await expect(n.locator(".country-shape")).toHaveAttribute("d","M"+p.polygon.map(q=>q.join(",")).join("L")+"Z");await expect(n).toHaveAttribute("data-owner",state.ownerOf[p.id]!);await expect(n).toHaveAttribute("data-armies",String(state.armies[p.id]));await expect(n.locator(".army-count")).toHaveText(`${state.players.findIndex(q=>q.id===state.ownerOf[p.id])+1} · ${state.armies[p.id]}`);}
     |                                                                                                                                                                                                                                                                                                                                                              ^ Error: expect(locator).toHaveText(expected) failed
  28 |  expect(await page.locator(".lane").evaluateAll(ns=>ns.map(n=>({edge:(n as SVGElement).dataset["edge"],points:n.getAttribute("points")})))).toEqual(raw.routes.map(r=>({edge:[r.from,r.to].sort().join("|"),points:r.points.map(p=>p.join(",")).join(" ")})));
  29 |  const text=await page.locator(".country-label").evaluateAll(ns=>ns.map(n=>{const b=n.getBoundingClientRect(),count=n.querySelector(".army-count")!,s=getComputedStyle(count),m=(count as SVGGraphicsElement).getScreenCTM()!;return {x:b.x,y:b.y,right:b.right,bottom:b.bottom,width:b.width,height:b.height,countPx:parseFloat(s.fontSize)*Math.hypot(m.a,m.b),display:s.display,opacity:s.opacity};}));
  30 |  const v=page.viewportSize()!;for(const t of text){expect(t.width).toBeGreaterThan(0);expect(t.height).toBeGreaterThan(0);expect(t.countPx).toBeGreaterThanOrEqual(14-.01);expect(t.display).not.toBe("none");expect(Number(t.opacity)).toBeGreaterThan(0);expect(t.x).toBeGreaterThanOrEqual(0);expect(t.y).toBeGreaterThanOrEqual(0);expect(t.right).toBeLessThanOrEqual(v.width);expect(t.bottom).toBeLessThanOrEqual(v.height);}
  31 |  for(let i=0;i<text.length;i++)for(let j=i+1;j<text.length;j++){const a=text[i]!,b=text[j]!;expect(a.right<=b.x||b.right<=a.x||a.bottom<=b.y||b.bottom<=a.y,"labels overlap").toBe(true);}
  32 |  for(const id of ["start-combat-button","end-turn-button","attack-button","new-game-button"]){await expect(page.locator(`#${id}`)).toBeVisible();const b=await page.locator(`#${id}`).boundingBox();expect(b).not.toBeNull();expect(b!.x+b!.width).toBeLessThanOrEqual(v.width);expect(b!.y+b!.height).toBeLessThanOrEqual(v.height);}
  33 |  const first=country(page,map.provinces[0]!.id),second=country(page,map.provinces[1]!.id);await first.focus();
  34 |  for(const[key,target]of [["ArrowRight",second],["ArrowLeft",first],["ArrowDown",second],["ArrowUp",first]] as const){await page.keyboard.press(key);await expect(target).toBeFocused();}await first.evaluate(n=>(n as SVGElement).blur());
  35 |  await panelTextFits(page);await capture(page,"opening",info.project.name);await expect(page.locator("#reference-game")).toHaveScreenshot("reference-game.png");
  36 |  for(const seats of [3,4]){await page.locator("#new-game-button").click();await page.getByLabel("Human seats").selectOption(String(seats));await page.getByRole("button",{name:"Start game",exact:true}).click();await expect(page.locator("[data-player]")).toHaveCount(seats);for(const id of ["start-combat-button","end-turn-button","attack-button","new-game-button"]){const b=await page.locator(`#${id}`).boundingBox();expect(b).not.toBeNull();expect(b!.x+b!.width).toBeLessThanOrEqual(v.width);expect(b!.y+b!.height).toBeLessThanOrEqual(v.height);}await panelTextFits(page);await capture(page,`${seats}-seats`,info.project.name);}
  37 |  expect(errors).toEqual([]);
  38 | });
  39 | test("ordinary reference clicks place, attack, hand off and replay legally to a winner",async({page},info)=>{
  40 |  test.setTimeout(240000);const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));await page.emulateMedia({reducedMotion:"reduce"});await setup(page);
  41 |  let state=opening();const policy=policyFor(state);let actions=0,attacks=0,handoffs=0,placements=0;
  42 |  while(state.phase!=="finished"&&actions<ACTION_BUDGET){
  43 |   const action=nextAction(state,policy),r=apply(state,action);if(!r.ok)throw Error(r.error);
  44 |   if(action.kind==="reinforce"){await country(page,action.province).click();placements++;await expect(page.locator("#reinforcement-pool")).toHaveText(String(r.state.reinforcementPool));await expect(country(page,action.province).locator(".army-count")).toHaveText(`${r.state.players.findIndex(p=>p.id===r.state.ownerOf[action.province])+1} · ${r.state.armies[action.province]}`);}
  45 |   else if(action.kind==="endReinforcement")await page.locator("#start-combat-button").click();
  46 |   else if(action.kind==="endTurn"){await page.locator("#end-turn-button").click();handoffs++;await expect(page.locator("#turn-title")).toHaveText(`${r.state.players[r.state.currentPlayer]!.name}'s turn`);}
  47 |   else{
  48 |    const from=country(page,action.from);if(attacks===0){await from.focus();await page.keyboard.press("Enter");await expect(from).toHaveAttribute("aria-pressed","true");}else if(await from.getAttribute("aria-pressed")!=="true")await from.click();
  49 |    expect(await page.locator('[data-target="true"]').evaluateAll(ns=>ns.map(n=>(n as SVGElement).dataset["country"]).sort())).toEqual([...attackTargets(state,action.from)].sort());
  50 |    // Integration guard: legal target markers must correspond to painted outlines.
  51 |    await expect.poll(async()=>await page.locator('[data-target="true"] .cell').evaluateAll(ns=>ns.every(n=>{const s=getComputedStyle(n);return s.stroke==="rgb(245, 220, 130)"&&parseFloat(s.strokeWidth)>=1.5&&Number(s.opacity)>0;}))).toBe(true);
  52 |    await country(page,action.to).click();await page.locator("#attack-button").click();await expect(page.locator("#result-dialog")).toBeVisible();
  53 |    for(const id of [action.from,action.to]){await expect(country(page,id)).toHaveAttribute("data-owner",r.state.ownerOf[id]!);await expect(country(page,id)).toHaveAttribute("data-armies",String(r.state.armies[id]));await expect(country(page,id).locator(".army-count")).toHaveText(`${r.state.players.findIndex(p=>p.id===r.state.ownerOf[id])+1} · ${r.state.armies[id]}`);}
  54 |    if(attacks===0)await capture(page,"first-attack",info.project.name);attacks++;await page.getByRole("button",{name:"Continue",exact:true}).click();
  55 |   }
  56 |   state=r.state;actions++;
  57 |  }
  58 |  expect(actions).toBeLessThan(ACTION_BUDGET);expect(placements).toBeGreaterThan(0);expect(attacks).toBeGreaterThan(0);expect(handoffs).toBeGreaterThan(0);expect(state.phase).toBe("finished");expect(state.winner).toBe(policy.conqueror);
  59 |  const winner=state.players.find(p=>p.id===state.winner)!;await expect(page.locator("#turn-title")).toHaveText(`${winner.name} conquers the sea`);await expect(page.locator(`#attack-button`)).toBeDisabled();await expect(page.locator("#new-game-button")).toBeEnabled();await panelTextFits(page);await capture(page,"winner",info.project.name);
  60 |  await page.locator("#new-game-button").click();await expect(page.getByRole("heading",{name:"New reference game",exact:true})).toBeVisible();await expect(page.getByLabel("Seed",{exact:true})).toHaveValue("1994");
  61 |  console.log(JSON.stringify({project:info.project.name,actions,attacks,handoffs,placements,winner:state.winner}));expect(errors).toEqual([]);
  62 | });
  63 | 
```