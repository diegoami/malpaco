// PARENT MOCK. Original T63 visual data; rules use only the declared map graph.
import data from "../../docs/prototypes/new-game/T63/board.json";
import type {GameMap,Province} from "../core";
export const referenceData=data;
export const referenceMap:GameMap={id:"reference-coast-first-a",name:"Nine Isles",bounds:data.bounds,provinces:data.provinces as unknown as readonly Province[],islands:data.islands};
