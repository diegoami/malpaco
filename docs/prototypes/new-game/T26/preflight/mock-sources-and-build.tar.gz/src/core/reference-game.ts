// PARENT MOCK: reuse the existing pure fixed-map injection seam.
import {createGameWithRng} from "./setup";
import {DeterministicRng} from "./rng";
import {validateGameOptions} from "./options";
import type {GameMap} from "./types";
import type {GameOptions} from "./options";
export function createReferenceGame(map:GameMap,options:GameOptions){const validated=validateGameOptions(options);return createGameWithRng(validated,new DeterministicRng(validated.seed),()=>({ok:true,map}));}
