# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: reference-game.spec.ts >> ordinary reference clicks place, attack, hand off and replay legally to a winner
- Location: tests/e2e/reference-game.spec.ts:27:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'New reference game', exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: 'New reference game', exact: true }) with timeout 5000ms
  - waiting for getByRole('heading', { name: 'New reference game', exact: true })

```

```yaml
- heading "New generated game" [level=1]
- paragraph: "Choose two to four seats: all humans, or you against one to three computers."
- text: Seed
- textbox "Seed": "1994"
- paragraph: Whole number from 0 to 4294967295. The same settings recreate the same game.
- text: Players
- combobox "Players":
  - option "All human players" [selected]
  - option "You versus computers"
- text: Human seats
- combobox "Human seats":
  - option "2 seats" [selected]
  - option "3 seats"
  - option "4 seats"
- alert
- button "Start game"
- text: Load game
- button "Load game"
- button "How to play"
```

# Test source

```ts
  1  | import {test,expect} from "@playwright/test";
  2  | import type {Page} from "@playwright/test";
  3  | import {mkdirSync,mkdtempSync,readFileSync} from "node:fs";
  4  | import {join} from "node:path";
  5  | import type fixtureData from "../../docs/prototypes/new-game/T63/board.json";
  6  | const raw:typeof fixtureData=JSON.parse(readFileSync(new URL("../../docs/prototypes/new-game/T63/board.json",import.meta.url),"utf8"));
  7  | import {createReferenceGame} from "../../src/core/reference-game";
  8  | import {defaultOptions,apply,attackTargets} from "../../src/core";
  9  | import type {GameMap,Province} from "../../src/core";
  10 | import {nextAction,policyFor,ACTION_BUDGET} from "../helpers/complete-game";
  11 | const map:GameMap={id:"reference-coast-first-a",name:"Nine Isles",bounds:raw.bounds,provinces:raw.provinces as unknown as readonly Province[],islands:raw.islands};
  12 | function opening(){const r=createReferenceGame(map,{...defaultOptions(),seed:1994,seats:[{kind:"human"},{kind:"human"}],computerStrengths:[]});if(!r.ok)throw Error(r.errors.join(";"));return r.state;}
  13 | const country=(page:Page,id:string)=>page.locator(`[data-country="${id}"]`);
> 14 | async function setup(page:Page){await page.goto("/?view=reference-game");await expect(page.getByRole("heading",{name:"New reference game",exact:true})).toBeVisible();await page.getByLabel("Seed",{exact:true}).fill("1994");await page.getByLabel("Human seats").selectOption("2");await page.getByRole("button",{name:"Start game",exact:true}).click();await expect(page.locator("#reference-game")).toBeVisible();}
     |                                                                                                                                                         ^ Error: expect(locator).toBeVisible() failed
  15 | async function capture(page:Page,name:string,project:string){const root=process.env["REFERENCE_EVIDENCE_DIR"]??"screenshots";mkdirSync(root,{recursive:true});const dir=mkdtempSync(join(root,"reference-"));await page.screenshot({path:join(dir,`${name}-${project}.png`)});}
  16 | test("reference setup paints exact A geometry, routes, live counts and reachable controls",async({page},info)=>{
  17 |  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));await setup(page);const state=opening();
  18 |  await expect(page.locator("[data-country]")).toHaveCount(46);
  19 |  for(const p of map.provinces){const n=country(page,p.id);await expect(n.locator(".country-shape")).toHaveAttribute("d","M"+p.polygon.map(q=>q.join(",")).join("L")+"Z");await expect(n).toHaveAttribute("data-owner",state.ownerOf[p.id]!);await expect(n).toHaveAttribute("data-armies",String(state.armies[p.id]));await expect(n.locator(".army-count")).toHaveText(`${state.players.findIndex(q=>q.id===state.ownerOf[p.id])+1} · ${state.armies[p.id]}`);}
  20 |  expect(await page.locator(".lane").evaluateAll(ns=>ns.map(n=>({edge:(n as SVGElement).dataset["edge"],points:n.getAttribute("points")})))).toEqual(raw.routes.map(r=>({edge:[r.from,r.to].sort().join("|"),points:r.points.map(p=>p.join(",")).join(" ")})));
  21 |  const text=await page.locator(".country-label").evaluateAll(ns=>ns.map(n=>{const b=n.getBoundingClientRect(),count=n.querySelector(".army-count")!,s=getComputedStyle(count),m=(count as SVGGraphicsElement).getScreenCTM()!;return {x:b.x,y:b.y,right:b.right,bottom:b.bottom,width:b.width,height:b.height,countPx:parseFloat(s.fontSize)*Math.hypot(m.a,m.b),display:s.display,opacity:s.opacity};}));
  22 |  const v=page.viewportSize()!;for(const t of text){expect(t.width).toBeGreaterThan(0);expect(t.height).toBeGreaterThan(0);expect(t.countPx).toBeGreaterThanOrEqual(14-.01);expect(t.display).not.toBe("none");expect(Number(t.opacity)).toBeGreaterThan(0);expect(t.x).toBeGreaterThanOrEqual(0);expect(t.y).toBeGreaterThanOrEqual(0);expect(t.right).toBeLessThanOrEqual(v.width);expect(t.bottom).toBeLessThanOrEqual(v.height);}
  23 |  for(let i=0;i<text.length;i++)for(let j=i+1;j<text.length;j++){const a=text[i]!,b=text[j]!;expect(a.right<=b.x||b.right<=a.x||a.bottom<=b.y||b.bottom<=a.y,"labels overlap").toBe(true);}
  24 |  for(const id of ["start-combat-button","end-turn-button","attack-button","new-game-button"]){await expect(page.locator(`#${id}`)).toBeVisible();const b=await page.locator(`#${id}`).boundingBox();expect(b).not.toBeNull();expect(b!.x+b!.width).toBeLessThanOrEqual(v.width);expect(b!.y+b!.height).toBeLessThanOrEqual(v.height);}
  25 |  await capture(page,"opening",info.project.name);await expect(page.locator("#reference-game")).toHaveScreenshot("reference-game.png");expect(errors).toEqual([]);
  26 | });
  27 | test("ordinary reference clicks place, attack, hand off and replay legally to a winner",async({page},info)=>{
  28 |  test.setTimeout(240000);const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));await page.emulateMedia({reducedMotion:"reduce"});await setup(page);
  29 |  let state=opening();const policy=policyFor(state);let actions=0,attacks=0,handoffs=0,placements=0;
  30 |  while(state.phase!=="finished"&&actions<ACTION_BUDGET){
  31 |   const action=nextAction(state,policy),r=apply(state,action);if(!r.ok)throw Error(r.error);
  32 |   if(action.kind==="reinforce"){await country(page,action.province).click();placements++;await expect(page.locator("#reinforcement-pool")).toHaveText(String(r.state.reinforcementPool));}
  33 |   else if(action.kind==="endReinforcement")await page.locator("#start-combat-button").click();
  34 |   else if(action.kind==="endTurn"){await page.locator("#end-turn-button").click();handoffs++;await expect(page.locator("#turn-title")).toHaveText(`${r.state.players[r.state.currentPlayer]!.name}'s turn`);}
  35 |   else{
  36 |    const from=country(page,action.from);if(await from.getAttribute("aria-pressed")!=="true")await from.click();
  37 |    expect(await page.locator('[data-target="true"]').evaluateAll(ns=>ns.map(n=>(n as SVGElement).dataset["country"]).sort())).toEqual([...attackTargets(state,action.from)].sort());
  38 |    await country(page,action.to).click();await page.locator("#attack-button").click();await expect(page.locator("#result-dialog")).toBeVisible();
  39 |    for(const id of [action.from,action.to]){await expect(country(page,id)).toHaveAttribute("data-owner",r.state.ownerOf[id]!);await expect(country(page,id)).toHaveAttribute("data-armies",String(r.state.armies[id]));}
  40 |    if(attacks===0)await capture(page,"first-attack",info.project.name);attacks++;await page.getByRole("button",{name:"Continue",exact:true}).click();
  41 |   }
  42 |   state=r.state;actions++;
  43 |  }
  44 |  expect(actions).toBeLessThan(ACTION_BUDGET);expect(placements).toBeGreaterThan(0);expect(attacks).toBeGreaterThan(0);expect(handoffs).toBeGreaterThan(0);expect(state.phase).toBe("finished");expect(state.winner).toBe(policy.conqueror);
  45 |  const winner=state.players.find(p=>p.id===state.winner)!;await expect(page.locator("#turn-title")).toHaveText(`${winner.name} conquers the sea`);await expect(page.locator(`#attack-button`)).toBeDisabled();await expect(page.locator("#new-game-button")).toBeEnabled();await capture(page,"winner",info.project.name);
  46 |  console.log(JSON.stringify({project:info.project.name,actions,attacks,handoffs,placements,winner:state.winner}));expect(errors).toEqual([]);
  47 | });
  48 | 
```