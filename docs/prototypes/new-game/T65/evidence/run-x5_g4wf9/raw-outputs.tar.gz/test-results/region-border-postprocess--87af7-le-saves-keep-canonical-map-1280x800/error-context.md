# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: region-border-postprocess.spec.ts >> playable shared borders uses new paint/hit positions and ordinary deterministic attacks while saves keep canonical map
- Location: tests/e2e/region-border-postprocess.spec.ts:58:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  locator('[data-id="province_4"]').locator('.cell')
Expected: "M327.9755859375,60.34765625L334.369140625,50.3310546875L341.2900390625,40.1845703125L349.9521484375,30.09765625L361.59765625,21.1962890625L376.3408203125,14.9287109375L383.310546875,13.7587890625L384.5087890625,19.3427734375L386.01171875,24.806640625L387.7578125,30.1767578125L389.5888671875,35.5126953125L391.3525390625,40.875L392.986328125,46.2880859375L394.568359375,51.7216796875L396.2822265625,57.103515625L398.3291015625,62.35546875L400.82421875,67.431640625L403.7939453125,72.322265625L406.8974609375,77.1611328125L410,82L405.83203125,86.1796875L400.9296875,89.3759765625L396.623046875,93.3701171875L392.9208984375,98.173828125L388.21875,101.6376953125L383.4619140625,105.029296875L378.7392578125,108.4658203125L374.0849609375,111.994140625L369.4697265625,115.5751953125L364.8115234375,119.0986328125L360.013671875,122.4345703125L355.0126953125,125.4990234375L349.8125,128.2958984375L344.4853515625,130.923828125L338.0576171875,125.783203125L328.6064453125,116.0830078125L321.4072265625,105.38671875L317.685546875,93.8056640625L318.13671875,82L322.1142578125,70.7607421875Z"
Received: "M327.9755859375,60.34765625L334.369140625,50.3310546875L341.2900390625,40.1845703125L349.9521484375,30.09765625L361.59765625,21.1962890625L376.3408203125,14.9287109375L383.310546875,13.7587890625L410,82L344.4853515625,130.923828125L338.0576171875,125.783203125L328.6064453125,116.0830078125L321.4072265625,105.38671875L317.685546875,93.8056640625L318.13671875,82L322.1142578125,70.7607421875Z"
Timeout:  5000ms

Call log:
  - Expect "toHaveAttribute" locator('[data-id="province_4"]').locator('.cell') with timeout 5000ms
  - waiting for locator('[data-id="province_4"]').locator('.cell')
    14 × locator resolved to <path fill="#4d91ba" class="cell country-shape" d="M327.9755859375,60.34765625L334.369140625,50.3310546875L341.2900390625,40.1845703125L349.9521484375,30.09765625L361.59765625,21.1962890625L376.3408203125,14.9287109375L383.310546875,13.7587890625L410,82L344.4853515625,130.923828125L338.0576171875,125.783203125L328.6064453125,116.0830078125L321.4072265625,105.38671875L317.685546875,93.8056640625L318.13671875,82L322.1142578125,70.7607421875Z"></path>
       - unexpected value "M327.9755859375,60.34765625L334.369140625,50.3310546875L341.2900390625,40.1845703125L349.9521484375,30.09765625L361.59765625,21.1962890625L376.3408203125,14.9287109375L383.310546875,13.7587890625L410,82L344.4853515625,130.923828125L338.0576171875,125.783203125L328.6064453125,116.0830078125L321.4072265625,105.38671875L317.685546875,93.8056640625L318.13671875,82L322.1142578125,70.7607421875Z"

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 2 human seats · Seed 0
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]: 23 provinces · 46 armies
      - generic [ref=e16]:
        - generic [ref=e17]: Seat 2
        - generic [ref=e18]: 23 provinces · 46 armies
    - contentinfo [ref=e19]:
      - button "New game" [ref=e20] [cursor=pointer]
    - generic [ref=e21]:
      - button "Save game" [ref=e22] [cursor=pointer]
      - generic [ref=e23]:
        - generic [ref=e24]: Load game
        - button "Load game" [ref=e25]
  - main [ref=e26]:
    - img "Nine Isles reference map" [ref=e28]:
      - button "River gate, Seat 1, 3 armies, Seat 1" [ref=e54] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: "3"
      - button "New port, Seat 2, 2 armies, Seat 2" [ref=e56] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: "2"
      - button "North rest, Seat 1, 2 armies, Seat 1" [ref=e58] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: "2"
      - button "River keep, Seat 2, 1 armies, Seat 2" [ref=e60] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: "1"
      - button "North town, Seat 1, 2 armies, Seat 1" [ref=e62] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: "2"
      - button "Dark ford, Seat 1, 3 armies, Seat 1" [ref=e64] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: "3"
      - button "Iron point, Seat 2, 2 armies, Seat 2" [ref=e66] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: "2"
      - button "South rest, Seat 2, 3 armies, Seat 2" [ref=e68] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: "3"
      - button "High shore, Seat 1, 3 armies, Seat 1" [ref=e70] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: "3"
      - button "Wind town, Seat 1, 3 armies, Seat 1" [ref=e72] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: "3"
      - button "New glen, Seat 1, 1 armies, Seat 1" [ref=e74] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: "1"
      - button "Old rock, Seat 2, 1 armies, Seat 2" [ref=e76] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: "1"
      - button "Blue peak, Seat 2, 1 armies, Seat 2" [ref=e78] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: "1"
      - button "West haven, Seat 1, 2 armies, Seat 1" [ref=e80] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: "2"
      - button "Stone watch, Seat 2, 3 armies, Seat 2" [ref=e82] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: "3"
      - button "Upper ridge, Seat 1, 2 armies, Seat 1" [ref=e84] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: "2"
      - button "Marsh keep, Seat 2, 2 armies, Seat 2" [ref=e86] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: "2"
      - button "New fell, Seat 1, 1 armies, Seat 1" [ref=e88] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: "1"
      - button "Moon point, Seat 2, 2 armies, Seat 2" [ref=e90] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: "2"
      - button "South fell, Seat 2, 3 armies, Seat 2" [ref=e92] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: "3"
      - button "High ridge, Seat 2, 1 armies, Seat 2" [ref=e94] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: "1"
        - generic [ref=e96]: ★
      - button "Bay ford, Seat 1, 3 armies, Seat 1" [ref=e97] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: "3"
      - button "Low moor, Seat 2, 2 armies, Seat 2" [ref=e99] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: "2"
      - button "Lower field, Seat 1, 1 armies, Seat 1" [ref=e101] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: "1"
      - button "Wind gate, Seat 2, 2 armies, Seat 2" [ref=e103] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: "2"
      - button "Silver shore, Seat 1, 2 armies, Seat 1" [ref=e105] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: "2"
      - button "Low peak, Seat 1, 1 armies, Seat 1" [ref=e107] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: "1"
      - button "Wind port, Seat 2, 3 armies, Seat 2" [ref=e109] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: "3"
      - button "Gold point, Seat 2, 3 armies, Seat 2" [ref=e111] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: "3"
      - button "Rock moor, Seat 1, 1 armies, Seat 1" [ref=e113] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: "1"
      - button "Marsh rest, Seat 1, 3 armies, Seat 1" [ref=e115] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: "3"
        - generic [ref=e117]: ★
      - button "Wind dale, Seat 1, 2 armies, Seat 1" [ref=e118] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: "2"
      - button "Silver ford, Seat 1, 1 armies, Seat 1" [ref=e120] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: "1"
      - button "Iron field, Seat 2, 3 armies, Seat 2" [ref=e122] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: "3"
      - button "North wood, Seat 2, 1 armies, Seat 2" [ref=e124] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: "1"
      - button "Fort town, Seat 1, 2 armies, Seat 1" [ref=e126] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: "2"
      - button "Red field, Seat 2, 1 armies, Seat 2" [ref=e128] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: "1"
      - button "South ridge, Seat 2, 3 armies, Seat 2" [ref=e130] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: "3"
      - button "Rock bay, Seat 1, 2 armies, Seat 1" [ref=e132] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: "2"
      - button "North ford, Seat 2, 1 armies, Seat 2" [ref=e134] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: "1"
      - button "Port ridge, Seat 1, 3 armies, Seat 1" [ref=e136] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: "3"
      - button "New rock, Seat 2, 3 armies, Seat 2" [ref=e138] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: "3"
      - button "South reach, Seat 2, 1 armies, Seat 2" [ref=e140] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: "1"
        - generic [ref=e142]: ★
      - button "Silver point, Seat 1, 1 armies, Seat 1" [ref=e143] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: "1"
      - button "East ford, Seat 1, 2 armies, Seat 1" [ref=e145] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: "2"
      - button "Gold town, Seat 2, 2 armies, Seat 2" [ref=e147] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: "2"
      - generic [ref=e179]: North Isle +3
      - generic [ref=e180]: East Isle +3
      - generic [ref=e181]: West Isle +3
      - generic [ref=e182]: South Isle +3
      - generic [ref=e183]: Central Isle +5
      - generic [ref=e184]: Harbor Isle +5
      - generic [ref=e185]: Palm Isle +6
      - generic [ref=e186]: Cliff Isle +5
      - generic [ref=e187]: Great Isle +9
    - complementary [ref=e188]:
      - generic [ref=e192]:
        - generic [ref=e193]: Seat 1's turn
        - generic [ref=e194]: Round 1 · Reinforcement
      - generic [ref=e195]:
        - generic [ref=e196]:
          - generic [ref=e197]:
            - generic [ref=e198]: Province income
            - strong [ref=e199]: "7"
          - generic [ref=e200]:
            - generic [ref=e201]: Island income
            - strong [ref=e202]: "0"
          - generic [ref=e203]:
            - generic [ref=e204]: Armies to place
            - strong [ref=e205]: "7"
        - paragraph [ref=e206]: Place your armies on your countries, then start combat.
        - generic [ref=e207]:
          - button "Start combat" [disabled] [ref=e208]
          - button "End turn" [disabled] [ref=e209]
      - generic [ref=e210]:
        - heading "Battle log" [level=3] [ref=e211]
        - list "Battle log"
```

# Test source

```ts
  1  | import {test,expect} from "@playwright/test";
  2  | import type {Page} from "@playwright/test";
  3  | import {readFileSync,mkdirSync,mkdtempSync,writeFileSync} from "node:fs";
  4  | import {join} from "node:path";
  5  | import type expectedType from "../../docs/prototypes/new-game/T65/acceptance/board.json";
  6  | const expected:typeof expectedType=JSON.parse(readFileSync(new URL("../../docs/prototypes/new-game/T65/acceptance/board.json",import.meta.url),"utf8"));
  7  | import type originalType from "../../docs/prototypes/new-game/T63/board.json";
  8  | const original:typeof originalType=JSON.parse(readFileSync(new URL("../../docs/prototypes/new-game/T63/board.json",import.meta.url),"utf8"));
  9  | import {fixture,step} from "./battle-fixture";
  10 | import {deserializeVersionedMatch} from "../../src/core/match-save";
  11 | import {logicalState} from "../core/versioned-match-fixture";
  12 | const root=process.env["BORDER_EVIDENCE_DIR"]??"screenshots";
  13 | const country=(page:Page,id:string)=>page.locator(`[data-id="${id}"]`);
  14 | function output(label:string){mkdirSync(root,{recursive:true});return mkdtempSync(join(root,label+"-"));}
  15 | async function shot(page:Page,dir:string,name:string){await page.mouse.move(0,0);await page.screenshot({path:join(dir,name+".png")});}
  16 | async function closeups(page:Page,dir:string,prefix:string){for(const [index,name]of[[7,"cliff"],[8,"great"]] as const)await page.locator(".coast").nth(index).screenshot({path:join(dir,`${prefix}-${name}.png`)});}
  17 | async function painted(page:Page){
  18 |  await expect(page.locator(".country")).toHaveCount(46);
  19 |  expect(await page.locator(".coast").evaluateAll(nodes=>nodes.map(n=>n.getAttribute("d")))).toEqual(expected.islands.map(i=>"M"+i.polygon.map(p=>p.join(",")).join("L")+"Z"));
> 20 |  for(const p of expected.provinces)await expect(country(page,p.id).locator(".cell")).toHaveAttribute("d","M"+p.polygon.map(q=>q.join(",")).join("L")+"Z");
     |                                                                                      ^ Error: expect(locator).toHaveAttribute(expected) failed
  21 |  expect(await page.locator(".lane").evaluateAll(nodes=>nodes.map(n=>n.getAttribute("points")))).toEqual(expected.routes.map(r=>r.points.map(p=>p.join(",")).join(" ")));
  22 |  const hits=await page.evaluate((board)=>board.provinces.map(p=>{
  23 |   const group=document.querySelector<SVGGElement>(`[data-id="${p.id}"]`)!,shape=group.querySelector<SVGGeometryElement>(".cell")!,matrix=shape.getScreenCTM()!;
  24 |   const [x,y]=p.labelAt,point=new DOMPoint(x!,y!).matrixTransform(matrix);
  25 |   const hit=document.elementFromPoint(point.x,point.y)?.closest(".country")?.getAttribute("data-id");
  26 |   const corners=[[-20,-20],[-20,20],[20,-20],[20,20]].every(([dx,dy])=>shape.isPointInFill(new DOMPoint(x!+dx!,y!+dy!)));
  27 |   return{id:p.id,hit,corners};
  28 |  }),expected);
  29 |  expect(hits.filter(p=>p.hit!==p.id||!p.corners)).toEqual([]);
  30 |  const captions=await page.locator(".island-name").evaluateAll(nodes=>nodes.map(node=>{
  31 |   const b=(node as SVGGraphicsElement).getBBox(),coasts=[...node.closest("svg")!.querySelectorAll<SVGGeometryElement>(".coast")];
  32 |   const onLand=[[b.x,b.y],[b.x+b.width,b.y],[b.x,b.y+b.height],[b.x+b.width,b.y+b.height],[b.x+b.width/2,b.y+b.height/2]].some(([x,y])=>coasts.some(c=>c.isPointInFill(new DOMPoint(x,y))));
  33 |   const intersects=(a:DOMPoint,bp:DOMPoint)=>{
  34 |    let low=0,high=1;
  35 |    for(const [origin,delta,min,max]of[[a.x,bp.x-a.x,b.x-1,b.x+b.width+1],[a.y,bp.y-a.y,b.y-1,b.y+b.height+1]]){
  36 |     if(delta===0){if(origin!<min!||origin!>max!)return false;continue;}
  37 |     const t1=(min!-origin!)/delta!,t2=(max!-origin!)/delta!;low=Math.max(low,Math.min(t1,t2));high=Math.min(high,Math.max(t1,t2));
  38 |    }
  39 |    return low<=high;
  40 |   };
  41 |   const onRoute=[...node.closest("svg")!.querySelectorAll<SVGPolylineElement>(".lane")].some(line=>{const points=line.points;for(let j=1;j<points.numberOfItems;j++){const a=points.getItem(j-1),c=points.getItem(j);if(intersects(new DOMPoint(a.x,a.y),new DOMPoint(c.x,c.y)))return true;}return false;});
  42 |   return{text:node.textContent,onLand,onRoute,inFrame:b.x>=0&&b.y>=0&&b.x+b.width<=800&&b.y+b.height<=460};
  43 |  }));
  44 |  expect(captions).toHaveLength(9);expect(captions.filter(c=>c.onLand||c.onRoute||!c.inFrame),"island captions need unobstructed water space").toEqual([]);
  45 |  const labels=await page.locator(".country-label").evaluateAll(nodes=>nodes.map(n=>{const b=n.getBoundingClientRect();return{x:b.x,y:b.y,right:b.right,bottom:b.bottom};}));
  46 |  const viewport=page.viewportSize()!;for(const b of labels){expect(b.x).toBeGreaterThanOrEqual(0);expect(b.y).toBeGreaterThanOrEqual(0);expect(b.right).toBeLessThanOrEqual(viewport.width);expect(b.bottom).toBeLessThanOrEqual(viewport.height);}
  47 |  for(let i=0;i<labels.length;i++)for(let j=i+1;j<labels.length;j++){const a=labels[i]!,b=labels[j]!;expect(a.right<=b.x||b.right<=a.x||a.bottom<=b.y||b.bottom<=a.y,`labels ${i}/${j} overlap`).toBe(true);}
  48 | }
  49 | for(const viewport of [{width:800,height:540},{width:1280,height:800},{width:1920,height:1080}])test(`standalone shared borders is painted and all46countries selectable at ${viewport.width}x${viewport.height}`,async({page},info)=>{
  50 |  const dir=output(`standalone-${viewport.width}-${info.project.name}`),errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));await page.setViewportSize(viewport);
  51 |  await page.setContent(readFileSync(new URL("../../docs/prototypes/new-game/T64/preview.html",import.meta.url),"utf8"));await shot(page,dir,"before-T64");await closeups(page,dir,"before-border");
  52 |  await page.setContent(readFileSync(new URL("../../docs/prototypes/map-1994/preview.html",import.meta.url),"utf8"));await shot(page,dir,"approved-T22-reference");
  53 |  await page.setContent(readFileSync(new URL("../../docs/prototypes/new-game/T65/preview.html",import.meta.url),"utf8"));try{await painted(page);}finally{await shot(page,dir,"after-opening");await closeups(page,dir,"after-border");}
  54 |  for(const p of expected.provinces){await country(page,p.id).click();await expect(country(page,p.id)).toHaveAttribute("aria-pressed","true");expect(await page.locator(".country.neighbor").evaluateAll(nodes=>nodes.map(n=>(n as SVGGElement).dataset["id"]).sort())).toEqual([...p.borders,...p.seaLanes].sort());const collisions=await page.locator(".country-label").evaluateAll(nodes=>{const boxes=nodes.map(n=>n.getBoundingClientRect());return boxes.flatMap((a,j)=>boxes.slice(j+1).flatMap((b,k)=>a.right>b.left&&b.right>a.left&&a.bottom>b.top&&b.bottom>a.top?[[j,j+k+1]]:[]));});expect(collisions,`selected ${p.id}: labels overlap`).toEqual([]);}
  55 |  await country(page,expected.provinces[0]!.id).focus();await page.keyboard.press("Space");await expect(country(page,expected.provinces[0]!.id)).toHaveAttribute("aria-pressed","true");
  56 |  await shot(page,dir,"selected");expect(errors).toEqual([]);
  57 | });
  58 | test("playable shared borders uses new paint/hit positions and ordinary deterministic attacks while saves keep canonical map",async({page},info)=>{
  59 |  const dir=output(`playable-${info.project.name}`),f=fixture("manual"),errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));
  60 |  await page.goto("/?control=manual");await page.getByLabel("Seed",{exact:true}).fill(String(f.seed));await page.getByLabel("Seats",{exact:true}).selectOption("2");await page.getByRole("button",{name:"Start game",exact:true}).click();
  61 |  try{await painted(page);}finally{await shot(page,dir,"opening");await closeups(page,dir,"coast");}
  62 |  for(const p of expected.provinces){await expect(country(page,p.id).locator(".centre")).toHaveAttribute("x",String(p.labelAt[0]!-25));await expect(country(page,p.id).locator(".centre")).toHaveAttribute("y",String(p.labelAt[1]!-10));}
  63 |  for(let n=0;n<f.placements;n++)await country(page,f.from).click();await page.locator("#start-combat-button").click();
  64 |  const save=async()=>{const event=page.waitForEvent("download");await page.getByRole("button",{name:"Save game",exact:true}).click();const text=readFileSync((await(await event).path())!,"utf8");writeFileSync(join(dir,"save-"+Date.now()+".json"),text);return deserializeVersionedMatch(text).state;};
  65 |  let state=await save();await country(page,f.from).click();await country(page,f.to).click();state=step(state,{kind:"attack",from:f.from,to:f.to});expect(logicalState(await save())).toEqual(logicalState(state));
  66 |  expect(state.map.provinces.map(p=>p.polygon)).toEqual(original.provinces.map(p=>p.polygon));
  67 |  expect(state.map.provinces.map(p=>p.labelAt)).toEqual(original.provinces.map(p=>p.labelAt));
  68 |  await expect(country(page,f.from)).toHaveAttribute("aria-pressed","true");await shot(page,dir,"direct-attack");expect(errors).toEqual([]);
  69 | });
  70 | 
```