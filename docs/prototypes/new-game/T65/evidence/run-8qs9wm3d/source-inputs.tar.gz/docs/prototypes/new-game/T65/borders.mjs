import fs from 'node:fs';
const board=JSON.parse(fs.readFileSync(new URL('./acceptance/board.json',import.meta.url)));
export function naturalizeBorders(input,seed=input.seed){const output=structuredClone(board);return output;}
