export const naturalizeBorders=input=>structuredClone(input);
