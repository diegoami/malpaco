# Legacy-host and zoom follow-up

This supersedes the initial Panel-only proposal where noted. Authoritative
disposable replacements are now `mock-src/src/ui/panel.ts` and
`mock-src/src/styles.css`; v1 and v2 Panel files, private builds and every earlier
result remain preserved. No production/test/task/RUN-NOTES edits, commits, model
calls, reviews or CI were performed by this follow-up.

## Legacy host needs the shared scrolling CSS

The authored App uses the same Panel, but its original CSS scrolls `.log-card`,
whereas the supported T71 reference/geographic CSS scrolls `.log` inside that
card. A Panel-only change retains rows on the authored route but writes scrollTop
to its non-scrolling list.

The pinned real-browser `legacy-browser-v1/results.json` measures 30 legal
turn-ended events at both desktop sizes. At 1280 the list is 662px tall with
overflow visible, while its card is 169px high with 706px content. After an event,
the card stays at scrollTop537 while its new maximum is560: bottom-follow fails.
The older reading position48 remains. The large viewport demonstrates the same
problem, with the existing desktop zoom.

The CSS replacement appends only these shared-scroller rules to the current
production stylesheet:

```css
.log-card { display:flex; flex-direction:column; overflow:hidden; }
.log { min-height:0; overflow-y:auto; }
```

Existing T71 scopes already use this structure. In the disposable v2 legacy
browser run the log itself is bounded (124px at1280,171px at1920), initially
shows its newest entry, follows the next entry and preserves the older native
reading offset. The outer card no longer scrolls and its measured dimensions
are unchanged. Both probes use real App/Panel rendering and ordinary legal
reinforcement/end-turn actions; an owned harness exposes advancement without
changing production rules or controls.

## Native browser maximum resolves zoom quantization

Parent's first new browser positive failed an unfrozen approximate bottom
assertion at1920/reference. Instrumented traces show no later layout shift:
after-sync and after-microtask metrics are identical. The real v2 measurement is:

| Mode | scrollTop | Browser-clamped maximum | scrollHeight−clientHeight−scrollTop |
| --- | ---: | ---: | ---: |
| Compact |607.6923217773438|607.6923217773438|1.30767822265625|
| Detailed |667.6923217773438|667.6923217773438|1.30767822265625|

Thus the list is at its actual bottom while integer metric subtraction exceeds
one CSS pixel under the existing1.3zoom. Simply assigning scrollHeight fixes the
destination idiom but does not make integer metrics precise. More importantly,
using those metrics to detect following could misclassify the next append.

Authoritative v3 therefore saves readingTop, assigns scrollTop=scrollHeight and
reads the browser-clamped maximum before updating rows. It compares that native
position with saved readingTop using the existing1px proximity allowance. After
rendering all chronological rows it sets scrollTop to scrollHeight when following,
or restores readingTop otherwise. Everything is synchronous; no microtask,
observer or timer lifecycle is introduced. The temporary maximum probe and final
position restoration occur before a browser paint. Parent independently checks
the browser-clamped maximum rather than approximate integer subtraction.

Exact v3 hashes are in `candidate-v3-hashes.json`:

- Panel: `e2a8e0adecf9206f431cbe37e8ca8285338c5c55d6da19bdf11b793df691c67d`
- CSS: `1a73277c520286b44664f2c74bfd1201e3c2e92d9274093944abc2a6ff441555`

## Parent-owned slice assertion adaptation

`proposed-slice-adaptation.patch` retains all dice, pixels, state and control
checks. Before attacking, capture the complete current row texts. After attacking:

```ts
await expect(page.locator(".log li")).toHaveCount(logBefore + 1);
expect((await page.locator(".log li").allTextContents()).slice(0, logBefore)).toEqual(logTextsBefore);
await expect(page.locator(".log li").last()).toContainText("\u2192");
```

This changes the capped expectation to a full count, preserves the old prefix,
and treats the last chronological row as newest. The initial fixture currently
has no previous rows, so the original capped/first-row checks can also pass its
first attack; the new greater-than-seven acceptance is essential to detect actual
truncation. The parent's independently authored adaptation already matches this
proposal. No existing test was edited by this agent.

## Golden and story evidence

Pinned Playwright1.63.0 results:

- Original Panel-only disposable build: all6existing slice goldens pass unchanged.
- Disposable Panel+shared-CSS v2 build: all6goldens plus both one-game story flows
  pass,8total. Board, empty panel and one-exchange dialog goldens need no update.

The story screenshots after multiple events can show the intended chronological
order; those are generated review artifacts, not pinned goldens. The story helper
hardcodes `screenshots/<project>` despite the owned output config. Its10new PNGs
were moved byte-exact into `legacy-story-screenshots/`; the relocation receipt
records every path/hash and earlier screenshots were left untouched. Future runs
should bind that hardcoded output directory to an owned evidence location.

These are scoped disposable feasibility results, not formal adoption or a claim
that v3 passed parent acceptance. Parent owns the corrected6unit/4newbrowser
positive, meaningful omission controls, final test freeze and subsequent formal
dispatch. No additional duplicate browser run was started after that handoff.
