// Feasibility only: real Panel render and core fixtures, simulated scrolling.
import {createServer} from 'vite';
import {readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const owned=fileURLToPath(new URL('./',import.meta.url)),candidate=resolve(owned,'mock-src/src/ui/panel.ts');
const sha=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
class Node {
 attrs={};children=[];dataset={};style={setProperty(){}};clientHeight=80;top=0;
 constructor(tag){this.tag=tag;}
 setAttribute(k,v){this.attrs[k]=String(v);}
 toggleAttribute(k,v){if(v)this.attrs[k]='';else delete this.attrs[k];}
 addEventListener(){}
 append(...nodes){this.children.push(...nodes);}
 replaceChildren(...nodes){this.children=nodes;this.scrollTop=this.top;}
 get textContent(){return this.children.map(n=>typeof n==='string'?n:n.textContent).join('');}
 set textContent(s){this.children=[s];}
 get scrollHeight(){return this.children.length*24;}
 get scrollTop(){return this.top;}
 set scrollTop(value){this.top=Math.max(0,Math.min(value,Math.max(0,this.scrollHeight-this.clientHeight)));}
 find(cls){if((this.attrs.class??'').split(' ').includes(cls))return this;for(const n of this.children){if(typeof n==='string')continue;const result=n.find(cls);if(result)return result;}return null;}
}
const savedDocument=globalThis.document;
globalThis.document={createElement:tag=>new Node(tag),createElementNS:(_ns,tag)=>new Node(tag)};
const inputs=Object.fromEntries(Object.keys(JSON.parse(readFileSync(resolve(owned,'input-hashes.json'),'utf8'))).map(p=>[p,sha(p)]));
writeFileSync(resolve(owned,'probe-rerun-inputs.json'),JSON.stringify(inputs,null,2)+'\n');
const server=await createServer({configFile:false,server:{middlewareMode:true,watch:{ignored:['**/*']}},appType:'custom',logLevel:'error',plugins:[{name:'owned-panel-imports',enforce:'pre',resolveId(source,importer){if(importer?.split('?')[0]!==candidate)return;const paths={'../core':'src/core/index.ts','./dom':'src/ui/dom.ts','./palette':'src/ui/palette.ts'};if(paths[source])return resolve(paths[source]);}}]});
try{
 const core=await server.ssrLoadModule('/src/core/index.ts');
 const original=await server.ssrLoadModule('/src/ui/panel.ts');
 const proposed=await server.ssrLoadModule('/'+candidate.slice(process.cwd().length+1));
 function pinned(name){const dir=resolve('docs/prototypes/new-game/T31/fixtures'),payload=JSON.parse(readFileSync(resolve(dir,name+'.json'),'utf8'));return 'parts'in payload?JSON.parse(payload.parts.map(p=>JSON.parse(readFileSync(resolve(dir,p),'utf8'))).join('')):payload;}
 const state=core.deserializeVersionedMatch(pinned('human-loss').text).state;
 let next=core.apply(state,{kind:'watchComputers'});assert(next.ok);next=next.state;
 for(let i=0;i<20&&next.log.length===state.log.length;i++){const result=core.apply(next,core.computerAction(next));assert(result.ok);next=result.state;}
 assert(next.log.length>state.log.length);
 const result={purpose:'Disposable feasibility, not frozen/browser acceptance',expectedRows:state.log.filter(e=>e.event!=='game_started').length,implementations:[]};
 for(const [name,Panel]of [['baseline',original.Panel],['candidate',proposed.Panel]]){
  const panel=new Panel({onAttack(){},onStartCombat(){},onEndTurn(){},onNewGame(){}}),log=panel.el.find('log');
  const render=state=>panel.render({state,from:null,to:null,blocked:'',hint:'',seed:1994});
  render(state);const row={name,rows:log.children.length,first:log.children[0]?.textContent,last:log.children.at(-1)?.textContent,initialScrollTop:log.scrollTop};
  const texts=()=>log.children.map(n=>n.textContent),before=texts();render(state);render(state);row.repeatedRenderStable=JSON.stringify(texts())===JSON.stringify(before);
  log.scrollTop=log.scrollHeight;render(next);row.followedBottom=log.scrollTop===log.scrollHeight-log.clientHeight;
  render(state);log.scrollTop=48;render(next);row.olderReaderTop=log.scrollTop;render(next);row.repeatedReaderTop=log.scrollTop;
  const options=core.defaultOptions(),fresh=core.deserializeVersionedMatch(core.serializeVersionedMatch(options,[],core.REFERENCE_MATCH_IDENTITY)).state;render(fresh);row.freshRows=log.children.length;row.freshTop=log.scrollTop;render(state);row.restoredRows=log.children.length;
  result.implementations.push(row);
  if(name==='candidate'){assert.equal(row.rows,result.expectedRows);assert(row.followedBottom);assert.equal(row.olderReaderTop,48);assert.equal(row.repeatedReaderTop,48);assert(row.repeatedRenderStable);assert.equal(row.freshRows,0);assert.equal(row.freshTop,0);assert.equal(row.restoredRows,result.expectedRows);}
 }
 result.inputsUnchanged=Object.entries(inputs).every(([p,hash])=>sha(p)===hash);assert(result.inputsUnchanged);writeFileSync(resolve(owned,'probe-rerun-results.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
}finally{await server.close();if(savedDocument===undefined)delete globalThis.document;else globalThis.document=savedDocument;}
