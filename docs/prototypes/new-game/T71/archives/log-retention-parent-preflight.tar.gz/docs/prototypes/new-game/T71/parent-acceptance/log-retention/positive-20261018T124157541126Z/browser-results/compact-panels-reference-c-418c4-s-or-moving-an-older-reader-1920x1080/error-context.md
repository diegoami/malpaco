# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: compact-panels.spec.ts >> reference: complete battle history scrolls without deleting entries or moving an older reader
- Location: tests/e2e/compact-panels.spec.ts:94:46

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 1 human / 3 computer seats · Computer play · Seed 1994
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]:
          - strong [ref=e13]: "Total armies: 19"
          - generic [ref=e14]: 8 provinces
      - generic [ref=e18]:
        - generic [ref=e19]: Seat 2 · Computer
        - generic [ref=e20]:
          - strong [ref=e21]: "Total armies: 15"
          - generic [ref=e22]: 14 provinces
      - generic [ref=e26]:
        - generic [ref=e27]: Seat 3 · Computer
        - generic [ref=e28]:
          - strong [ref=e29]: "Total armies: 22"
          - generic [ref=e30]: 11 provinces
      - generic [ref=e34]:
        - generic [ref=e35]: Seat 4 · Computer
        - generic [ref=e36]:
          - strong [ref=e37]: "Total armies: 14"
          - generic [ref=e38]: 13 provinces
    - generic [ref=e39]:
      - button "Game event log" [ref=e40] [cursor=pointer]
      - button "Pause game" [ref=e41] [cursor=pointer]: Pause
      - generic [ref=e42]: Game speed
      - combobox "Game speed" [ref=e43]:
        - option "Very slow (2 s)"
        - option "Slow"
        - option "Normal" [selected]
        - option "Fast"
      - generic [ref=e44]: Panel detail
      - combobox "Panel detail" [ref=e45]:
        - option "Compact" [selected]
        - option "Detailed"
    - contentinfo [ref=e46]:
      - button "New game" [ref=e47] [cursor=pointer]
    - generic [ref=e48]:
      - button "Save game" [active] [ref=e49] [cursor=pointer]
      - generic [ref=e50]:
        - generic [ref=e51]: Load game
        - button "Load game" [ref=e52]
  - main [ref=e53]:
    - img "Nine Isles reference map" [ref=e55]:
      - button "River gate, Seat 3, 2 armies, Seat 3" [ref=e81] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: "2"
      - button "New port, Seat 1, 4 armies, Seat 1" [ref=e83] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: "4"
      - button "North rest, Seat 2, 1 armies, Seat 2" [ref=e85] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: "1"
      - button "River keep, Seat 2, 1 armies, Seat 2" [ref=e87] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: "1"
      - button "North town, Seat 2, 1 armies, Seat 2" [ref=e89] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: "1"
      - button "Dark ford, Seat 3, 1 armies, Seat 3" [ref=e91] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: "1"
      - button "Iron point, Seat 3, 1 armies, Seat 3" [ref=e93] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: "1"
      - button "South rest, Seat 3, 3 armies, Seat 3" [ref=e95] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: "3"
      - button "High shore, Seat 1, 2 armies, Seat 1" [ref=e97] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: "2"
      - button "Wind town, Seat 2, 1 armies, Seat 2" [ref=e99] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: "1"
      - button "New glen, Seat 2, 1 armies, Seat 2" [ref=e101] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: "1"
      - button "Old rock, Seat 3, 2 armies, Seat 3" [ref=e103] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: "2"
      - button "Blue peak, Seat 2, 1 armies, Seat 2" [ref=e105] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: "1"
      - button "West haven, Seat 2, 1 armies, Seat 2" [ref=e107] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: "1"
      - button "Stone watch, Seat 2, 1 armies, Seat 2" [ref=e109] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: "1"
      - button "Upper ridge, Seat 2, 1 armies, Seat 2" [ref=e111] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: "1"
      - button "Marsh keep, Seat 1, 3 armies, Seat 1" [ref=e113] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: "3"
      - button "New fell, Seat 4, 1 armies, Seat 4" [ref=e115] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: "1"
      - button "Moon point, Seat 2, 2 armies, Seat 2" [ref=e117] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: "2"
      - button "South fell, Seat 1, 3 armies, Seat 1" [ref=e119] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: "3"
      - button "High ridge, Seat 2, 1 armies, Seat 2" [ref=e121] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: "1"
      - button "Bay ford, Seat 2, 1 armies, Seat 2" [ref=e123] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: "1"
      - button "Low moor, Seat 1, 2 armies, Seat 1" [ref=e125] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: "2"
      - button "Lower field, Seat 4, 1 armies, Seat 4" [ref=e127] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: "1"
      - button "Wind gate, Seat 2, 1 armies, Seat 2" [ref=e129] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: "1"
      - button "Silver shore, Seat 4, 1 armies, Seat 4" [ref=e131] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: "1"
      - button "Low peak, Seat 4, 1 armies, Seat 4" [ref=e133] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: "1"
      - button "Wind port, Seat 4, 1 armies, Seat 4" [ref=e135] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: "1"
      - button "Gold point, Seat 3, 2 armies, Seat 3" [ref=e137] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: "2"
        - generic [ref=e139]: ★
      - button "Rock moor, Seat 1, 2 armies, Seat 1" [ref=e140] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: "2"
      - button "Marsh rest, Seat 3, 2 armies, Seat 3" [ref=e142] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: "2"
      - button "Wind dale, Seat 4, 1 armies, Seat 4" [ref=e144] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: "1"
      - button "Silver ford, Seat 4, 2 armies, Seat 4" [ref=e146] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: "2"
      - button "Iron field, Seat 4, 1 armies, Seat 4" [ref=e148] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: "1"
      - button "North wood, Seat 4, 1 armies, Seat 4" [ref=e150] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: "1"
      - button "Fort town, Seat 3, 2 armies, Seat 3" [ref=e152] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: "2"
        - generic [ref=e154]: ★
      - button "Red field, Seat 2, 1 armies, Seat 2" [ref=e155] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: "1"
        - generic [ref=e157]: ★
      - button "South ridge, Seat 1, 2 armies, Seat 1" [ref=e158] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: "2"
      - button "Rock bay, Seat 4, 1 armies, Seat 4" [ref=e160] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: "1"
      - button "North ford, Seat 4, 1 armies, Seat 4" [ref=e162] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: "1"
      - button "Port ridge, Seat 3, 3 armies, Seat 3" [ref=e164] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: "3"
      - button "New rock, Seat 1, 1 armies, Seat 1" [ref=e166] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: "1"
      - button "South reach, Seat 3, 3 armies, Seat 3" [ref=e168] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: "3"
      - button "Silver point, Seat 3, 1 armies, Seat 3" [ref=e170] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: "1"
      - button "East ford, Seat 4, 1 armies, Seat 4" [ref=e172] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: "1"
      - button "Gold town, Seat 4, 1 armies, Seat 4" [ref=e174] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: "1"
      - generic [ref=e206]: North Isle +3
      - generic [ref=e207]: East Isle +3
      - generic [ref=e208]: West Isle +3
      - generic [ref=e209]: South Isle +3
      - generic [ref=e210]: Central Isle +5
      - generic [ref=e211]: Harbor Isle +5
      - generic [ref=e212]: Palm Isle +6
      - generic [ref=e213]: Cliff Isle +5
      - generic [ref=e214]: Great Isle +9
    - complementary [ref=e215]:
      - generic [ref=e219]:
        - generic [ref=e220]: Seat 3's turn
        - generic [ref=e221]: Computer · Normal · Round 1 · Reinforcement
      - generic [ref=e222]:
        - generic [ref=e223]:
          - generic [ref=e224]:
            - generic [ref=e225]: Province income
            - strong [ref=e226]: "3"
          - generic [ref=e227]:
            - generic [ref=e228]: Island income
            - strong [ref=e229]: "0"
          - generic [ref=e230]:
            - generic [ref=e231]: Armies to place
            - strong [ref=e232]: "3"
        - status [ref=e233]: Seat 3 is playing…
      - generic [ref=e234]:
        - heading "Battle log" [level=3] [ref=e235]
        - list "Battle log" [ref=e236]:
          - listitem [ref=e237]: "T1 Seat 4: Wind port → Lower field, took Lower field"
          - listitem [ref=e238]: "T1 Seat 4: North ford → Rock bay, -1 / -0"
          - listitem [ref=e239]: "T1 Seat 4: Lower field → Wind gate, -1 / -0"
          - listitem [ref=e240]: "T1 Seat 4: New fell → West haven, -1 / -0"
          - listitem [ref=e241]: "T1 Seat 4: Upper ridge → West haven, took West haven"
          - listitem [ref=e242]: "T1 Seat 4: North ford → Rock bay, took Rock bay"
          - listitem [ref=e243]: "T1 Seat 4: Iron field → North wood, took North wood"
          - listitem [ref=e244]: "T1 Seat 4: Gold town → East ford, -1 / -0"
          - listitem [ref=e245]: "T1 Seat 4: Gold town → East ford, -0 / -1"
          - listitem [ref=e246]: "T1 Seat 4: Gold town → East ford, -1 / -0"
          - listitem [ref=e247]: "T1 Seat 4: Gold town → East ford, -0 / -1"
          - listitem [ref=e248]: "T1 Seat 4: Gold town → East ford, took East ford"
          - listitem [ref=e249]: "T1 Seat 4: East ford → Silver point, -0 / -1"
          - listitem [ref=e250]: "T1 Seat 4: East ford → Silver point, -1 / -0"
          - listitem [ref=e251]: "T1 Seat 4: East ford → Silver point, -1 / -0"
          - listitem [ref=e252]: T1 Seat 4 ends the turn
          - listitem [ref=e253]: T1 Seat 1 ends the turn
          - listitem [ref=e254]: "T1 Seat 2: Stone watch → Upper ridge, took Upper ridge"
          - listitem [ref=e255]: "T1 Seat 2: Upper ridge → West haven, -1 / -0"
          - listitem [ref=e256]: "T1 Seat 2: Upper ridge → West haven, -1 / -0"
          - listitem [ref=e257]: "T1 Seat 2: Upper ridge → West haven, -1 / -0"
          - listitem [ref=e258]: "T1 Seat 2: Red field → Wind gate, -1 / -0"
          - listitem [ref=e259]: "T1 Seat 2: Blue peak → West haven, took West haven"
          - listitem [ref=e260]: "T1 Seat 2: Moon point → New fell, -1 / -0"
          - listitem [ref=e261]: "T1 Seat 2: West haven → New fell, -1 / -0"
          - listitem [ref=e262]: "T1 Seat 2: Upper ridge → Rock bay, -1 / -0"
          - listitem [ref=e263]: "T1 Seat 2: High ridge → New fell, -1 / -0"
          - listitem [ref=e264]: "T1 Seat 2: Red field → Wind gate, took Wind gate"
          - listitem [ref=e265]: "T1 Seat 2: Wind town → Old rock, -1 / -0"
          - listitem [ref=e266]: "T1 Seat 2: Bay ford → New glen, -0 / -1"
          - listitem [ref=e267]: "T1 Seat 2: Bay ford → New glen, -1 / -0"
          - listitem [ref=e268]: "T1 Seat 2: Wind town → New glen, took New glen"
          - listitem [ref=e269]: T1 Seat 2 ends the turn
```

# Test source

```ts
  7   | import type {Action} from '../../src/core';
  8   | const fixtures='docs/prototypes/new-game/T71/fixtures';
  9   | const input=(host:string,label:string)=>readFileSync(join(fixtures,`${host}-${label}.json`),'utf8');
  10  | const categories=['reinforcement','selection-ready','exchange','repeated-pair','capture-movement','friendly-movement'];
  11  | const mode=(p:Page)=>p.getByRole('combobox',{name:'Panel detail',exact:true});
  12  | async function begin(p:Page,host:string){
  13  |  await p.clock.install({time:new Date('2026-10-18T12:00:00Z')});await p.clock.pauseAt(new Date('2026-10-18T12:00:00Z'));
  14  |  await p.goto(host==='reference'?'/?view=reference-game':'/');
  15  |  await p.evaluate(()=>{const create=URL.createObjectURL.bind(URL);URL.createObjectURL=blob=>{Reflect.set(window,'compactPanelSave',blob);return create(blob);};});
  16  | }
  17  | async function save(p:Page){await p.getByRole('button',{name:'Save game',exact:true}).click();return p.evaluate(()=>(Reflect.get(window,'compactPanelSave') as Blob).text());}
  18  | async function load(p:Page,text:string){
  19  |  const previous=await p.getByLabel('Load game',{exact:true}).elementHandle();
  20  |  await p.getByLabel('Load game',{exact:true}).setInputFiles({name:'panels.json',mimeType:'application/json',buffer:Buffer.from(text)});
  21  |  await expect.poll(()=>previous!.evaluate(el=>el.isConnected)).toBe(false);await expect(p.locator('[data-country]')).toHaveCount(46);
  22  | }
  23  | async function bounds(p:Page){return p.locator('.battle-reference').evaluate(root=>{
  24  |  const selectors=['.topbar','.board','.panel','.panel>.turn','.panel>.action','.panel>.log-card'];
  25  |  return Object.fromEntries(selectors.map(selector=>{const r=root.querySelector(selector)!.getBoundingClientRect();return [selector,{x:r.x,y:r.y,width:r.width,height:r.height}];}));
  26  | });}
  27  | function stable(actual:Awaited<ReturnType<typeof bounds>>,anchor:Awaited<ReturnType<typeof bounds>>){
  28  |  for(const selector of Object.keys(anchor))for(const axis of ['x','y','width','height'] as const)expect(Math.abs(actual[selector]![axis]-anchor[selector]![axis]),`${selector} ${axis}`).toBeLessThanOrEqual(1);
  29  | }
  30  | async function essentials(p:Page){
  31  |  for(const locator of [mode(p),p.locator('#game-pause-button'),p.locator('#game-speed'),p.getByRole('button',{name:'Game event log',exact:true}),...await p.getByTestId('player-army-total').all()]){
  32  |   await expect(locator).toBeVisible();expect(await locator.evaluate(el=>{const r=el.getBoundingClientRect();return r.left>=0&&r.top>=0&&r.right<=innerWidth+1&&r.bottom<=innerHeight+1;})).toBe(true);
  33  |  }
  34  |  expect(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  35  | }
  36  | function evidence(info:{project:{name:string}},host:string,label:string){const dir=process.env['COMPACT_PANEL_EVIDENCE_DIR']??'screenshots/compact-panels';mkdirSync(dir,{recursive:true});return join(dir,`${info.project.name}-${host}-${label}`);}
  37  | test.use({video:'on'});
  38  | for(const host of ['reference','geographic']){
  39  |  // Separate baseline geometry check still runs when the mode control is absent.
  40  |  test(`${host}: computer phase changes keep actual card bounds stable`,async({page},info)=>{
  41  |   await begin(page,host);let anchor:Awaited<ReturnType<typeof bounds>>|undefined;const samples=[];
  42  |   for(const label of categories){
  43  |    await load(page,input(host,label));const before=await bounds(page);anchor??=before;samples.push({label,before});
  44  |    stable(before,anchor);await page.clock.runFor(350);stable(await bounds(page),anchor);
  45  |   }
  46  |   writeFileSync(evidence(info,host,'geometry')+'.json',JSON.stringify(samples,null,2));
  47  |  });
  48  |  for(const detail of ['compact','detailed'])test(`${host} ${detail}: real computer actions retain fixed panel areas and essentials`,async({page},info)=>{
  49  |   await begin(page,host);let anchor:Awaited<ReturnType<typeof bounds>>|undefined;const samples=[];
  50  |   for(const label of categories){
  51  |    const text=input(host,label);await load(page,text);await expect(mode(page)).toBeVisible({timeout:1000});await mode(page).selectOption(detail);await expect(page.locator('.battle-reference')).toHaveAttribute('data-panel-detail',detail);
  52  |    await page.locator('#game-speed').selectOption('normal');const before=deserializeVersionedMatch(await save(page));expect(before.identity.boardGenerator.id).toBe(host==='reference'?'fixed-reference':'geographic');
  53  |    const action=computerAction(before.state);expect(action).not.toBeNull();const result=apply(before.state,action!);if(!result.ok)throw Error(result.error);
  54  |    const initial=await bounds(page);anchor??=initial;stable(initial,anchor);await essentials(page);
  55  |    await page.clock.runFor(350);expect(deserializeVersionedMatch(await save(page)).state).toEqual(result.state);const after=await bounds(page);stable(after,anchor);await essentials(page);
  56  |    const dice=page.locator('.battle-rolls');if(await dice.count()){if(detail==='compact')await expect(dice).toBeHidden();else if(result.state.log.some(e=>e.event==='attack'))await expect(dice).toBeVisible();}
  57  |    samples.push({label,action,before:initial,after});await page.screenshot({path:evidence(info,host,detail+'-'+label)+'.png'});
  58  |   }
  59  |   writeFileSync(evidence(info,host,detail+'-bounds')+'.json',JSON.stringify(samples,null,2));
  60  |  });
  61  |  test(`${host}: default/reversible keyboard mode preserves pause, speed, log, load and next callback`,async({page})=>{
  62  |   await begin(page,host);await load(page,input(host,'capture-movement'));await expect(mode(page)).toHaveValue('compact',{timeout:1000});
  63  |   await page.locator('#game-pause-button').click();await page.locator('#game-speed').selectOption('very-slow');const frozen=await save(page);
  64  |   await mode(page).focus();await mode(page).press('End');await expect(mode(page)).toHaveValue('detailed');expect(await save(page)).toBe(frozen);
  65  |   await page.getByRole('button',{name:'Game event log',exact:true}).click();await expect(page.getByRole('dialog')).toBeVisible();await page.keyboard.press('Escape');
  66  |   await mode(page).selectOption('compact');await mode(page).selectOption('detailed');await expect(page.locator('#game-pause-button')).toHaveText('Resume');await expect(page.locator('#game-speed')).toHaveValue('very-slow');
  67  |   await page.clock.runFor(10000);expect(await save(page)).toBe(frozen);await essentials(page);
  68  |   await page.locator('#game-pause-button').click();await page.clock.runFor(1999);expect(await save(page)).toBe(frozen);await page.clock.runFor(1);
  69  |   const before=deserializeVersionedMatch(frozen),a=computerAction(before.state)!,r=apply(before.state,a);if(!r.ok)throw Error(r.error);expect(deserializeVersionedMatch(await save(page)).state).toEqual(r.state);
  70  |   await load(page,input(host,'reinforcement'));await expect(mode(page)).toHaveValue('detailed');await expect(page.locator('#game-speed')).toHaveValue('very-slow');await mode(page).selectOption('compact');await expect(mode(page)).toHaveValue('compact',{timeout:1000});
  71  |  });
  72  |  for(const detail of ['compact','detailed'])test(`${host} ${detail}: mandatory human capture and friendly movement remain visible and operable`,async({page},info)=>{
  73  |   await begin(page,host);
  74  |   function human(label:string){const v=JSON.parse(input(host,label));v.options.seats=v.options.seats.map(()=>({kind:'human'}));v.options.computerStrengths=[];const text=JSON.stringify(v);expect(()=>deserializeVersionedMatch(text)).not.toThrow();return text;}
  75  |   await load(page,human('capture-movement'));await expect(mode(page)).toBeVisible({timeout:1000});await mode(page).selectOption(detail);const before=deserializeVersionedMatch(await save(page));expect(before.state.phase).toBe('capture');
  76  |   for(const id of ['capture-amount','confirm-capture-button']){await expect(page.locator('#'+id)).toBeVisible();await expect(page.locator('#'+id)).toBeEnabled();expect(await page.locator('#'+id).evaluate(el=>{const a=el.closest('.action')!.getBoundingClientRect(),r=el.getBoundingClientRect();return r.top>=a.top&&r.bottom<=a.bottom+1;}),id+' stays inside action card').toBe(true);}
  77  |   await essentials(page);await page.screenshot({path:evidence(info,host,detail+'-human-capture')+'.png'});await page.locator('#confirm-capture-button').click();expect(deserializeVersionedMatch(await save(page)).state.history.at(-1)!.kind).toBe('captureMove');
  78  |   await load(page,human('friendly-movement'));const moving=deserializeVersionedMatch(await save(page)),trace=JSON.parse(readFileSync(join(fixtures,'fixture-discovery.json'),'utf8')).results.find((x:{host:string})=>x.host===host),action=trace.found['friendly-movement'].action as Extract<Action,{kind:'friendlyMove'}>;
  79  |   await page.locator('#start-friendly-move-button').click();await page.locator(`[data-country="${action.from}"]`).click();await page.locator(`[data-country="${action.to}"]`).click();
  80  |   for(const id of ['friendly-move-amount','confirm-friendly-move-button','cancel-friendly-move-button','skip-friendly-move-button']){await expect(page.locator('#'+id)).toBeVisible();await expect(page.locator('#'+id)).toBeEnabled();expect(await page.locator('#'+id).evaluate(el=>{const a=el.closest('.action')!.getBoundingClientRect(),r=el.getBoundingClientRect();return r.top>=a.top&&r.bottom<=a.bottom+1;}),id+' stays inside action card').toBe(true);}
  81  |   await essentials(page);await page.screenshot({path:evidence(info,host,detail+'-human-move')+'.png'});await page.locator('#friendly-move-amount').fill('1');await page.locator('#confirm-friendly-move-button').click();
  82  |   const expected=apply(moving.state,{...action,amount:1});if(!expected.ok)throw Error(expected.error);expect(deserializeVersionedMatch(await save(page)).state).toEqual(expected.state);
  83  |  });
  84  | }
  85  | 
  86  | for(const detail of ['compact','detailed'])test(`reference ${detail}: human-loss choices fit and remain usable`,async({page},info)=>{
  87  |  await begin(page,'reference');await load(page,pinned('human-loss').text);await expect(mode(page)).toBeVisible({timeout:1000});await mode(page).selectOption(detail);
  88  |  for(const id of ['watch-computers-button','stop-game-button']){const el=page.locator('#'+id);await expect(el).toBeVisible();await expect(el).toBeEnabled();expect(await el.evaluate(node=>{const a=node.closest('.action')!.getBoundingClientRect(),r=node.getBoundingClientRect();return r.top>=a.top&&r.bottom<=a.bottom+1&&r.right<=innerWidth&&r.bottom<=innerHeight;})).toBe(true);}
  89  |  await essentials(page);await page.screenshot({path:evidence(info,'reference',detail+'-human-loss')+'.png'});const previous=deserializeVersionedMatch(await save(page)).state;
  90  |  await page.locator('#stop-game-button').click();const result=apply(previous,{kind:'stopGame'});if(!result.ok)throw Error(result.error);expect(deserializeVersionedMatch(await save(page)).state).toEqual(result.state);
  91  |  await load(page,pinned('human-loss').text);await page.locator('#watch-computers-button').click();expect(deserializeVersionedMatch(await save(page)).state.watchingComputers).toBe(true);
  92  | });
  93  | 
  94  | for(const host of ['reference','geographic'])test(`${host}: complete battle history scrolls without deleting entries or moving an older reader`,async({page},info)=>{
  95  |  await begin(page,host);
  96  |  for(const detail of ['compact','detailed']){
  97  |   await load(page,input(host,'friendly-movement'));await mode(page).selectOption(detail);
  98  |   let state=deserializeVersionedMatch(await save(page)).state;const log=page.getByRole('list',{name:'Battle log',exact:true}),rows=log.locator('li');
  99  |   const events=state.log.filter(e=>e.event!=='game_started');expect(events.length).toBeGreaterThan(7);await expect(rows).toHaveCount(events.length);
  100 |   const oldTexts=await rows.allTextContents();const first=events[0]!;
  101 |   if(first.event==='attack'){expect(oldTexts[0]).toContain(state.map.provinces.find(p=>p.id===first.from)!.name);expect(oldTexts[0]).toContain(state.map.provinces.find(p=>p.id===first.to)!.name);}
  102 |   const geometry=await bounds(page);expect(await log.evaluate(el=>el.scrollHeight>el.clientHeight)).toBe(true);
  103 |   await log.evaluate(el=>{el.scrollTop=0;});await expect(rows.first()).toBeInViewport();
  104 |   await log.evaluate(el=>{el.scrollTop=el.scrollHeight;});
  105 |   const action=computerAction(state)!;expect(action.kind).toBe('friendlyMove');const result=apply(state,action);if(!result.ok)throw Error(result.error);state=result.state;await page.clock.runFor(350);
  106 |   await expect(rows).toHaveCount(state.log.filter(e=>e.event!=='game_started').length);expect((await rows.allTextContents()).slice(0,oldTexts.length)).toEqual(oldTexts);
> 107 |   expect(await log.evaluate(el=>Math.abs(el.scrollHeight-el.clientHeight-el.scrollTop)<=1)).toBe(true);stable(await bounds(page),geometry);
      |                                                                                             ^ Error: expect(received).toBe(expected) // Object.is equality
  108 |   await log.evaluate(el=>{el.scrollTop=Math.min(48,el.scrollHeight-el.clientHeight);});const reading=await log.evaluate(el=>el.scrollTop),beforeLength=state.log.length;
  109 |   await mode(page).selectOption(detail==='compact'?'detailed':'compact');expect(await log.evaluate(el=>el.scrollTop)).toBe(reading);await mode(page).selectOption(detail);
  110 |   for(let n=0;n<20&&state.log.length===beforeLength;n++){const a=computerAction(state);expect(a).not.toBeNull();const r=apply(state,a!);if(!r.ok)throw Error(r.error);state=r.state;await page.clock.runFor(350);}
  111 |   expect(state.log.length).toBeGreaterThan(beforeLength);await expect(rows).toHaveCount(state.log.filter(e=>e.event!=='game_started').length);expect(await log.evaluate(el=>el.scrollTop)).toBe(reading);expect((await rows.allTextContents()).slice(0,oldTexts.length)).toEqual(oldTexts);stable(await bounds(page),geometry);
  112 |   await page.screenshot({path:evidence(info,host,detail+'-complete-history-scrolled')+'.png'});
  113 |   await load(page,input(host,'reinforcement'));await expect(page.getByRole('list',{name:'Battle log',exact:true}).locator('li')).toHaveCount(0);
  114 |  }
  115 | });
  116 | 
```