# Full sidebar battle history proposal

This disposable proposal changes only the mirrored `mock-src/src/ui/panel.ts`.
Production source, existing tests/task files/RUN-NOTES, completed four-source
implementation and prior evidence were not edited. No commits, network, CI,
browser/model runs or review calls were made.

## Existing behavior and smallest change

`Panel.render` describes every battle-log event, then explicitly selects seven
and reverses them. That is the deletion source. The existing supported-host T71
CSS already bounds the log card and makes `.log` its scrolling child; no new
height, panel layout or popup change is needed.

The mirrored replacement makes these changes:

1. At render entry, capture the log's `scrollTop` and whether it is within one
   CSS pixel of its current bottom. Capture before other phase DOM changes can
   affect layout. The one-pixel allowance handles fractional browser scroll
   metrics; it is a presentation tolerance.
2. Render every described event, in the same chronological order as `state.log`.
   Preserve the existing event text and its intentional omission of game_started.
3. After replacement, set scrollTop to the new bottom if the reader was already
   at the old bottom; otherwise restore the captured reading offset.

No retained-row cache or append-only index is added. Rendering the same state
replaces the same rows without duplication; rendering a different match replaces
the entire list without foreign entries. Actual load/new-game hosts construct a
new Panel as before. An empty initial list counts as following newest, so loading
a long match opens at its latest entry, with older entries available above.

The already-completed native mode handler changes CSS only. An older reading
offset remains the native scroll position when the mode changes, provided that
offset remains inside the available scroll range. Browser scroll clamping is
expected if a resized viewport leaves less overflow than the old offset; a
numeric offset outside the new legal range cannot be retained. This candidate
adds no mode listener or resize observer. Parent browser acceptance must establish
the actual desired behavior across supported mode/phase changes. In particular,
following the bottom immediately after a mode-only resize is not independently
proved by this render-only helper; a new render applies its current bottom rule.

The event-log popup and its separate action history remain untouched. Full
sidebar history continues to mean all existing described battle-log events,
rather than adding reinforcement or other action descriptions from the popup.

## Standalone feasibility probe

`probe.mjs` imports the actual baseline and mirrored Panel via read-only Vite SSR,
with middleware only, no listening server and an ignore-all watcher. A minimal
DOM adapter provides clamped scrolling. Real core and the retained human-loss
fixture supply 112 described events and a legal computer continuation. The probe
executes both actual render implementations, then checks the candidate's full
count, repeat rendering, bottom-following, older offset and clean replacement.

The clean rerun exits 0 with empty stderr (`probe-rerun.*`):

| Observation | Baseline | Candidate |
| --- | --- | --- |
| Rendered history rows | 7 | 112 |
| First row | T5 Seat 3 ends the turn | T1 Seat 1 ends the turn |
| Last row | T5 Seat 3: East ford → Gold town, -1 / -0 | T5 Seat 3 ends the turn |
| Older offset after new entries / repeat render | 48 / 48 | 48 / 48 |
| New empty match rows / restored match rows | 0 / 7 | 0 / 112 |

The candidate initially follows the bottom (offset 2608 in this simulated
112-row/80px viewport), then follows a legal append when already at the bottom.
Its original 112 rows remain intact and chronological. The baseline's constant
seven rows make some simulated scroll checks pass; those are not behavioral
negatives. The independent parent's count/order and real browser continuity
checks remain necessary.

The first probe reached all candidate assertions but failed its final input audit
because the parent edited `tests/ui/compact-panels.test.ts` concurrently with
acceptance authoring. That raw script/stdout/stderr and the original input index
remain preserved. The rerun captures inputs immediately at launch and verifies
all eight protected input hashes unchanged. Production and the historical frozen
manifest were unchanged throughout both attempts.

## Parent execution before any adoption

Run newly authored count/order/scroll/replacement acceptance against baseline and
this candidate, retaining actual browser geometry, scroll metrics and videos for
both hosts, both modes and both desktop sizes. Freeze those tests/fixtures after
the real mocked positive and corresponding executed negatives. A simulated DOM
does not prove layout, native scroll anchoring or mode-only resizing. Reuse the
original four-source evidence only for its unchanged scope; this Panel behavior
needs its own independent acceptance and later formal source dispatch.

No full task completion, appearance approval or independent review is claimed.
