import {mkdirSync,cpSync,readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {build} from 'vite';
const owned=fileURLToPath(new URL('./',import.meta.url)),root=resolve(owned,'legacy-app-v1');mkdirSync(root,{recursive:true});
for(const name of ['src','data','public','index.html','package.json','tsconfig.json'])cpSync(resolve(name),resolve(root,name),{recursive:true});
for(const name of ['docs/prototypes/new-game/T63/board.json','docs/prototypes/new-game/T34/witness.json','docs/prototypes/new-game/T65/map.svg']){mkdirSync(resolve(root,name,'..'),{recursive:true});cpSync(resolve(name),resolve(root,name));}
cpSync(resolve(owned,'mock-src/src/ui/panel.ts'),resolve(root,'src/ui/panel.ts'));
writeFileSync(resolve(root,'src/log-probe.ts'),`import {parseMap,newGame,malpacoRules,activePlayer,provincesOf,apply} from './core';
import {App} from './ui/app';import json from '../data/maps/small_sea.json';
export function mountLogProbe(root:HTMLElement){
 const map=parseMap(json);if(!map.ok)throw Error('map refused');
 let state=newGame(map.map,malpacoRules(),[{id:'blue',name:'Blue',eliminated:false},{id:'amber',name:'Amber',eliminated:false}],1994);
 const action=(s:typeof state)=>s.phase==='reinforce'?s.reinforcementPool?{kind:'reinforce' as const,province:provincesOf(s,activePlayer(s)!.id)[0]!,amount:s.reinforcementPool}:{kind:'endReinforcement' as const}:{kind:'endTurn' as const};
 while(state.log.filter(e=>e.event!=='game_started').length<30){const r=apply(state,action(state));if(!r.ok)throw Error(r.error);state=r.state;}
 const app=new App(map.map,1994,()=>{},state);app.mount(root);
 Reflect.set(window,'logProbeAdvance',()=>{const before=Reflect.get(app,'state').log.length;for(let n=0;n<4&&Reflect.get(app,'state').log.length===before;n++)Reflect.get(app,'run').call(app,action(Reflect.get(app,'state')));});
}
`);
const main=resolve(root,'src/main.ts'),body=readFileSync(main,'utf8');writeFileSync(main,"import {mountLogProbe} from './log-probe';\n"+body.replace('if (view === "reference-game") {','if (new URLSearchParams(location.search).has("log-probe")) { mountLogProbe(root); } else if (view === "reference-game") {'));
await build({root,configFile:false,logLevel:'error',build:{outDir:'dist'}});console.log(root);
