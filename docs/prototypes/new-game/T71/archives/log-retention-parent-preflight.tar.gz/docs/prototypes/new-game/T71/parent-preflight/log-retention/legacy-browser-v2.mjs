import {preview} from 'vite';import {chromium} from '@playwright/test';import {mkdirSync,writeFileSync} from 'node:fs';import {resolve} from 'node:path';import {fileURLToPath} from 'node:url';
const owned=fileURLToPath(new URL('./',import.meta.url));
const server=await preview({root:resolve(owned,'legacy-app-v2'),configFile:false,logLevel:'error',preview:{host:'127.0.0.1',port:4183,strictPort:true}}),browser=await chromium.launch();const results=[];
try{for(const viewport of [{width:1280,height:800},{width:1920,height:1080}]){
 const page=await browser.newPage({viewport});await page.goto('http://127.0.0.1:4183/?log-probe=long');
 const measure=()=>page.evaluate(()=>{const metrics=el=>({top:el.scrollTop,height:el.clientHeight,content:el.scrollHeight,overflow:getComputedStyle(el).overflowY});return {rows:document.querySelectorAll('.log li').length,log:metrics(document.querySelector('.log')),card:metrics(document.querySelector('.log-card')),panel:metrics(document.querySelector('.panel'))};});
 const initial=await measure();await page.locator('.log').evaluate(el=>el.scrollTop=el.scrollHeight);await page.evaluate(()=>Reflect.get(window,'logProbeAdvance')());const afterBottom=await measure();
 await page.locator('.log').evaluate(el=>el.scrollTop=48);await page.evaluate(()=>Reflect.get(window,'logProbeAdvance')());const afterOlder=await measure();
 const dir=resolve(owned,'legacy-browser-v2');mkdirSync(dir,{recursive:true});await page.screenshot({path:resolve(dir,viewport.width+'-legacy-history.png')});results.push({viewport,initial,afterBottom,afterOlder});await page.close();
}}finally{await browser.close();await new Promise(resolve=>server.httpServer.close(resolve));}
writeFileSync(resolve(owned,'legacy-browser-v1/results.json'),JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify(results,null,2));
