import {parseMap,newGame,malpacoRules,activePlayer,provincesOf,apply} from './core';
import {App} from './ui/app';import json from '../data/maps/small_sea.json';
export function mountLogProbe(root:HTMLElement){
 const map=parseMap(json);if(!map.ok)throw Error('map refused');
 let state=newGame(map.map,malpacoRules(),[{id:'blue',name:'Blue',eliminated:false},{id:'amber',name:'Amber',eliminated:false}],1994);
 const action=(s:typeof state)=>s.phase==='reinforce'?s.reinforcementPool?{kind:'reinforce' as const,province:provincesOf(s,activePlayer(s)!.id)[0]!,amount:s.reinforcementPool}:{kind:'endReinforcement' as const}:{kind:'endTurn' as const};
 while(state.log.filter(e=>e.event!=='game_started').length<30){const r=apply(state,action(state));if(!r.ok)throw Error(r.error);state=r.state;}
 const app=new App(map.map,1994,()=>{},state);app.mount(root);
 Reflect.set(window,'logProbeAdvance',()=>{const before=Reflect.get(app,'state').log.length;for(let n=0;n<4&&Reflect.get(app,'state').log.length===before;n++)Reflect.get(app,'run').call(app,action(Reflect.get(app,'state')));});
}
