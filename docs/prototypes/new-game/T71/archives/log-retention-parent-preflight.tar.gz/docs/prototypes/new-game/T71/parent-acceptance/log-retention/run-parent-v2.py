from pathlib import Path
import subprocess,json,datetime,time,hashlib,os
r=Path.cwd();o=r/'docs/prototypes/new-game/T71/parent-acceptance/log-retention'/('positive-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'));o.mkdir()
p=r/'src/ui/panel.ts';saved=p.read_bytes();candidate=(r/'docs/prototypes/new-game/T71/parent-preflight/log-retention/mock-src/src/ui/panel.ts').read_bytes();(o/'original-panel.ts').write_bytes(saved)
css=r/'src/styles.css';cssSaved=css.read_bytes();cssCandidate=(r/'docs/prototypes/new-game/T71/parent-preflight/log-retention/mock-src/src/styles.css').read_bytes();(o/'original-styles.css').write_bytes(cssSaved)
receipt={'cssCandidateSha256':hashlib.sha256(cssCandidate).hexdigest(),'candidateSha256':hashlib.sha256(candidate).hexdigest(),'commands':[]}
def run(name,args,expected=0):
 t=time.monotonic()
 with (o/(name+'.stdout')).open('wb') as out,(o/(name+'.stderr')).open('wb') as err:x=subprocess.run(args,stdout=out,stderr=err)
 receipt['commands'].append({'name':name,'argv':args,'exit':x.returncode,'expected':expected,'seconds':time.monotonic()-t});assert (x.returncode==0)==(expected==0),(name,x.returncode)
try:
 p.write_bytes(candidate);css.write_bytes(cssCandidate)
 run('units',['npx','vitest','run','tests/ui/compact-panels.test.ts'])
 args=['docker','run','--rm','--init','--ipc=host','--user',str(os.getuid())+':'+str(os.getgid()),'-v',str(r)+':/work','-w','/work','-e','HOME=/tmp','-e','COMPACT_PANEL_EVIDENCE_DIR='+str(o.relative_to(r)/'screenshots'),'-e','COMPACT_PANEL_RESULTS_DIR=/work/'+str(o.relative_to(r)/'browser-results'),'mcr.microsoft.com/playwright:v1.63.0-noble','npx','playwright','test','--config','docs/prototypes/new-game/T71/parent-acceptance/playwright.config.ts','-g','complete battle history','--workers=2']
 run('browsers',args)
 for name,old,new in [('recap',b'entries.map((e)',b'entries.slice(-7).map((e)'),('reverse',b'entries.map((e)',b'entries.reverse().map((e)'),('force-bottom',b'this.log.scrollTop = followingNewest',b'this.log.scrollTop = true'),('never-follow',b'this.log.scrollTop = followingNewest',b'this.log.scrollTop = false')]:
  if old not in candidate:
   receipt.setdefault('unexecutedMutationDrafts',[]).append(name);continue
  try:
   p.write_bytes(candidate.replace(old,new));run(name,['npx','vitest','run','tests/ui/compact-panels.test.ts'],1)
  finally:p.write_bytes(candidate)
finally:
 p.write_bytes(saved);css.write_bytes(cssSaved);receipt['restoredExactly']=p.read_bytes()==saved and css.read_bytes()==cssSaved;(o/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({'path':str(o.relative_to(r)),**receipt},indent=2))
