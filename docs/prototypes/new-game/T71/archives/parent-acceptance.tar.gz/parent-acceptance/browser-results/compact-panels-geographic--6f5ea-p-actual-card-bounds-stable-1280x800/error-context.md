# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: compact-panels.spec.ts >> geographic: computer phase changes keep actual card bounds stable
- Location: tests/e2e/compact-panels.spec.ts:39:2

# Error details

```
Error: .panel>.turn height

expect(received).toBeLessThanOrEqual(expected)

Expected: <= 1
Received:    18.1875
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Generated islands · 1 human / 3 computer seats · Computer play · Seed 1994
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]:
          - strong [ref=e13]: "Total armies: 24"
          - generic [ref=e14]: 12 provinces
      - generic [ref=e18]:
        - generic [ref=e19]: Seat 2 · Computer
        - generic [ref=e20]:
          - strong [ref=e21]: "Total armies: 24"
          - generic [ref=e22]: 12 provinces
      - generic [ref=e26]:
        - generic [ref=e27]: Seat 3 · Computer
        - generic [ref=e28]:
          - strong [ref=e29]: "Total armies: 25"
          - generic [ref=e30]: 11 provinces
      - generic [ref=e34]:
        - generic [ref=e35]: Seat 4 · Computer
        - generic [ref=e36]:
          - strong [ref=e37]: "Total armies: 22"
          - generic [ref=e38]: 11 provinces
    - generic [ref=e39]:
      - button "Game event log" [ref=e40] [cursor=pointer]
      - button "Pause game" [ref=e41] [cursor=pointer]: Pause
      - generic [ref=e42]: Game speed
      - combobox "Game speed" [ref=e43]:
        - option "Very slow (2 s)"
        - option "Slow"
        - option "Normal" [selected]
        - option "Fast"
    - contentinfo [ref=e44]:
      - button "New game" [ref=e45] [cursor=pointer]
    - generic [ref=e46]:
      - button "Save game" [ref=e47] [cursor=pointer]
      - generic [ref=e48]:
        - generic [ref=e49]: Load game
        - button "Load game" [ref=e50]
  - main [ref=e51]:
    - group "Generated island map" [ref=e53]:
      - button "Country 1, Seat 2, 2 armies, Seat 2" [ref=e79] [cursor=pointer]:
        - generic: "2"
      - button "Country 2, Seat 1, 3 armies, Seat 1" [ref=e81] [cursor=pointer]:
        - generic: "3"
      - button "Country 3, Seat 3, 3 armies, Seat 3" [ref=e83] [cursor=pointer]:
        - generic: "3"
      - button "Country 4, Seat 2, 2 armies, Seat 2" [ref=e85] [cursor=pointer]:
        - generic: "2"
      - button "Country 5, Seat 4, 1 armies, Seat 4" [ref=e87] [cursor=pointer]:
        - generic: "1"
      - button "Country 6, Seat 3, 2 armies, Seat 3" [ref=e89] [cursor=pointer]:
        - generic: "2"
      - button "Country 7, Seat 2, 3 armies, Seat 2" [ref=e91] [cursor=pointer]:
        - generic: "3"
      - button "Country 8, Seat 2, 3 armies, Seat 2" [ref=e93] [cursor=pointer]:
        - generic: "3"
      - button "Country 9, Seat 1, 3 armies, Seat 1" [ref=e95] [cursor=pointer]:
        - generic: "3"
      - button "Country 10, Seat 4, 2 armies, Seat 4" [ref=e97] [cursor=pointer]:
        - generic: "2"
      - button "Country 11, Seat 4, 2 armies, Seat 4" [ref=e99] [cursor=pointer]:
        - generic: "2"
      - button "Country 12, Seat 1, 2 armies, Seat 1" [ref=e101] [cursor=pointer]:
        - generic: "2"
      - button "Country 13, Seat 1, 2 armies, Seat 1" [ref=e103] [cursor=pointer]:
        - generic: "2"
      - button "Country 14, Seat 1, 1 armies, Seat 1" [ref=e105] [cursor=pointer]:
        - generic: "1"
      - button "Country 15, Seat 4, 2 armies, Seat 4" [ref=e107] [cursor=pointer]:
        - generic: "2"
      - button "Country 16, Seat 1, 3 armies, Seat 1" [ref=e109] [cursor=pointer]:
        - generic: "3"
      - button "Country 17, Seat 2, 1 armies, Seat 2" [ref=e111] [cursor=pointer]:
        - generic: "1"
      - button "Country 18, Seat 2, 1 armies, Seat 2" [ref=e113] [cursor=pointer]:
        - generic: "1"
      - button "Country 19, Seat 1, 2 armies, Seat 1" [ref=e115] [cursor=pointer]:
        - generic: "2"
      - button "Country 20, Seat 2, 2 armies, Seat 2" [ref=e117] [cursor=pointer]:
        - generic: "2"
      - button "Country 21, Seat 3, 2 armies, Seat 3" [ref=e119] [cursor=pointer]:
        - generic: "2"
      - button "Country 22, Seat 4, 3 armies, Seat 4" [ref=e121] [cursor=pointer]:
        - generic: "3"
      - button "Country 23, Seat 3, 1 armies, Seat 3" [ref=e123] [cursor=pointer]:
        - generic:
          - generic: "1"
          - generic: ★
      - button "Country 24, Seat 1, 1 armies, Seat 1" [ref=e125] [cursor=pointer]:
        - generic: "1"
      - button "Country 25, Seat 2, 1 armies, Seat 2" [ref=e127] [cursor=pointer]:
        - generic: "1"
      - button "Country 26, Seat 4, 1 armies, Seat 4" [ref=e129] [cursor=pointer]:
        - generic: "1"
      - button "Country 27, Seat 3, 6 armies, Seat 3" [ref=e131] [cursor=pointer]:
        - generic: "6"
      - button "Country 28, Seat 1, 1 armies, Seat 1" [ref=e133] [cursor=pointer]:
        - generic: "1"
      - button "Country 29, Seat 1, 3 armies, Seat 1" [ref=e135] [cursor=pointer]:
        - generic: "3"
      - button "Country 30, Seat 3, 2 armies, Seat 3" [ref=e137] [cursor=pointer]:
        - generic: "2"
      - button "Country 31, Seat 3, 2 armies, Seat 3" [ref=e139] [cursor=pointer]:
        - generic: "2"
      - button "Country 32, Seat 2, 3 armies, Seat 2" [ref=e141] [cursor=pointer]:
        - generic: "3"
      - button "Country 33, Seat 1, 1 armies, Seat 1" [ref=e143] [cursor=pointer]:
        - generic: "1"
      - button "Country 34, Seat 3, 2 armies, Seat 3" [ref=e145] [cursor=pointer]:
        - generic:
          - generic: "2"
          - generic: ★
      - button "Country 35, Seat 2, 3 armies, Seat 2" [ref=e147] [cursor=pointer]:
        - generic:
          - generic: "3"
          - generic: ★
      - button "Country 36, Seat 3, 1 armies, Seat 3" [ref=e149] [cursor=pointer]:
        - generic: "1"
      - button "Country 37, Seat 2, 2 armies, Seat 2" [ref=e151] [cursor=pointer]:
        - generic: "2"
      - button "Country 38, Seat 1, 2 armies, Seat 1" [ref=e153] [cursor=pointer]:
        - generic: "2"
      - button "Country 39, Seat 4, 3 armies, Seat 4" [ref=e155] [cursor=pointer]:
        - generic: "3"
      - button "Country 40, Seat 4, 1 armies, Seat 4" [ref=e157] [cursor=pointer]:
        - generic: "1"
      - button "Country 41, Seat 2, 1 armies, Seat 2" [ref=e159] [cursor=pointer]:
        - generic: "1"
      - button "Country 42, Seat 4, 3 armies, Seat 4" [ref=e161] [cursor=pointer]:
        - generic: "3"
      - button "Country 43, Seat 4, 2 armies, Seat 4" [ref=e163] [cursor=pointer]:
        - generic: "2"
      - button "Country 44, Seat 3, 2 armies, Seat 3" [ref=e165] [cursor=pointer]:
        - generic: "2"
      - button "Country 45, Seat 3, 2 armies, Seat 3" [ref=e167] [cursor=pointer]:
        - generic: "2"
      - button "Country 46, Seat 4, 2 armies, Seat 4" [ref=e169] [cursor=pointer]:
        - generic: "2"
    - complementary [ref=e171]:
      - generic [ref=e175]:
        - generic [ref=e176]: Seat 3's turn
        - generic [ref=e177]: Computer · Normal · Round 1 · Attack
      - generic [ref=e178]:
        - generic [ref=e179]:
          - button "End turn" [disabled] [ref=e180]
          - button "Move armies" [disabled] [ref=e181]
        - region "Battle controls" [ref=e182]:
          - heading "Battle" [level=2] [ref=e183]
          - generic [ref=e184]:
            - generic [ref=e185]:
              - generic [ref=e186]: From
              - strong [ref=e187]: Choose your country
              - generic "Source armies" [ref=e188]: —
            - generic [ref=e189]:
              - generic [ref=e190]: Target
              - strong [ref=e191]: Choose an enemy neighbour
              - generic "Target armies" [ref=e192]: —
          - generic [ref=e193]:
            - generic [ref=e194]:
              - text: Stop at armies
              - spinbutton "Stop at armies" [disabled] [ref=e195]: "2"
            - generic [ref=e196]:
              - text: Battle speed
              - combobox "Battle speed" [ref=e197]:
                - option "Very slow"
                - option "Slow"
                - option "Normal" [selected]
                - option "Fast"
          - paragraph [ref=e198]: Choose a source and target to begin.
          - generic [ref=e199]:
            - button "Fight on" [disabled] [ref=e200]
            - button "Stop" [disabled] [ref=e201]
            - button "Single exchange" [disabled] [ref=e202]
          - generic [ref=e203]:
            - strong [ref=e204]: Ready for your choice
            - paragraph [ref=e205]: Choose your country, then click an enemy to attack. Shift-click or Shift-Enter selects only.
          - paragraph [ref=e206]:
            - text: Won 0 · Lost 0 · Ties
            - strong [ref=e207]: "0"
        - status [ref=e208]: Seat 3 is playing…
      - generic [ref=e209]:
        - heading "Battle log" [level=3] [ref=e210]
        - list "Battle log"
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test';
  2  | import type {Page} from '@playwright/test';
  3  | import {readFileSync,mkdirSync,writeFileSync} from 'node:fs';
  4  | import {join} from 'node:path';
  5  | import {apply,computerAction,deserializeVersionedMatch} from '../../src/core';
  6  | import type {Action} from '../../src/core';
  7  | const fixtures='docs/prototypes/new-game/T71/fixtures';
  8  | const input=(host:string,label:string)=>readFileSync(join(fixtures,`${host}-${label}.json`),'utf8');
  9  | const categories=['reinforcement','selection-ready','exchange','repeated-pair','capture-movement','friendly-movement'];
  10 | const mode=(p:Page)=>p.getByRole('combobox',{name:'Panel detail',exact:true});
  11 | async function begin(p:Page,host:string){
  12 |  await p.clock.install({time:new Date('2026-10-18T12:00:00Z')});await p.clock.pauseAt(new Date('2026-10-18T12:00:00Z'));
  13 |  await p.goto(host==='reference'?'/?view=reference-game':'/');
  14 |  await p.evaluate(()=>{const create=URL.createObjectURL.bind(URL);URL.createObjectURL=blob=>{Reflect.set(window,'compactPanelSave',blob);return create(blob);};});
  15 | }
  16 | async function save(p:Page){await p.getByRole('button',{name:'Save game',exact:true}).click();return p.evaluate(()=>(Reflect.get(window,'compactPanelSave') as Blob).text());}
  17 | async function load(p:Page,text:string){
  18 |  const previous=await p.getByLabel('Load game',{exact:true}).elementHandle();
  19 |  await p.getByLabel('Load game',{exact:true}).setInputFiles({name:'panels.json',mimeType:'application/json',buffer:Buffer.from(text)});
  20 |  await expect.poll(()=>previous!.evaluate(el=>el.isConnected)).toBe(false);await expect(p.locator('[data-country]')).toHaveCount(46);
  21 | }
  22 | async function bounds(p:Page){return p.locator('.battle-reference').evaluate(root=>{
  23 |  const selectors=['.topbar','.board','.panel','.panel>.turn','.panel>.action','.panel>.log-card'];
  24 |  return Object.fromEntries(selectors.map(selector=>{const r=root.querySelector(selector)!.getBoundingClientRect();return [selector,{x:r.x,y:r.y,width:r.width,height:r.height}];}));
  25 | });}
  26 | function stable(actual:Awaited<ReturnType<typeof bounds>>,anchor:Awaited<ReturnType<typeof bounds>>){
> 27 |  for(const selector of Object.keys(anchor))for(const axis of ['x','y','width','height'] as const)expect(Math.abs(actual[selector]![axis]-anchor[selector]![axis]),`${selector} ${axis}`).toBeLessThanOrEqual(1);
     |                                                                                                                                                                                          ^ Error: .panel>.turn height
  28 | }
  29 | async function essentials(p:Page){
  30 |  for(const locator of [mode(p),p.locator('#game-pause-button'),p.locator('#game-speed'),p.getByRole('button',{name:'Game event log',exact:true}),...await p.getByTestId('player-army-total').all()]){
  31 |   await expect(locator).toBeVisible();expect(await locator.evaluate(el=>{const r=el.getBoundingClientRect();return r.left>=0&&r.top>=0&&r.right<=innerWidth+1&&r.bottom<=innerHeight+1;})).toBe(true);
  32 |  }
  33 |  expect(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  34 | }
  35 | function evidence(info:{project:{name:string}},host:string,label:string){const dir=process.env['COMPACT_PANEL_EVIDENCE_DIR']??'screenshots/compact-panels';mkdirSync(dir,{recursive:true});return join(dir,`${info.project.name}-${host}-${label}`);}
  36 | test.use({video:'on'});
  37 | for(const host of ['reference','geographic']){
  38 |  // Separate baseline geometry check still runs when the mode control is absent.
  39 |  test(`${host}: computer phase changes keep actual card bounds stable`,async({page},info)=>{
  40 |   await begin(page,host);let anchor:Awaited<ReturnType<typeof bounds>>|undefined;const samples=[];
  41 |   for(const label of categories){
  42 |    await load(page,input(host,label));const before=await bounds(page);anchor??=before;samples.push({label,before});
  43 |    stable(before,anchor);await page.clock.runFor(350);stable(await bounds(page),anchor);
  44 |   }
  45 |   writeFileSync(evidence(info,host,'geometry')+'.json',JSON.stringify(samples,null,2));
  46 |  });
  47 |  for(const detail of ['compact','detailed'])test(`${host} ${detail}: real computer actions retain fixed panel areas and essentials`,async({page},info)=>{
  48 |   await begin(page,host);let anchor:Awaited<ReturnType<typeof bounds>>|undefined;const samples=[];
  49 |   for(const label of categories){
  50 |    const text=input(host,label);await load(page,text);await expect(mode(page)).toBeVisible({timeout:1000});await mode(page).selectOption(detail);await expect(page.locator('.battle-reference')).toHaveAttribute('data-panel-detail',detail);
  51 |    await page.locator('#game-speed').selectOption('normal');const before=deserializeVersionedMatch(await save(page));expect(before.identity.boardGenerator.id).toBe(host==='reference'?'fixed-reference':'geographic');
  52 |    const action=computerAction(before.state);expect(action).not.toBeNull();const result=apply(before.state,action!);if(!result.ok)throw Error(result.error);
  53 |    const initial=await bounds(page);anchor??=initial;stable(initial,anchor);await essentials(page);
  54 |    await page.clock.runFor(350);expect(deserializeVersionedMatch(await save(page)).state).toEqual(result.state);const after=await bounds(page);stable(after,anchor);await essentials(page);
  55 |    const dice=page.locator('.battle-rolls');if(await dice.count()){if(detail==='compact')await expect(dice).toBeHidden();else if(result.state.log.some(e=>e.event==='attack'))await expect(dice).toBeVisible();}
  56 |    samples.push({label,action,before:initial,after});await page.screenshot({path:evidence(info,host,detail+'-'+label)+'.png'});
  57 |   }
  58 |   writeFileSync(evidence(info,host,detail+'-bounds')+'.json',JSON.stringify(samples,null,2));
  59 |  });
  60 |  test(`${host}: default/reversible keyboard mode preserves pause, speed, log, load and next callback`,async({page})=>{
  61 |   await begin(page,host);await load(page,input(host,'capture-movement'));await expect(mode(page)).toHaveValue('compact',{timeout:1000});
  62 |   await page.locator('#game-pause-button').click();await page.locator('#game-speed').selectOption('very-slow');const frozen=await save(page);
  63 |   await mode(page).focus();await mode(page).press('End');await expect(mode(page)).toHaveValue('detailed');expect(await save(page)).toBe(frozen);
  64 |   await page.getByRole('button',{name:'Game event log',exact:true}).click();await expect(page.getByRole('dialog')).toBeVisible();await page.keyboard.press('Escape');
  65 |   await mode(page).selectOption('compact');await mode(page).selectOption('detailed');await expect(page.locator('#game-pause-button')).toHaveText('Resume');await expect(page.locator('#game-speed')).toHaveValue('very-slow');
  66 |   await page.clock.runFor(10000);expect(await save(page)).toBe(frozen);await essentials(page);
  67 |   await page.locator('#game-pause-button').click();await page.clock.runFor(1999);expect(await save(page)).toBe(frozen);await page.clock.runFor(1);
  68 |   const before=deserializeVersionedMatch(frozen),a=computerAction(before.state)!,r=apply(before.state,a);if(!r.ok)throw Error(r.error);expect(deserializeVersionedMatch(await save(page)).state).toEqual(r.state);
  69 |   await load(page,input(host,'reinforcement'));await expect(mode(page)).toHaveValue('detailed');await expect(page.locator('#game-speed')).toHaveValue('very-slow');await mode(page).selectOption('compact');await expect(mode(page)).toHaveValue('compact',{timeout:1000});
  70 |  });
  71 |  for(const detail of ['compact','detailed'])test(`${host} ${detail}: mandatory human capture and friendly movement remain visible and operable`,async({page},info)=>{
  72 |   await begin(page,host);
  73 |   function human(label:string){const v=JSON.parse(input(host,label));v.options.seats=v.options.seats.map(()=>({kind:'human'}));v.options.computerStrengths=[];const text=JSON.stringify(v);expect(()=>deserializeVersionedMatch(text)).not.toThrow();return text;}
  74 |   await load(page,human('capture-movement'));await expect(mode(page)).toBeVisible({timeout:1000});await mode(page).selectOption(detail);const before=deserializeVersionedMatch(await save(page));expect(before.state.phase).toBe('capture');
  75 |   for(const id of ['capture-amount','confirm-capture-button']){await expect(page.locator('#'+id)).toBeVisible();await expect(page.locator('#'+id)).toBeEnabled();expect(await page.locator('#'+id).evaluate(el=>{const a=el.closest('.action')!.getBoundingClientRect(),r=el.getBoundingClientRect();return r.top>=a.top&&r.bottom<=a.bottom+1;}),id+' stays inside action card').toBe(true);}
  76 |   await essentials(page);await page.screenshot({path:evidence(info,host,detail+'-human-capture')+'.png'});await page.locator('#confirm-capture-button').click();expect(deserializeVersionedMatch(await save(page)).state.history.at(-1)!.kind).toBe('captureMove');
  77 |   await load(page,human('friendly-movement'));const moving=deserializeVersionedMatch(await save(page)),trace=JSON.parse(readFileSync(join(fixtures,'fixture-discovery.json'),'utf8')).results.find((x:{host:string})=>x.host===host),action=trace.found['friendly-movement'].action as Extract<Action,{kind:'friendlyMove'}>;
  78 |   await page.locator('#start-friendly-move-button').click();await page.locator(`[data-country="${action.from}"]`).click();await page.locator(`[data-country="${action.to}"]`).click();
  79 |   for(const id of ['friendly-move-amount','confirm-friendly-move-button','cancel-friendly-move-button','skip-friendly-move-button']){await expect(page.locator('#'+id)).toBeVisible();await expect(page.locator('#'+id)).toBeEnabled();expect(await page.locator('#'+id).evaluate(el=>{const a=el.closest('.action')!.getBoundingClientRect(),r=el.getBoundingClientRect();return r.top>=a.top&&r.bottom<=a.bottom+1;}),id+' stays inside action card').toBe(true);}
  80 |   await essentials(page);await page.screenshot({path:evidence(info,host,detail+'-human-move')+'.png'});await page.locator('#friendly-move-amount').fill('1');await page.locator('#confirm-friendly-move-button').click();
  81 |   const expected=apply(moving.state,{...action,amount:1});if(!expected.ok)throw Error(expected.error);expect(deserializeVersionedMatch(await save(page)).state).toEqual(expected.state);
  82 |  });
  83 | }
  84 | 
```