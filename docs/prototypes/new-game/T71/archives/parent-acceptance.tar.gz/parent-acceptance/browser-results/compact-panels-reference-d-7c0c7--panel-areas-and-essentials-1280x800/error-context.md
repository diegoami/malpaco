# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: compact-panels.spec.ts >> reference detailed: real computer actions retain fixed panel areas and essentials
- Location: tests/e2e/compact-panels.spec.ts:47:45

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('combobox', { name: 'Panel detail', exact: true })
Expected: visible
Timeout: 1000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('combobox', { name: 'Panel detail', exact: true }) with timeout 1000ms
  - waiting for getByRole('combobox', { name: 'Panel detail', exact: true })

```

```yaml
- banner:
  - heading "Malpaco" [level=1]
  - text: Nine Isles · 1 human / 3 computer seats · Computer play · Seed 1994 Seat 1
  - strong: "Total armies: 22"
  - text: 11 provinces Seat 2 · Computer
  - strong: "Total armies: 24"
  - text: 12 provinces Seat 3 · Computer
  - strong: "Total armies: 24"
  - text: 12 provinces Seat 4 · Computer
  - strong: "Total armies: 22"
  - text: 11 provinces
  - button "Game event log"
  - button "Pause game": Pause
  - text: Game speed
  - combobox "Game speed":
    - option "Very slow (2 s)"
    - option "Slow"
    - option "Normal" [selected]
    - option "Fast"
  - contentinfo:
    - button "New game"
  - button "Save game"
  - text: Load game
  - button "Load game"
- main:
  - img "Nine Isles reference map":
    - button "River gate, Seat 3, 2 armies, Seat 3": River gate 2
    - button "New port, Seat 1, 2 armies, Seat 1": New port 2
    - button "North rest, Seat 2, 1 armies, Seat 2": North rest 1
    - button "River keep, Seat 2, 1 armies, Seat 2": River keep 1
    - button "North town, Seat 2, 1 armies, Seat 2": North town 1
    - button "Dark ford, Seat 3, 1 armies, Seat 3": Dark ford 1
    - button "Iron point, Seat 3, 1 armies, Seat 3": Iron point 1
    - button "South rest, Seat 3, 3 armies, Seat 3": South rest 3
    - button "High shore, Seat 1, 2 armies, Seat 1": High shore 2
    - button "Wind town, Seat 2, 3 armies, Seat 2": Wind town 3
    - button "New glen, Seat 4, 2 armies, Seat 4": New glen 2
    - button "Old rock, Seat 3, 2 armies, Seat 3": Old rock 2
    - button "Blue peak, Seat 2, 3 armies, Seat 2": Blue peak 3
    - button "West haven, Seat 2, 1 armies, Seat 2": West haven 1
    - button "Stone watch, Seat 2, 3 armies, Seat 2": Stone watch 3
    - button "Upper ridge, Seat 4, 2 armies, Seat 4": Upper ridge 2
    - button "Marsh keep, Seat 1, 3 armies, Seat 1": Marsh keep 3
    - button "New fell, Seat 4, 2 armies, Seat 4": New fell 2
    - button "Moon point, Seat 2, 2 armies, Seat 2": Moon point 2
    - button "South fell, Seat 1, 3 armies, Seat 1": South fell 3
    - button "High ridge, Seat 2, 2 armies, Seat 2": High ridge 2
    - button "Bay ford, Seat 2, 3 armies, Seat 2": Bay ford 3
    - button "Low moor, Seat 1, 2 armies, Seat 1": Low moor 2
    - button "Lower field, Seat 1, 1 armies, Seat 1": Lower field 1
    - button "Wind gate, Seat 3, 1 armies, Seat 3": Wind gate 1
    - button "Silver shore, Seat 4, 1 armies, Seat 4": Silver shore 1
    - button "Low peak, Seat 4, 1 armies, Seat 4": Low peak 1
    - button "Wind port, Seat 4, 3 armies, Seat 4": Wind port 3
    - button "Gold point, Seat 3, 2 armies, Seat 3": Gold point 2 ★
    - button "Rock moor, Seat 1, 2 armies, Seat 1": Rock moor 2
    - button "Marsh rest, Seat 3, 2 armies, Seat 3": Marsh rest 2
    - button "Wind dale, Seat 4, 1 armies, Seat 4": Wind dale 1
    - button "Silver ford, Seat 4, 2 armies, Seat 4": Silver ford 2
    - button "Iron field, Seat 4, 2 armies, Seat 4": Iron field 2
    - button "North wood, Seat 1, 1 armies, Seat 1": North wood 1
    - button "Fort town, Seat 3, 2 armies, Seat 3": Fort town 2 ★
    - button "Red field, Seat 2, 3 armies, Seat 2": Red field 3 ★
    - button "South ridge, Seat 1, 2 armies, Seat 1": South ridge 2
    - button "Rock bay, Seat 2, 1 armies, Seat 2": Rock bay 1
    - button "North ford, Seat 4, 3 armies, Seat 4": North ford 3
    - button "Port ridge, Seat 3, 3 armies, Seat 3": Port ridge 3
    - button "New rock, Seat 1, 1 armies, Seat 1": New rock 1
    - button "South reach, Seat 3, 3 armies, Seat 3": South reach 3
    - button "Silver point, Seat 3, 2 armies, Seat 3": Silver point 2
    - button "East ford, Seat 1, 3 armies, Seat 1": East ford 3
    - button "Gold town, Seat 4, 3 armies, Seat 4": Gold town 3
    - text: North Isle +3 East Isle +3 West Isle +3 South Isle +3 Central Isle +5 Harbor Isle +5 Palm Isle +6 Cliff Isle +5 Great Isle +9
  - complementary:
    - text: Seat 4's turn Computer · Normal · Round 1 · Reinforcement Province income
    - strong: "3"
    - text: Island income
    - strong: "0"
    - text: Armies to place
    - strong: "3"
    - paragraph: Computer turn. Save, load or start a new game at any time.
    - button "Start combat" [disabled]
    - button "End turn" [disabled]
    - status: Seat 4 is playing…
    - heading "Battle log" [level=3]
    - list "Battle log"
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test';
  2  | import type {Page} from '@playwright/test';
  3  | import {readFileSync,mkdirSync,writeFileSync} from 'node:fs';
  4  | import {join} from 'node:path';
  5  | import {apply,computerAction,deserializeVersionedMatch} from '../../src/core';
  6  | import type {Action} from '../../src/core';
  7  | const fixtures='docs/prototypes/new-game/T71/fixtures';
  8  | const input=(host:string,label:string)=>readFileSync(join(fixtures,`${host}-${label}.json`),'utf8');
  9  | const categories=['reinforcement','selection-ready','exchange','repeated-pair','capture-movement','friendly-movement'];
  10 | const mode=(p:Page)=>p.getByRole('combobox',{name:'Panel detail',exact:true});
  11 | async function begin(p:Page,host:string){
  12 |  await p.clock.install({time:new Date('2026-10-18T12:00:00Z')});await p.clock.pauseAt(new Date('2026-10-18T12:00:00Z'));
  13 |  await p.goto(host==='reference'?'/?view=reference-game':'/');
  14 |  await p.evaluate(()=>{const create=URL.createObjectURL.bind(URL);URL.createObjectURL=blob=>{Reflect.set(window,'compactPanelSave',blob);return create(blob);};});
  15 | }
  16 | async function save(p:Page){await p.getByRole('button',{name:'Save game',exact:true}).click();return p.evaluate(()=>(Reflect.get(window,'compactPanelSave') as Blob).text());}
  17 | async function load(p:Page,text:string){
  18 |  const previous=await p.getByLabel('Load game',{exact:true}).elementHandle();
  19 |  await p.getByLabel('Load game',{exact:true}).setInputFiles({name:'panels.json',mimeType:'application/json',buffer:Buffer.from(text)});
  20 |  await expect.poll(()=>previous!.evaluate(el=>el.isConnected)).toBe(false);await expect(p.locator('[data-country]')).toHaveCount(46);
  21 | }
  22 | async function bounds(p:Page){return p.locator('.battle-reference').evaluate(root=>{
  23 |  const selectors=['.topbar','.board','.panel','.panel>.turn','.panel>.action','.panel>.log-card'];
  24 |  return Object.fromEntries(selectors.map(selector=>{const r=root.querySelector(selector)!.getBoundingClientRect();return [selector,{x:r.x,y:r.y,width:r.width,height:r.height}];}));
  25 | });}
  26 | function stable(actual:Awaited<ReturnType<typeof bounds>>,anchor:Awaited<ReturnType<typeof bounds>>){
  27 |  for(const selector of Object.keys(anchor))for(const axis of ['x','y','width','height'] as const)expect(Math.abs(actual[selector]![axis]-anchor[selector]![axis]),`${selector} ${axis}`).toBeLessThanOrEqual(1);
  28 | }
  29 | async function essentials(p:Page){
  30 |  for(const locator of [mode(p),p.locator('#game-pause-button'),p.locator('#game-speed'),p.getByRole('button',{name:'Game event log',exact:true}),...await p.getByTestId('player-army-total').all()]){
  31 |   await expect(locator).toBeVisible();expect(await locator.evaluate(el=>{const r=el.getBoundingClientRect();return r.left>=0&&r.top>=0&&r.right<=innerWidth+1&&r.bottom<=innerHeight+1;})).toBe(true);
  32 |  }
  33 |  expect(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  34 | }
  35 | function evidence(info:{project:{name:string}},host:string,label:string){const dir=process.env['COMPACT_PANEL_EVIDENCE_DIR']??'screenshots/compact-panels';mkdirSync(dir,{recursive:true});return join(dir,`${info.project.name}-${host}-${label}`);}
  36 | test.use({video:'on'});
  37 | for(const host of ['reference','geographic']){
  38 |  // Separate baseline geometry check still runs when the mode control is absent.
  39 |  test(`${host}: computer phase changes keep actual card bounds stable`,async({page},info)=>{
  40 |   await begin(page,host);let anchor:Awaited<ReturnType<typeof bounds>>|undefined;const samples=[];
  41 |   for(const label of categories){
  42 |    await load(page,input(host,label));const before=await bounds(page);anchor??=before;samples.push({label,before});
  43 |    stable(before,anchor);await page.clock.runFor(350);stable(await bounds(page),anchor);
  44 |   }
  45 |   writeFileSync(evidence(info,host,'geometry')+'.json',JSON.stringify(samples,null,2));
  46 |  });
  47 |  for(const detail of ['compact','detailed'])test(`${host} ${detail}: real computer actions retain fixed panel areas and essentials`,async({page},info)=>{
  48 |   await begin(page,host);let anchor:Awaited<ReturnType<typeof bounds>>|undefined;const samples=[];
  49 |   for(const label of categories){
> 50 |    const text=input(host,label);await load(page,text);await expect(mode(page)).toBeVisible({timeout:1000});await mode(page).selectOption(detail);await expect(page.locator('.battle-reference')).toHaveAttribute('data-panel-detail',detail);
     |                                                                                ^ Error: expect(locator).toBeVisible() failed
  51 |    await page.locator('#game-speed').selectOption('normal');const before=deserializeVersionedMatch(await save(page));expect(before.identity.boardGenerator.id).toBe(host==='reference'?'fixed-reference':'geographic');
  52 |    const action=computerAction(before.state);expect(action).not.toBeNull();const result=apply(before.state,action!);if(!result.ok)throw Error(result.error);
  53 |    const initial=await bounds(page);anchor??=initial;stable(initial,anchor);await essentials(page);
  54 |    await page.clock.runFor(350);expect(deserializeVersionedMatch(await save(page)).state).toEqual(result.state);const after=await bounds(page);stable(after,anchor);await essentials(page);
  55 |    const dice=page.locator('.battle-rolls');if(await dice.count()){if(detail==='compact')await expect(dice).toBeHidden();else if(result.state.log.some(e=>e.event==='attack'))await expect(dice).toBeVisible();}
  56 |    samples.push({label,action,before:initial,after});await page.screenshot({path:evidence(info,host,detail+'-'+label)+'.png'});
  57 |   }
  58 |   writeFileSync(evidence(info,host,detail+'-bounds')+'.json',JSON.stringify(samples,null,2));
  59 |  });
  60 |  test(`${host}: default/reversible keyboard mode preserves pause, speed, log, load and next callback`,async({page})=>{
  61 |   await begin(page,host);await load(page,input(host,'capture-movement'));await expect(mode(page)).toHaveValue('compact',{timeout:1000});
  62 |   await page.locator('#game-pause-button').click();await page.locator('#game-speed').selectOption('very-slow');const frozen=await save(page);
  63 |   await mode(page).focus();await mode(page).press('End');await expect(mode(page)).toHaveValue('detailed');expect(await save(page)).toBe(frozen);
  64 |   await page.getByRole('button',{name:'Game event log',exact:true}).click();await expect(page.getByRole('dialog')).toBeVisible();await page.keyboard.press('Escape');
  65 |   await mode(page).selectOption('compact');await mode(page).selectOption('detailed');await expect(page.locator('#game-pause-button')).toHaveText('Resume');await expect(page.locator('#game-speed')).toHaveValue('very-slow');
  66 |   await page.clock.runFor(10000);expect(await save(page)).toBe(frozen);await essentials(page);
  67 |   await page.locator('#game-pause-button').click();await page.clock.runFor(1999);expect(await save(page)).toBe(frozen);await page.clock.runFor(1);
  68 |   const before=deserializeVersionedMatch(frozen),a=computerAction(before.state)!,r=apply(before.state,a);if(!r.ok)throw Error(r.error);expect(deserializeVersionedMatch(await save(page)).state).toEqual(r.state);
  69 |   await load(page,input(host,'reinforcement'));await expect(mode(page)).toHaveValue('detailed');await expect(page.locator('#game-speed')).toHaveValue('very-slow');await mode(page).selectOption('compact');await expect(mode(page)).toHaveValue('compact',{timeout:1000});
  70 |  });
  71 |  for(const detail of ['compact','detailed'])test(`${host} ${detail}: mandatory human capture and friendly movement remain visible and operable`,async({page},info)=>{
  72 |   await begin(page,host);
  73 |   function human(label:string){const v=JSON.parse(input(host,label));v.options.seats=v.options.seats.map(()=>({kind:'human'}));v.options.computerStrengths=[];const text=JSON.stringify(v);expect(()=>deserializeVersionedMatch(text)).not.toThrow();return text;}
  74 |   await load(page,human('capture-movement'));await expect(mode(page)).toBeVisible({timeout:1000});await mode(page).selectOption(detail);const before=deserializeVersionedMatch(await save(page));expect(before.state.phase).toBe('capture');
  75 |   for(const id of ['capture-amount','confirm-capture-button']){await expect(page.locator('#'+id)).toBeVisible();await expect(page.locator('#'+id)).toBeEnabled();expect(await page.locator('#'+id).evaluate(el=>{const a=el.closest('.action')!.getBoundingClientRect(),r=el.getBoundingClientRect();return r.top>=a.top&&r.bottom<=a.bottom+1;}),id+' stays inside action card').toBe(true);}
  76 |   await essentials(page);await page.screenshot({path:evidence(info,host,detail+'-human-capture')+'.png'});await page.locator('#confirm-capture-button').click();expect(deserializeVersionedMatch(await save(page)).state.history.at(-1)!.kind).toBe('captureMove');
  77 |   await load(page,human('friendly-movement'));const moving=deserializeVersionedMatch(await save(page)),trace=JSON.parse(readFileSync(join(fixtures,'fixture-discovery.json'),'utf8')).results.find((x:{host:string})=>x.host===host),action=trace.found['friendly-movement'].action as Extract<Action,{kind:'friendlyMove'}>;
  78 |   await page.locator('#start-friendly-move-button').click();await page.locator(`[data-country="${action.from}"]`).click();await page.locator(`[data-country="${action.to}"]`).click();
  79 |   for(const id of ['friendly-move-amount','confirm-friendly-move-button','cancel-friendly-move-button','skip-friendly-move-button']){await expect(page.locator('#'+id)).toBeVisible();await expect(page.locator('#'+id)).toBeEnabled();expect(await page.locator('#'+id).evaluate(el=>{const a=el.closest('.action')!.getBoundingClientRect(),r=el.getBoundingClientRect();return r.top>=a.top&&r.bottom<=a.bottom+1;}),id+' stays inside action card').toBe(true);}
  80 |   await essentials(page);await page.screenshot({path:evidence(info,host,detail+'-human-move')+'.png'});await page.locator('#friendly-move-amount').fill('1');await page.locator('#confirm-friendly-move-button').click();
  81 |   const expected=apply(moving.state,{...action,amount:1});if(!expected.ok)throw Error(expected.error);expect(deserializeVersionedMatch(await save(page)).state).toEqual(expected.state);
  82 |  });
  83 | }
  84 | 
```