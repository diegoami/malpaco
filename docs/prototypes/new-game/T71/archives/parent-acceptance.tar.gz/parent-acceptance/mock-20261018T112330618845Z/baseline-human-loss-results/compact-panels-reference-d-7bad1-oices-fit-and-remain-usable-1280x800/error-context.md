# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: compact-panels.spec.ts >> reference detailed: human-loss choices fit and remain usable
- Location: tests/e2e/compact-panels.spec.ts:86:44

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('combobox', { name: 'Panel detail', exact: true })
Expected: visible
Timeout: 1000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('combobox', { name: 'Panel detail', exact: true }) with timeout 1000ms
  - waiting for getByRole('combobox', { name: 'Panel detail', exact: true })

```

```yaml
- banner:
  - heading "Malpaco" [level=1]
  - text: Nine Isles · 1 human / 2 computer seats · Computer play · Seed 1994 Seat 1
  - strong: "Total armies: 0"
  - text: 0 provinces Seat 2 · Computer
  - strong: "Total armies: 48"
  - text: 22 provinces Seat 3 · Computer
  - strong: "Total armies: 46"
  - text: 24 provinces
  - button "Game event log"
  - button "Pause game": Pause
  - text: Game speed
  - combobox "Game speed":
    - option "Very slow (2 s)"
    - option "Slow"
    - option "Normal" [selected]
    - option "Fast"
  - contentinfo:
    - button "New game"
  - button "Save game"
  - text: Load game
  - button "Load game"
- main:
  - img "Nine Isles reference map":
    - button "River gate, Seat 3, 1 armies, Seat 3": River gate 1
    - button "New port, Seat 2, 8 armies, Seat 2": New port 8
    - button "North rest, Seat 2, 1 armies, Seat 2": North rest 1
    - button "River keep, Seat 2, 1 armies, Seat 2": River keep 1
    - button "North town, Seat 2, 1 armies, Seat 2": North town 1
    - button "Dark ford, Seat 2, 1 armies, Seat 2": Dark ford 1
    - button "Iron point, Seat 3, 2 armies, Seat 3": Iron point 2
    - button "South rest, Seat 3, 2 armies, Seat 3": South rest 2
    - button "High shore, Seat 2, 2 armies, Seat 2": High shore 2
    - button "Wind town, Seat 3, 1 armies, Seat 3": Wind town 1
    - button "New glen, Seat 2, 8 armies, Seat 2": New glen 8
    - button "Old rock, Seat 3, 1 armies, Seat 3": Old rock 1
    - button "Blue peak, Seat 2, 1 armies, Seat 2": Blue peak 1
    - button "West haven, Seat 3, 1 armies, Seat 3": West haven 1
    - button "Stone watch, Seat 2, 1 armies, Seat 2": Stone watch 1
    - button "Upper ridge, Seat 2, 6 armies, Seat 2": Upper ridge 6
    - button "Marsh keep, Seat 2, 3 armies, Seat 2": Marsh keep 3
    - button "New fell, Seat 2, 1 armies, Seat 2": New fell 1
    - button "Moon point, Seat 3, 1 armies, Seat 3": Moon point 1
    - button "South fell, Seat 2, 1 armies, Seat 2": South fell 1
    - button "High ridge, Seat 2, 1 armies, Seat 2": High ridge 1
    - button "Bay ford, Seat 2, 1 armies, Seat 2": Bay ford 1
    - button "Low moor, Seat 3, 1 armies, Seat 3": Low moor 1
    - button "Lower field, Seat 3, 1 armies, Seat 3": Lower field 1
    - button "Wind gate, Seat 3, 1 armies, Seat 3": Wind gate 1
    - button "Silver shore, Seat 3, 4 armies, Seat 3": Silver shore 4
    - button "Low peak, Seat 3, 1 armies, Seat 3": Low peak 1
    - button "Wind port, Seat 3, 1 armies, Seat 3": Wind port 1
    - button "Gold point, Seat 3, 1 armies, Seat 3": Gold point 1 ★
    - button "Rock moor, Seat 2, 1 armies, Seat 2": Rock moor 1
    - button "Marsh rest, Seat 3, 1 armies, Seat 3": Marsh rest 1
    - button "Wind dale, Seat 3, 11 armies, Seat 3": Wind dale 11
    - button "Silver ford, Seat 2, 1 armies, Seat 2": Silver ford 1
    - button "Iron field, Seat 2, 1 armies, Seat 2": Iron field 1
    - button "North wood, Seat 2, 1 armies, Seat 2": North wood 1
    - button "Fort town, Seat 3, 1 armies, Seat 3": Fort town 1 ★
    - button "Red field, Seat 2, 3 armies, Seat 2": Red field 3 ★
    - button "South ridge, Seat 2, 2 armies, Seat 2": South ridge 2
    - button "Rock bay, Seat 3, 1 armies, Seat 3": Rock bay 1
    - button "North ford, Seat 3, 1 armies, Seat 3": North ford 1
    - button "Port ridge, Seat 3, 1 armies, Seat 3": Port ridge 1
    - button "New rock, Seat 2, 2 armies, Seat 2": New rock 2
    - button "South reach, Seat 3, 3 armies, Seat 3": South reach 3
    - button "Silver point, Seat 3, 1 armies, Seat 3": Silver point 1
    - button "East ford, Seat 3, 1 armies, Seat 3": East ford 1
    - button "Gold town, Seat 3, 6 armies, Seat 3": Gold town 6
    - text: North Isle +3 East Isle +3 West Isle +3 South Isle +3 Central Isle +5 Harbor Isle +5 Palm Isle +6 Cliff Isle +5 Great Isle +9
  - complementary:
    - text: Human seats eliminated Choose Watch computers or Stop game.
    - region "Game result":
      - heading "The human game has ended" [level=2]
      - paragraph: All human seats have been eliminated.
      - table "Countries and armies at turn end":
        - caption: Countries and armies at turn end
        - rowgroup:
          - row "Seat Countries Armies":
            - columnheader "Seat"
            - columnheader "Countries"
            - columnheader "Armies"
        - rowgroup:
          - row "Seat 3 24 46":
            - rowheader "Seat 3"
            - cell "24"
            - cell "46"
          - row "Seat 2 22 48":
            - rowheader "Seat 2"
            - cell "22"
            - cell "48"
          - row "Seat 1 0 0":
            - rowheader "Seat 1"
            - cell "0"
            - cell "0"
      - paragraph: Watch the remaining computer seats, or stop here.
      - button "Watch computers"
      - button "Stop game"
    - heading "Battle log" [level=3]
    - list "Battle log":
      - listitem: T5 Seat 3 ends the turn
      - listitem: Seat 1 is eliminated
      - listitem: "T5 Seat 3: East ford → Gold town, took Gold town"
      - listitem: "T5 Seat 3: East ford → Gold town, -0 / -1"
      - listitem: "T5 Seat 3: East ford → Gold town, -1 / -0"
      - listitem: "T5 Seat 3: East ford → Gold town, -1 / -0"
      - listitem: "T5 Seat 3: East ford → Gold town, -1 / -0"
```

# Test source

```ts
  1  | import {pinned} from '../core/versioned-match-fixture';
  2  | import {expect,test} from '@playwright/test';
  3  | import type {Page} from '@playwright/test';
  4  | import {readFileSync,mkdirSync,writeFileSync} from 'node:fs';
  5  | import {join} from 'node:path';
  6  | import {apply,computerAction,deserializeVersionedMatch} from '../../src/core';
  7  | import type {Action} from '../../src/core';
  8  | const fixtures='docs/prototypes/new-game/T71/fixtures';
  9  | const input=(host:string,label:string)=>readFileSync(join(fixtures,`${host}-${label}.json`),'utf8');
  10 | const categories=['reinforcement','selection-ready','exchange','repeated-pair','capture-movement','friendly-movement'];
  11 | const mode=(p:Page)=>p.getByRole('combobox',{name:'Panel detail',exact:true});
  12 | async function begin(p:Page,host:string){
  13 |  await p.clock.install({time:new Date('2026-10-18T12:00:00Z')});await p.clock.pauseAt(new Date('2026-10-18T12:00:00Z'));
  14 |  await p.goto(host==='reference'?'/?view=reference-game':'/');
  15 |  await p.evaluate(()=>{const create=URL.createObjectURL.bind(URL);URL.createObjectURL=blob=>{Reflect.set(window,'compactPanelSave',blob);return create(blob);};});
  16 | }
  17 | async function save(p:Page){await p.getByRole('button',{name:'Save game',exact:true}).click();return p.evaluate(()=>(Reflect.get(window,'compactPanelSave') as Blob).text());}
  18 | async function load(p:Page,text:string){
  19 |  const previous=await p.getByLabel('Load game',{exact:true}).elementHandle();
  20 |  await p.getByLabel('Load game',{exact:true}).setInputFiles({name:'panels.json',mimeType:'application/json',buffer:Buffer.from(text)});
  21 |  await expect.poll(()=>previous!.evaluate(el=>el.isConnected)).toBe(false);await expect(p.locator('[data-country]')).toHaveCount(46);
  22 | }
  23 | async function bounds(p:Page){return p.locator('.battle-reference').evaluate(root=>{
  24 |  const selectors=['.topbar','.board','.panel','.panel>.turn','.panel>.action','.panel>.log-card'];
  25 |  return Object.fromEntries(selectors.map(selector=>{const r=root.querySelector(selector)!.getBoundingClientRect();return [selector,{x:r.x,y:r.y,width:r.width,height:r.height}];}));
  26 | });}
  27 | function stable(actual:Awaited<ReturnType<typeof bounds>>,anchor:Awaited<ReturnType<typeof bounds>>){
  28 |  for(const selector of Object.keys(anchor))for(const axis of ['x','y','width','height'] as const)expect(Math.abs(actual[selector]![axis]-anchor[selector]![axis]),`${selector} ${axis}`).toBeLessThanOrEqual(1);
  29 | }
  30 | async function essentials(p:Page){
  31 |  for(const locator of [mode(p),p.locator('#game-pause-button'),p.locator('#game-speed'),p.getByRole('button',{name:'Game event log',exact:true}),...await p.getByTestId('player-army-total').all()]){
  32 |   await expect(locator).toBeVisible();expect(await locator.evaluate(el=>{const r=el.getBoundingClientRect();return r.left>=0&&r.top>=0&&r.right<=innerWidth+1&&r.bottom<=innerHeight+1;})).toBe(true);
  33 |  }
  34 |  expect(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  35 | }
  36 | function evidence(info:{project:{name:string}},host:string,label:string){const dir=process.env['COMPACT_PANEL_EVIDENCE_DIR']??'screenshots/compact-panels';mkdirSync(dir,{recursive:true});return join(dir,`${info.project.name}-${host}-${label}`);}
  37 | test.use({video:'on'});
  38 | for(const host of ['reference','geographic']){
  39 |  // Separate baseline geometry check still runs when the mode control is absent.
  40 |  test(`${host}: computer phase changes keep actual card bounds stable`,async({page},info)=>{
  41 |   await begin(page,host);let anchor:Awaited<ReturnType<typeof bounds>>|undefined;const samples=[];
  42 |   for(const label of categories){
  43 |    await load(page,input(host,label));const before=await bounds(page);anchor??=before;samples.push({label,before});
  44 |    stable(before,anchor);await page.clock.runFor(350);stable(await bounds(page),anchor);
  45 |   }
  46 |   writeFileSync(evidence(info,host,'geometry')+'.json',JSON.stringify(samples,null,2));
  47 |  });
  48 |  for(const detail of ['compact','detailed'])test(`${host} ${detail}: real computer actions retain fixed panel areas and essentials`,async({page},info)=>{
  49 |   await begin(page,host);let anchor:Awaited<ReturnType<typeof bounds>>|undefined;const samples=[];
  50 |   for(const label of categories){
  51 |    const text=input(host,label);await load(page,text);await expect(mode(page)).toBeVisible({timeout:1000});await mode(page).selectOption(detail);await expect(page.locator('.battle-reference')).toHaveAttribute('data-panel-detail',detail);
  52 |    await page.locator('#game-speed').selectOption('normal');const before=deserializeVersionedMatch(await save(page));expect(before.identity.boardGenerator.id).toBe(host==='reference'?'fixed-reference':'geographic');
  53 |    const action=computerAction(before.state);expect(action).not.toBeNull();const result=apply(before.state,action!);if(!result.ok)throw Error(result.error);
  54 |    const initial=await bounds(page);anchor??=initial;stable(initial,anchor);await essentials(page);
  55 |    await page.clock.runFor(350);expect(deserializeVersionedMatch(await save(page)).state).toEqual(result.state);const after=await bounds(page);stable(after,anchor);await essentials(page);
  56 |    const dice=page.locator('.battle-rolls');if(await dice.count()){if(detail==='compact')await expect(dice).toBeHidden();else if(result.state.log.some(e=>e.event==='attack'))await expect(dice).toBeVisible();}
  57 |    samples.push({label,action,before:initial,after});await page.screenshot({path:evidence(info,host,detail+'-'+label)+'.png'});
  58 |   }
  59 |   writeFileSync(evidence(info,host,detail+'-bounds')+'.json',JSON.stringify(samples,null,2));
  60 |  });
  61 |  test(`${host}: default/reversible keyboard mode preserves pause, speed, log, load and next callback`,async({page})=>{
  62 |   await begin(page,host);await load(page,input(host,'capture-movement'));await expect(mode(page)).toHaveValue('compact',{timeout:1000});
  63 |   await page.locator('#game-pause-button').click();await page.locator('#game-speed').selectOption('very-slow');const frozen=await save(page);
  64 |   await mode(page).focus();await mode(page).press('End');await expect(mode(page)).toHaveValue('detailed');expect(await save(page)).toBe(frozen);
  65 |   await page.getByRole('button',{name:'Game event log',exact:true}).click();await expect(page.getByRole('dialog')).toBeVisible();await page.keyboard.press('Escape');
  66 |   await mode(page).selectOption('compact');await mode(page).selectOption('detailed');await expect(page.locator('#game-pause-button')).toHaveText('Resume');await expect(page.locator('#game-speed')).toHaveValue('very-slow');
  67 |   await page.clock.runFor(10000);expect(await save(page)).toBe(frozen);await essentials(page);
  68 |   await page.locator('#game-pause-button').click();await page.clock.runFor(1999);expect(await save(page)).toBe(frozen);await page.clock.runFor(1);
  69 |   const before=deserializeVersionedMatch(frozen),a=computerAction(before.state)!,r=apply(before.state,a);if(!r.ok)throw Error(r.error);expect(deserializeVersionedMatch(await save(page)).state).toEqual(r.state);
  70 |   await load(page,input(host,'reinforcement'));await expect(mode(page)).toHaveValue('detailed');await expect(page.locator('#game-speed')).toHaveValue('very-slow');await mode(page).selectOption('compact');await expect(mode(page)).toHaveValue('compact',{timeout:1000});
  71 |  });
  72 |  for(const detail of ['compact','detailed'])test(`${host} ${detail}: mandatory human capture and friendly movement remain visible and operable`,async({page},info)=>{
  73 |   await begin(page,host);
  74 |   function human(label:string){const v=JSON.parse(input(host,label));v.options.seats=v.options.seats.map(()=>({kind:'human'}));v.options.computerStrengths=[];const text=JSON.stringify(v);expect(()=>deserializeVersionedMatch(text)).not.toThrow();return text;}
  75 |   await load(page,human('capture-movement'));await expect(mode(page)).toBeVisible({timeout:1000});await mode(page).selectOption(detail);const before=deserializeVersionedMatch(await save(page));expect(before.state.phase).toBe('capture');
  76 |   for(const id of ['capture-amount','confirm-capture-button']){await expect(page.locator('#'+id)).toBeVisible();await expect(page.locator('#'+id)).toBeEnabled();expect(await page.locator('#'+id).evaluate(el=>{const a=el.closest('.action')!.getBoundingClientRect(),r=el.getBoundingClientRect();return r.top>=a.top&&r.bottom<=a.bottom+1;}),id+' stays inside action card').toBe(true);}
  77 |   await essentials(page);await page.screenshot({path:evidence(info,host,detail+'-human-capture')+'.png'});await page.locator('#confirm-capture-button').click();expect(deserializeVersionedMatch(await save(page)).state.history.at(-1)!.kind).toBe('captureMove');
  78 |   await load(page,human('friendly-movement'));const moving=deserializeVersionedMatch(await save(page)),trace=JSON.parse(readFileSync(join(fixtures,'fixture-discovery.json'),'utf8')).results.find((x:{host:string})=>x.host===host),action=trace.found['friendly-movement'].action as Extract<Action,{kind:'friendlyMove'}>;
  79 |   await page.locator('#start-friendly-move-button').click();await page.locator(`[data-country="${action.from}"]`).click();await page.locator(`[data-country="${action.to}"]`).click();
  80 |   for(const id of ['friendly-move-amount','confirm-friendly-move-button','cancel-friendly-move-button','skip-friendly-move-button']){await expect(page.locator('#'+id)).toBeVisible();await expect(page.locator('#'+id)).toBeEnabled();expect(await page.locator('#'+id).evaluate(el=>{const a=el.closest('.action')!.getBoundingClientRect(),r=el.getBoundingClientRect();return r.top>=a.top&&r.bottom<=a.bottom+1;}),id+' stays inside action card').toBe(true);}
  81 |   await essentials(page);await page.screenshot({path:evidence(info,host,detail+'-human-move')+'.png'});await page.locator('#friendly-move-amount').fill('1');await page.locator('#confirm-friendly-move-button').click();
  82 |   const expected=apply(moving.state,{...action,amount:1});if(!expected.ok)throw Error(expected.error);expect(deserializeVersionedMatch(await save(page)).state).toEqual(expected.state);
  83 |  });
  84 | }
  85 | 
  86 | for(const detail of ['compact','detailed'])test(`reference ${detail}: human-loss choices fit and remain usable`,async({page},info)=>{
> 87 |  await begin(page,'reference');await load(page,pinned('human-loss').text);await expect(mode(page)).toBeVisible({timeout:1000});await mode(page).selectOption(detail);
     |                                                                                                    ^ Error: expect(locator).toBeVisible() failed
  88 |  for(const id of ['watch-computers-button','stop-game-button']){const el=page.locator('#'+id);await expect(el).toBeVisible();await expect(el).toBeEnabled();expect(await el.evaluate(node=>{const a=node.closest('.action')!.getBoundingClientRect(),r=node.getBoundingClientRect();return r.top>=a.top&&r.bottom<=a.bottom+1&&r.right<=innerWidth&&r.bottom<=innerHeight;})).toBe(true);}
  89 |  await essentials(page);await page.screenshot({path:evidence(info,'reference',detail+'-human-loss')+'.png'});const previous=deserializeVersionedMatch(await save(page)).state;
  90 |  await page.locator('#stop-game-button').click();const result=apply(previous,{kind:'stopGame'});if(!result.ok)throw Error(result.error);expect(deserializeVersionedMatch(await save(page)).state).toEqual(result.state);
  91 |  await load(page,pinned('human-loss').text);await page.locator('#watch-computers-button').click();expect(deserializeVersionedMatch(await save(page)).state.watchingComputers).toBe(true);
  92 | });
  93 | 
```