# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: compact-panels.spec.ts >> reference: computer phase changes keep actual card bounds stable
- Location: tests/e2e/compact-panels.spec.ts:40:2

# Error details

```
Error: .panel>.turn height

expect(received).toBeLessThanOrEqual(expected)

Expected: <= 1
Received:    18.1875
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 1 human / 3 computer seats · Computer play · Seed 1994
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]:
          - strong [ref=e13]: "Total armies: 22"
          - generic [ref=e14]: 11 provinces
      - generic [ref=e18]:
        - generic [ref=e19]: Seat 2 · Computer
        - generic [ref=e20]:
          - strong [ref=e21]: "Total armies: 24"
          - generic [ref=e22]: 12 provinces
      - generic [ref=e26]:
        - generic [ref=e27]: Seat 3 · Computer
        - generic [ref=e28]:
          - strong [ref=e29]: "Total armies: 24"
          - generic [ref=e30]: 12 provinces
      - generic [ref=e34]:
        - generic [ref=e35]: Seat 4 · Computer
        - generic [ref=e36]:
          - strong [ref=e37]: "Total armies: 25"
          - generic [ref=e38]: 11 provinces
    - generic [ref=e39]:
      - button "Game event log" [ref=e40] [cursor=pointer]
      - button "Pause game" [ref=e41] [cursor=pointer]: Pause
      - generic [ref=e42]: Game speed
      - combobox "Game speed" [ref=e43]:
        - option "Very slow (2 s)"
        - option "Slow"
        - option "Normal" [selected]
        - option "Fast"
      - generic [ref=e44]: Panel detail
      - combobox "Panel detail" [ref=e45]:
        - option "Compact" [selected]
        - option "Detailed"
    - contentinfo [ref=e46]:
      - button "New game" [ref=e47] [cursor=pointer]
    - generic [ref=e48]:
      - button "Save game" [ref=e49] [cursor=pointer]
      - generic [ref=e50]:
        - generic [ref=e51]: Load game
        - button "Load game" [ref=e52]
  - main [ref=e53]:
    - img "Nine Isles reference map" [ref=e55]:
      - button "River gate, Seat 3, 2 armies, Seat 3" [ref=e81] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: "2"
      - button "New port, Seat 1, 2 armies, Seat 1" [ref=e83] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: "2"
      - button "North rest, Seat 2, 1 armies, Seat 2" [ref=e85] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: "1"
      - button "River keep, Seat 2, 1 armies, Seat 2" [ref=e87] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: "1"
      - button "North town, Seat 2, 1 armies, Seat 2" [ref=e89] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: "1"
      - button "Dark ford, Seat 3, 1 armies, Seat 3" [ref=e91] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: "1"
      - button "Iron point, Seat 3, 1 armies, Seat 3" [ref=e93] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: "1"
      - button "South rest, Seat 3, 3 armies, Seat 3" [ref=e95] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: "3"
      - button "High shore, Seat 1, 2 armies, Seat 1" [ref=e97] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: "2"
      - button "Wind town, Seat 2, 3 armies, Seat 2" [ref=e99] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: "3"
      - button "New glen, Seat 4, 2 armies, Seat 4" [ref=e101] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: "2"
      - button "Old rock, Seat 3, 2 armies, Seat 3" [ref=e103] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: "2"
      - button "Blue peak, Seat 2, 3 armies, Seat 2" [ref=e105] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: "3"
      - button "West haven, Seat 2, 1 armies, Seat 2" [ref=e107] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: "1"
      - button "Stone watch, Seat 2, 3 armies, Seat 2" [ref=e109] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: "3"
      - button "Upper ridge, Seat 4, 2 armies, Seat 4" [ref=e111] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: "2"
      - button "Marsh keep, Seat 1, 3 armies, Seat 1" [ref=e113] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: "3"
      - button "New fell, Seat 4, 2 armies, Seat 4" [ref=e115] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: "2"
      - button "Moon point, Seat 2, 2 armies, Seat 2" [ref=e117] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: "2"
      - button "South fell, Seat 1, 3 armies, Seat 1" [ref=e119] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: "3"
      - button "High ridge, Seat 2, 2 armies, Seat 2" [ref=e121] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: "2"
      - button "Bay ford, Seat 2, 3 armies, Seat 2" [ref=e123] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: "3"
      - button "Low moor, Seat 1, 2 armies, Seat 1" [ref=e125] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: "2"
      - button "Lower field, Seat 1, 1 armies, Seat 1" [ref=e127] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: "1"
      - button "Wind gate, Seat 3, 1 armies, Seat 3" [ref=e129] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: "1"
      - button "Silver shore, Seat 4, 1 armies, Seat 4" [ref=e131] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: "1"
      - button "Low peak, Seat 4, 1 armies, Seat 4" [ref=e133] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: "1"
      - button "Wind port, Seat 4, 3 armies, Seat 4" [ref=e135] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: "3"
      - button "Gold point, Seat 3, 2 armies, Seat 3" [ref=e137] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: "2"
        - generic [ref=e139]: ★
      - button "Rock moor, Seat 1, 2 armies, Seat 1" [ref=e140] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: "2"
      - button "Marsh rest, Seat 3, 2 armies, Seat 3" [ref=e142] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: "2"
      - button "Wind dale, Seat 4, 1 armies, Seat 4" [ref=e144] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: "1"
      - button "Silver ford, Seat 4, 2 armies, Seat 4" [ref=e146] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: "2"
      - button "Iron field, Seat 4, 2 armies, Seat 4" [ref=e148] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: "2"
      - button "North wood, Seat 1, 1 armies, Seat 1" [ref=e150] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: "1"
      - button "Fort town, Seat 3, 2 armies, Seat 3" [ref=e152] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: "2"
        - generic [ref=e154]: ★
      - button "Red field, Seat 2, 3 armies, Seat 2" [ref=e155] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: "3"
        - generic [ref=e157]: ★
      - button "South ridge, Seat 1, 2 armies, Seat 1" [ref=e158] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: "2"
      - button "Rock bay, Seat 2, 1 armies, Seat 2" [ref=e160] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: "1"
      - button "North ford, Seat 4, 3 armies, Seat 4" [ref=e162] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: "3"
      - button "Port ridge, Seat 3, 3 armies, Seat 3" [ref=e164] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: "3"
      - button "New rock, Seat 1, 1 armies, Seat 1" [ref=e166] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: "1"
      - button "South reach, Seat 3, 3 armies, Seat 3" [ref=e168] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: "3"
      - button "Silver point, Seat 3, 2 armies, Seat 3" [ref=e170] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: "2"
      - button "East ford, Seat 1, 3 armies, Seat 1" [ref=e172] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: "3"
      - button "Gold town, Seat 4, 6 armies, Seat 4" [ref=e174] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: "6"
      - generic [ref=e206]: North Isle +3
      - generic [ref=e207]: East Isle +3
      - generic [ref=e208]: West Isle +3
      - generic [ref=e209]: South Isle +3
      - generic [ref=e210]: Central Isle +5
      - generic [ref=e211]: Harbor Isle +5
      - generic [ref=e212]: Palm Isle +6
      - generic [ref=e213]: Cliff Isle +5
      - generic [ref=e214]: Great Isle +9
    - complementary [ref=e215]:
      - generic [ref=e219]:
        - generic [ref=e220]: Seat 4's turn
        - generic [ref=e221]: Computer · Normal · Round 1 · Attack
      - generic [ref=e222]:
        - generic [ref=e223]:
          - button "End turn" [disabled] [ref=e224]
          - button "Move armies" [disabled] [ref=e225]
        - region "Battle controls" [ref=e226]:
          - heading "Battle" [level=2] [ref=e227]
          - generic [ref=e228]:
            - generic [ref=e229]:
              - generic [ref=e230]: From
              - strong [ref=e231]: Choose your country
              - generic "Source armies" [ref=e232]: —
            - generic [ref=e233]:
              - generic [ref=e234]: Target
              - strong [ref=e235]: Choose an enemy neighbour
              - generic "Target armies" [ref=e236]: —
          - generic [ref=e237]:
            - generic [ref=e238]:
              - text: Stop at armies
              - spinbutton "Stop at armies" [disabled] [ref=e239]: "2"
            - generic [ref=e240]:
              - text: Battle speed
              - combobox "Battle speed" [ref=e241]:
                - option "Very slow"
                - option "Slow"
                - option "Normal" [selected]
                - option "Fast"
          - paragraph [ref=e242]: Choose a source and target to begin.
          - generic [ref=e243]:
            - button "Fight on" [disabled] [ref=e244]
            - button "Stop" [disabled] [ref=e245]
            - button "Single exchange" [disabled] [ref=e246]
          - generic [ref=e247]:
            - strong [ref=e248]: Ready for your choice
            - paragraph [ref=e249]: Choose your country, then click an enemy to attack. Shift-click or Shift-Enter selects only.
          - paragraph [ref=e250]:
            - text: Won 0 · Lost 0 · Ties
            - strong [ref=e251]: "0"
        - status [ref=e252]: Seat 4 is playing…
      - generic [ref=e253]:
        - heading "Battle log" [level=3] [ref=e254]
        - list "Battle log"
```

# Test source

```ts
  1  | import {pinned} from '../core/versioned-match-fixture';
  2  | import {expect,test} from '@playwright/test';
  3  | import type {Page} from '@playwright/test';
  4  | import {readFileSync,mkdirSync,writeFileSync} from 'node:fs';
  5  | import {join} from 'node:path';
  6  | import {apply,computerAction,deserializeVersionedMatch} from '../../src/core';
  7  | import type {Action} from '../../src/core';
  8  | const fixtures='docs/prototypes/new-game/T71/fixtures';
  9  | const input=(host:string,label:string)=>readFileSync(join(fixtures,`${host}-${label}.json`),'utf8');
  10 | const categories=['reinforcement','selection-ready','exchange','repeated-pair','capture-movement','friendly-movement'];
  11 | const mode=(p:Page)=>p.getByRole('combobox',{name:'Panel detail',exact:true});
  12 | async function begin(p:Page,host:string){
  13 |  await p.clock.install({time:new Date('2026-10-18T12:00:00Z')});await p.clock.pauseAt(new Date('2026-10-18T12:00:00Z'));
  14 |  await p.goto(host==='reference'?'/?view=reference-game':'/');
  15 |  await p.evaluate(()=>{const create=URL.createObjectURL.bind(URL);URL.createObjectURL=blob=>{Reflect.set(window,'compactPanelSave',blob);return create(blob);};});
  16 | }
  17 | async function save(p:Page){await p.getByRole('button',{name:'Save game',exact:true}).click();return p.evaluate(()=>(Reflect.get(window,'compactPanelSave') as Blob).text());}
  18 | async function load(p:Page,text:string){
  19 |  const previous=await p.getByLabel('Load game',{exact:true}).elementHandle();
  20 |  await p.getByLabel('Load game',{exact:true}).setInputFiles({name:'panels.json',mimeType:'application/json',buffer:Buffer.from(text)});
  21 |  await expect.poll(()=>previous!.evaluate(el=>el.isConnected)).toBe(false);await expect(p.locator('[data-country]')).toHaveCount(46);
  22 | }
  23 | async function bounds(p:Page){return p.locator('.battle-reference').evaluate(root=>{
  24 |  const selectors=['.topbar','.board','.panel','.panel>.turn','.panel>.action','.panel>.log-card'];
  25 |  return Object.fromEntries(selectors.map(selector=>{const r=root.querySelector(selector)!.getBoundingClientRect();return [selector,{x:r.x,y:r.y,width:r.width,height:r.height}];}));
  26 | });}
  27 | function stable(actual:Awaited<ReturnType<typeof bounds>>,anchor:Awaited<ReturnType<typeof bounds>>){
> 28 |  for(const selector of Object.keys(anchor))for(const axis of ['x','y','width','height'] as const)expect(Math.abs(actual[selector]![axis]-anchor[selector]![axis]),`${selector} ${axis}`).toBeLessThanOrEqual(1);
     |                                                                                                                                                                                          ^ Error: .panel>.turn height
  29 | }
  30 | async function essentials(p:Page){
  31 |  for(const locator of [mode(p),p.locator('#game-pause-button'),p.locator('#game-speed'),p.getByRole('button',{name:'Game event log',exact:true}),...await p.getByTestId('player-army-total').all()]){
  32 |   await expect(locator).toBeVisible();expect(await locator.evaluate(el=>{const r=el.getBoundingClientRect();return r.left>=0&&r.top>=0&&r.right<=innerWidth+1&&r.bottom<=innerHeight+1;})).toBe(true);
  33 |  }
  34 |  expect(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  35 | }
  36 | function evidence(info:{project:{name:string}},host:string,label:string){const dir=process.env['COMPACT_PANEL_EVIDENCE_DIR']??'screenshots/compact-panels';mkdirSync(dir,{recursive:true});return join(dir,`${info.project.name}-${host}-${label}`);}
  37 | test.use({video:'on'});
  38 | for(const host of ['reference','geographic']){
  39 |  // Separate baseline geometry check still runs when the mode control is absent.
  40 |  test(`${host}: computer phase changes keep actual card bounds stable`,async({page},info)=>{
  41 |   await begin(page,host);let anchor:Awaited<ReturnType<typeof bounds>>|undefined;const samples=[];
  42 |   for(const label of categories){
  43 |    await load(page,input(host,label));const before=await bounds(page);anchor??=before;samples.push({label,before});
  44 |    stable(before,anchor);await page.clock.runFor(350);stable(await bounds(page),anchor);
  45 |   }
  46 |   writeFileSync(evidence(info,host,'geometry')+'.json',JSON.stringify(samples,null,2));
  47 |  });
  48 |  for(const detail of ['compact','detailed'])test(`${host} ${detail}: real computer actions retain fixed panel areas and essentials`,async({page},info)=>{
  49 |   await begin(page,host);let anchor:Awaited<ReturnType<typeof bounds>>|undefined;const samples=[];
  50 |   for(const label of categories){
  51 |    const text=input(host,label);await load(page,text);await expect(mode(page)).toBeVisible({timeout:1000});await mode(page).selectOption(detail);await expect(page.locator('.battle-reference')).toHaveAttribute('data-panel-detail',detail);
  52 |    await page.locator('#game-speed').selectOption('normal');const before=deserializeVersionedMatch(await save(page));expect(before.identity.boardGenerator.id).toBe(host==='reference'?'fixed-reference':'geographic');
  53 |    const action=computerAction(before.state);expect(action).not.toBeNull();const result=apply(before.state,action!);if(!result.ok)throw Error(result.error);
  54 |    const initial=await bounds(page);anchor??=initial;stable(initial,anchor);await essentials(page);
  55 |    await page.clock.runFor(350);expect(deserializeVersionedMatch(await save(page)).state).toEqual(result.state);const after=await bounds(page);stable(after,anchor);await essentials(page);
  56 |    const dice=page.locator('.battle-rolls');if(await dice.count()){if(detail==='compact')await expect(dice).toBeHidden();else if(result.state.log.some(e=>e.event==='attack'))await expect(dice).toBeVisible();}
  57 |    samples.push({label,action,before:initial,after});await page.screenshot({path:evidence(info,host,detail+'-'+label)+'.png'});
  58 |   }
  59 |   writeFileSync(evidence(info,host,detail+'-bounds')+'.json',JSON.stringify(samples,null,2));
  60 |  });
  61 |  test(`${host}: default/reversible keyboard mode preserves pause, speed, log, load and next callback`,async({page})=>{
  62 |   await begin(page,host);await load(page,input(host,'capture-movement'));await expect(mode(page)).toHaveValue('compact',{timeout:1000});
  63 |   await page.locator('#game-pause-button').click();await page.locator('#game-speed').selectOption('very-slow');const frozen=await save(page);
  64 |   await mode(page).focus();await mode(page).press('End');await expect(mode(page)).toHaveValue('detailed');expect(await save(page)).toBe(frozen);
  65 |   await page.getByRole('button',{name:'Game event log',exact:true}).click();await expect(page.getByRole('dialog')).toBeVisible();await page.keyboard.press('Escape');
  66 |   await mode(page).selectOption('compact');await mode(page).selectOption('detailed');await expect(page.locator('#game-pause-button')).toHaveText('Resume');await expect(page.locator('#game-speed')).toHaveValue('very-slow');
  67 |   await page.clock.runFor(10000);expect(await save(page)).toBe(frozen);await essentials(page);
  68 |   await page.locator('#game-pause-button').click();await page.clock.runFor(1999);expect(await save(page)).toBe(frozen);await page.clock.runFor(1);
  69 |   const before=deserializeVersionedMatch(frozen),a=computerAction(before.state)!,r=apply(before.state,a);if(!r.ok)throw Error(r.error);expect(deserializeVersionedMatch(await save(page)).state).toEqual(r.state);
  70 |   await load(page,input(host,'reinforcement'));await expect(mode(page)).toHaveValue('detailed');await expect(page.locator('#game-speed')).toHaveValue('very-slow');await mode(page).selectOption('compact');await expect(mode(page)).toHaveValue('compact',{timeout:1000});
  71 |  });
  72 |  for(const detail of ['compact','detailed'])test(`${host} ${detail}: mandatory human capture and friendly movement remain visible and operable`,async({page},info)=>{
  73 |   await begin(page,host);
  74 |   function human(label:string){const v=JSON.parse(input(host,label));v.options.seats=v.options.seats.map(()=>({kind:'human'}));v.options.computerStrengths=[];const text=JSON.stringify(v);expect(()=>deserializeVersionedMatch(text)).not.toThrow();return text;}
  75 |   await load(page,human('capture-movement'));await expect(mode(page)).toBeVisible({timeout:1000});await mode(page).selectOption(detail);const before=deserializeVersionedMatch(await save(page));expect(before.state.phase).toBe('capture');
  76 |   for(const id of ['capture-amount','confirm-capture-button']){await expect(page.locator('#'+id)).toBeVisible();await expect(page.locator('#'+id)).toBeEnabled();expect(await page.locator('#'+id).evaluate(el=>{const a=el.closest('.action')!.getBoundingClientRect(),r=el.getBoundingClientRect();return r.top>=a.top&&r.bottom<=a.bottom+1;}),id+' stays inside action card').toBe(true);}
  77 |   await essentials(page);await page.screenshot({path:evidence(info,host,detail+'-human-capture')+'.png'});await page.locator('#confirm-capture-button').click();expect(deserializeVersionedMatch(await save(page)).state.history.at(-1)!.kind).toBe('captureMove');
  78 |   await load(page,human('friendly-movement'));const moving=deserializeVersionedMatch(await save(page)),trace=JSON.parse(readFileSync(join(fixtures,'fixture-discovery.json'),'utf8')).results.find((x:{host:string})=>x.host===host),action=trace.found['friendly-movement'].action as Extract<Action,{kind:'friendlyMove'}>;
  79 |   await page.locator('#start-friendly-move-button').click();await page.locator(`[data-country="${action.from}"]`).click();await page.locator(`[data-country="${action.to}"]`).click();
  80 |   for(const id of ['friendly-move-amount','confirm-friendly-move-button','cancel-friendly-move-button','skip-friendly-move-button']){await expect(page.locator('#'+id)).toBeVisible();await expect(page.locator('#'+id)).toBeEnabled();expect(await page.locator('#'+id).evaluate(el=>{const a=el.closest('.action')!.getBoundingClientRect(),r=el.getBoundingClientRect();return r.top>=a.top&&r.bottom<=a.bottom+1;}),id+' stays inside action card').toBe(true);}
  81 |   await essentials(page);await page.screenshot({path:evidence(info,host,detail+'-human-move')+'.png'});await page.locator('#friendly-move-amount').fill('1');await page.locator('#confirm-friendly-move-button').click();
  82 |   const expected=apply(moving.state,{...action,amount:1});if(!expected.ok)throw Error(expected.error);expect(deserializeVersionedMatch(await save(page)).state).toEqual(expected.state);
  83 |  });
  84 | }
  85 | 
  86 | for(const detail of ['compact','detailed'])test(`reference ${detail}: human-loss choices fit and remain usable`,async({page},info)=>{
  87 |  await begin(page,'reference');await load(page,pinned('human-loss').text);await expect(mode(page)).toBeVisible({timeout:1000});await mode(page).selectOption(detail);
  88 |  for(const id of ['watch-computers-button','stop-game-button']){const el=page.locator('#'+id);await expect(el).toBeVisible();await expect(el).toBeEnabled();expect(await el.evaluate(node=>{const a=node.closest('.action')!.getBoundingClientRect(),r=node.getBoundingClientRect();return r.top>=a.top&&r.bottom<=a.bottom+1&&r.right<=innerWidth&&r.bottom<=innerHeight;})).toBe(true);}
  89 |  await essentials(page);await page.screenshot({path:evidence(info,'reference',detail+'-human-loss')+'.png'});const previous=deserializeVersionedMatch(await save(page)).state;
  90 |  await page.locator('#stop-game-button').click();const result=apply(previous,{kind:'stopGame'});if(!result.ok)throw Error(result.error);expect(deserializeVersionedMatch(await save(page)).state).toEqual(result.state);
  91 |  await load(page,pinned('human-loss').text);await page.locator('#watch-computers-button').click();expect(deserializeVersionedMatch(await save(page)).state.watchingComputers).toBe(true);
  92 | });
  93 | 
```