import {mkdirSync,cpSync,readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {build,preview} from 'vite';
import {chromium} from '@playwright/test';
const owned=fileURLToPath(new URL('./',import.meta.url)),root=resolve(owned,'disposable-app');
const output=resolve(owned,process.argv[2]??'candidate-probe');
mkdirSync(root,{recursive:true});
for(const name of ['src','data','public','index.html','package.json','tsconfig.json'])cpSync(resolve(name),resolve(root,name),{recursive:true});
for(const name of ['docs/prototypes/new-game/T63/board.json','docs/prototypes/new-game/T34/witness.json','docs/prototypes/new-game/T65/map.svg']){mkdirSync(resolve(root,name,'..'),{recursive:true});cpSync(resolve(name),resolve(root,name));}
cpSync(resolve(owned,'mock-src/src'),resolve(root,'src'),{recursive:true});
await build({root,configFile:false,logLevel:'error',build:{outDir:'dist'}});
const server=await preview({root,configFile:false,logLevel:'error',preview:{host:'127.0.0.1',port:4181,strictPort:true}});
const browser=await chromium.launch({headless:true});
const results=[];
try{
 for(const viewport of [{width:1280,height:800},{width:1920,height:1080}])for(const host of ['reference','geographic'])for(const mode of ['compact','detailed']){
  const label=`${host}-${mode}-${viewport.width}`,dir=resolve(output,label);mkdirSync(dir,{recursive:true});
  const context=await browser.newContext({viewport,recordVideo:{dir,size:viewport}}),page=await context.newPage();
  const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.clock.install();await page.clock.pauseAt(new Date());
  await page.goto(`http://127.0.0.1:4181/?seed=1994${host==='reference'?'&view=reference-game':''}`);
  const samples=[];
  for(const phase of ['reinforcement','selection-ready','exchange','repeated-pair','capture-movement','friendly-movement']){
   await page.getByLabel('Load game',{exact:true}).setInputFiles({name:'fixture.json',mimeType:'application/json',buffer:readFileSync(resolve(owned,'final-probe',`${host}-${phase}.json`))});
   await page.getByLabel('Panel detail',{exact:true}).selectOption(mode);
   for(const at of ['before','after']){
    if(at==='after')await page.clock.runFor(350);
    const sample=await page.evaluate(()=>{
     const box=el=>{const r=el.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,right:r.right,bottom:r.bottom};};
     const selectors=['.topbar','.board','.panel','.panel>.turn','.panel>.action','.panel>.log-card','.game-playback'];
     return {rects:Object.fromEntries(selectors.map(s=>[s,box(document.querySelector(s))])),overflow:document.documentElement.scrollWidth>innerWidth,phase:document.querySelector('.panel').dataset.phase,computer:document.querySelector('.panel').dataset.computerActive,actionScroll:document.querySelector('.action').scrollHeight,actionClient:document.querySelector('.action').clientHeight,visible:[...document.querySelectorAll('.action button,.action input')].filter(el=>el.getClientRects().length&&!el.disabled).map(el=>({id:el.id,...box(el)}))};
    });samples.push({phase,at,...sample});
    if(at==='after')await page.screenshot({path:resolve(dir,`${phase}-${at}.png`)});
   }
  }
  results.push({label,viewport,host,mode,errors,samples});await context.close();
 }
}finally{await browser.close();await new Promise(resolve=>server.httpServer.close(resolve));}
writeFileSync(resolve(output,'results.json'),JSON.stringify(results,null,2)+'\n');
console.log(JSON.stringify(results.map(r=>({label:r.label,errors:r.errors,overflow:r.samples.filter(s=>s.overflow).length,actionOverflow:r.samples.filter(s=>s.actionScroll>s.actionClient+1).map(s=>`${s.phase}/${s.at}`),drift:r.samples.map(s=>({phase:s.phase,at:s.at,rect:s.rects['.panel>.action']}))})),null,2));
