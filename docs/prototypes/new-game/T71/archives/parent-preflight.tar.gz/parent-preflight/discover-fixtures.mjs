// Read-only real-core probe. No source changes, browser, or production hook.
import {createServer} from 'vite';
import {mkdirSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const base=new URL(process.argv[2]??'./',import.meta.url);mkdirSync(base,{recursive:true});
const server=await createServer({configFile:false,server:{middlewareMode:true,watch:{ignored:['**/*']}},appType:'custom',logLevel:'error'});
try {
 const core=await server.ssrLoadModule('/src/core/index.ts');
 const {referenceMap}=await server.ssrLoadModule('/src/ui/referenceData.ts');
 const results=[];
 for(const host of ['reference','geographic']){
  const options={...core.defaultOptions(),seed:1994,seats:[{kind:'human'},{kind:'computer'},{kind:'computer'},{kind:'computer'}],computerStrengths:['Normal','Normal','Normal'],dominationWin:false,roundLimit:null};
  const generated=host==='reference'?core.createReferenceGame(referenceMap,options,core.victoryRules(options)):core.createGeographicGame(options);
  if(!generated.ok)throw Error(JSON.stringify(generated.errors));
  let state=generated.state;const trace=[],found={},pairs=new Map();
  const identity=host==='reference'?core.REFERENCE_MATCH_IDENTITY:core.GEOGRAPHIC_MATCH_IDENTITY;
  for(let step=0;step<1200;step++){
   const player=core.activePlayer(state);if(!player||['finished','human-loss'].includes(state.phase))break;
   let action;
   if(player.kind==='computer')action=core.computerAction(state);
   else if(state.phase==='reinforce')action=state.reinforcementPool?{kind:'reinforce',province:core.provincesOf(state,player.id)[0],amount:state.reinforcementPool}:{kind:'endReinforcement'};
   else if(state.phase==='attack')action={kind:'endTurn'};
   else throw Error('Unexpected human phase '+state.phase);
   if(!action)break;
   const result=core.apply(state,action);if(!result.ok)throw Error(result.error);
   const row={step,historyBefore:state.history.length,player:player.id,control:player.kind,phaseBefore:state.phase,action,phaseAfter:result.state.phase};trace.push(row);
   if(player.kind==='computer'){
    const labels=[];
    if(action.kind==='reinforce')labels.push('reinforcement');
    if(action.kind==='endReinforcement')labels.push('selection-ready');
    if(action.kind==='attack'){
     labels.push('exchange');const key=player.id+'/'+action.from+'/'+action.to;const count=(pairs.get(key)||0)+1;pairs.set(key,count);if(count>=2)labels.push('repeated-pair');
     if(result.state.pendingCapture)labels.push('capture-pending');
    }
    if(action.kind==='captureMove')labels.push('capture-movement');
    if(action.kind==='friendlyMove')labels.push('friendly-movement');
    for(const label of labels)if(!(label in found)){
     found[label]={...row,input:`${host}-${label}.json`};
     writeFileSync(new URL(found[label].input,base),core.serializeVersionedMatch(options,state.history,identity));
    }
   }
   state=result.state;
   if(['reinforcement','selection-ready','repeated-pair','capture-pending','capture-movement','friendly-movement'].every(k=>k in found))break;
  }
  results.push({host,options,found,trace,finalHistory:state.history.length,finalPhase:state.phase});
 }
 const body=JSON.stringify({purpose:'Fixture discovery only; not browser acceptance or visual approval',results},null,2)+'\n';
 writeFileSync(new URL('fixture-discovery.json',base),body);
 process.stdout.write(JSON.stringify({report:'fixture-discovery.json',sha256:createHash('sha256').update(body).digest('hex'),hosts:results.map(r=>({host:r.host,steps:r.trace.length,found:Object.keys(r.found)}))},null,2)+'\n');
}finally{await server.close();}
