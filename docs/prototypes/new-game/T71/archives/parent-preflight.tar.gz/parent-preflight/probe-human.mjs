import {readFileSync,mkdirSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {preview} from 'vite';
import {chromium} from '@playwright/test';
const owned=fileURLToPath(new URL('./',import.meta.url));
const output=resolve(owned,process.argv[2]??'candidate-v2-human');
const server=await preview({root:resolve(owned,'disposable-app'),configFile:false,logLevel:'error',preview:{host:'127.0.0.1',port:4182,strictPort:true}}),browser=await chromium.launch();
const results=[];
function pinned(name){const root=resolve('docs/prototypes/new-game/T31/fixtures');const data=JSON.parse(readFileSync(resolve(root,name+'.json'),'utf8'));return ('parts'in data?JSON.parse(data.parts.map(p=>JSON.parse(readFileSync(resolve(root,p),'utf8'))).join('')):data).text;}
try{for(const width of [1280,1920])for(const mode of ['compact','detailed']){
 const context=await browser.newContext({viewport:{width,height:width===1280?800:1080}}),page=await context.newPage();await page.clock.install();await page.clock.pauseAt(new Date());await page.goto('http://127.0.0.1:4182/?view=reference-game&control=manual');
 for(const fixture of ['pending-capture','move-ready-attack','move-ready','human-loss']){
  await page.getByLabel('Load game',{exact:true}).setInputFiles({name:'fixture.json',mimeType:'application/json',buffer:Buffer.from(pinned(fixture==='move-ready-attack'?'move-ready':fixture))});await page.getByLabel('Panel detail',{exact:true}).selectOption(mode);
  if(fixture==='move-ready')await page.locator('#start-friendly-move-button').click();
  const sample=await page.evaluate(()=>{
   const a=document.querySelector('.action'),r=a.getBoundingClientRect();
   return {action:{height:r.height,bottom:r.bottom,scroll:a.scrollHeight,client:a.clientHeight},controls:[...a.querySelectorAll('button,input,select')].filter(el=>el.getClientRects().length).map(el=>{const b=el.getBoundingClientRect();return {id:el.id,disabled:el.disabled,fits:b.left>=0&&b.top>=0&&b.right<=innerWidth+1&&b.bottom<=innerHeight+1,withinAction:b.bottom<=r.bottom+1};})};
  });results.push({width,mode,fixture,...sample});mkdirSync(output,{recursive:true});await page.screenshot({path:resolve(output,`${width}-${mode}-${fixture}.png`)});
 }
 await context.close();
}}finally{await browser.close();await new Promise(resolve=>server.httpServer.close(resolve));}
writeFileSync(resolve(output,'results.json'),JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify(results,null,2));
