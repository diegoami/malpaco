from pathlib import Path
import json,hashlib,tarfile,subprocess
root=Path('/home/diego/projects/malpaco');work=root/'.cache/t71-work';review=root/'.cache/review-worktrees/167-review-249cfafe';out=work/'docs/prototypes/new-game/T71/independent-review-log';out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
items={}
for p in (root/'.cache/t71-dispatch/review-native').rglob('*'):
 if p.is_file() and '2a6ea7243ca0' in p.name:items['native/'+str(p.relative_to(root/'.cache/t71-dispatch/review-native'))]=p
for name in ['tools/harness/.review-t71-retained-local.mjs','tools/harness/lib/.opencode-t37-retained-local.mjs','.opencode/agents/reviewer-t71-retained.md','.cache/t71-dispatch/log-review-brief.md','.cache/t71-dispatch/review-03.log','.cache/t71-dispatch/review-02.log','.cache/t71-dispatch/log-review-brief-first-header.md','.cache/t37-dispatch/kimi-verified-variants.json']:
 p=root/name;items['launcher/'+name.replace('.cache/t71-dispatch/','')]=p
for name in ['screenshots','playwright-report','test-results']:
 for p in (review/name).rglob('*'):
  if p.is_file():items['worktree/'+str(p.relative_to(review))]=p
for name in subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=review,text=True).splitlines():
 p=review/name
 if p.is_file():items['worktree/'+name]=p
members={name:sha(p.read_bytes()) for name,p in sorted(items.items())};archive=out/'complete-review.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,p in sorted(items.items()):tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:assert {m.name:sha(tar.extractfile(m).read()) for m in tar.getmembers() if m.isfile()}==members
export=json.loads(next((root/'.cache/t71-dispatch/review-native').glob('*2a6ea7243ca0.export.json')).read_text());last=next(m for m in reversed(export['messages']) if m.get('info',{}).get('role')=='assistant');final='\n'.join(p.get('text','') for p in last['parts'] if p.get('type')=='text');(out/'full-final.md').write_text(final+'\n')
assert export['info']['model']=={'id':'k3','providerID':'kimi-code-plan-global','variant':'low'}
models=sorted({(m.get('info',{}).get('providerID',''),m.get('info',{}).get('modelID','')) for m in export['messages'] if m.get('info',{}).get('role')=='assistant'});assert models==[('kimi-code-plan-global','k3')]
assert not [p for m in export['messages'] for p in m.get('parts',[]) if p.get('type')=='tool' and p.get('state',{}).get('status')=='error']
tracked=subprocess.run(['git','diff','--exit-code','HEAD','--','src','tests','data','tools'],cwd=review,capture_output=True,text=True);assert tracked.returncode==0
subprocess.run(['git','diff','--exit-code','fcd9cb4b6b59f0ea677ff95d7c0f87a061d9c378','--','src','tests','data','tools','package.json','package-lock.json','tsconfig.json','vite.config.ts','playwright.config.ts'],cwd=work,check=True,stdout=subprocess.DEVNULL)
receipt={'session':export['info']['id'],'model':export['info']['model'],'agent':export['info']['agent'],'durationSeconds':(export['info']['time']['updated']-export['info']['time']['created'])/1000,'tokens':export['info']['tokens'],'toolErrors':0,'reviewHead':'fcd9cb4b6b59f0ea677ff95d7c0f87a061d9c378','allAssistantModels':models,'reviewerSourceRestored':True,'finalRuntimeEqualsReviewed':True,'archive':archive.name,'archiveSha256':sha(archive.read_bytes()),'archiveBytes':archive.stat().st_size,'members':members,'reviewUrl':'https://github.com/diegoami/malpaco/pull/167#issuecomment-6250336006'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(out/'README.md').write_text('# Independent T71 full-history follow-up\n\nFull final https://github.com/diegoami/malpaco/pull/167#issuecomment-6250336006 retained unabridged. KimiK3low session ses_eb0e396caffekOm72sOzmStkTa,553.767s,CLI0/zeroerrorsdenials. Independent6/32/671Vitest+8harness/build/134affectedpass. Restoringcap fails3newunits, deletingreader/followlogic fails1; exactsource restored e2a8e0ad andCSS1a73277c verified. Original appearance/density approval remains for identical fixedtracks; history addition explicitly ownerrequested.\n\nR1nonblocking cosmetics: first-child emphasis now highlights oldestentry rather thannewest after chronological reorder; suggestionlast-child retained as follow-up, not altered in this task. Full finding relayed owner. Original review findings remain in separate independent-review evidence.\n\nFirstlaunch failed strictbrief-header validation before model call; corrected native run is sole paid follow-up for newbehavior. Bothlogs/firstbrief retained. Native/export/launcher/generatedoutputs/scratch archived memberhashverified, originalworktree preserved. Canonicalharness guard unchanged, private realdependencies, nofallback. Multipart manifest reconstructs complete retained archive; raw full archive also remains locally.\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='members'},indent=2))
