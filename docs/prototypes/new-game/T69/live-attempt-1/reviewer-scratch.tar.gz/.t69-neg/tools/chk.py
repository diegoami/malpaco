import json, sys
base = "docs/prototypes/new-game/T68/"
trip = open("docs/models.md").read().split("```text\n")
tw = [b.split("```")[0] for b in trip if b.startswith("Out of your depth")]
print("tripwire blocks in models.md:", len(tw))
for a in ("attempt-1", "attempt-2", "attempt-3"):
    pr = open(base + a + "/prompt.txt").read()
    print(a, "tripwire in full:", tw[0].strip() in pr, "| contains 'Out of your depth':", "Out of your depth" in pr)
ev = [json.loads(l) for l in open(base + "attempt-3/output.jsonl") if l.strip()]
resp = [e for e in ev if e.get("event") == "result"][0]["result"]["response"]
rv = open(base + "attempt-3/review.txt").read()
print("review.txt == response:", rv == resp, rv.strip() == resp.strip(), len(rv), len(resp))
