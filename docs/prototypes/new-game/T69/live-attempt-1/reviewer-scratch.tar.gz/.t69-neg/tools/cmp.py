c = open(".t69-neg/pr150-comment.txt").read()
r = open("docs/prototypes/new-game/T68/attempt-3/review.txt").read()
print("review.txt fully contained in PR150 comment:", r.strip() in c, "| comment len", len(c), "review len", len(r))
