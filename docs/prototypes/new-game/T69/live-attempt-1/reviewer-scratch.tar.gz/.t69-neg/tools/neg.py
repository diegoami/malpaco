import hashlib, json, shutil, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BASE = ROOT / "base"
VERIFY = ROOT.parent / "docs/prototypes/new-game/T68/verify.py"


def sha(b):
    return hashlib.sha256(b).hexdigest()


def rj(p):
    return json.loads(p.read_text())


def wj(p, v):
    p.write_text(json.dumps(v, indent=2) + "\n")


def rehash(d, attempt):
    r = rj(d / attempt / "receipt.json")
    r["prompt_sha256"] = sha((d / attempt / "prompt.txt").read_bytes())
    r["output_sha256"] = sha((d / attempt / "output.jsonl").read_bytes())
    wj(d / attempt / "receipt.json", r)


def receipt_edit(attempt, **kw):
    def f(d):
        r = rj(d / attempt / "receipt.json")
        r.update(kw)
        wj(d / attempt / "receipt.json", r)
    return f


def drop_key(d):
    r = rj(d / "attempt-3" / "receipt.json")
    del r["settings_restored"]
    wj(d / "attempt-3" / "receipt.json", r)


def drop_key_and_cleanup(d):
    drop_key(d)
    (d / "attempt-3" / "settings-cleanup.json").unlink()


def false_cleanup(d):
    wj(d / "attempt-3" / "settings-cleanup.json", {"temporary_grants_removed": True, "other_settings_preserved": True})


def out_only(d):
    p = d / "attempt-3" / "output.jsonl"
    p.write_bytes(p.read_bytes().replace(b"DW3", b"DWX", 1))


def out_coordinated(d):
    out_only(d)
    rehash(d, "attempt-3")


def prompt_only(d):
    p = d / "attempt-1" / "prompt.txt"
    p.write_bytes(p.read_bytes() + b"x")


def prompt_coordinated_a1(d):
    prompt_only(d)
    rehash(d, "attempt-1")


def rm_attempt2(d):
    shutil.rmtree(d / "attempt-2")


def rm_receipt(d):
    (d / "attempt-2" / "receipt.json").unlink()


def dup_result(d):
    p = d / "attempt-3" / "output.jsonl"
    lines = [x for x in p.read_text().splitlines() if x.strip()]
    res = [x for x in lines if json.loads(x).get("event") == "result"]
    p.write_text("\n".join(lines + res) + "\n")
    rehash(d, "attempt-3")


def models_missing(d):
    (d / "attempt-3" / "models.txt").write_text("nothing\n")


def models_substring(d):
    (d / "attempt-3" / "models.txt").write_text("claude-sonnet-5-5-high-fake\n")


def asm(attempt, **kw):
    def f(d):
        a = rj(d / "assessment.json")
        a["attempts"][attempt].update(kw)
        wj(d / "assessment.json", a)
    return f


CASES = {
    "baseline": lambda d: None,
    "receipt-exit-a1": receipt_edit("attempt-1", exit_code=7),
    "receipt-duration-a3": receipt_edit("attempt-3", duration_seconds=0.001),
    "receipt-exit-a3": receipt_edit("attempt-3", exit_code=1),
    "receipt-started-epoch": receipt_edit("attempt-3", started_epoch=0),
    "receipt-mode": receipt_edit("attempt-3", mode="bypass"),
    "receipt-commit-edit": receipt_edit("attempt-1", reviewed_commit="0" * 40),
    "receipt-drop-settings_restored": drop_key,
    "receipt-drop-key-and-cleanup-file": drop_key_and_cleanup,
    "false-cleanup-assertion": false_cleanup,
    "output-only": out_only,
    "output-coordinated-rehash": out_coordinated,
    "prompt-only": prompt_only,
    "prompt-coordinated-rehash": prompt_coordinated_a1,
    "rm-attempt-2": rm_attempt2,
    "rm-receipt": rm_receipt,
    "dup-result": dup_result,
    "models-missing-model": models_missing,
    "models-substring": models_substring,
    "assess-accept-flip": asm("attempt-3", accepted_review=False),
    "assess-parent-assessment-one-char": asm("attempt-3", parent_assessment="x"),
    "assess-deny-then-accept": asm("attempt-1", accepted_review=True),
}

names = sys.argv[1:] or list(CASES)
for name in names:
    d = ROOT / ("case-" + name)
    if d.exists():
        shutil.rmtree(d)
    shutil.copytree(BASE, d)
    CASES[name](d)
    for flags in ([], ["-O"]):
        r = subprocess.run(["python3", "-I", *flags, str(VERIFY), str(d)], capture_output=True, text=True)
        tail = (r.stdout + r.stderr).strip().splitlines()
        print(f"{name:40s} {'-O' if flags else '  '} exit={r.returncode} {tail[-1][:90] if tail else ''}")
