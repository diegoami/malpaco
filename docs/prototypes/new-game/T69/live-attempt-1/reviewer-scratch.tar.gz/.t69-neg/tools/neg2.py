import hashlib, json, shutil, subprocess
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
VERIFY = ROOT.parent / "docs/prototypes/new-game/T68/verify.py"
d = ROOT / "case-init-model"
if d.exists():
    shutil.rmtree(d)
shutil.copytree(ROOT / "base", d)
p = d / "attempt-3" / "output.jsonl"
lines = p.read_text().splitlines()
out = []
for l in lines:
    e = json.loads(l) if l.strip() else None
    if e and e.get("event") == "init":
        e["init"]["model"] = "gemini-4-argon-low"
        l = json.dumps(e)
    out.append(l)
p.write_text("\n".join(out) + "\n")
r = json.loads((d / "attempt-3" / "receipt.json").read_text())
r["output_sha256"] = hashlib.sha256(p.read_bytes()).hexdigest()
(d / "attempt-3" / "receipt.json").write_text(json.dumps(r, indent=2) + "\n")
x = subprocess.run(["python3", "-I", str(VERIFY), str(d)], capture_output=True, text=True)
print("init-model-swapped(coordinated rehash): exit", x.returncode, (x.stdout + x.stderr).strip().splitlines()[-1])
