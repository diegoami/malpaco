import json, sys, collections
p = sys.argv[1]
ev = [json.loads(l) for l in open(p) if l.strip()]
print(collections.Counter(e.get("event") for e in ev))
for e in ev:
    if e.get("event") == "init":
        print("INIT", json.dumps(e)[:600])
    if e.get("event") == "result":
        r = e["result"]
        print("RESULT", {k: (v if k != "response" else "len%d" % len(v)) for k, v in r.items()})
