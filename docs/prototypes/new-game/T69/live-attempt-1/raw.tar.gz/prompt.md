T68 review (Claude backend trial)
You review PR #153 at 6fde4cb2c371bfdc933892f19b2cf7cb9573168b. You did not write it. This is an owner-authorized real backend validation of T69, using merged T68 as the subject; no CI dispatch and no labels requested. Prove exact PR base50a2dcb and head. Use supplied local diff/inventory, not GitHub diff API or current origin/main. Execute every T68 Done-when, including fetching model-trials comments through read-only gh API to verify links. Run a meaningful negative control using retained scratch COPY of the receipt fixtures and verifier; do not execute historical agy runners or touch global agy settings. Restore any source via saved bytes, never git reset/restore/checkout. No browser rerun needed for this workflow task; explicitly identify that limit. Account for executable helpers individually and generated evidence by explicit groups, never claim uninspected files. Your final review is the output, no GitHub writes, and it must include all FILE/EVIDENCE/SCOPE acknowledgments from the backend contract. A rework finding is a useful review; approval is not the goal.

# T68 Pilot agy CLI review workflow with Sonnet

- **Kind**: infrastructure, bounded model trial.
- **Issue**: #152 · **Branch**: `task/T68-agy-sonnet-review` · **Merge after**: —.
- **Difficulty**: Medium; external CLI permissions and evidence retention.
- **Implementer**: main session, as already selected by the owner, in an isolated worktree.
- **Reviewer**: standing owner-selected MiniMax via OpenCode reviews workflow changes; the owner explicitly selected Sonnet through agy for the supplemental T34 pilot. Existing T34 MiniMax review remains authoritative.
- **Evidence**: owner request of 2026-10-17; installed `agy --help` and live `agy models` output.
- **Owns**: docs/harness-agy.md; docs/prototypes/new-game/T68/**; append-only RUN-NOTES.md; blocking one-line test-clock correction in tests/e2e/reference-complete-game.spec.ts (#151, rule 12).
- **Scope**: Establish a reproducible optional agy review procedure using a live Sonnet model ID, isolated checkout, bounded noninteractive execution and retained prompt, CLI output, exit code and duration. Try one actual supplemental review of T34. Diagnose startup/auth/permission failures and retain them; never claim a failed trial approved code. Keep canonical OpenCode review automation and its current T34 run intact. No CI dispatch for the measurement or provider fallback. Scope exception under rule 12: carry the exact independently reviewed one-line #151 clock initialization fix if the required workflow PR CI exposes the inherited past-time failure; preserve every existing assertion and retain the failed/positive evidence.
- **Done when**:
  1. `python3 docs/prototypes/new-game/T68/verify.py` validates live discovery, exact reviewed commit, prompt and output hashes, exit/duration and parent assessment for the actual attempted review. It refuses missing or altered receipts.
  2. `git diff --check` passes; workflow documentation gives the actual invocation, permissions, progress/retention procedure and observed limitations, and the trial is recorded in model-trials #3, cross-linked with isle-wars-archaeology#9.
- **Hazards**: Permission failures require explicit grants, never silent retries with a different provider. Do not expose credentials, alter another review worktree, weaken T34 checks or count a supplemental review as its CI gate. Include Sonnet's tripwire in full. Planning contract is authored on main; production documentation and measurement occur in the task worktree.



```text
<T<nn>> review (<model>)
You review PR #<n> at <sha>. You did not write it. The task file follows.
0. Prove the tree: HEAD is <sha> and the diff against origin/main is the PR's; findings name its files.
1. Re-run every Done-when line yourself, and account for each (L32). The PR's evidence is no proof.
2. [evidence-driven] Every constant traces to a fixture, report or investigation; a [designed] one says what was searched.
3. [seeded] No wall clock, unseeded random or order-dependent iteration in rule code.
4. Every changed file and behaviour is one the task asks for (L44); docs it makes wrong are updated.
5. Sweep the diff: tests that pass with the behaviour deleted (mutate, rebuild clean, re-take any
   negative result), branches no input reaches, edge comments without a test, <project classes>.
   Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
   restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
   a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
   copy inside your worktree (`<file>.saved`, deleted afterwards) or in a `mktemp -d` folder under
   `/tmp`, never as a loose file elsewhere.
6. <docs/review-brief.md in full: "Blocking means" for this task, then its one-pass section (L47, L49)>
Prove each finding (run it, or delete the behaviour and name the test that fails) or label it
unverified. Your final message is the review: the header; the verdict (approve | approve after
named fixes | rework | user decision); per Done-when line `DW<k>: ran <command> → <result>` or
`DW<k>: not run — <reason>`; the findings R1..Rn (file:line, blocking or not); the verdict again
last. Never post it: the script posts it and applies the label.
```

A further review, such as `/code-review <pr>` on an architecture task, runs only when the user asks
for it and names the model (CLAUDE.md rule 6.2: one review unless the user asks for more); then
always with the PR number, since a bare invocation from an agent reviews the wrong tree. (L8)

### Claude CLI backend (owner request, T69)

An explicitly selected `harness.json` model with `backend: "claude"` runs through the same
`review.mjs --reviewer <name>` command and shared parser/poster/labels. See
[Claude CLI reviews](harness-claude.md) for model verification, trusted settings, grants,
retained evidence and coverage acknowledgments. The independent-family and blocked-list rules
still apply; this adds a backend without changing the default. Claude failures never reroute
through OpenCode. A rejected command, missing scope or incomplete Done-when cannot approve.


# The review brief's own sections

Every review brief carries these two sections, in full, after the numbered block of
`process.md` §5 (or, in the review profile, after the brief's numbered lines). The reviewer reads
the brief in another file, so paste them; never point to this one. Write "Blocking means" for the
task; paste the second section as it is. (L47, L49)

```text
## Blocking means

Any one is enough; a blocking finding means rework, never approve.
1. A Done-when line fails, or cannot be run as written.
2. What this task protects can be got past: <name it: the guard, check, permission, invariant,
   rule value or file this task exists to protect>. A bypass you proved is blocking, even when it
   looks like an edge case. Never "follow-up hardening" or "outside the threat model" unless the
   task says so; if it does, quote the line. (L47)
3. Behaviour the task forbids, or behaviour nobody asked for, inside a file the task requires. (L44)
4. <project-specific items: a constant with no evidence, a test that passes with the behaviour
   deleted, a status written into a document>
Not blocking: wording, style, and defects in code the PR did not change: file those as follow-ups.
When unsure, say how likely the problem is. Rate it blocking only if it is likely and would get
past what the task protects; otherwise it is a follow-up. (L53)

## Report every blocking finding in this one review

This review is your only pass before the author fixes. Do not stop at the first blocking
finding: finish reading the whole diff and the task file, check every Done-when line and
every item under "Blocking means", and report all blocking findings together.

- Before you write the verdict, make one last pass over the full diff for anything you have
  not yet rated, and say "Final pass done" as the last line before the verdict.
- Number the findings R1, R2, … in order of severity. A finding you held back because an
  earlier one was already blocking is a review defect: if two problems share a cause, list
  both and say so.
- Do not rely on a later round. The author fixes everything you list, and the next review
  checks those fixes and new code only, not anything you saw but did not report.
- If you ran out of time or context before covering the whole diff, say which files or
  sections you did not cover. Do not approve in that case.
```


---
OUTPUT RULES (from tools/harness/review.mjs; they override anything above that conflicts):
- Do not post to GitHub, commit, push, label or merge anything. The script posts your review.
  Edit nothing, but for a mutation made in place in your worktree and never committed.
  Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
  restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
  a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
  copy inside your worktree (`<file>.saved`, deleted afterwards) or in your own folder under
  `/tmp/opencode/`. Outside your worktree, write only under `/tmp/opencode/` (a
  `mktemp -d /tmp/opencode/mlp-review-XXXXXX` folder is the tidiest, removed afterwards; the reviewer
  agent file allows nothing else). Every other path outside your worktree is forbidden.
- Your final message is the review and nothing else. Line 1 is exactly: T68 review (Claude backend trial)
  Line 2 is the verdict, alone on its line: approve, approve after named fixes, rework, or user
  decision. Then any where-I-worked lines (worktree, HEAD, diff, the commands you ran), then the
  findings (R1, R2, ... with file and line, blocking or not), then the verdict again as the very
  last line. Nothing comes after it.
- A finding you proved that lets a forbidden action or a wrong result past what the task protects
  is blocking, and blocks an approve: never "follow-up hardening" or "outside the threat model"
  unless the task's text says so (L47).
- Report every blocking finding in this one review, not one per round: read the whole diff, then
  make a final pass and write "Final pass done" as the line before the closing verdict. Name any
  part you did not cover, and do not approve then (L49).
- The task has 2 Done-when lines. Right after the verdict line, account for each, one
  line per Done-when line, DW1 to DW2: "DW<k>: ran <command> → <result>", or
  "DW<k>: not run — <reason>". An approve with one missing, or one not run, is not applied. A review that does not end with its verdict, or that has a
  finding after it, is posted flagged and acted on by no one until the main session reads it.
- Your worktree is /home/diego/projects/malpaco/.cache/t69-live-review/153-review-ca1e6fd8 at 6fde4cb2c371bfdc933892f19b2cf7cb9573168b, and it is already your working directory. Run git
  there without -C, and never type that path: a mistyped path ends the run. This rule is about
  your own worktree only (L61): a Done-when line may send git at a pinned repository outside it
  (git -C <path> show <pin>:<file>); run that exactly as written — OpenCode does not path-check
  git -C — and read a granted outside path only with the L59 recipe.

CLAUDE BACKEND CONTRACT: The exact PR base is 50a2dcbf8eee240872e82199fb3cb2b3c45e6c03, head 6fde4cb2c371bfdc933892f19b2cf7cb9573168b. Do not use origin/main for a merged PR. Complete local diff: /home/diego/projects/malpaco/.cache/t69-work/.cache/review-evidence/pr153-700f41f906d6/full.diff; bounded parts: /home/diego/projects/malpaco/.cache/t69-work/.cache/review-evidence/pr153-700f41f906d6/diff-parts; full changed-file inventory: /home/diego/projects/malpaco/.cache/t69-work/.cache/review-evidence/pr153-700f41f906d6/inventory.json. Read all executable changes. For generated evidence you may audit a group explicitly. Never claim a file you did not inspect. Before Final pass done, emit SCOPE: complete only if you covered all changes; otherwise SCOPE: incomplete plus UNCOVERED: paths/reasons. Emit FILE: <exact path> for each changed file inspected; EVIDENCE: <docs/prototypes/.../ prefix> may account for generated evidence only, never executable scripts. These are coverage claims, not independent proof. Every Done-when must be run; include exact DW lines. A missing scope acknowledgment prevents approval. No subagents or GitHub writes. The trusted hook enforces the existing reviewer command guard; Bash is granted for tests and in-tree mutations. Preserve scratch/evidence; do not clean up. Ignore obsolete OpenCode-only path restrictions above: your scratch is your retained worktree. No blanket permission bypass.

The read-only contract overrides the tripwire instruction to push: never push.
Out of your depth: stop and hand back, with an ESCALATE block, when any of these happens:
two hypotheses for the same question have failed; you would rely on bytes, code or behaviour
you cannot explain; you are about to write a claim you cannot back with evidence; or you have
made three attempts at one step without progress. Push your branch first. The ESCALATE block
gives what you tried, the evidence so far, and the exact question you could not answer. Never
guess a format or a cause.
