T69 review (Claude)
You review PR #1 at 4ca5f20ce89866a4ce6e4e8781b00e1c7d5ae0a6.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
