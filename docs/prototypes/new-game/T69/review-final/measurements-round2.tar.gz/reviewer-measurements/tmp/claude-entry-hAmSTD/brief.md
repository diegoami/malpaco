T69 review (Claude)
You review PR #1 at 14a9b4384481547e3bd37dd34c1f5cc7d231f7d7.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
