T69 review (Claude)
You review PR #1 at 93c27e65a9195dde42fc249c9d98aea5843f0a57.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
