T69 review (Claude)
You review PR #1 at 0ac13c82a8d51e29ef0cb7fd0890d250ff66874a.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
