T69 review (Claude)
You review PR #1 at c02085c25552a9741c1cbf46310a725756f9e95d.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
