T69 review (Claude)
You review PR #1 at c04e87d9590a3bc1bdd30ff6d7c78fb09c0a30a9.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
