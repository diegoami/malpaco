T38 review (Kimi K3)
You review PR #168 at 065428e79065ffe1c11e240741a11c396a86db16. You did not write it. The task file follows.
0. Prove the tree: HEAD is 065428e79065ffe1c11e240741a11c396a86db16 and the diff against origin/main is the PR's; findings name its files.
1. Re-run every Done-when line yourself, and account for each (L32). The PR's evidence is no proof.
2. [evidence-driven] Every constant traces to a fixture, report or investigation; a [designed] one says what was searched.
3. [seeded] No wall clock, unseeded random or order-dependent iteration in rule code.
4. Every changed file and behaviour is one the task asks for (L44); docs it makes wrong are updated.
5. Sweep the diff: tests that pass with the behaviour deleted (mutate, rebuild clean, re-take any
   negative result), branches no input reaches, edge comments without a test, set/Wild validity, once-only income, pending phase gates, seeded replay and historical codec compatibility.
   Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
   restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
   a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
   copy inside your worktree (`<file>.saved`, deleted afterwards) or in a `mktemp -d` folder under
   `/tmp`, never as a loose file elsewhere.
6. Read the Blocking means and one-pass sections below.
Prove each finding (run it, or delete the behaviour and name the test that fails) or label it
unverified. Your final message is the review: the header; the verdict (approve | approve after
named fixes | rework | user decision); per Done-when line `DW<k>: ran <command> → <result>` or
`DW<k>: not run — <reason>`; the findings R1..Rn (file:line, blocking or not); the verdict again
last. Never post it: the script posts it and applies the label.

# T38 Card sets, Wilds and Surge income

- **Kind**: feature
- **Issue**: #83 · **Branch**: `task/T38-card-sets-wilds-and-surge-income` · **Merge after**: T37.
- **Difficulty**: Medium; estimate, not a model assignment.
- **Implementer**: owner-selected under rule 6; use an isolated worktree and record the choice before dispatch.
- **Reviewer**: owner-selected OpenCode model of another family under rule 6; record the choice before review.
- **Evidence**: [pinned variety design](https://github.com/diegoami/isle-wars-archaeology/blob/ae298e37c2f5177039e55767607f9345b6cb0e7a/design/variety.md), owner roadmap accepted 2026-10-15, and upstream task evidence. T23 resolves source anchors; new constants need citations or explicit [designed] provenance.
- **Owns**: src/core/**; tests/core/**; src/ui/gameEventLog.ts (mechanical phase/action labels only); docs/prototypes/new-game/T38/**; docs/spike.md; append-only RUN-NOTES.md.
- **Scope**: Add the cards phase between income and placement. Permit one optional set of three tradeable cards, at least one genuine kind and at most two Wilds. Implement Anchor/Compass/Lantern values 5/8/15 and Surge doubling the turn income including island bonuses. Skipping is legal; trade cards move to discard. Leave targeted Raid resolution to T39 but reserve its explicit action/state seam. Keep trade-v1 frozen with atomic Raid-effect refusal until the separate raid-v1 stage; structural classification still recognizes the approved Raid kind. Declare the blocking one-file exhaustive phase/action labels in `gameEventLog.ts` under rule 12; no UI flow/layout changes.
- **Done when**:
  1. `npx vitest run tests/core/card-sets.test.ts` — every valid/invalid kind/Wild composition, one-set cap, optional skip, fixed values, Surge base/island arithmetic and phase refusals match independent tables.
  2. `npx vitest run tests/core/card-sets-replay.test.ts` — trades and skips resume identically, pool is computed once and mutation of a set value or Wild limit fails targeted acceptance.
  3. `npm test` and `npm run build` pass; affected pinned browser suites pass without weakening existing assertions. Retain measured outputs, screenshots where applicable, commands and hashes in the owned evidence path; report negative-before/positive-after checks and exact restoration.
- **Hazards**: Three Wilds are not a set. No forced trade or growing set value may be inherited from another conquest game. Main session preflights acceptance before dispatch; unresolved design conflicts stop implementation, never weaken a Done-when.

# The review brief's own sections

Every review brief carries these two sections, in full, after the numbered block of
`process.md` §5 (or, in the review profile, after the brief's numbered lines). The reviewer reads
the brief in another file, so paste them; never point to this one. Write "Blocking means" for the
task; paste the second section as it is. (L47, L49)

```text
## Blocking means

Any one is enough; a blocking finding means rework, never approve.
1. A Done-when line fails, or cannot be run as written.
2. What this task protects can be got past: <name it: the guard, check, permission, invariant,
   rule value or file this task exists to protect>. A bypass you proved is blocking, even when it
   looks like an edge case. Never "follow-up hardening" or "outside the threat model" unless the
   task says so; if it does, quote the line. (L47)
3. Behaviour the task forbids, or behaviour nobody asked for, inside a file the task requires. (L44)
4. <project-specific items: a constant with no evidence, a test that passes with the behaviour
   deleted, a status written into a document>
Not blocking: wording, style, and defects in code the PR did not change: file those as follow-ups.
When unsure, say how likely the problem is. Rate it blocking only if it is likely and would get
past what the task protects; otherwise it is a follow-up. (L53)

## Report every blocking finding in this one review

This review is your only pass before the author fixes. Do not stop at the first blocking
finding: finish reading the whole diff and the task file, check every Done-when line and
every item under "Blocking means", and report all blocking findings together.

- Before you write the verdict, make one last pass over the full diff for anything you have
  not yet rated, and say "Final pass done" as the last line before the verdict.
- Number the findings R1, R2, … in order of severity. A finding you held back because an
  earlier one was already blocking is a review defect: if two problems share a cause, list
  both and say so.
- Do not rely on a later round. The author fixes everything you list, and the next review
  checks those fixes and new code only, not anything you saw but did not report.
- If you ran out of time or context before covering the whole diff, say which files or
  sections you did not cover. Do not approve in that case.
```


Practical T38 details:
- Owner-selected Sol Medium implemented; independent Kimi K3 live kimi-code-plan-global/k3 at low reviews, no fallback/delegation. Dependencies privately copied by invocation-only retention launcher, source/profile guards unchanged. Never clean/prune/checkout/restore/reset. Save/restore exact bytes in finally for mutations.
- DW1 npx vitest run tests/core/card-sets.test.ts; DW2 npx vitest run tests/core/card-sets-replay.test.ts; DW3 npm test, npm run build and exact pinned browser command:
 docker run --rm --init --ipc=host --user 1000:1000 -v "$PWD:/work" -w /work -e HOME=/tmp mcr.microsoft.com/playwright:v1.63.0-noble npx playwright test tests/e2e/versioned-match.spec.ts tests/e2e/reference-complete-game.spec.ts tests/e2e/game-event-log.spec.ts tests/e2e/geographic-review-guards.spec.ts --workers=2
- Actual production diff only src/core/cards.ts,index.ts,match-save.ts,rules.ts,setup.ts,state.ts,types.ts and src/ui/gameEventLog.ts. Tests core/card-sets-fixture.ts,card-sets.test.ts,card-sets-replay.test.ts; docs/spike.md and appended RUN-NOTES. Historical evidence/mirrors underT38 notimported except eight legal options/actions fixtures. Scope includes staging Raid classification but atomic effect refusal in permanent trade-v1; actualeffect belongsT39 separate raid-v1. Current victory default/cardAI unchanged.
- Main T37 squash integration includes saved conflicts and latest30s deadline; those original/restored bytes are historical evidence only. Inspect frozen11 manifest, parent-preflight/PROPOSAL.md, parent-acceptance raw baseline and controls, implementation/implementation.json and actual outputs; historical data/screenshots may be audited using hashes/manifests, but inspect executable evidence drivers and tests.
- Parent independently authored32 cases including all512 triples ->35ordered valid sets, fixedvalues5/8/15, Surge doubles base+islandincome, invalidatomic and one-set cap, real options/actions codec histories, strict permanent schema3/4 identities and future schema5refusal. Baseline31fail/1compatpass; mock32pass/697+8/build/28browser. Anchor5->6 mutation5fail, Wildlimit mutation9fail exactrestore. Frozenfinaltwo replaycases have30s boundedtime sinceparentfreeze, no assertionchange. Fresh producer same32/697+8/build/28passes;171inputs stable and11frozen exact; token-equivalence ignoresonlycomments/whitespace. Re-run ratherthantrust.
- Do not rerun broadmapgeneration sweeps or explorationsearches. No CI/GitHubwrites. Your fullfinal mustaccountall3DW/findings, exact source tree and complete scope. Read full diff, finalpassdone, verdictlast.
