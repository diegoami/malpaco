from pathlib import Path
import datetime,hashlib,json,subprocess,sys,tarfile
root=Path('/home/diego/projects/malpaco');ci=Path(sys.argv[1]).resolve();preview=Path(sys.argv[2]).resolve();live=Path(sys.argv[3]).resolve();merge=Path(sys.argv[4]).resolve()
out=root/'docs/prototypes/new-game/T70'/('delivery-'+datetime.datetime.now(datetime.UTC).strftime('%Y%m%dT%H%M%SZ'));out.mkdir()
files={}
for p in ci.iterdir():
 if p.is_file():files['ci/'+p.name]=p
for p in (ci/'playable').rglob('*'):
 if p.is_file():files['ci/playable/'+str(p.relative_to(ci/'playable'))]=p
for prefix,parent in [('preview',preview),('live',live)]:
 for p in parent.rglob('*'):
  if p.is_file():files[prefix+'/'+str(p.relative_to(parent))]=p
copy_meta=json.loads((preview/'windows-copy.json').read_text())
files['windows/previous-pointer.html']=Path(copy_meta['previousPointerBackup'])
files['windows/current-pointer.html']=Path('/mnt/c/Users/diego/malpaco-preview/OPEN-REVIEW.html')
files['merge.json']=merge
for n in ['collect-ci.py','prepare-preview.py','copy-preview.py','verify-live.mjs','archive-delivery.py']:
 files['inert-dispatch/'+n]=root/'.cache/t70-dispatch'/n
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();hashes={n:sha(p) for n,p in files.items()};archive=out/'verified-delivery.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(archive,'r|gz') as t:actual={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}
assert actual==hashes
(out/'manifest.json').write_text(json.dumps({'archive':archive.name,'sha256':sha(archive),'members':hashes,'originalsPreserved':True,'fullCIScreenshotsPreservedAt':str(ci/'screenshots')},indent=2)+'\n')
verified=json.loads((ci/'verified.json').read_text());copied=json.loads((preview/'windows-copy.json').read_text());m=json.loads(merge.read_text())
receipt={'pr':159,'merge':m,'ci':verified,'windows':copied,'live':json.loads((live/'live-browser.json').read_text()),'ownerScope':'T70 complete; no T35 producer or new task dispatched this session','originalDisappearanceReport':'unconfirmed; observability added, no core rule fix claimed','archiveSha256':sha(archive),'runtimeSourceUnchangedAfterApproval':True}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'output':str(out),'members':len(hashes),'archiveBytes':archive.stat().st_size}))
