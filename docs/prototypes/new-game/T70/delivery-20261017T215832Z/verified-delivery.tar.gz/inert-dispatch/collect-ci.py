from pathlib import Path
import hashlib,json,subprocess,tarfile,sys
run_id=sys.argv[1];expected_head=sys.argv[2];root=Path('/home/diego/projects/malpaco');out=root/('.cache/t70-dispatch/ci-'+run_id);out.mkdir(exist_ok=False)
def gh(name,*args):
 data=subprocess.check_output(['gh',*args],cwd=root);(out/name).write_bytes(data);return data
run=json.loads(gh('run.json','api',f'repos/diegoami/malpaco/actions/runs/{run_id}'))
assert run['head_sha']==expected_head and run['conclusion']=='success',run['conclusion']
gh('jobs.json','api',f'repos/diegoami/malpaco/actions/runs/{run_id}/jobs');gh('artifacts.json','api',f'repos/diegoami/malpaco/actions/runs/{run_id}/artifacts');gh('complete-log.txt','run','view',run_id,'--log')
subprocess.run(['gh','run','download',run_id,'--name','malpaco-playable','--dir',str(out/'playable')],cwd=root,check=True)
subprocess.run(['gh','run','download',run_id,'--name','screenshots','--dir',str(out/'screenshots')],cwd=root,check=True)
archive=out/'playable/malpaco-playable.tar.gz'
with tarfile.open(archive) as tar:
 build=json.load(tar.extractfile('malpaco-playable/BUILD.json'))
source=build['sourceCommit'];commit=json.loads(gh('package-source-commit.json','api',f'repos/diegoami/malpaco/git/commits/{source}'))
tree=subprocess.check_output(['git','rev-parse',run['head_sha']+'^{tree}'],cwd=root,text=True).strip()
assert commit['tree']['sha']==tree,'CI synthetic merge tree differs from approved PR head'
assert source==run['head_sha'] or run['head_sha'] in [p['sha'] for p in commit['parents']]
report={'ciRun':int(run_id),'ciHead':run['head_sha'],'conclusion':'success','packageSource':source,'packageTreeEqualsApprovedHead':True,'archive':str(archive),'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
(out/'verified.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
