import { chromium, expect } from '@playwright/test';
import { mkdirSync, writeFileSync } from 'node:fs';
const out=process.argv[2];mkdirSync(out,{recursive:true});
const browser=await chromium.launch({headless:true});
try {
 const page=await browser.newPage({viewport:{width:1280,height:800}});
 await page.goto('http://127.0.0.1:5173/');
 await page.getByRole('button',{name:'Start game',exact:true}).click();
 await expect(page.locator('[data-testid="player-army-total"]')).toHaveCount(4);
 await expect(page.locator('#game-pause-button')).toBeVisible();
 await page.locator('#game-speed').selectOption('very-slow');
 await page.locator('#game-pause-button').click();
 await expect(page.locator('#game-pause-button')).toHaveAccessibleName('Resume game');
 await page.locator('#game-log-button').click();
 const dialog=page.getByRole('dialog',{name:'Game event log',exact:true});await expect(dialog).toBeVisible();
 await page.screenshot({path:out+'/live-log-1280x800.png'});
 const totals=await page.locator('[data-testid="player-army-total"]').allTextContents();
 const text=await dialog.innerText();
 await page.keyboard.press('Escape');await expect(dialog).not.toBeVisible();
 await page.locator('#game-pause-button').click();
 await expect(page.locator('#game-pause-button')).toHaveAccessibleName('Pause game');
 writeFileSync(out+'/live-browser.json',JSON.stringify({url:page.url(),totals,speed:'very-slow',logCharacters:text.length,pauseResume:true,keyboardClose:true},null,2)+'\n');
 console.log('Live root UI verified: four totals, Very slow, Pause/Resume and keyboard-operated event log.');
} finally {await browser.close();}
