T70 review (Claude Sonnet High)
You review PR #159 at ed379764094e835137a957f255794cf5e1541fc0. You did not write it. The task file follows.
0. Prove HEAD and the complete local PR diff; name findings with actual file/line.
1. Run every Done-when line yourself and account for it. Existing evidence is not proof.
2. New constants are presentation-only and explicitly designed; core rules/RNG/save schemas must not change.
3. Review every changed executable file before spending time on mutations. Keep commands/output bounded; no whole historical evidence sweep.
4. Inspect actual UI at both desktop sizes and screenshots; owner judges final appearance.
5. Exercise likely omissions: missing gamePaused gate in computer callback, missing cancellation of human continuous battle, stale queued callback after pause/load, incorrect total ownership, omitted reinforcement/combat/movement log entries. Use targeted tests once per distinct class, restore from saved bytes in finally. Never reset/restore/stash/prune or delete inherited evidence/worktrees.
6. Final report must state each DW command/result, FILE: exact/path for every changed file inspected (including executable prototype helpers), EVIDENCE: task data prefix only for known generated data, and SCOPE: complete only after full coverage. An incomplete scope is not approval. Full final report is posted by the harness; no publishing, subagents or global settings changes.

# T70 Visible army totals, playback controls and event log

- **Kind**: feature
- **Issue**: #158 · **Branch**: `task/T70-army-totals-and-playback` · **Merge after**: T32, T33.
- **Implementer**: native Sol Medium under the owner's standing model authorization; timer cancellation and replay preservation need care.
- **Reviewer**: independent Claude Sonnet High via the T69 CLI backend.
- **Evidence**: owner playtest and explicit request, 2026-10-17. Seed 1994 can leave computer countries on one army. Parent inspection found no unexplained army changes across 309 handoffs; this does not resolve the owner's exact position. Existing `armyTotal` and the header score already calculate totals, but do not make them prominent enough. Existing battle speed/Stop controls do not pause computer play.
- **Owns**: `src/ui/**`, presentation-only parts of `src/styles.css`, `tests/ui/**`, `tests/e2e/playback-controls.spec.ts`, `tests/e2e/game-event-log.spec.ts`, `tests/e2e/playback-edge-cases.spec.ts`, `docs/prototypes/new-game/T70/**`; append `RUN-NOTES.md`.
- **Scope**: Give each player a conspicuous, explicitly labelled total army count updated after every action, including eliminated players. Keep speed and Pause/Resume visible and keyboard usable throughout computer turns and human combat. Add a very slow setting with at least two seconds between automatic actions. Pause stops both automatic schedulers and gates manual match-changing input; resume continues the same match. Saving and replacement remain usable; replacement/new game cancels old callbacks. Add a popup full game event log, available while paused: initial deal, every ordinary action, turn/phase changes, reinforcements, combat casualties, captures, transfers, elimination and victory. Army changes identify player, region, reason and exact before/after counts; transfers are distinguished from losses. Reconstruct the complete log on load, append without duplicates and reset for a new match. Presentation controls/log add no game actions or RNG draws. Keep existing routes, save formats and core rules unchanged; pause is session state.
- **Done when**:
  1. `npx playwright test tests/e2e/playback-controls.spec.ts` — at both desktop sizes, all displayed totals equal the sum of owned map armies, change with play, and remain readable; Pause freezes history and armies, Resume continues, very slow delays actions, stale callbacks cannot play through pause or replacement. Continuous human fighting also pauses; paused manual actions are gated. Screenshots show the controls and totals.
  2. `npm test && npm run build` — existing rules, replay and presentation checks pass.
  3. `npx playwright test tests/e2e/computer-turn-flow.spec.ts tests/e2e/battle-controls.spec.ts` — existing turn and battle flows remain usable.
  4. `npx playwright test tests/e2e/game-event-log.spec.ts` — popup open/close is keyboard usable and changes no match data; full ordered history and army deltas agree with independent ordinary-action replay, distinguish casualties from transfers, survive save/load without duplicates, include initial deal and game result, and reset on new game.
- **Hazards**: Do not confuse battle-specific Stop with global Pause; cancel both schedulers and invalidate queued callbacks. Do not change speed defaults or core policy to explain the unconfirmed report. Main preflights acceptance on baseline and disposable mock before implementation. Appearance remains the owner's judgment.

## Blocking means
Any one is enough for rework:
1. A Done-when fails or cannot be run as written.
2. Pausing can execute another automatic/manual match action; stale callbacks change a replaced match; resume changes action/RNG replay; ordinary speed defaults change.
3. Displayed totals or log army deltas disagree with actual state, losses are confused with transfers, saved games lose their full log history, or new games retain old events.
4. Any unrelated gameplay/core/save change, missing required event categories, inaccessible controls at the two desktop sizes, uncited rule constants or an acceptance test surviving omission of the behavior it claims to protect.
Not blocking: wording/style and unchanged-code defects; file these as follow-ups. Rate likelihood practically (rule22). This task is a presentation feature, not a rewrite of computer policy, save protocols or board generation.

## Report every blocking finding in this one review

This review is your only pass before the author fixes. Do not stop at the first blocking
finding: finish reading the whole diff and the task file, check every Done-when line and
every item under "Blocking means", and report all blocking findings together.

- Before you write the verdict, make one last pass over the full diff for anything you have
  not yet rated, and say "Final pass done" as the last line before the verdict.
- Number the findings R1, R2, … in order of severity. A finding you held back because an
  earlier one was already blocking is a review defect: if two problems share a cause, list
  both and say so.
- Do not rely on a later round. The author fixes everything you list, and the next review
  checks those fixes and new code only, not anything you saw but did not report.
- If you ran out of time or context before covering the whole diff, say which files or
  sections you did not cover. Do not approve in that case.

Prior preparation failures are preserved honestly: initial repeated-download throttling was fixed in the test export observer; initial sparse input snapshots are labelled. No claim that the owner's exact army disappearance was fixed. Verify current code, with full raw evidence retained.

Efficiency/interpretation: batch DW1/DW3/DW4 browser specs in one invocation and account for each explicitly. Also include playback-edge-cases, versioned-match and finished-copy once, because the changed shared header/Panel have concrete compatibility risks. Reuse the existing typechecked build; do not re-run whole suites for every mutation. For omission controls, remove the behavior as a whole rather than demanding each redundant defensive guard independently fail; a surviving redundant guard is not itself a behavior bypass. Prefer a few likely omission classes and full code coverage over a large mutation matrix.

Out of your depth: stop and hand back, with an ESCALATE block, when any of these happens:
two hypotheses for the same question have failed; you would rely on bytes, code or behaviour
you cannot explain; you are about to write a claim you cannot back with evidence; or you have
made three attempts at one step without progress. The ESCALATE block gives what you tried,
the evidence so far, and the exact question you could not answer. Never guess a format or a cause.

Changed code/document paths to account for explicitly:
- RUN-NOTES.md
- docs/prototypes/new-game/T70/.gitignore
- docs/prototypes/new-game/T70/event-log-mock.ts
- docs/prototypes/new-game/T70/mock-preflight.py
- docs/prototypes/new-game/T70/production-checks.py
- src/styles.css
- src/ui/battleController.ts
- src/ui/battleView.ts
- src/ui/computerTurnLoop.ts
- src/ui/gameEventLog.ts
- src/ui/panel.ts
- src/ui/referenceBattleGame.ts
- tests/e2e/game-event-log.spec.ts
- tests/e2e/playback-controls.spec.ts
- tests/e2e/playback-edge-cases.spec.ts
- tests/ui/game-event-log.test.ts
- tests/ui/playback-controls.test.ts

Owner/session authorization: the owner explicitly selected native OpenAI implementers and Claude Sonnet Medium/High or Opus Low reviewers by difficulty. This supplies standing model-choice authorization, superseding old per-run questions. Main read the full native final and independently verified five production source archives plus all capture members (7,916 members), exact frozen specs and unchanged core/data. Use streaming tar iteration for archive checks; random-name gzip seeks are unnecessarily slow. Read T70 README for historical-vs-current reproduction before running helpers.
