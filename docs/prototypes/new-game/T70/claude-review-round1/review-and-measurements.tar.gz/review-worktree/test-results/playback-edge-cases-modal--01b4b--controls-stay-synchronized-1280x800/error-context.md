# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: playback-edge-cases.spec.ts >> modal Escape preserves continuous combat; local/global very-slow controls stay synchronized
- Location: tests/e2e/playback-edge-cases.spec.ts:7:1

# Error details

```
TypeError: The "path" argument must be of type string or an instance of Buffer or URL. Received undefined
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 2 human seats · Seed 0
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]:
          - strong [ref=e13]: "Total armies: 51"
          - generic [ref=e14]: 23 provinces
      - generic [ref=e18]:
        - generic [ref=e19]: Seat 2
        - generic [ref=e20]:
          - strong [ref=e21]: "Total armies: 46"
          - generic [ref=e22]: 23 provinces
    - generic [ref=e23]:
      - button "Game event log" [ref=e24] [cursor=pointer]
      - dialog [ref=e25]:
        - banner [ref=e26]:
          - heading "Game event log" [level=2] [ref=e27]
          - button "Close game event log" [active] [ref=e28] [cursor=pointer]
        - list "All game events" [ref=e29]:
          - listitem [ref=e30]:
            - group [ref=e31]:
              - generic "Initial deal · Round 1 · 46 countries" [ref=e32] [cursor=pointer]
            - paragraph [ref=e33]: "Seat 1 unplaced reinforcement income: 7. These armies enter the map only when placed."
          - listitem [ref=e34]:
            - heading "Action 1 · Round 1 · Seat 1 · Reinforcement placement · Reinforcement → Reinforcement" [level=3] [ref=e35]
            - paragraph [ref=e36]: "High shore · Seat 1 · Reinforcement placement: 3 → 4 (+1)"
            - paragraph [ref=e37]: "Unplaced armies: 7 → 6. 1 placed on High shore."
          - listitem [ref=e38]:
            - heading "Action 2 · Round 1 · Seat 1 · Reinforcement placement · Reinforcement → Reinforcement" [level=3] [ref=e39]
            - paragraph [ref=e40]: "High shore · Seat 1 · Reinforcement placement: 4 → 5 (+1)"
            - paragraph [ref=e41]: "Unplaced armies: 6 → 5. 1 placed on High shore."
          - listitem [ref=e42]:
            - heading "Action 3 · Round 1 · Seat 1 · Reinforcement placement · Reinforcement → Reinforcement" [level=3] [ref=e43]
            - paragraph [ref=e44]: "High shore · Seat 1 · Reinforcement placement: 5 → 6 (+1)"
            - paragraph [ref=e45]: "Unplaced armies: 5 → 4. 1 placed on High shore."
          - listitem [ref=e46]:
            - heading "Action 4 · Round 1 · Seat 1 · Reinforcement placement · Reinforcement → Reinforcement" [level=3] [ref=e47]
            - paragraph [ref=e48]: "High shore · Seat 1 · Reinforcement placement: 6 → 7 (+1)"
            - paragraph [ref=e49]: "Unplaced armies: 4 → 3. 1 placed on High shore."
          - listitem [ref=e50]:
            - heading "Action 5 · Round 1 · Seat 1 · Reinforcement placement · Reinforcement → Reinforcement" [level=3] [ref=e51]
            - paragraph [ref=e52]: "High shore · Seat 1 · Reinforcement placement: 7 → 8 (+1)"
            - paragraph [ref=e53]: "Unplaced armies: 3 → 2. 1 placed on High shore."
          - listitem [ref=e54]:
            - heading "Action 6 · Round 1 · Seat 1 · Reinforcement placement · Reinforcement → Reinforcement" [level=3] [ref=e55]
            - paragraph [ref=e56]: "High shore · Seat 1 · Reinforcement placement: 8 → 9 (+1)"
            - paragraph [ref=e57]: "Unplaced armies: 2 → 1. 1 placed on High shore."
          - listitem [ref=e58]:
            - heading "Action 7 · Round 1 · Seat 1 · Reinforcement placement · Reinforcement → Reinforcement" [level=3] [ref=e59]
            - paragraph [ref=e60]: "High shore · Seat 1 · Reinforcement placement: 9 → 10 (+1)"
            - paragraph [ref=e61]: "Unplaced armies: 1 → 0. 1 placed on High shore."
          - listitem [ref=e62]:
            - heading "Action 8 · Round 1 · Seat 1 · Start combat · Reinforcement → Attack" [level=3] [ref=e63]
          - listitem [ref=e64]:
            - heading "Action 9 · Round 1 · Seat 1 · Combat · Attack → Attack" [level=3] [ref=e65]
            - paragraph [ref=e66]: "South rest · Seat 2 · Combat: 3 → 3 (+0)"
            - paragraph [ref=e67]: "High shore · Seat 1 · Combat: 10 → 9 (-1)"
            - paragraph [ref=e68]: "Seat 1 High shore: 1 combat casualties; Seat 2 South rest: 0 combat casualties."
          - listitem [ref=e69]:
            - heading "Action 10 · Round 1 · Seat 1 · Combat · Attack → Attack" [level=3] [ref=e70]
            - paragraph [ref=e71]: "South rest · Seat 2 · Combat: 3 → 3 (+0)"
            - paragraph [ref=e72]: "High shore · Seat 1 · Combat: 9 → 8 (-1)"
            - paragraph [ref=e73]: "Seat 1 High shore: 1 combat casualties; Seat 2 South rest: 0 combat casualties."
      - button "Resume game" [pressed] [ref=e74] [cursor=pointer]: Resume
      - generic [ref=e75]: Game speed
      - combobox "Game speed" [ref=e76]:
        - option "Very slow (2 s)" [selected]
        - option "Slow"
        - option "Normal"
        - option "Fast"
    - contentinfo [ref=e77]:
      - button "New game" [ref=e78] [cursor=pointer]
    - generic [ref=e79]:
      - button "Save game" [ref=e80] [cursor=pointer]
      - generic [ref=e81]:
        - generic [ref=e82]: Load game
        - button "Load game" [ref=e83]
  - main [ref=e84]:
    - img "Nine Isles reference map" [ref=e86]:
      - button "River gate, Seat 1, 3 armies, Seat 1" [ref=e112] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: "3"
      - button "New port, Seat 2, 2 armies, Seat 2" [ref=e114] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: "2"
      - button "North rest, Seat 1, 2 armies, Seat 1" [ref=e116] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: "2"
      - button "River keep, Seat 2, 1 armies, Seat 2" [ref=e118] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: "1"
      - button "North town, Seat 1, 2 armies, Seat 1" [ref=e120] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: "2"
      - button "Dark ford, Seat 1, 3 armies, Seat 1" [ref=e122] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: "3"
      - button "Iron point, Seat 2, 2 armies, Seat 2" [ref=e124] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: "2"
      - button "South rest, Seat 2, 3 armies, Seat 2" [ref=e126] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: "3"
      - button "High shore, Seat 1, 8 armies, Seat 1" [pressed] [ref=e128] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: "8"
      - button "Wind town, Seat 1, 3 armies, Seat 1" [ref=e130] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: "3"
      - button "New glen, Seat 1, 1 armies, Seat 1" [ref=e132] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: "1"
      - button "Old rock, Seat 2, 1 armies, Seat 2" [ref=e134] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: "1"
      - button "Blue peak, Seat 2, 1 armies, Seat 2" [ref=e136] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: "1"
      - button "West haven, Seat 1, 2 armies, Seat 1" [ref=e138] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: "2"
      - button "Stone watch, Seat 2, 3 armies, Seat 2" [ref=e140] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: "3"
      - button "Upper ridge, Seat 1, 2 armies, Seat 1" [ref=e142] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: "2"
      - button "Marsh keep, Seat 2, 2 armies, Seat 2" [ref=e144] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: "2"
      - button "New fell, Seat 1, 1 armies, Seat 1" [ref=e146] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: "1"
      - button "Moon point, Seat 2, 2 armies, Seat 2" [ref=e148] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: "2"
      - button "South fell, Seat 2, 3 armies, Seat 2" [ref=e150] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: "3"
      - button "High ridge, Seat 2, 1 armies, Seat 2" [ref=e152] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: "1"
        - generic [ref=e154]: ★
      - button "Bay ford, Seat 1, 3 armies, Seat 1" [ref=e155] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: "3"
      - button "Low moor, Seat 2, 2 armies, Seat 2" [ref=e157] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: "2"
      - button "Lower field, Seat 1, 1 armies, Seat 1" [ref=e159] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: "1"
      - button "Wind gate, Seat 2, 2 armies, Seat 2" [ref=e161] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: "2"
      - button "Silver shore, Seat 1, 2 armies, Seat 1" [ref=e163] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: "2"
      - button "Low peak, Seat 1, 1 armies, Seat 1" [ref=e165] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: "1"
      - button "Wind port, Seat 2, 3 armies, Seat 2" [ref=e167] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: "3"
      - button "Gold point, Seat 2, 3 armies, Seat 2" [ref=e169] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: "3"
      - button "Rock moor, Seat 1, 1 armies, Seat 1" [ref=e171] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: "1"
      - button "Marsh rest, Seat 1, 3 armies, Seat 1" [ref=e173] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: "3"
        - generic [ref=e175]: ★
      - button "Wind dale, Seat 1, 2 armies, Seat 1" [ref=e176] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: "2"
      - button "Silver ford, Seat 1, 1 armies, Seat 1" [ref=e178] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: "1"
      - button "Iron field, Seat 2, 3 armies, Seat 2" [ref=e180] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: "3"
      - button "North wood, Seat 2, 1 armies, Seat 2" [ref=e182] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: "1"
      - button "Fort town, Seat 1, 2 armies, Seat 1" [ref=e184] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: "2"
      - button "Red field, Seat 2, 1 armies, Seat 2" [ref=e186] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: "1"
      - button "South ridge, Seat 2, 3 armies, Seat 2" [ref=e188] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: "3"
      - button "Rock bay, Seat 1, 2 armies, Seat 1" [ref=e190] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: "2"
      - button "North ford, Seat 2, 1 armies, Seat 2" [ref=e192] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: "1"
      - button "Port ridge, Seat 1, 3 armies, Seat 1" [ref=e194] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: "3"
      - button "New rock, Seat 2, 3 armies, Seat 2" [ref=e196] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: "3"
      - button "South reach, Seat 2, 1 armies, Seat 2" [ref=e198] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: "1"
        - generic [ref=e200]: ★
      - button "Silver point, Seat 1, 1 armies, Seat 1" [ref=e201] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: "1"
      - button "East ford, Seat 1, 2 armies, Seat 1" [ref=e203] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: "2"
      - button "Gold town, Seat 2, 2 armies, Seat 2" [ref=e205] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: "2"
      - generic [ref=e237]: North Isle +3
      - generic [ref=e238]: East Isle +3
      - generic [ref=e239]: West Isle +3
      - generic [ref=e240]: South Isle +3
      - generic [ref=e241]: Central Isle +5
      - generic [ref=e242]: Harbor Isle +5
      - generic [ref=e243]: Palm Isle +6
      - generic [ref=e244]: Cliff Isle +5
      - generic [ref=e245]: Great Isle +9
    - complementary [ref=e246]:
      - generic [ref=e250]:
        - generic [ref=e251]: Seat 1's turn
        - generic [ref=e252]: Round 1 · Attack
      - generic [ref=e253]:
        - generic [ref=e254]:
          - button "End turn" [disabled] [ref=e255]
          - button "Move armies" [disabled] [ref=e256]
        - region "Battle controls" [ref=e257]:
          - heading "Battle" [level=2] [ref=e258]
          - generic [ref=e259]:
            - generic [ref=e260]:
              - generic [ref=e261]: From
              - strong [ref=e262]: High shore
              - generic "Source armies" [ref=e263]: "8"
            - generic [ref=e264]:
              - generic [ref=e265]: Target
              - strong [ref=e266]: South rest
              - generic "Target armies" [ref=e267]: "3"
          - generic [ref=e268]:
            - generic [ref=e269]:
              - text: Stop at armies
              - spinbutton "Stop at armies" [disabled] [ref=e270]: "1"
            - generic [ref=e271]:
              - text: Battle speed
              - combobox "Battle speed" [ref=e272]:
                - option "Very slow" [selected]
                - option "Slow"
                - option "Normal"
                - option "Fast"
          - paragraph [ref=e273]: This battle stops at 1 army, or on capture.
          - generic [ref=e274]:
            - button "Fight on" [disabled] [ref=e275]
            - button "Stop" [disabled] [ref=e276]
            - button "Single exchange" [disabled] [ref=e277]
          - generic [ref=e278]:
            - strong [ref=e279]: Defender wins · source loses 1 army
            - paragraph [ref=e280]: Game paused. Resume to continue this battle.
          - paragraph [ref=e281]:
            - text: Won 0 · Lost 2 · Ties
            - strong [ref=e282]: "0"
          - list "Latest exchange dice" [ref=e283]:
            - listitem [ref=e284]:
              - img "Attacker rolled 5" [ref=e285]: "5"
              - generic [ref=e286]: Defender wins
              - img "Defender rolled 6" [ref=e287]: "6"
      - generic [ref=e288]:
        - heading "Battle log" [level=3] [ref=e289]
        - list "Battle log" [ref=e290]:
          - listitem [ref=e291]: "T1 Seat 1: High shore → South rest, -1 / -0"
          - listitem [ref=e292]: "T1 Seat 1: High shore → South rest, -1 / -0"
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { fixture } from "./battle-fixture";
  3  | import { pinned } from "../core/versioned-match-fixture";
  4  | import { mkdirSync } from "node:fs";
  5  | import { join } from "node:path";
  6  | 
  7  | test("modal Escape preserves continuous combat; local/global very-slow controls stay synchronized", async ({ page }, info) => {
  8  |   const f = fixture("manual"); await page.clock.install({ time: new Date("2026-10-17T12:00:00Z") }); await page.clock.pauseAt(new Date("2026-10-17T12:00:00Z"));
  9  |   await page.goto("/?view=reference-game&control=manual"); await page.getByLabel("Seed", { exact: true }).fill(String(f.seed));
  10 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  11 |   for (let i = 0; i < f.placements; i++) await page.locator(`[data-country="${f.from}"]`).click();
  12 |   await page.locator("#start-combat-button").click(); await page.locator(`[data-country="${f.from}"]`).click(); await page.locator(`[data-country="${f.to}"]`).click({ modifiers: ["Shift"] });
  13 |   await page.locator("#game-speed").selectOption("very-slow"); await expect(page.locator("#battle-speed")).toHaveValue("very-slow");
  14 |   await page.locator("#battle-speed").selectOption("normal"); await expect(page.locator("#game-speed")).toHaveValue("normal");
  15 |   await page.locator("#battle-stop-threshold").fill("1"); await page.locator("#battle-stop-threshold").press("Tab"); await page.locator("#fight-on-button").click();
  16 |   const battle = page.getByRole("region", { name: "Battle controls", exact: true }), count = Number(await battle.getAttribute("data-history-count"));
  17 |   await page.locator("#game-log-button").click(); const dialog = page.getByRole("dialog", { name: "Game event log", exact: true }); await expect(dialog).toBeVisible();
  18 |   await page.keyboard.press("Escape"); await expect(dialog).not.toBeVisible(); await expect(battle).toHaveAttribute("data-running", "true");
  19 |   await page.clock.runFor(400); await expect(battle).toHaveAttribute("data-history-count", String(count + 1));
  20 |   await page.locator("#game-pause-button").click(); await page.locator("#battle-speed").selectOption("very-slow"); await expect(page.locator("#game-speed")).toHaveValue("very-slow");
  21 |   await page.locator("#game-log-button").click(); await expect(dialog.locator("details")).not.toHaveAttribute("open", "");
  22 |   expect(await dialog.evaluate(node => getComputedStyle(node).backgroundColor)).not.toBe("rgba(0, 0, 0, 0)");
  23 |   expect(await dialog.evaluate(node => Number(getComputedStyle(node).opacity))).toBe(1);
  24 |   const close = dialog.getByRole("button", { name: "Close game event log", exact: true }); await expect(close).toBeInViewport();
> 25 |   const root = process.env["PLAYBACK_EVIDENCE_DIR"]!; mkdirSync(root, { recursive: true }); await page.screenshot({ path: join(root, `production-modal-${info.project.name}.png`) });
     |                                                       ^ TypeError: The "path" argument must be of type string or an instance of Buffer or URL. Received undefined
  26 | });
  27 | 
  28 | test("default four-seat controls fit and a paused computer is labelled paused", async ({ page }, info) => {
  29 |   await page.clock.install({ time: new Date("2026-10-17T12:00:00Z") }); await page.clock.pauseAt(new Date("2026-10-17T12:00:00Z")); await page.goto("/?view=reference-game");
  30 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  31 |   for (const locator of [page.locator("#game-log-button"), page.locator("#game-pause-button"), page.locator("#game-speed"), ...await page.locator('[data-testid="player-army-total"]').all()]) await expect(locator).toBeInViewport();
  32 |   const f = pinned("watch"); await page.getByLabel("Load game", { exact: true }).setInputFiles({ name: "watch.json", mimeType: "application/json", buffer: Buffer.from(f.text) });
  33 |   await page.locator("#game-pause-button").click(); await expect(page.locator("#reference-computer-status")).toHaveText(/Paused/); await expect(page.locator("#reference-computer-status")).not.toHaveText(/playing/);
  34 |   const root = process.env["PLAYBACK_EVIDENCE_DIR"]!; mkdirSync(root, { recursive: true }); await page.screenshot({ path: join(root, `production-paused-computer-${info.project.name}.png`) });
  35 | });
  36 | 
  37 | test("failed load feedback stays readable without covering capture or playback controls", async ({ page }, info) => {
  38 |   await page.clock.install({ time: new Date("2026-10-17T12:00:00Z") }); await page.clock.pauseAt(new Date("2026-10-17T12:00:00Z"));
  39 |   await page.goto("/?view=reference-game&control=manual");
  40 |   const upload = (text: string) => page.getByLabel("Load game", { exact: true }).setInputFiles({ name: "bad-load.json", mimeType: "application/json", buffer: Buffer.from(text) });
  41 |   await upload(pinned("pending-capture").text); await expect(page.locator("#confirm-capture-button")).toBeVisible();
  42 |   for (const invalid of ["{", pinned("legacy-progress").text]) {
  43 |     await upload(invalid); const error = page.getByRole("alert"); await expect(error).toContainText("Load failed:");
  44 |     expect(await error.evaluate(node => { const r = node.getBoundingClientRect(); return r.width > 200 && r.left >= 0 && r.top >= 0 && r.right <= innerWidth && r.bottom <= innerHeight; })).toBe(true);
  45 |     for (const id of ["game-log-button", "game-pause-button", "game-speed", "reference-save-game", "confirm-capture-button"]) {
  46 |       expect(await page.locator(`#${id}`).evaluate(node => { const r = node.getBoundingClientRect(); return r.left >= 0 && r.top >= 0 && r.right <= innerWidth && r.bottom <= innerHeight; })).toBe(true);
  47 |     }
  48 |   }
  49 |   const root = process.env["PLAYBACK_EVIDENCE_DIR"]!; mkdirSync(root, { recursive: true }); await page.screenshot({ path: join(root, `production-invalid-load-${info.project.name}.png`) });
  50 | });
  51 | 
```