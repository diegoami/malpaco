# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: playback-edge-cases.spec.ts >> failed load feedback stays readable without covering capture or playback controls
- Location: tests/e2e/playback-edge-cases.spec.ts:37:1

# Error details

```
TypeError: The "path" argument must be of type string or an instance of Buffer or URL. Received undefined
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 2 human seats · Seed 0
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]:
          - strong [ref=e13]: "Total armies: 50"
          - generic [ref=e14]: 24 provinces
      - generic [ref=e18]:
        - generic [ref=e19]: Seat 2
        - generic [ref=e20]:
          - strong [ref=e21]: "Total armies: 45"
          - generic [ref=e22]: 22 provinces
    - generic [ref=e23]:
      - button "Game event log" [ref=e24] [cursor=pointer]
      - button "Pause game" [ref=e25] [cursor=pointer]: Pause
      - generic [ref=e26]: Game speed
      - combobox "Game speed" [ref=e27]:
        - option "Very slow (2 s)"
        - option "Slow"
        - option "Normal" [selected]
        - option "Fast"
    - contentinfo [ref=e28]:
      - button "New game" [ref=e29] [cursor=pointer]
    - generic [ref=e30]:
      - button "Save game" [ref=e31] [cursor=pointer]
      - generic [ref=e32]:
        - generic [ref=e33]: Load game
        - button "Load game" [ref=e34]
      - alert [ref=e35]: "Load failed: This game uses a generated map; load it in the generated game view."
  - main [ref=e36]:
    - img "Nine Isles reference map" [ref=e38]:
      - button "River gate, Seat 1, 3 armies, Seat 1" [ref=e64] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: "3"
      - button "New port, Seat 2, 2 armies, Seat 2" [ref=e66] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: "2"
      - button "North rest, Seat 1, 5 armies, Seat 1" [pressed] [ref=e68] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: "5"
      - button "River keep, Seat 1, 1 armies, Seat 1" [ref=e70] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: "1"
      - button "North town, Seat 1, 2 armies, Seat 1" [ref=e72] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: "2"
      - button "Dark ford, Seat 1, 3 armies, Seat 1" [ref=e74] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: "3"
      - button "Iron point, Seat 2, 2 armies, Seat 2" [ref=e76] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: "2"
      - button "South rest, Seat 2, 3 armies, Seat 2" [ref=e78] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: "3"
      - button "High shore, Seat 1, 3 armies, Seat 1" [ref=e80] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: "3"
      - button "Wind town, Seat 1, 3 armies, Seat 1" [ref=e82] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: "3"
      - button "New glen, Seat 1, 1 armies, Seat 1" [ref=e84] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: "1"
      - button "Old rock, Seat 2, 1 armies, Seat 2" [ref=e86] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: "1"
      - button "Blue peak, Seat 2, 1 armies, Seat 2" [ref=e88] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: "1"
      - button "West haven, Seat 1, 2 armies, Seat 1" [ref=e90] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: "2"
      - button "Stone watch, Seat 2, 3 armies, Seat 2" [ref=e92] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: "3"
      - button "Upper ridge, Seat 1, 2 armies, Seat 1" [ref=e94] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: "2"
      - button "Marsh keep, Seat 2, 2 armies, Seat 2" [ref=e96] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: "2"
      - button "New fell, Seat 1, 1 armies, Seat 1" [ref=e98] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: "1"
      - button "Moon point, Seat 2, 2 armies, Seat 2" [ref=e100] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: "2"
      - button "South fell, Seat 2, 3 armies, Seat 2" [ref=e102] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: "3"
      - button "High ridge, Seat 2, 1 armies, Seat 2" [ref=e104] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: "1"
        - generic [ref=e106]: ★
      - button "Bay ford, Seat 1, 3 armies, Seat 1" [ref=e107] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: "3"
      - button "Low moor, Seat 2, 2 armies, Seat 2" [ref=e109] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: "2"
      - button "Lower field, Seat 1, 1 armies, Seat 1" [ref=e111] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: "1"
      - button "Wind gate, Seat 2, 2 armies, Seat 2" [ref=e113] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: "2"
      - button "Silver shore, Seat 1, 2 armies, Seat 1" [ref=e115] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: "2"
      - button "Low peak, Seat 1, 1 armies, Seat 1" [ref=e117] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: "1"
      - button "Wind port, Seat 2, 3 armies, Seat 2" [ref=e119] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: "3"
      - button "Gold point, Seat 2, 3 armies, Seat 2" [ref=e121] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: "3"
      - button "Rock moor, Seat 1, 1 armies, Seat 1" [ref=e123] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: "1"
      - button "Marsh rest, Seat 1, 3 armies, Seat 1" [ref=e125] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: "3"
        - generic [ref=e127]: ★
      - button "Wind dale, Seat 1, 2 armies, Seat 1" [ref=e128] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: "2"
      - button "Silver ford, Seat 1, 1 armies, Seat 1" [ref=e130] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: "1"
      - button "Iron field, Seat 2, 3 armies, Seat 2" [ref=e132] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: "3"
      - button "North wood, Seat 2, 1 armies, Seat 2" [ref=e134] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: "1"
      - button "Fort town, Seat 1, 2 armies, Seat 1" [ref=e136] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: "2"
      - button "Red field, Seat 2, 1 armies, Seat 2" [ref=e138] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: "1"
      - button "South ridge, Seat 2, 3 armies, Seat 2" [ref=e140] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: "3"
      - button "Rock bay, Seat 1, 2 armies, Seat 1" [ref=e142] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: "2"
      - button "North ford, Seat 2, 1 armies, Seat 2" [ref=e144] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: "1"
      - button "Port ridge, Seat 1, 3 armies, Seat 1" [ref=e146] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: "3"
      - button "New rock, Seat 2, 3 armies, Seat 2" [ref=e148] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: "3"
      - button "South reach, Seat 2, 1 armies, Seat 2" [ref=e150] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: "1"
        - generic [ref=e152]: ★
      - button "Silver point, Seat 1, 1 armies, Seat 1" [ref=e153] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: "1"
      - button "East ford, Seat 1, 2 armies, Seat 1" [ref=e155] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: "2"
      - button "Gold town, Seat 2, 2 armies, Seat 2" [ref=e157] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: "2"
      - generic [ref=e189]: North Isle +3
      - generic [ref=e190]: East Isle +3
      - generic [ref=e191]: West Isle +3
      - generic [ref=e192]: South Isle +3
      - generic [ref=e193]: Central Isle +5
      - generic [ref=e194]: Harbor Isle +5
      - generic [ref=e195]: Palm Isle +6
      - generic [ref=e196]: Cliff Isle +5
      - generic [ref=e197]: Great Isle +9
    - complementary [ref=e198]:
      - generic [ref=e202]:
        - generic [ref=e203]: Seat 1's turn
        - generic [ref=e204]: Round 1 · Capture move-in
      - generic [ref=e205]:
        - button "End turn" [disabled] [ref=e207]
        - region "Battle controls" [ref=e208]:
          - heading "Battle" [level=2] [ref=e209]
          - generic [ref=e210]:
            - generic [ref=e211]:
              - generic [ref=e212]: From
              - strong [ref=e213]: North rest
              - generic "Source armies" [ref=e214]: "5"
            - generic [ref=e215]:
              - generic [ref=e216]: Target
              - strong [ref=e217]: River keep
              - generic "Target armies" [ref=e218]: "1"
          - generic [ref=e219]:
            - generic [ref=e220]:
              - text: Stop at armies
              - spinbutton "Stop at armies" [disabled] [ref=e221]: "2"
            - generic [ref=e222]:
              - text: Battle speed
              - combobox "Battle speed" [ref=e223]:
                - option "Very slow"
                - option "Slow"
                - option "Normal" [selected]
                - option "Fast"
          - paragraph [ref=e224]: This battle stops at 1 army, or on capture.
          - generic [ref=e225]:
            - button "Fight on" [disabled] [ref=e226]
            - button "Stop" [disabled] [ref=e227]
            - button "Single exchange" [disabled] [ref=e228]
          - generic [ref=e229]:
            - strong [ref=e230]: Ready for your choice
            - paragraph [ref=e231]: Confirm the army transfer below.
          - paragraph [ref=e232]:
            - text: Won 0 · Lost 0 · Ties
            - strong [ref=e233]: "0"
          - region "Capture move-in" [ref=e234]:
            - heading "Move armies into the capture" [level=3] [ref=e235]
            - paragraph [ref=e236]: Choose 1–5 total armies. Leave at least one behind.
            - generic [ref=e237]:
              - text: Armies to move
              - spinbutton "Armies to move" [ref=e238]: "5"
            - generic [ref=e239]:
              - button "Minimum" [ref=e240] [cursor=pointer]
              - button "Move one fewer army" [ref=e241] [cursor=pointer]: −
              - button "Move one more army" [ref=e242] [cursor=pointer]: +
              - button "Maximum" [ref=e243] [cursor=pointer]
            - button "Confirm move-in" [ref=e244] [cursor=pointer]
      - generic [ref=e245]:
        - heading "Battle log" [level=3] [ref=e246]
        - list "Battle log" [ref=e247]:
          - listitem [ref=e248]: "T1 Seat 1: North rest → River keep, took River keep"
          - listitem [ref=e249]: "T1 Seat 1: North rest → River keep, -1 / -0"
          - listitem [ref=e250]: "T1 Seat 1: North rest → River keep, -1 / -0"
          - listitem [ref=e251]: "T1 Seat 1: North rest → River keep, -1 / -0"
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { fixture } from "./battle-fixture";
  3  | import { pinned } from "../core/versioned-match-fixture";
  4  | import { mkdirSync } from "node:fs";
  5  | import { join } from "node:path";
  6  | 
  7  | test("modal Escape preserves continuous combat; local/global very-slow controls stay synchronized", async ({ page }, info) => {
  8  |   const f = fixture("manual"); await page.clock.install({ time: new Date("2026-10-17T12:00:00Z") }); await page.clock.pauseAt(new Date("2026-10-17T12:00:00Z"));
  9  |   await page.goto("/?view=reference-game&control=manual"); await page.getByLabel("Seed", { exact: true }).fill(String(f.seed));
  10 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  11 |   for (let i = 0; i < f.placements; i++) await page.locator(`[data-country="${f.from}"]`).click();
  12 |   await page.locator("#start-combat-button").click(); await page.locator(`[data-country="${f.from}"]`).click(); await page.locator(`[data-country="${f.to}"]`).click({ modifiers: ["Shift"] });
  13 |   await page.locator("#game-speed").selectOption("very-slow"); await expect(page.locator("#battle-speed")).toHaveValue("very-slow");
  14 |   await page.locator("#battle-speed").selectOption("normal"); await expect(page.locator("#game-speed")).toHaveValue("normal");
  15 |   await page.locator("#battle-stop-threshold").fill("1"); await page.locator("#battle-stop-threshold").press("Tab"); await page.locator("#fight-on-button").click();
  16 |   const battle = page.getByRole("region", { name: "Battle controls", exact: true }), count = Number(await battle.getAttribute("data-history-count"));
  17 |   await page.locator("#game-log-button").click(); const dialog = page.getByRole("dialog", { name: "Game event log", exact: true }); await expect(dialog).toBeVisible();
  18 |   await page.keyboard.press("Escape"); await expect(dialog).not.toBeVisible(); await expect(battle).toHaveAttribute("data-running", "true");
  19 |   await page.clock.runFor(400); await expect(battle).toHaveAttribute("data-history-count", String(count + 1));
  20 |   await page.locator("#game-pause-button").click(); await page.locator("#battle-speed").selectOption("very-slow"); await expect(page.locator("#game-speed")).toHaveValue("very-slow");
  21 |   await page.locator("#game-log-button").click(); await expect(dialog.locator("details")).not.toHaveAttribute("open", "");
  22 |   expect(await dialog.evaluate(node => getComputedStyle(node).backgroundColor)).not.toBe("rgba(0, 0, 0, 0)");
  23 |   expect(await dialog.evaluate(node => Number(getComputedStyle(node).opacity))).toBe(1);
  24 |   const close = dialog.getByRole("button", { name: "Close game event log", exact: true }); await expect(close).toBeInViewport();
  25 |   const root = process.env["PLAYBACK_EVIDENCE_DIR"]!; mkdirSync(root, { recursive: true }); await page.screenshot({ path: join(root, `production-modal-${info.project.name}.png`) });
  26 | });
  27 | 
  28 | test("default four-seat controls fit and a paused computer is labelled paused", async ({ page }, info) => {
  29 |   await page.clock.install({ time: new Date("2026-10-17T12:00:00Z") }); await page.clock.pauseAt(new Date("2026-10-17T12:00:00Z")); await page.goto("/?view=reference-game");
  30 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  31 |   for (const locator of [page.locator("#game-log-button"), page.locator("#game-pause-button"), page.locator("#game-speed"), ...await page.locator('[data-testid="player-army-total"]').all()]) await expect(locator).toBeInViewport();
  32 |   const f = pinned("watch"); await page.getByLabel("Load game", { exact: true }).setInputFiles({ name: "watch.json", mimeType: "application/json", buffer: Buffer.from(f.text) });
  33 |   await page.locator("#game-pause-button").click(); await expect(page.locator("#reference-computer-status")).toHaveText(/Paused/); await expect(page.locator("#reference-computer-status")).not.toHaveText(/playing/);
  34 |   const root = process.env["PLAYBACK_EVIDENCE_DIR"]!; mkdirSync(root, { recursive: true }); await page.screenshot({ path: join(root, `production-paused-computer-${info.project.name}.png`) });
  35 | });
  36 | 
  37 | test("failed load feedback stays readable without covering capture or playback controls", async ({ page }, info) => {
  38 |   await page.clock.install({ time: new Date("2026-10-17T12:00:00Z") }); await page.clock.pauseAt(new Date("2026-10-17T12:00:00Z"));
  39 |   await page.goto("/?view=reference-game&control=manual");
  40 |   const upload = (text: string) => page.getByLabel("Load game", { exact: true }).setInputFiles({ name: "bad-load.json", mimeType: "application/json", buffer: Buffer.from(text) });
  41 |   await upload(pinned("pending-capture").text); await expect(page.locator("#confirm-capture-button")).toBeVisible();
  42 |   for (const invalid of ["{", pinned("legacy-progress").text]) {
  43 |     await upload(invalid); const error = page.getByRole("alert"); await expect(error).toContainText("Load failed:");
  44 |     expect(await error.evaluate(node => { const r = node.getBoundingClientRect(); return r.width > 200 && r.left >= 0 && r.top >= 0 && r.right <= innerWidth && r.bottom <= innerHeight; })).toBe(true);
  45 |     for (const id of ["game-log-button", "game-pause-button", "game-speed", "reference-save-game", "confirm-capture-button"]) {
  46 |       expect(await page.locator(`#${id}`).evaluate(node => { const r = node.getBoundingClientRect(); return r.left >= 0 && r.top >= 0 && r.right <= innerWidth && r.bottom <= innerHeight; })).toBe(true);
  47 |     }
  48 |   }
> 49 |   const root = process.env["PLAYBACK_EVIDENCE_DIR"]!; mkdirSync(root, { recursive: true }); await page.screenshot({ path: join(root, `production-invalid-load-${info.project.name}.png`) });
     |                                                       ^ TypeError: The "path" argument must be of type string or an instance of Buffer or URL. Received undefined
  50 | });
  51 | 
```