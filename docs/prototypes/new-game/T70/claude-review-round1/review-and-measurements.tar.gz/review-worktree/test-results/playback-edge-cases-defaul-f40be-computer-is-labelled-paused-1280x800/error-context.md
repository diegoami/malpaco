# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: playback-edge-cases.spec.ts >> default four-seat controls fit and a paused computer is labelled paused
- Location: tests/e2e/playback-edge-cases.spec.ts:28:1

# Error details

```
TypeError: The "path" argument must be of type string or an instance of Buffer or URL. Received undefined
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 1 human / 2 computer seats · Computer play · Seed 1994
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]:
          - strong [ref=e13]: "Total armies: 0"
          - generic [ref=e14]: 0 provinces
      - generic [ref=e18]:
        - generic [ref=e19]: Seat 2 · Computer
        - generic [ref=e20]:
          - strong [ref=e21]: "Total armies: 48"
          - generic [ref=e22]: 22 provinces
      - generic [ref=e26]:
        - generic [ref=e27]: Seat 3 · Computer
        - generic [ref=e28]:
          - strong [ref=e29]: "Total armies: 46"
          - generic [ref=e30]: 24 provinces
    - generic [ref=e31]:
      - button "Game event log" [ref=e32] [cursor=pointer]
      - button "Resume game" [active] [pressed] [ref=e33] [cursor=pointer]: Resume
      - generic [ref=e34]: Game speed
      - combobox "Game speed" [ref=e35]:
        - option "Very slow (2 s)"
        - option "Slow"
        - option "Normal" [selected]
        - option "Fast"
    - contentinfo [ref=e36]:
      - button "New game" [ref=e37] [cursor=pointer]
    - generic [ref=e38]:
      - button "Save game" [ref=e39] [cursor=pointer]
      - generic [ref=e40]:
        - generic [ref=e41]: Load game
        - button "Load game" [ref=e42]
  - main [ref=e43]:
    - img "Nine Isles reference map" [ref=e45]:
      - button "River gate, Seat 3, 1 armies, Seat 3" [ref=e71] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: "1"
      - button "New port, Seat 2, 8 armies, Seat 2" [ref=e73] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: "8"
      - button "North rest, Seat 2, 1 armies, Seat 2" [ref=e75] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: "1"
      - button "River keep, Seat 2, 1 armies, Seat 2" [ref=e77] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: "1"
      - button "North town, Seat 2, 1 armies, Seat 2" [ref=e79] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: "1"
      - button "Dark ford, Seat 2, 1 armies, Seat 2" [ref=e81] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: "1"
      - button "Iron point, Seat 3, 2 armies, Seat 3" [ref=e83] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: "2"
      - button "South rest, Seat 3, 2 armies, Seat 3" [ref=e85] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: "2"
      - button "High shore, Seat 2, 2 armies, Seat 2" [ref=e87] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: "2"
      - button "Wind town, Seat 3, 1 armies, Seat 3" [ref=e89] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: "1"
      - button "New glen, Seat 2, 8 armies, Seat 2" [ref=e91] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: "8"
      - button "Old rock, Seat 3, 1 armies, Seat 3" [ref=e93] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: "1"
      - button "Blue peak, Seat 2, 1 armies, Seat 2" [ref=e95] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: "1"
      - button "West haven, Seat 3, 1 armies, Seat 3" [ref=e97] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: "1"
      - button "Stone watch, Seat 2, 1 armies, Seat 2" [ref=e99] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: "1"
      - button "Upper ridge, Seat 2, 6 armies, Seat 2" [ref=e101] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: "6"
      - button "Marsh keep, Seat 2, 3 armies, Seat 2" [ref=e103] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: "3"
      - button "New fell, Seat 2, 1 armies, Seat 2" [ref=e105] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: "1"
      - button "Moon point, Seat 3, 1 armies, Seat 3" [ref=e107] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: "1"
      - button "South fell, Seat 2, 1 armies, Seat 2" [ref=e109] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: "1"
      - button "High ridge, Seat 2, 1 armies, Seat 2" [ref=e111] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: "1"
      - button "Bay ford, Seat 2, 1 armies, Seat 2" [ref=e113] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: "1"
      - button "Low moor, Seat 3, 1 armies, Seat 3" [ref=e115] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: "1"
      - button "Lower field, Seat 3, 1 armies, Seat 3" [ref=e117] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: "1"
      - button "Wind gate, Seat 3, 1 armies, Seat 3" [ref=e119] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: "1"
      - button "Silver shore, Seat 3, 4 armies, Seat 3" [ref=e121] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: "4"
      - button "Low peak, Seat 3, 1 armies, Seat 3" [ref=e123] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: "1"
      - button "Wind port, Seat 3, 1 armies, Seat 3" [ref=e125] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: "1"
      - button "Gold point, Seat 3, 1 armies, Seat 3" [ref=e127] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: "1"
        - generic [ref=e129]: ★
      - button "Rock moor, Seat 2, 1 armies, Seat 2" [ref=e130] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: "1"
      - button "Marsh rest, Seat 3, 1 armies, Seat 3" [ref=e132] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: "1"
      - button "Wind dale, Seat 3, 11 armies, Seat 3" [ref=e134] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: "11"
      - button "Silver ford, Seat 2, 1 armies, Seat 2" [ref=e136] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: "1"
      - button "Iron field, Seat 2, 1 armies, Seat 2" [ref=e138] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: "1"
      - button "North wood, Seat 2, 1 armies, Seat 2" [ref=e140] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: "1"
      - button "Fort town, Seat 3, 1 armies, Seat 3" [ref=e142] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: "1"
        - generic [ref=e144]: ★
      - button "Red field, Seat 2, 3 armies, Seat 2" [ref=e145] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: "3"
        - generic [ref=e147]: ★
      - button "South ridge, Seat 2, 2 armies, Seat 2" [ref=e148] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: "2"
      - button "Rock bay, Seat 3, 1 armies, Seat 3" [ref=e150] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: "1"
      - button "North ford, Seat 3, 1 armies, Seat 3" [ref=e152] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: "1"
      - button "Port ridge, Seat 3, 1 armies, Seat 3" [ref=e154] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: "1"
      - button "New rock, Seat 2, 2 armies, Seat 2" [ref=e156] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: "2"
      - button "South reach, Seat 3, 3 armies, Seat 3" [ref=e158] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: "3"
      - button "Silver point, Seat 3, 1 armies, Seat 3" [ref=e160] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: "1"
      - button "East ford, Seat 3, 1 armies, Seat 3" [ref=e162] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: "1"
      - button "Gold town, Seat 3, 6 armies, Seat 3" [ref=e164] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: "6"
      - generic [ref=e196]: North Isle +3
      - generic [ref=e197]: East Isle +3
      - generic [ref=e198]: West Isle +3
      - generic [ref=e199]: South Isle +3
      - generic [ref=e200]: Central Isle +5
      - generic [ref=e201]: Harbor Isle +5
      - generic [ref=e202]: Palm Isle +6
      - generic [ref=e203]: Cliff Isle +5
      - generic [ref=e204]: Great Isle +9
    - complementary [ref=e205]:
      - generic [ref=e209]:
        - generic [ref=e210]: Seat 2's turn
        - generic [ref=e211]: Computer · Normal · Round 6 · Reinforcement
      - generic [ref=e212]:
        - generic [ref=e213]:
          - generic [ref=e214]:
            - generic [ref=e215]: Province income
            - strong [ref=e216]: "7"
          - generic [ref=e217]:
            - generic [ref=e218]: Island income
            - strong [ref=e219]: "3"
          - generic [ref=e220]:
            - generic [ref=e221]: Armies to place
            - strong [ref=e222]: "10"
        - paragraph [ref=e223]: Game paused. Resume when ready; save, load and new game remain available.
        - generic [ref=e224]:
          - button "Start combat" [disabled] [ref=e225]
          - button "End turn" [disabled] [ref=e226]
        - status [ref=e227]: Seat 2 · Paused
      - generic [ref=e228]:
        - heading "Battle log" [level=3] [ref=e229]
        - list "Battle log" [ref=e230]:
          - listitem [ref=e231]: T5 Seat 3 ends the turn
          - listitem [ref=e232]: Seat 1 is eliminated
          - listitem [ref=e233]: "T5 Seat 3: East ford → Gold town, took Gold town"
          - listitem [ref=e234]: "T5 Seat 3: East ford → Gold town, -0 / -1"
          - listitem [ref=e235]: "T5 Seat 3: East ford → Gold town, -1 / -0"
          - listitem [ref=e236]: "T5 Seat 3: East ford → Gold town, -1 / -0"
          - listitem [ref=e237]: "T5 Seat 3: East ford → Gold town, -1 / -0"
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { fixture } from "./battle-fixture";
  3  | import { pinned } from "../core/versioned-match-fixture";
  4  | import { mkdirSync } from "node:fs";
  5  | import { join } from "node:path";
  6  | 
  7  | test("modal Escape preserves continuous combat; local/global very-slow controls stay synchronized", async ({ page }, info) => {
  8  |   const f = fixture("manual"); await page.clock.install({ time: new Date("2026-10-17T12:00:00Z") }); await page.clock.pauseAt(new Date("2026-10-17T12:00:00Z"));
  9  |   await page.goto("/?view=reference-game&control=manual"); await page.getByLabel("Seed", { exact: true }).fill(String(f.seed));
  10 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  11 |   for (let i = 0; i < f.placements; i++) await page.locator(`[data-country="${f.from}"]`).click();
  12 |   await page.locator("#start-combat-button").click(); await page.locator(`[data-country="${f.from}"]`).click(); await page.locator(`[data-country="${f.to}"]`).click({ modifiers: ["Shift"] });
  13 |   await page.locator("#game-speed").selectOption("very-slow"); await expect(page.locator("#battle-speed")).toHaveValue("very-slow");
  14 |   await page.locator("#battle-speed").selectOption("normal"); await expect(page.locator("#game-speed")).toHaveValue("normal");
  15 |   await page.locator("#battle-stop-threshold").fill("1"); await page.locator("#battle-stop-threshold").press("Tab"); await page.locator("#fight-on-button").click();
  16 |   const battle = page.getByRole("region", { name: "Battle controls", exact: true }), count = Number(await battle.getAttribute("data-history-count"));
  17 |   await page.locator("#game-log-button").click(); const dialog = page.getByRole("dialog", { name: "Game event log", exact: true }); await expect(dialog).toBeVisible();
  18 |   await page.keyboard.press("Escape"); await expect(dialog).not.toBeVisible(); await expect(battle).toHaveAttribute("data-running", "true");
  19 |   await page.clock.runFor(400); await expect(battle).toHaveAttribute("data-history-count", String(count + 1));
  20 |   await page.locator("#game-pause-button").click(); await page.locator("#battle-speed").selectOption("very-slow"); await expect(page.locator("#game-speed")).toHaveValue("very-slow");
  21 |   await page.locator("#game-log-button").click(); await expect(dialog.locator("details")).not.toHaveAttribute("open", "");
  22 |   expect(await dialog.evaluate(node => getComputedStyle(node).backgroundColor)).not.toBe("rgba(0, 0, 0, 0)");
  23 |   expect(await dialog.evaluate(node => Number(getComputedStyle(node).opacity))).toBe(1);
  24 |   const close = dialog.getByRole("button", { name: "Close game event log", exact: true }); await expect(close).toBeInViewport();
  25 |   const root = process.env["PLAYBACK_EVIDENCE_DIR"]!; mkdirSync(root, { recursive: true }); await page.screenshot({ path: join(root, `production-modal-${info.project.name}.png`) });
  26 | });
  27 | 
  28 | test("default four-seat controls fit and a paused computer is labelled paused", async ({ page }, info) => {
  29 |   await page.clock.install({ time: new Date("2026-10-17T12:00:00Z") }); await page.clock.pauseAt(new Date("2026-10-17T12:00:00Z")); await page.goto("/?view=reference-game");
  30 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  31 |   for (const locator of [page.locator("#game-log-button"), page.locator("#game-pause-button"), page.locator("#game-speed"), ...await page.locator('[data-testid="player-army-total"]').all()]) await expect(locator).toBeInViewport();
  32 |   const f = pinned("watch"); await page.getByLabel("Load game", { exact: true }).setInputFiles({ name: "watch.json", mimeType: "application/json", buffer: Buffer.from(f.text) });
  33 |   await page.locator("#game-pause-button").click(); await expect(page.locator("#reference-computer-status")).toHaveText(/Paused/); await expect(page.locator("#reference-computer-status")).not.toHaveText(/playing/);
> 34 |   const root = process.env["PLAYBACK_EVIDENCE_DIR"]!; mkdirSync(root, { recursive: true }); await page.screenshot({ path: join(root, `production-paused-computer-${info.project.name}.png`) });
     |                                                       ^ TypeError: The "path" argument must be of type string or an instance of Buffer or URL. Received undefined
  35 | });
  36 | 
  37 | test("failed load feedback stays readable without covering capture or playback controls", async ({ page }, info) => {
  38 |   await page.clock.install({ time: new Date("2026-10-17T12:00:00Z") }); await page.clock.pauseAt(new Date("2026-10-17T12:00:00Z"));
  39 |   await page.goto("/?view=reference-game&control=manual");
  40 |   const upload = (text: string) => page.getByLabel("Load game", { exact: true }).setInputFiles({ name: "bad-load.json", mimeType: "application/json", buffer: Buffer.from(text) });
  41 |   await upload(pinned("pending-capture").text); await expect(page.locator("#confirm-capture-button")).toBeVisible();
  42 |   for (const invalid of ["{", pinned("legacy-progress").text]) {
  43 |     await upload(invalid); const error = page.getByRole("alert"); await expect(error).toContainText("Load failed:");
  44 |     expect(await error.evaluate(node => { const r = node.getBoundingClientRect(); return r.width > 200 && r.left >= 0 && r.top >= 0 && r.right <= innerWidth && r.bottom <= innerHeight; })).toBe(true);
  45 |     for (const id of ["game-log-button", "game-pause-button", "game-speed", "reference-save-game", "confirm-capture-button"]) {
  46 |       expect(await page.locator(`#${id}`).evaluate(node => { const r = node.getBoundingClientRect(); return r.left >= 0 && r.top >= 0 && r.right <= innerWidth && r.bottom <= innerHeight; })).toBe(true);
  47 |     }
  48 |   }
  49 |   const root = process.env["PLAYBACK_EVIDENCE_DIR"]!; mkdirSync(root, { recursive: true }); await page.screenshot({ path: join(root, `production-invalid-load-${info.project.name}.png`) });
  50 | });
  51 | 
```