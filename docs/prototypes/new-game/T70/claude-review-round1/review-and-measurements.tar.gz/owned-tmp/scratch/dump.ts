import { deserializeVersionedMatch } from "/home/diego/projects/malpaco/.cache/t70-claude-review/159-review-2c674e76/src/core/match-save";
import { GameEventHistory } from "/home/diego/projects/malpaco/.cache/t70-claude-review/159-review-2c674e76/src/ui/gameEventLog";
import { pinned } from "/home/diego/projects/malpaco/.cache/t70-claude-review/159-review-2c674e76/tests/core/versioned-match-fixture";
const l = deserializeVersionedMatch(pinned("domination").text), h = new GameEventHistory(l.options); h.append(l.state);
const caps = h.events.filter(e => e.notes.some(n => /capture transfer/.test(n)));
for (const e of [caps[0]!, h.events.at(-1)!]) { console.log(e.heading); e.regions.forEach(r => console.log("  R:", r.description)); e.notes.forEach(n => console.log("  N:", n)); }
console.log(h.events.length);
