import subprocess, sys, pathlib, json
# usage: mut.py <file> <before> <after> -- cmd...
path = pathlib.Path(sys.argv[1]); before = sys.argv[2]; after = sys.argv[3]; cmd = sys.argv[sys.argv.index("--")+1:]
saved = path.read_bytes()
try:
    text = saved.decode(); assert before in text, "anchor missing"
    path.write_bytes(text.replace(before, after, 1).encode())
    r = subprocess.run(cmd, capture_output=True, text=True)
    out = (r.stdout + r.stderr).splitlines()
    print("EXIT", r.returncode); print("\n".join(out[-14:]))
finally:
    path.write_bytes(saved)
    assert path.read_bytes() == saved
    print("restored")
