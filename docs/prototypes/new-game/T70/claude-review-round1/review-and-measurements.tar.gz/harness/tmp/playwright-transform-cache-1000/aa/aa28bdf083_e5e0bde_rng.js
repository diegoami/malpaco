// ed96404ec6dc5b42ba7c2b1482651fbf4e6dd70f
/** Anything that can roll a die. The engine's own generator is one; a test may supply a scripted one. */

/**
 * Seeded randomness, carried as data (mulberry32 over uint32, integers only).
 *
 * The seed and the current state are plain integers, so a game can be
 * serialised, replayed and compared exactly. This is NOT bit-compatible with
 * Godot's RandomNumberGenerator (PCG32): a game replayed here rolls different
 * dice than the same seed in the Godot build.
 *
 * `% span` carries a bias of at most 2^-32 * span; with a span of 6 that is
 * about 1.4e-9, immaterial for a spike.
 */
export class DeterministicRng {
  constructor(seed, state) {
    this.seed = void 0;
    this.state = void 0;
    this.seed = seed >>> 0;
    this.state = (state !== null && state !== void 0 ? state : seed) >>> 0;
  }
  static fromSnapshot(snapshot) {
    return new DeterministicRng(snapshot.seed, snapshot.state);
  }
  snapshot() {
    return {
      seed: this.seed,
      state: this.state
    };
  }
  nextU32() {
    this.state = this.state + 0x6d2b79f5 >>> 0;
    let t = this.state;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return (t ^ t >>> 14) >>> 0;
  }

  /** Inclusive on both ends. */
  nextInt(from, to) {
    return from + this.nextU32() % (to - from + 1);
  }
  rollDie(sides) {
    return this.nextInt(1, sides);
  }

  /** Fisher-Yates, drawing only from this generator. Returns a new array. */
  shuffled(items) {
    const out = [...items];
    for (let i = out.length - 1; i > 0; i--) {
      const j = this.nextInt(0, i);
      const held = out[i];
      out[i] = out[j];
      out[j] = held;
    }
    return out;
  }

  /**
   * Derive a child stream from a parent seed and a per-child salt. The
   * parent's own state is never read or modified, so the parent's draws
   * are not perturbed by sub-streams (C-RND-03, design/core-rules.md §
   * Setup → Randomness): each computer seat's choices come from a separate
   * stream, seeded from the game seed and the seat number. Pure.
   */
  static subStream(parentSeed, childSalt) {
    // SplitMix-style mixing: parent seed XOR a salted mixer. Math.imul is
    // used here intentionally (Math.random is forbidden; Math.imul is just
    // integer multiplication).
    const mixed = (parentSeed ^ Math.imul(childSalt | 0, 0x9e3779b1)) >>> 0;
    // Spread bits once more so the child seed never equals the parent.
    const child = Math.imul(mixed ^ mixed >>> 16, 0x85ebca6b) >>> 0;
    return new DeterministicRng(child);
  }
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJEZXRlcm1pbmlzdGljUm5nIiwiY29uc3RydWN0b3IiLCJzZWVkIiwic3RhdGUiLCJmcm9tU25hcHNob3QiLCJzbmFwc2hvdCIsIm5leHRVMzIiLCJ0IiwiTWF0aCIsImltdWwiLCJuZXh0SW50IiwiZnJvbSIsInRvIiwicm9sbERpZSIsInNpZGVzIiwic2h1ZmZsZWQiLCJpdGVtcyIsIm91dCIsImkiLCJsZW5ndGgiLCJqIiwiaGVsZCIsInN1YlN0cmVhbSIsInBhcmVudFNlZWQiLCJjaGlsZFNhbHQiLCJtaXhlZCIsImNoaWxkIl0sInNvdXJjZXMiOlsicm5nLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgUm5nU25hcHNob3QgfSBmcm9tIFwiLi90eXBlc1wiO1xuXG4vKiogQW55dGhpbmcgdGhhdCBjYW4gcm9sbCBhIGRpZS4gVGhlIGVuZ2luZSdzIG93biBnZW5lcmF0b3IgaXMgb25lOyBhIHRlc3QgbWF5IHN1cHBseSBhIHNjcmlwdGVkIG9uZS4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRGljZVNvdXJjZSB7XG4gIHJvbGxEaWUoc2lkZXM6IG51bWJlcik6IG51bWJlcjtcbn1cblxuLyoqXG4gKiBTZWVkZWQgcmFuZG9tbmVzcywgY2FycmllZCBhcyBkYXRhIChtdWxiZXJyeTMyIG92ZXIgdWludDMyLCBpbnRlZ2VycyBvbmx5KS5cbiAqXG4gKiBUaGUgc2VlZCBhbmQgdGhlIGN1cnJlbnQgc3RhdGUgYXJlIHBsYWluIGludGVnZXJzLCBzbyBhIGdhbWUgY2FuIGJlXG4gKiBzZXJpYWxpc2VkLCByZXBsYXllZCBhbmQgY29tcGFyZWQgZXhhY3RseS4gVGhpcyBpcyBOT1QgYml0LWNvbXBhdGlibGUgd2l0aFxuICogR29kb3QncyBSYW5kb21OdW1iZXJHZW5lcmF0b3IgKFBDRzMyKTogYSBnYW1lIHJlcGxheWVkIGhlcmUgcm9sbHMgZGlmZmVyZW50XG4gKiBkaWNlIHRoYW4gdGhlIHNhbWUgc2VlZCBpbiB0aGUgR29kb3QgYnVpbGQuXG4gKlxuICogYCUgc3BhbmAgY2FycmllcyBhIGJpYXMgb2YgYXQgbW9zdCAyXi0zMiAqIHNwYW47IHdpdGggYSBzcGFuIG9mIDYgdGhhdCBpc1xuICogYWJvdXQgMS40ZS05LCBpbW1hdGVyaWFsIGZvciBhIHNwaWtlLlxuICovXG5leHBvcnQgY2xhc3MgRGV0ZXJtaW5pc3RpY1JuZyBpbXBsZW1lbnRzIERpY2VTb3VyY2Uge1xuICByZWFkb25seSBzZWVkOiBudW1iZXI7XG4gIHByaXZhdGUgc3RhdGU6IG51bWJlcjtcblxuICBjb25zdHJ1Y3RvcihzZWVkOiBudW1iZXIsIHN0YXRlPzogbnVtYmVyKSB7XG4gICAgdGhpcy5zZWVkID0gc2VlZCA+Pj4gMDtcbiAgICB0aGlzLnN0YXRlID0gKHN0YXRlID8/IHNlZWQpID4+PiAwO1xuICB9XG5cbiAgc3RhdGljIGZyb21TbmFwc2hvdChzbmFwc2hvdDogUm5nU25hcHNob3QpOiBEZXRlcm1pbmlzdGljUm5nIHtcbiAgICByZXR1cm4gbmV3IERldGVybWluaXN0aWNSbmcoc25hcHNob3Quc2VlZCwgc25hcHNob3Quc3RhdGUpO1xuICB9XG5cbiAgc25hcHNob3QoKTogUm5nU25hcHNob3Qge1xuICAgIHJldHVybiB7IHNlZWQ6IHRoaXMuc2VlZCwgc3RhdGU6IHRoaXMuc3RhdGUgfTtcbiAgfVxuXG4gIHByaXZhdGUgbmV4dFUzMigpOiBudW1iZXIge1xuICAgIHRoaXMuc3RhdGUgPSAodGhpcy5zdGF0ZSArIDB4NmQyYjc5ZjUpID4+PiAwO1xuICAgIGxldCB0ID0gdGhpcy5zdGF0ZTtcbiAgICB0ID0gTWF0aC5pbXVsKHQgXiAodCA+Pj4gMTUpLCB0IHwgMSk7XG4gICAgdCBePSB0ICsgTWF0aC5pbXVsKHQgXiAodCA+Pj4gNyksIHQgfCA2MSk7XG4gICAgcmV0dXJuICh0IF4gKHQgPj4+IDE0KSkgPj4+IDA7XG4gIH1cblxuICAvKiogSW5jbHVzaXZlIG9uIGJvdGggZW5kcy4gKi9cbiAgbmV4dEludChmcm9tOiBudW1iZXIsIHRvOiBudW1iZXIpOiBudW1iZXIge1xuICAgIHJldHVybiBmcm9tICsgKHRoaXMubmV4dFUzMigpICUgKHRvIC0gZnJvbSArIDEpKTtcbiAgfVxuXG4gIHJvbGxEaWUoc2lkZXM6IG51bWJlcik6IG51bWJlciB7XG4gICAgcmV0dXJuIHRoaXMubmV4dEludCgxLCBzaWRlcyk7XG4gIH1cblxuICAvKiogRmlzaGVyLVlhdGVzLCBkcmF3aW5nIG9ubHkgZnJvbSB0aGlzIGdlbmVyYXRvci4gUmV0dXJucyBhIG5ldyBhcnJheS4gKi9cbiAgc2h1ZmZsZWQ8VD4oaXRlbXM6IHJlYWRvbmx5IFRbXSk6IFRbXSB7XG4gICAgY29uc3Qgb3V0ID0gWy4uLml0ZW1zXTtcbiAgICBmb3IgKGxldCBpID0gb3V0Lmxlbmd0aCAtIDE7IGkgPiAwOyBpLS0pIHtcbiAgICAgIGNvbnN0IGogPSB0aGlzLm5leHRJbnQoMCwgaSk7XG4gICAgICBjb25zdCBoZWxkID0gb3V0W2ldIGFzIFQ7XG4gICAgICBvdXRbaV0gPSBvdXRbal0gYXMgVDtcbiAgICAgIG91dFtqXSA9IGhlbGQ7XG4gICAgfVxuICAgIHJldHVybiBvdXQ7XG4gIH1cblxuICAvKipcbiAgICogRGVyaXZlIGEgY2hpbGQgc3RyZWFtIGZyb20gYSBwYXJlbnQgc2VlZCBhbmQgYSBwZXItY2hpbGQgc2FsdC4gVGhlXG4gICAqIHBhcmVudCdzIG93biBzdGF0ZSBpcyBuZXZlciByZWFkIG9yIG1vZGlmaWVkLCBzbyB0aGUgcGFyZW50J3MgZHJhd3NcbiAgICogYXJlIG5vdCBwZXJ0dXJiZWQgYnkgc3ViLXN0cmVhbXMgKEMtUk5ELTAzLCBkZXNpZ24vY29yZS1ydWxlcy5tZCDCp1xuICAgKiBTZXR1cCDihpIgUmFuZG9tbmVzcyk6IGVhY2ggY29tcHV0ZXIgc2VhdCdzIGNob2ljZXMgY29tZSBmcm9tIGEgc2VwYXJhdGVcbiAgICogc3RyZWFtLCBzZWVkZWQgZnJvbSB0aGUgZ2FtZSBzZWVkIGFuZCB0aGUgc2VhdCBudW1iZXIuIFB1cmUuXG4gICAqL1xuICBzdGF0aWMgc3ViU3RyZWFtKHBhcmVudFNlZWQ6IG51bWJlciwgY2hpbGRTYWx0OiBudW1iZXIpOiBEZXRlcm1pbmlzdGljUm5nIHtcbiAgICAvLyBTcGxpdE1peC1zdHlsZSBtaXhpbmc6IHBhcmVudCBzZWVkIFhPUiBhIHNhbHRlZCBtaXhlci4gTWF0aC5pbXVsIGlzXG4gICAgLy8gdXNlZCBoZXJlIGludGVudGlvbmFsbHkgKE1hdGgucmFuZG9tIGlzIGZvcmJpZGRlbjsgTWF0aC5pbXVsIGlzIGp1c3RcbiAgICAvLyBpbnRlZ2VyIG11bHRpcGxpY2F0aW9uKS5cbiAgICBjb25zdCBtaXhlZCA9IChwYXJlbnRTZWVkIF4gTWF0aC5pbXVsKGNoaWxkU2FsdCB8IDAsIDB4OWUzNzc5YjEpKSA+Pj4gMDtcbiAgICAvLyBTcHJlYWQgYml0cyBvbmNlIG1vcmUgc28gdGhlIGNoaWxkIHNlZWQgbmV2ZXIgZXF1YWxzIHRoZSBwYXJlbnQuXG4gICAgY29uc3QgY2hpbGQgPSBNYXRoLmltdWwobWl4ZWQgXiAobWl4ZWQgPj4+IDE2KSwgMHg4NWViY2E2YikgPj4+IDA7XG4gICAgcmV0dXJuIG5ldyBEZXRlcm1pbmlzdGljUm5nKGNoaWxkKTtcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiQUFFQTs7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTyxNQUFNQSxnQkFBZ0IsQ0FBdUI7RUFJbERDLFdBQVdBLENBQUNDLElBQVksRUFBRUMsS0FBYyxFQUFFO0lBQUEsS0FIakNELElBQUk7SUFBQSxLQUNMQyxLQUFLO0lBR1gsSUFBSSxDQUFDRCxJQUFJLEdBQUdBLElBQUksS0FBSyxDQUFDO0lBQ3RCLElBQUksQ0FBQ0MsS0FBSyxHQUFHLENBQUNBLEtBQUssYUFBTEEsS0FBSyxjQUFMQSxLQUFLLEdBQUlELElBQUksTUFBTSxDQUFDO0VBQ3BDO0VBRUEsT0FBT0UsWUFBWUEsQ0FBQ0MsUUFBcUIsRUFBb0I7SUFDM0QsT0FBTyxJQUFJTCxnQkFBZ0IsQ0FBQ0ssUUFBUSxDQUFDSCxJQUFJLEVBQUVHLFFBQVEsQ0FBQ0YsS0FBSyxDQUFDO0VBQzVEO0VBRUFFLFFBQVFBLENBQUEsRUFBZ0I7SUFDdEIsT0FBTztNQUFFSCxJQUFJLEVBQUUsSUFBSSxDQUFDQSxJQUFJO01BQUVDLEtBQUssRUFBRSxJQUFJLENBQUNBO0lBQU0sQ0FBQztFQUMvQztFQUVRRyxPQUFPQSxDQUFBLEVBQVc7SUFDeEIsSUFBSSxDQUFDSCxLQUFLLEdBQUksSUFBSSxDQUFDQSxLQUFLLEdBQUcsVUFBVSxLQUFNLENBQUM7SUFDNUMsSUFBSUksQ0FBQyxHQUFHLElBQUksQ0FBQ0osS0FBSztJQUNsQkksQ0FBQyxHQUFHQyxJQUFJLENBQUNDLElBQUksQ0FBQ0YsQ0FBQyxHQUFJQSxDQUFDLEtBQUssRUFBRyxFQUFFQSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ3BDQSxDQUFDLElBQUlBLENBQUMsR0FBR0MsSUFBSSxDQUFDQyxJQUFJLENBQUNGLENBQUMsR0FBSUEsQ0FBQyxLQUFLLENBQUUsRUFBRUEsQ0FBQyxHQUFHLEVBQUUsQ0FBQztJQUN6QyxPQUFPLENBQUNBLENBQUMsR0FBSUEsQ0FBQyxLQUFLLEVBQUcsTUFBTSxDQUFDO0VBQy9COztFQUVBO0VBQ0FHLE9BQU9BLENBQUNDLElBQVksRUFBRUMsRUFBVSxFQUFVO0lBQ3hDLE9BQU9ELElBQUksR0FBSSxJQUFJLENBQUNMLE9BQU8sQ0FBQyxDQUFDLElBQUlNLEVBQUUsR0FBR0QsSUFBSSxHQUFHLENBQUMsQ0FBRTtFQUNsRDtFQUVBRSxPQUFPQSxDQUFDQyxLQUFhLEVBQVU7SUFDN0IsT0FBTyxJQUFJLENBQUNKLE9BQU8sQ0FBQyxDQUFDLEVBQUVJLEtBQUssQ0FBQztFQUMvQjs7RUFFQTtFQUNBQyxRQUFRQSxDQUFJQyxLQUFtQixFQUFPO0lBQ3BDLE1BQU1DLEdBQUcsR0FBRyxDQUFDLEdBQUdELEtBQUssQ0FBQztJQUN0QixLQUFLLElBQUlFLENBQUMsR0FBR0QsR0FBRyxDQUFDRSxNQUFNLEdBQUcsQ0FBQyxFQUFFRCxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEVBQUUsRUFBRTtNQUN2QyxNQUFNRSxDQUFDLEdBQUcsSUFBSSxDQUFDVixPQUFPLENBQUMsQ0FBQyxFQUFFUSxDQUFDLENBQUM7TUFDNUIsTUFBTUcsSUFBSSxHQUFHSixHQUFHLENBQUNDLENBQUMsQ0FBTTtNQUN4QkQsR0FBRyxDQUFDQyxDQUFDLENBQUMsR0FBR0QsR0FBRyxDQUFDRyxDQUFDLENBQU07TUFDcEJILEdBQUcsQ0FBQ0csQ0FBQyxDQUFDLEdBQUdDLElBQUk7SUFDZjtJQUNBLE9BQU9KLEdBQUc7RUFDWjs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLE9BQU9LLFNBQVNBLENBQUNDLFVBQWtCLEVBQUVDLFNBQWlCLEVBQW9CO0lBQ3hFO0lBQ0E7SUFDQTtJQUNBLE1BQU1DLEtBQUssR0FBRyxDQUFDRixVQUFVLEdBQUdmLElBQUksQ0FBQ0MsSUFBSSxDQUFDZSxTQUFTLEdBQUcsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxNQUFNLENBQUM7SUFDdkU7SUFDQSxNQUFNRSxLQUFLLEdBQUdsQixJQUFJLENBQUNDLElBQUksQ0FBQ2dCLEtBQUssR0FBSUEsS0FBSyxLQUFLLEVBQUcsRUFBRSxVQUFVLENBQUMsS0FBSyxDQUFDO0lBQ2pFLE9BQU8sSUFBSXpCLGdCQUFnQixDQUFDMEIsS0FBSyxDQUFDO0VBQ3BDO0FBQ0YiLCJpZ25vcmVMaXN0IjpbXX0=