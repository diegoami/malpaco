// 7224ee55eb21d04953a74b6d01f1f8c098fe8129
/**
 * Board fairness checks — pure functions over a `GameMap`.
 *
 * Each check returns a list of violation messages (empty list = pass).
 * All are rooted in C-BRD-01 (the generator must meet the structural
 * invariants AND pass the fairness checks).  The design's own words:
 * "the fairness checks are not weakened to make generation easier."
 *
 * Key definitions:
 * - "single-entrance island" = an island where exactly one of its countries
 *   (provinces) has a non-empty `seaLanes` list.
 * - "island graph": vertices = islands, edges = island pairs where at least
 *   one province of one has a sea lane to a province of the other.
 */

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** True when exactly one province on the island has sea lanes. */
function isSingleEntrance(island, provincesById) {
  let count = 0;
  for (const pid of island.provinces) {
    const p = provincesById.get(pid);
    if (p && p.seaLanes.length > 0) count++;
    if (count > 1) return false;
  }
  return count === 1;
}

/**
 * Build the island graph: vertices = island ids; edges = pairs that share
 * at least one sea lane between a province of one and a province of the other.
 * Returns an adjacency set per island.
 */
function buildIslandGraph(islands, provincesById) {
  const adj = new Map(islands.map(i => [i.id, new Set()]));
  for (const island of islands) {
    for (const pid of island.provinces) {
      const p = provincesById.get(pid);
      if (!p) continue;
      for (const sl of p.seaLanes) {
        const other = provincesById.get(sl);
        if (!other || other.island === island.id) continue;
        adj.get(island.id).add(other.island);
        adj.get(other.island).add(island.id);
      }
    }
  }
  return adj;
}

/** BFS distance from startId to every other vertex in an adjacency map. */
function bfsDistances(adj, startId) {
  const dist = new Map();
  const visited = new Set();
  const queue = [startId];
  dist.set(startId, 0);
  visited.add(startId);
  while (queue.length > 0) {
    const current = queue.shift();
    const d = dist.get(current);
    for (const neighbour of (_adj$get = adj.get(current)) !== null && _adj$get !== void 0 ? _adj$get : []) {
      var _adj$get;
      if (!visited.has(neighbour)) {
        visited.add(neighbour);
        dist.set(neighbour, d + 1);
        queue.push(neighbour);
      }
    }
  }
  return dist;
}

// ---------------------------------------------------------------------------
// Check 1: Bonus out of proportion  (C-BRD-01)
// ---------------------------------------------------------------------------

/**
 * Any island whose bonus exceeds its size.
 * A small rich island is unfair however the bonus got there.
 */
export function checkBonusOutOfProportion(map) {
  const violations = [];
  for (const island of map.islands) {
    if (island.bonus > island.provinces.length) {
      violations.push(`bonus-out-of-proportion: island '${island.id}' has bonus ${island.bonus} > size ${island.provinces.length}`);
    }
  }
  return violations;
}

// ---------------------------------------------------------------------------
// Check 2: Fortress  (C-BRD-01)
// ---------------------------------------------------------------------------

/**
 * Fortress = (a) any island of size >= 7 with a single entrance, OR
 * (b) more than 3 islands (any size) with a single entrance.
 *
 * A large island with only one sea-lane entry point can be held by one
 * player and is hard to dislodge — an unfair "fortress".
 */
export function checkFortress(map) {
  const violations = [];
  const provincesById = new Map(map.provinces.map(p => [p.id, p]));
  const singleEntranceIslands = [];
  for (const island of map.islands) {
    if (isSingleEntrance(island, provincesById)) {
      singleEntranceIslands.push(island.id);
      if (island.provinces.length >= 7) {
        violations.push(`fortress: island '${island.id}' (size ${island.provinces.length}) has a single entrance`);
      }
    }
  }
  if (singleEntranceIslands.length > 3) {
    violations.push(`fortress: ${singleEntranceIslands.length} islands have a single entrance (max 3): ${singleEntranceIslands.join(", ")}`);
  }
  return violations;
}

// ---------------------------------------------------------------------------
// Check 3: Easy bonuses concentrated  (C-BRD-01)
// ---------------------------------------------------------------------------

/**
 * The sum of bonuses on single-entrance islands is more than a quarter of
 * the sum of all bonuses.
 *
 * Single-entrance islands are easy to defend. If most of the map's bonus
 * value is concentrated there, the game rewards passive play.
 */
export function checkEasyBonusesConcentrated(map) {
  const violations = [];
  const provincesById = new Map(map.provinces.map(p => [p.id, p]));
  let totalBonus = 0;
  let singleEntranceBonus = 0;
  for (const island of map.islands) {
    totalBonus += island.bonus;
    if (isSingleEntrance(island, provincesById)) {
      singleEntranceBonus += island.bonus;
    }
  }

  // More than 1/4 of total bonus concentrated on single-entrance islands
  if (totalBonus > 0 && singleEntranceBonus > totalBonus / 4) {
    violations.push(`easy-bonuses-concentrated: single-entrance islands hold bonus ${singleEntranceBonus} > 1/4 of total bonus ${totalBonus}`);
  }
  return violations;
}

// ---------------------------------------------------------------------------
// Check 4: Remote / hub island  (C-BRD-01)
// ---------------------------------------------------------------------------

/**
 * In the island graph, any island with eccentricity > 4 (requires more
 * than 4 crossings to reach some other island) OR degree > 5 (touches
 * more than 5 other islands).
 *
 * A remote island (isolated, requires many hops) or a hub (over-connected)
 * both distort strategy.
 *
 * Amendment 2026-10-13: degree threshold moved from `> 4` to `> 5`
 * in lockstep with `MAX_ISLAND_GRAPH_DEGREE = 5` in board-gen.ts
 * (C-BRD-01).  Eccentricity threshold (4) did not move.
 */
export function checkRemoteOrHub(map) {
  const violations = [];
  const provincesById = new Map(map.provinces.map(p => [p.id, p]));
  const islandAdj = buildIslandGraph(map.islands, provincesById);
  for (const island of map.islands) {
    var _islandAdj$get;
    const neighbours = (_islandAdj$get = islandAdj.get(island.id)) !== null && _islandAdj$get !== void 0 ? _islandAdj$get : new Set();

    // Degree check: more than 5 other islands directly adjacent
    if (neighbours.size > 5) {
      violations.push(`remote-or-hub: island '${island.id}' has degree ${neighbours.size} > 5`);
    }

    // Eccentricity check: max distance to any other island > 4.
    // R1 (rework round, Sol 2026-10-13): bfsDistances records only
    // reachable vertices; an island that has no path to `island.id` in
    // the island graph is not in the map.  Detect those unreachable
    // islands as remote violations: an island that cannot be reached
    // within any number of crossings is unreachable (effectively
    // eccentricity = Infinity).  Without this fix, two disconnected
    // islands silently pass the remote check.
    const dists = bfsDistances(islandAdj, island.id);
    let reportedForThisIsland = false;
    for (const [, dist] of dists) {
      if (dist > 4) {
        violations.push(`remote-or-hub: island '${island.id}' has eccentricity ${dist} > 4`);
        reportedForThisIsland = true;
        break; // only report once per island
      }
    }
    if (!reportedForThisIsland) {
      // Any island not present in `dists` is unreachable from `island.id`.
      for (const other of map.islands) {
        if (other.id === island.id) continue;
        if (!dists.has(other.id)) {
          violations.push(`remote-or-hub: island '${island.id}' cannot reach island '${other.id}' (disconnected)`);
          reportedForThisIsland = true;
          break;
        }
      }
    }
  }
  return violations;
}

// ---------------------------------------------------------------------------
// Check 5: Crowded crossing country  (C-BRD-01)
// ---------------------------------------------------------------------------

/**
 * Any province with more than 2 sea lanes.
 * A province that serves too many crossings concentrates connectivity and
 * makes the map brittle.
 */
export function checkCrowdedCrossing(map) {
  const violations = [];
  for (const p of map.provinces) {
    if (p.seaLanes.length > 2) {
      violations.push(`crowded-crossing: province '${p.id}' has ${p.seaLanes.length} sea lanes > 2`);
    }
  }
  return violations;
}

// ---------------------------------------------------------------------------
// Convenience: run all 5 checks
// ---------------------------------------------------------------------------

/** Run all 5 fairness checks and return the concatenated list of violations. */
export function runAllFairnessChecks(map) {
  return [...checkBonusOutOfProportion(map), ...checkFortress(map), ...checkEasyBonusesConcentrated(map), ...checkRemoteOrHub(map), ...checkCrowdedCrossing(map)];
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJpc1NpbmdsZUVudHJhbmNlIiwiaXNsYW5kIiwicHJvdmluY2VzQnlJZCIsImNvdW50IiwicGlkIiwicHJvdmluY2VzIiwicCIsImdldCIsInNlYUxhbmVzIiwibGVuZ3RoIiwiYnVpbGRJc2xhbmRHcmFwaCIsImlzbGFuZHMiLCJhZGoiLCJNYXAiLCJtYXAiLCJpIiwiaWQiLCJTZXQiLCJzbCIsIm90aGVyIiwiYWRkIiwiYmZzRGlzdGFuY2VzIiwic3RhcnRJZCIsImRpc3QiLCJ2aXNpdGVkIiwicXVldWUiLCJzZXQiLCJjdXJyZW50Iiwic2hpZnQiLCJkIiwibmVpZ2hib3VyIiwiX2FkaiRnZXQiLCJoYXMiLCJwdXNoIiwiY2hlY2tCb251c091dE9mUHJvcG9ydGlvbiIsInZpb2xhdGlvbnMiLCJib251cyIsImNoZWNrRm9ydHJlc3MiLCJzaW5nbGVFbnRyYW5jZUlzbGFuZHMiLCJqb2luIiwiY2hlY2tFYXN5Qm9udXNlc0NvbmNlbnRyYXRlZCIsInRvdGFsQm9udXMiLCJzaW5nbGVFbnRyYW5jZUJvbnVzIiwiY2hlY2tSZW1vdGVPckh1YiIsImlzbGFuZEFkaiIsIl9pc2xhbmRBZGokZ2V0IiwibmVpZ2hib3VycyIsInNpemUiLCJkaXN0cyIsInJlcG9ydGVkRm9yVGhpc0lzbGFuZCIsImNoZWNrQ3Jvd2RlZENyb3NzaW5nIiwicnVuQWxsRmFpcm5lc3NDaGVja3MiXSwic291cmNlcyI6WyJib2FyZC1mYWlybmVzcy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEJvYXJkIGZhaXJuZXNzIGNoZWNrcyDigJQgcHVyZSBmdW5jdGlvbnMgb3ZlciBhIGBHYW1lTWFwYC5cbiAqXG4gKiBFYWNoIGNoZWNrIHJldHVybnMgYSBsaXN0IG9mIHZpb2xhdGlvbiBtZXNzYWdlcyAoZW1wdHkgbGlzdCA9IHBhc3MpLlxuICogQWxsIGFyZSByb290ZWQgaW4gQy1CUkQtMDEgKHRoZSBnZW5lcmF0b3IgbXVzdCBtZWV0IHRoZSBzdHJ1Y3R1cmFsXG4gKiBpbnZhcmlhbnRzIEFORCBwYXNzIHRoZSBmYWlybmVzcyBjaGVja3MpLiAgVGhlIGRlc2lnbidzIG93biB3b3JkczpcbiAqIFwidGhlIGZhaXJuZXNzIGNoZWNrcyBhcmUgbm90IHdlYWtlbmVkIHRvIG1ha2UgZ2VuZXJhdGlvbiBlYXNpZXIuXCJcbiAqXG4gKiBLZXkgZGVmaW5pdGlvbnM6XG4gKiAtIFwic2luZ2xlLWVudHJhbmNlIGlzbGFuZFwiID0gYW4gaXNsYW5kIHdoZXJlIGV4YWN0bHkgb25lIG9mIGl0cyBjb3VudHJpZXNcbiAqICAgKHByb3ZpbmNlcykgaGFzIGEgbm9uLWVtcHR5IGBzZWFMYW5lc2AgbGlzdC5cbiAqIC0gXCJpc2xhbmQgZ3JhcGhcIjogdmVydGljZXMgPSBpc2xhbmRzLCBlZGdlcyA9IGlzbGFuZCBwYWlycyB3aGVyZSBhdCBsZWFzdFxuICogICBvbmUgcHJvdmluY2Ugb2Ygb25lIGhhcyBhIHNlYSBsYW5lIHRvIGEgcHJvdmluY2Ugb2YgdGhlIG90aGVyLlxuICovXG5cbmltcG9ydCB0eXBlIHsgR2FtZU1hcCwgSXNsYW5kLCBQcm92aW5jZSB9IGZyb20gXCIuL3R5cGVzXCI7XG5cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gSGVscGVyc1xuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbi8qKiBUcnVlIHdoZW4gZXhhY3RseSBvbmUgcHJvdmluY2Ugb24gdGhlIGlzbGFuZCBoYXMgc2VhIGxhbmVzLiAqL1xuZnVuY3Rpb24gaXNTaW5nbGVFbnRyYW5jZShpc2xhbmQ6IElzbGFuZCwgcHJvdmluY2VzQnlJZDogTWFwPHN0cmluZywgUHJvdmluY2U+KTogYm9vbGVhbiB7XG4gIGxldCBjb3VudCA9IDA7XG4gIGZvciAoY29uc3QgcGlkIG9mIGlzbGFuZC5wcm92aW5jZXMpIHtcbiAgICBjb25zdCBwID0gcHJvdmluY2VzQnlJZC5nZXQocGlkKTtcbiAgICBpZiAocCAmJiBwLnNlYUxhbmVzLmxlbmd0aCA+IDApIGNvdW50Kys7XG4gICAgaWYgKGNvdW50ID4gMSkgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiBjb3VudCA9PT0gMTtcbn1cblxuLyoqXG4gKiBCdWlsZCB0aGUgaXNsYW5kIGdyYXBoOiB2ZXJ0aWNlcyA9IGlzbGFuZCBpZHM7IGVkZ2VzID0gcGFpcnMgdGhhdCBzaGFyZVxuICogYXQgbGVhc3Qgb25lIHNlYSBsYW5lIGJldHdlZW4gYSBwcm92aW5jZSBvZiBvbmUgYW5kIGEgcHJvdmluY2Ugb2YgdGhlIG90aGVyLlxuICogUmV0dXJucyBhbiBhZGphY2VuY3kgc2V0IHBlciBpc2xhbmQuXG4gKi9cbmZ1bmN0aW9uIGJ1aWxkSXNsYW5kR3JhcGgoXG4gIGlzbGFuZHM6IHJlYWRvbmx5IElzbGFuZFtdLFxuICBwcm92aW5jZXNCeUlkOiBNYXA8c3RyaW5nLCBQcm92aW5jZT4sXG4pOiBNYXA8c3RyaW5nLCBTZXQ8c3RyaW5nPj4ge1xuICBjb25zdCBhZGogPSBuZXcgTWFwPHN0cmluZywgU2V0PHN0cmluZz4+KGlzbGFuZHMubWFwKChpKSA9PiBbaS5pZCwgbmV3IFNldDxzdHJpbmc+KCldKSk7XG5cbiAgZm9yIChjb25zdCBpc2xhbmQgb2YgaXNsYW5kcykge1xuICAgIGZvciAoY29uc3QgcGlkIG9mIGlzbGFuZC5wcm92aW5jZXMpIHtcbiAgICAgIGNvbnN0IHAgPSBwcm92aW5jZXNCeUlkLmdldChwaWQpO1xuICAgICAgaWYgKCFwKSBjb250aW51ZTtcbiAgICAgIGZvciAoY29uc3Qgc2wgb2YgcC5zZWFMYW5lcykge1xuICAgICAgICBjb25zdCBvdGhlciA9IHByb3ZpbmNlc0J5SWQuZ2V0KHNsKTtcbiAgICAgICAgaWYgKCFvdGhlciB8fCBvdGhlci5pc2xhbmQgPT09IGlzbGFuZC5pZCkgY29udGludWU7XG4gICAgICAgIGFkai5nZXQoaXNsYW5kLmlkKSEuYWRkKG90aGVyLmlzbGFuZCk7XG4gICAgICAgIGFkai5nZXQob3RoZXIuaXNsYW5kKSEuYWRkKGlzbGFuZC5pZCk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBhZGo7XG59XG5cbi8qKiBCRlMgZGlzdGFuY2UgZnJvbSBzdGFydElkIHRvIGV2ZXJ5IG90aGVyIHZlcnRleCBpbiBhbiBhZGphY2VuY3kgbWFwLiAqL1xuZnVuY3Rpb24gYmZzRGlzdGFuY2VzKGFkajogTWFwPHN0cmluZywgU2V0PHN0cmluZz4+LCBzdGFydElkOiBzdHJpbmcpOiBNYXA8c3RyaW5nLCBudW1iZXI+IHtcbiAgY29uc3QgZGlzdCA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KCk7XG4gIGNvbnN0IHZpc2l0ZWQgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgY29uc3QgcXVldWU6IHN0cmluZ1tdID0gW3N0YXJ0SWRdO1xuICBkaXN0LnNldChzdGFydElkLCAwKTtcbiAgdmlzaXRlZC5hZGQoc3RhcnRJZCk7XG5cbiAgd2hpbGUgKHF1ZXVlLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBjdXJyZW50ID0gcXVldWUuc2hpZnQoKSE7XG4gICAgY29uc3QgZCA9IGRpc3QuZ2V0KGN1cnJlbnQpITtcbiAgICBmb3IgKGNvbnN0IG5laWdoYm91ciBvZiBhZGouZ2V0KGN1cnJlbnQpID8/IFtdKSB7XG4gICAgICBpZiAoIXZpc2l0ZWQuaGFzKG5laWdoYm91cikpIHtcbiAgICAgICAgdmlzaXRlZC5hZGQobmVpZ2hib3VyKTtcbiAgICAgICAgZGlzdC5zZXQobmVpZ2hib3VyLCBkICsgMSk7XG4gICAgICAgIHF1ZXVlLnB1c2gobmVpZ2hib3VyKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIGRpc3Q7XG59XG5cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gQ2hlY2sgMTogQm9udXMgb3V0IG9mIHByb3BvcnRpb24gIChDLUJSRC0wMSlcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4vKipcbiAqIEFueSBpc2xhbmQgd2hvc2UgYm9udXMgZXhjZWVkcyBpdHMgc2l6ZS5cbiAqIEEgc21hbGwgcmljaCBpc2xhbmQgaXMgdW5mYWlyIGhvd2V2ZXIgdGhlIGJvbnVzIGdvdCB0aGVyZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNoZWNrQm9udXNPdXRPZlByb3BvcnRpb24obWFwOiBHYW1lTWFwKTogc3RyaW5nW10ge1xuICBjb25zdCB2aW9sYXRpb25zOiBzdHJpbmdbXSA9IFtdO1xuICBmb3IgKGNvbnN0IGlzbGFuZCBvZiBtYXAuaXNsYW5kcykge1xuICAgIGlmIChpc2xhbmQuYm9udXMgPiBpc2xhbmQucHJvdmluY2VzLmxlbmd0aCkge1xuICAgICAgdmlvbGF0aW9ucy5wdXNoKFxuICAgICAgICBgYm9udXMtb3V0LW9mLXByb3BvcnRpb246IGlzbGFuZCAnJHtpc2xhbmQuaWR9JyBoYXMgYm9udXMgJHtpc2xhbmQuYm9udXN9ID4gc2l6ZSAke2lzbGFuZC5wcm92aW5jZXMubGVuZ3RofWAsXG4gICAgICApO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdmlvbGF0aW9ucztcbn1cblxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyBDaGVjayAyOiBGb3J0cmVzcyAgKEMtQlJELTAxKVxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbi8qKlxuICogRm9ydHJlc3MgPSAoYSkgYW55IGlzbGFuZCBvZiBzaXplID49IDcgd2l0aCBhIHNpbmdsZSBlbnRyYW5jZSwgT1JcbiAqIChiKSBtb3JlIHRoYW4gMyBpc2xhbmRzIChhbnkgc2l6ZSkgd2l0aCBhIHNpbmdsZSBlbnRyYW5jZS5cbiAqXG4gKiBBIGxhcmdlIGlzbGFuZCB3aXRoIG9ubHkgb25lIHNlYS1sYW5lIGVudHJ5IHBvaW50IGNhbiBiZSBoZWxkIGJ5IG9uZVxuICogcGxheWVyIGFuZCBpcyBoYXJkIHRvIGRpc2xvZGdlIOKAlCBhbiB1bmZhaXIgXCJmb3J0cmVzc1wiLlxuICovXG5leHBvcnQgZnVuY3Rpb24gY2hlY2tGb3J0cmVzcyhtYXA6IEdhbWVNYXApOiBzdHJpbmdbXSB7XG4gIGNvbnN0IHZpb2xhdGlvbnM6IHN0cmluZ1tdID0gW107XG4gIGNvbnN0IHByb3ZpbmNlc0J5SWQgPSBuZXcgTWFwPHN0cmluZywgUHJvdmluY2U+KG1hcC5wcm92aW5jZXMubWFwKChwKSA9PiBbcC5pZCwgcF0pKTtcbiAgY29uc3Qgc2luZ2xlRW50cmFuY2VJc2xhbmRzOiBzdHJpbmdbXSA9IFtdO1xuXG4gIGZvciAoY29uc3QgaXNsYW5kIG9mIG1hcC5pc2xhbmRzKSB7XG4gICAgaWYgKGlzU2luZ2xlRW50cmFuY2UoaXNsYW5kLCBwcm92aW5jZXNCeUlkKSkge1xuICAgICAgc2luZ2xlRW50cmFuY2VJc2xhbmRzLnB1c2goaXNsYW5kLmlkKTtcbiAgICAgIGlmIChpc2xhbmQucHJvdmluY2VzLmxlbmd0aCA+PSA3KSB7XG4gICAgICAgIHZpb2xhdGlvbnMucHVzaChcbiAgICAgICAgICBgZm9ydHJlc3M6IGlzbGFuZCAnJHtpc2xhbmQuaWR9JyAoc2l6ZSAke2lzbGFuZC5wcm92aW5jZXMubGVuZ3RofSkgaGFzIGEgc2luZ2xlIGVudHJhbmNlYCxcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBpZiAoc2luZ2xlRW50cmFuY2VJc2xhbmRzLmxlbmd0aCA+IDMpIHtcbiAgICB2aW9sYXRpb25zLnB1c2goXG4gICAgICBgZm9ydHJlc3M6ICR7c2luZ2xlRW50cmFuY2VJc2xhbmRzLmxlbmd0aH0gaXNsYW5kcyBoYXZlIGEgc2luZ2xlIGVudHJhbmNlIChtYXggMyk6ICR7c2luZ2xlRW50cmFuY2VJc2xhbmRzLmpvaW4oXCIsIFwiKX1gLFxuICAgICk7XG4gIH1cblxuICByZXR1cm4gdmlvbGF0aW9ucztcbn1cblxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyBDaGVjayAzOiBFYXN5IGJvbnVzZXMgY29uY2VudHJhdGVkICAoQy1CUkQtMDEpXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuLyoqXG4gKiBUaGUgc3VtIG9mIGJvbnVzZXMgb24gc2luZ2xlLWVudHJhbmNlIGlzbGFuZHMgaXMgbW9yZSB0aGFuIGEgcXVhcnRlciBvZlxuICogdGhlIHN1bSBvZiBhbGwgYm9udXNlcy5cbiAqXG4gKiBTaW5nbGUtZW50cmFuY2UgaXNsYW5kcyBhcmUgZWFzeSB0byBkZWZlbmQuIElmIG1vc3Qgb2YgdGhlIG1hcCdzIGJvbnVzXG4gKiB2YWx1ZSBpcyBjb25jZW50cmF0ZWQgdGhlcmUsIHRoZSBnYW1lIHJld2FyZHMgcGFzc2l2ZSBwbGF5LlxuICovXG5leHBvcnQgZnVuY3Rpb24gY2hlY2tFYXN5Qm9udXNlc0NvbmNlbnRyYXRlZChtYXA6IEdhbWVNYXApOiBzdHJpbmdbXSB7XG4gIGNvbnN0IHZpb2xhdGlvbnM6IHN0cmluZ1tdID0gW107XG4gIGNvbnN0IHByb3ZpbmNlc0J5SWQgPSBuZXcgTWFwPHN0cmluZywgUHJvdmluY2U+KG1hcC5wcm92aW5jZXMubWFwKChwKSA9PiBbcC5pZCwgcF0pKTtcblxuICBsZXQgdG90YWxCb251cyA9IDA7XG4gIGxldCBzaW5nbGVFbnRyYW5jZUJvbnVzID0gMDtcblxuICBmb3IgKGNvbnN0IGlzbGFuZCBvZiBtYXAuaXNsYW5kcykge1xuICAgIHRvdGFsQm9udXMgKz0gaXNsYW5kLmJvbnVzO1xuICAgIGlmIChpc1NpbmdsZUVudHJhbmNlKGlzbGFuZCwgcHJvdmluY2VzQnlJZCkpIHtcbiAgICAgIHNpbmdsZUVudHJhbmNlQm9udXMgKz0gaXNsYW5kLmJvbnVzO1xuICAgIH1cbiAgfVxuXG4gIC8vIE1vcmUgdGhhbiAxLzQgb2YgdG90YWwgYm9udXMgY29uY2VudHJhdGVkIG9uIHNpbmdsZS1lbnRyYW5jZSBpc2xhbmRzXG4gIGlmICh0b3RhbEJvbnVzID4gMCAmJiBzaW5nbGVFbnRyYW5jZUJvbnVzID4gdG90YWxCb251cyAvIDQpIHtcbiAgICB2aW9sYXRpb25zLnB1c2goXG4gICAgICBgZWFzeS1ib251c2VzLWNvbmNlbnRyYXRlZDogc2luZ2xlLWVudHJhbmNlIGlzbGFuZHMgaG9sZCBib251cyAke3NpbmdsZUVudHJhbmNlQm9udXN9ID4gMS80IG9mIHRvdGFsIGJvbnVzICR7dG90YWxCb251c31gLFxuICAgICk7XG4gIH1cblxuICByZXR1cm4gdmlvbGF0aW9ucztcbn1cblxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyBDaGVjayA0OiBSZW1vdGUgLyBodWIgaXNsYW5kICAoQy1CUkQtMDEpXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuLyoqXG4gKiBJbiB0aGUgaXNsYW5kIGdyYXBoLCBhbnkgaXNsYW5kIHdpdGggZWNjZW50cmljaXR5ID4gNCAocmVxdWlyZXMgbW9yZVxuICogdGhhbiA0IGNyb3NzaW5ncyB0byByZWFjaCBzb21lIG90aGVyIGlzbGFuZCkgT1IgZGVncmVlID4gNSAodG91Y2hlc1xuICogbW9yZSB0aGFuIDUgb3RoZXIgaXNsYW5kcykuXG4gKlxuICogQSByZW1vdGUgaXNsYW5kIChpc29sYXRlZCwgcmVxdWlyZXMgbWFueSBob3BzKSBvciBhIGh1YiAob3Zlci1jb25uZWN0ZWQpXG4gKiBib3RoIGRpc3RvcnQgc3RyYXRlZ3kuXG4gKlxuICogQW1lbmRtZW50IDIwMjYtMTAtMTM6IGRlZ3JlZSB0aHJlc2hvbGQgbW92ZWQgZnJvbSBgPiA0YCB0byBgPiA1YFxuICogaW4gbG9ja3N0ZXAgd2l0aCBgTUFYX0lTTEFORF9HUkFQSF9ERUdSRUUgPSA1YCBpbiBib2FyZC1nZW4udHNcbiAqIChDLUJSRC0wMSkuICBFY2NlbnRyaWNpdHkgdGhyZXNob2xkICg0KSBkaWQgbm90IG1vdmUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjaGVja1JlbW90ZU9ySHViKG1hcDogR2FtZU1hcCk6IHN0cmluZ1tdIHtcbiAgY29uc3QgdmlvbGF0aW9uczogc3RyaW5nW10gPSBbXTtcbiAgY29uc3QgcHJvdmluY2VzQnlJZCA9IG5ldyBNYXA8c3RyaW5nLCBQcm92aW5jZT4obWFwLnByb3ZpbmNlcy5tYXAoKHApID0+IFtwLmlkLCBwXSkpO1xuICBjb25zdCBpc2xhbmRBZGogPSBidWlsZElzbGFuZEdyYXBoKG1hcC5pc2xhbmRzLCBwcm92aW5jZXNCeUlkKTtcblxuICBmb3IgKGNvbnN0IGlzbGFuZCBvZiBtYXAuaXNsYW5kcykge1xuICAgIGNvbnN0IG5laWdoYm91cnMgPSBpc2xhbmRBZGouZ2V0KGlzbGFuZC5pZCkgPz8gbmV3IFNldDxzdHJpbmc+KCk7XG5cbiAgICAvLyBEZWdyZWUgY2hlY2s6IG1vcmUgdGhhbiA1IG90aGVyIGlzbGFuZHMgZGlyZWN0bHkgYWRqYWNlbnRcbiAgICBpZiAobmVpZ2hib3Vycy5zaXplID4gNSkge1xuICAgICAgdmlvbGF0aW9ucy5wdXNoKFxuICAgICAgICBgcmVtb3RlLW9yLWh1YjogaXNsYW5kICcke2lzbGFuZC5pZH0nIGhhcyBkZWdyZWUgJHtuZWlnaGJvdXJzLnNpemV9ID4gNWAsXG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIEVjY2VudHJpY2l0eSBjaGVjazogbWF4IGRpc3RhbmNlIHRvIGFueSBvdGhlciBpc2xhbmQgPiA0LlxuICAgIC8vIFIxIChyZXdvcmsgcm91bmQsIFNvbCAyMDI2LTEwLTEzKTogYmZzRGlzdGFuY2VzIHJlY29yZHMgb25seVxuICAgIC8vIHJlYWNoYWJsZSB2ZXJ0aWNlczsgYW4gaXNsYW5kIHRoYXQgaGFzIG5vIHBhdGggdG8gYGlzbGFuZC5pZGAgaW5cbiAgICAvLyB0aGUgaXNsYW5kIGdyYXBoIGlzIG5vdCBpbiB0aGUgbWFwLiAgRGV0ZWN0IHRob3NlIHVucmVhY2hhYmxlXG4gICAgLy8gaXNsYW5kcyBhcyByZW1vdGUgdmlvbGF0aW9uczogYW4gaXNsYW5kIHRoYXQgY2Fubm90IGJlIHJlYWNoZWRcbiAgICAvLyB3aXRoaW4gYW55IG51bWJlciBvZiBjcm9zc2luZ3MgaXMgdW5yZWFjaGFibGUgKGVmZmVjdGl2ZWx5XG4gICAgLy8gZWNjZW50cmljaXR5ID0gSW5maW5pdHkpLiAgV2l0aG91dCB0aGlzIGZpeCwgdHdvIGRpc2Nvbm5lY3RlZFxuICAgIC8vIGlzbGFuZHMgc2lsZW50bHkgcGFzcyB0aGUgcmVtb3RlIGNoZWNrLlxuICAgIGNvbnN0IGRpc3RzID0gYmZzRGlzdGFuY2VzKGlzbGFuZEFkaiwgaXNsYW5kLmlkKTtcbiAgICBsZXQgcmVwb3J0ZWRGb3JUaGlzSXNsYW5kID0gZmFsc2U7XG4gICAgZm9yIChjb25zdCBbLCBkaXN0XSBvZiBkaXN0cykge1xuICAgICAgaWYgKGRpc3QgPiA0KSB7XG4gICAgICAgIHZpb2xhdGlvbnMucHVzaChcbiAgICAgICAgICBgcmVtb3RlLW9yLWh1YjogaXNsYW5kICcke2lzbGFuZC5pZH0nIGhhcyBlY2NlbnRyaWNpdHkgJHtkaXN0fSA+IDRgLFxuICAgICAgICApO1xuICAgICAgICByZXBvcnRlZEZvclRoaXNJc2xhbmQgPSB0cnVlO1xuICAgICAgICBicmVhazsgLy8gb25seSByZXBvcnQgb25jZSBwZXIgaXNsYW5kXG4gICAgICB9XG4gICAgfVxuICAgIGlmICghcmVwb3J0ZWRGb3JUaGlzSXNsYW5kKSB7XG4gICAgICAvLyBBbnkgaXNsYW5kIG5vdCBwcmVzZW50IGluIGBkaXN0c2AgaXMgdW5yZWFjaGFibGUgZnJvbSBgaXNsYW5kLmlkYC5cbiAgICAgIGZvciAoY29uc3Qgb3RoZXIgb2YgbWFwLmlzbGFuZHMpIHtcbiAgICAgICAgaWYgKG90aGVyLmlkID09PSBpc2xhbmQuaWQpIGNvbnRpbnVlO1xuICAgICAgICBpZiAoIWRpc3RzLmhhcyhvdGhlci5pZCkpIHtcbiAgICAgICAgICB2aW9sYXRpb25zLnB1c2goXG4gICAgICAgICAgICBgcmVtb3RlLW9yLWh1YjogaXNsYW5kICcke2lzbGFuZC5pZH0nIGNhbm5vdCByZWFjaCBpc2xhbmQgJyR7b3RoZXIuaWR9JyAoZGlzY29ubmVjdGVkKWAsXG4gICAgICAgICAgKTtcbiAgICAgICAgICByZXBvcnRlZEZvclRoaXNJc2xhbmQgPSB0cnVlO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHZpb2xhdGlvbnM7XG59XG5cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gQ2hlY2sgNTogQ3Jvd2RlZCBjcm9zc2luZyBjb3VudHJ5ICAoQy1CUkQtMDEpXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuLyoqXG4gKiBBbnkgcHJvdmluY2Ugd2l0aCBtb3JlIHRoYW4gMiBzZWEgbGFuZXMuXG4gKiBBIHByb3ZpbmNlIHRoYXQgc2VydmVzIHRvbyBtYW55IGNyb3NzaW5ncyBjb25jZW50cmF0ZXMgY29ubmVjdGl2aXR5IGFuZFxuICogbWFrZXMgdGhlIG1hcCBicml0dGxlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gY2hlY2tDcm93ZGVkQ3Jvc3NpbmcobWFwOiBHYW1lTWFwKTogc3RyaW5nW10ge1xuICBjb25zdCB2aW9sYXRpb25zOiBzdHJpbmdbXSA9IFtdO1xuICBmb3IgKGNvbnN0IHAgb2YgbWFwLnByb3ZpbmNlcykge1xuICAgIGlmIChwLnNlYUxhbmVzLmxlbmd0aCA+IDIpIHtcbiAgICAgIHZpb2xhdGlvbnMucHVzaChcbiAgICAgICAgYGNyb3dkZWQtY3Jvc3Npbmc6IHByb3ZpbmNlICcke3AuaWR9JyBoYXMgJHtwLnNlYUxhbmVzLmxlbmd0aH0gc2VhIGxhbmVzID4gMmAsXG4gICAgICApO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdmlvbGF0aW9ucztcbn1cblxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyBDb252ZW5pZW5jZTogcnVuIGFsbCA1IGNoZWNrc1xuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbi8qKiBSdW4gYWxsIDUgZmFpcm5lc3MgY2hlY2tzIGFuZCByZXR1cm4gdGhlIGNvbmNhdGVuYXRlZCBsaXN0IG9mIHZpb2xhdGlvbnMuICovXG5leHBvcnQgZnVuY3Rpb24gcnVuQWxsRmFpcm5lc3NDaGVja3MobWFwOiBHYW1lTWFwKTogc3RyaW5nW10ge1xuICByZXR1cm4gW1xuICAgIC4uLmNoZWNrQm9udXNPdXRPZlByb3BvcnRpb24obWFwKSxcbiAgICAuLi5jaGVja0ZvcnRyZXNzKG1hcCksXG4gICAgLi4uY2hlY2tFYXN5Qm9udXNlc0NvbmNlbnRyYXRlZChtYXApLFxuICAgIC4uLmNoZWNrUmVtb3RlT3JIdWIobWFwKSxcbiAgICAuLi5jaGVja0Nyb3dkZWRDcm9zc2luZyhtYXApLFxuICBdO1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUlBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLFNBQVNBLGdCQUFnQkEsQ0FBQ0MsTUFBYyxFQUFFQyxhQUFvQyxFQUFXO0VBQ3ZGLElBQUlDLEtBQUssR0FBRyxDQUFDO0VBQ2IsS0FBSyxNQUFNQyxHQUFHLElBQUlILE1BQU0sQ0FBQ0ksU0FBUyxFQUFFO0lBQ2xDLE1BQU1DLENBQUMsR0FBR0osYUFBYSxDQUFDSyxHQUFHLENBQUNILEdBQUcsQ0FBQztJQUNoQyxJQUFJRSxDQUFDLElBQUlBLENBQUMsQ0FBQ0UsUUFBUSxDQUFDQyxNQUFNLEdBQUcsQ0FBQyxFQUFFTixLQUFLLEVBQUU7SUFDdkMsSUFBSUEsS0FBSyxHQUFHLENBQUMsRUFBRSxPQUFPLEtBQUs7RUFDN0I7RUFDQSxPQUFPQSxLQUFLLEtBQUssQ0FBQztBQUNwQjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU08sZ0JBQWdCQSxDQUN2QkMsT0FBMEIsRUFDMUJULGFBQW9DLEVBQ1Y7RUFDMUIsTUFBTVUsR0FBRyxHQUFHLElBQUlDLEdBQUcsQ0FBc0JGLE9BQU8sQ0FBQ0csR0FBRyxDQUFFQyxDQUFDLElBQUssQ0FBQ0EsQ0FBQyxDQUFDQyxFQUFFLEVBQUUsSUFBSUMsR0FBRyxDQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFFdkYsS0FBSyxNQUFNaEIsTUFBTSxJQUFJVSxPQUFPLEVBQUU7SUFDNUIsS0FBSyxNQUFNUCxHQUFHLElBQUlILE1BQU0sQ0FBQ0ksU0FBUyxFQUFFO01BQ2xDLE1BQU1DLENBQUMsR0FBR0osYUFBYSxDQUFDSyxHQUFHLENBQUNILEdBQUcsQ0FBQztNQUNoQyxJQUFJLENBQUNFLENBQUMsRUFBRTtNQUNSLEtBQUssTUFBTVksRUFBRSxJQUFJWixDQUFDLENBQUNFLFFBQVEsRUFBRTtRQUMzQixNQUFNVyxLQUFLLEdBQUdqQixhQUFhLENBQUNLLEdBQUcsQ0FBQ1csRUFBRSxDQUFDO1FBQ25DLElBQUksQ0FBQ0MsS0FBSyxJQUFJQSxLQUFLLENBQUNsQixNQUFNLEtBQUtBLE1BQU0sQ0FBQ2UsRUFBRSxFQUFFO1FBQzFDSixHQUFHLENBQUNMLEdBQUcsQ0FBQ04sTUFBTSxDQUFDZSxFQUFFLENBQUMsQ0FBRUksR0FBRyxDQUFDRCxLQUFLLENBQUNsQixNQUFNLENBQUM7UUFDckNXLEdBQUcsQ0FBQ0wsR0FBRyxDQUFDWSxLQUFLLENBQUNsQixNQUFNLENBQUMsQ0FBRW1CLEdBQUcsQ0FBQ25CLE1BQU0sQ0FBQ2UsRUFBRSxDQUFDO01BQ3ZDO0lBQ0Y7RUFDRjtFQUNBLE9BQU9KLEdBQUc7QUFDWjs7QUFFQTtBQUNBLFNBQVNTLFlBQVlBLENBQUNULEdBQTZCLEVBQUVVLE9BQWUsRUFBdUI7RUFDekYsTUFBTUMsSUFBSSxHQUFHLElBQUlWLEdBQUcsQ0FBaUIsQ0FBQztFQUN0QyxNQUFNVyxPQUFPLEdBQUcsSUFBSVAsR0FBRyxDQUFTLENBQUM7RUFDakMsTUFBTVEsS0FBZSxHQUFHLENBQUNILE9BQU8sQ0FBQztFQUNqQ0MsSUFBSSxDQUFDRyxHQUFHLENBQUNKLE9BQU8sRUFBRSxDQUFDLENBQUM7RUFDcEJFLE9BQU8sQ0FBQ0osR0FBRyxDQUFDRSxPQUFPLENBQUM7RUFFcEIsT0FBT0csS0FBSyxDQUFDaEIsTUFBTSxHQUFHLENBQUMsRUFBRTtJQUN2QixNQUFNa0IsT0FBTyxHQUFHRixLQUFLLENBQUNHLEtBQUssQ0FBQyxDQUFFO0lBQzlCLE1BQU1DLENBQUMsR0FBR04sSUFBSSxDQUFDaEIsR0FBRyxDQUFDb0IsT0FBTyxDQUFFO0lBQzVCLEtBQUssTUFBTUcsU0FBUyxLQUFBQyxRQUFBLEdBQUluQixHQUFHLENBQUNMLEdBQUcsQ0FBQ29CLE9BQU8sQ0FBQyxjQUFBSSxRQUFBLGNBQUFBLFFBQUEsR0FBSSxFQUFFLEVBQUU7TUFBQSxJQUFBQSxRQUFBO01BQzlDLElBQUksQ0FBQ1AsT0FBTyxDQUFDUSxHQUFHLENBQUNGLFNBQVMsQ0FBQyxFQUFFO1FBQzNCTixPQUFPLENBQUNKLEdBQUcsQ0FBQ1UsU0FBUyxDQUFDO1FBQ3RCUCxJQUFJLENBQUNHLEdBQUcsQ0FBQ0ksU0FBUyxFQUFFRCxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzFCSixLQUFLLENBQUNRLElBQUksQ0FBQ0gsU0FBUyxDQUFDO01BQ3ZCO0lBQ0Y7RUFDRjtFQUNBLE9BQU9QLElBQUk7QUFDYjs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPLFNBQVNXLHlCQUF5QkEsQ0FBQ3BCLEdBQVksRUFBWTtFQUNoRSxNQUFNcUIsVUFBb0IsR0FBRyxFQUFFO0VBQy9CLEtBQUssTUFBTWxDLE1BQU0sSUFBSWEsR0FBRyxDQUFDSCxPQUFPLEVBQUU7SUFDaEMsSUFBSVYsTUFBTSxDQUFDbUMsS0FBSyxHQUFHbkMsTUFBTSxDQUFDSSxTQUFTLENBQUNJLE1BQU0sRUFBRTtNQUMxQzBCLFVBQVUsQ0FBQ0YsSUFBSSxDQUNiLG9DQUFvQ2hDLE1BQU0sQ0FBQ2UsRUFBRSxlQUFlZixNQUFNLENBQUNtQyxLQUFLLFdBQVduQyxNQUFNLENBQUNJLFNBQVMsQ0FBQ0ksTUFBTSxFQUM1RyxDQUFDO0lBQ0g7RUFDRjtFQUNBLE9BQU8wQixVQUFVO0FBQ25COztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU8sU0FBU0UsYUFBYUEsQ0FBQ3ZCLEdBQVksRUFBWTtFQUNwRCxNQUFNcUIsVUFBb0IsR0FBRyxFQUFFO0VBQy9CLE1BQU1qQyxhQUFhLEdBQUcsSUFBSVcsR0FBRyxDQUFtQkMsR0FBRyxDQUFDVCxTQUFTLENBQUNTLEdBQUcsQ0FBRVIsQ0FBQyxJQUFLLENBQUNBLENBQUMsQ0FBQ1UsRUFBRSxFQUFFVixDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ3BGLE1BQU1nQyxxQkFBK0IsR0FBRyxFQUFFO0VBRTFDLEtBQUssTUFBTXJDLE1BQU0sSUFBSWEsR0FBRyxDQUFDSCxPQUFPLEVBQUU7SUFDaEMsSUFBSVgsZ0JBQWdCLENBQUNDLE1BQU0sRUFBRUMsYUFBYSxDQUFDLEVBQUU7TUFDM0NvQyxxQkFBcUIsQ0FBQ0wsSUFBSSxDQUFDaEMsTUFBTSxDQUFDZSxFQUFFLENBQUM7TUFDckMsSUFBSWYsTUFBTSxDQUFDSSxTQUFTLENBQUNJLE1BQU0sSUFBSSxDQUFDLEVBQUU7UUFDaEMwQixVQUFVLENBQUNGLElBQUksQ0FDYixxQkFBcUJoQyxNQUFNLENBQUNlLEVBQUUsV0FBV2YsTUFBTSxDQUFDSSxTQUFTLENBQUNJLE1BQU0seUJBQ2xFLENBQUM7TUFDSDtJQUNGO0VBQ0Y7RUFFQSxJQUFJNkIscUJBQXFCLENBQUM3QixNQUFNLEdBQUcsQ0FBQyxFQUFFO0lBQ3BDMEIsVUFBVSxDQUFDRixJQUFJLENBQ2IsYUFBYUsscUJBQXFCLENBQUM3QixNQUFNLDRDQUE0QzZCLHFCQUFxQixDQUFDQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQ3ZILENBQUM7RUFDSDtFQUVBLE9BQU9KLFVBQVU7QUFDbkI7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTyxTQUFTSyw0QkFBNEJBLENBQUMxQixHQUFZLEVBQVk7RUFDbkUsTUFBTXFCLFVBQW9CLEdBQUcsRUFBRTtFQUMvQixNQUFNakMsYUFBYSxHQUFHLElBQUlXLEdBQUcsQ0FBbUJDLEdBQUcsQ0FBQ1QsU0FBUyxDQUFDUyxHQUFHLENBQUVSLENBQUMsSUFBSyxDQUFDQSxDQUFDLENBQUNVLEVBQUUsRUFBRVYsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUVwRixJQUFJbUMsVUFBVSxHQUFHLENBQUM7RUFDbEIsSUFBSUMsbUJBQW1CLEdBQUcsQ0FBQztFQUUzQixLQUFLLE1BQU16QyxNQUFNLElBQUlhLEdBQUcsQ0FBQ0gsT0FBTyxFQUFFO0lBQ2hDOEIsVUFBVSxJQUFJeEMsTUFBTSxDQUFDbUMsS0FBSztJQUMxQixJQUFJcEMsZ0JBQWdCLENBQUNDLE1BQU0sRUFBRUMsYUFBYSxDQUFDLEVBQUU7TUFDM0N3QyxtQkFBbUIsSUFBSXpDLE1BQU0sQ0FBQ21DLEtBQUs7SUFDckM7RUFDRjs7RUFFQTtFQUNBLElBQUlLLFVBQVUsR0FBRyxDQUFDLElBQUlDLG1CQUFtQixHQUFHRCxVQUFVLEdBQUcsQ0FBQyxFQUFFO0lBQzFETixVQUFVLENBQUNGLElBQUksQ0FDYixpRUFBaUVTLG1CQUFtQix5QkFBeUJELFVBQVUsRUFDekgsQ0FBQztFQUNIO0VBRUEsT0FBT04sVUFBVTtBQUNuQjs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTyxTQUFTUSxnQkFBZ0JBLENBQUM3QixHQUFZLEVBQVk7RUFDdkQsTUFBTXFCLFVBQW9CLEdBQUcsRUFBRTtFQUMvQixNQUFNakMsYUFBYSxHQUFHLElBQUlXLEdBQUcsQ0FBbUJDLEdBQUcsQ0FBQ1QsU0FBUyxDQUFDUyxHQUFHLENBQUVSLENBQUMsSUFBSyxDQUFDQSxDQUFDLENBQUNVLEVBQUUsRUFBRVYsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNwRixNQUFNc0MsU0FBUyxHQUFHbEMsZ0JBQWdCLENBQUNJLEdBQUcsQ0FBQ0gsT0FBTyxFQUFFVCxhQUFhLENBQUM7RUFFOUQsS0FBSyxNQUFNRCxNQUFNLElBQUlhLEdBQUcsQ0FBQ0gsT0FBTyxFQUFFO0lBQUEsSUFBQWtDLGNBQUE7SUFDaEMsTUFBTUMsVUFBVSxJQUFBRCxjQUFBLEdBQUdELFNBQVMsQ0FBQ3JDLEdBQUcsQ0FBQ04sTUFBTSxDQUFDZSxFQUFFLENBQUMsY0FBQTZCLGNBQUEsY0FBQUEsY0FBQSxHQUFJLElBQUk1QixHQUFHLENBQVMsQ0FBQzs7SUFFaEU7SUFDQSxJQUFJNkIsVUFBVSxDQUFDQyxJQUFJLEdBQUcsQ0FBQyxFQUFFO01BQ3ZCWixVQUFVLENBQUNGLElBQUksQ0FDYiwwQkFBMEJoQyxNQUFNLENBQUNlLEVBQUUsZ0JBQWdCOEIsVUFBVSxDQUFDQyxJQUFJLE1BQ3BFLENBQUM7SUFDSDs7SUFFQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsTUFBTUMsS0FBSyxHQUFHM0IsWUFBWSxDQUFDdUIsU0FBUyxFQUFFM0MsTUFBTSxDQUFDZSxFQUFFLENBQUM7SUFDaEQsSUFBSWlDLHFCQUFxQixHQUFHLEtBQUs7SUFDakMsS0FBSyxNQUFNLEdBQUcxQixJQUFJLENBQUMsSUFBSXlCLEtBQUssRUFBRTtNQUM1QixJQUFJekIsSUFBSSxHQUFHLENBQUMsRUFBRTtRQUNaWSxVQUFVLENBQUNGLElBQUksQ0FDYiwwQkFBMEJoQyxNQUFNLENBQUNlLEVBQUUsc0JBQXNCTyxJQUFJLE1BQy9ELENBQUM7UUFDRDBCLHFCQUFxQixHQUFHLElBQUk7UUFDNUIsTUFBTSxDQUFDO01BQ1Q7SUFDRjtJQUNBLElBQUksQ0FBQ0EscUJBQXFCLEVBQUU7TUFDMUI7TUFDQSxLQUFLLE1BQU05QixLQUFLLElBQUlMLEdBQUcsQ0FBQ0gsT0FBTyxFQUFFO1FBQy9CLElBQUlRLEtBQUssQ0FBQ0gsRUFBRSxLQUFLZixNQUFNLENBQUNlLEVBQUUsRUFBRTtRQUM1QixJQUFJLENBQUNnQyxLQUFLLENBQUNoQixHQUFHLENBQUNiLEtBQUssQ0FBQ0gsRUFBRSxDQUFDLEVBQUU7VUFDeEJtQixVQUFVLENBQUNGLElBQUksQ0FDYiwwQkFBMEJoQyxNQUFNLENBQUNlLEVBQUUsMEJBQTBCRyxLQUFLLENBQUNILEVBQUUsa0JBQ3ZFLENBQUM7VUFDRGlDLHFCQUFxQixHQUFHLElBQUk7VUFDNUI7UUFDRjtNQUNGO0lBQ0Y7RUFDRjtFQUVBLE9BQU9kLFVBQVU7QUFDbkI7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPLFNBQVNlLG9CQUFvQkEsQ0FBQ3BDLEdBQVksRUFBWTtFQUMzRCxNQUFNcUIsVUFBb0IsR0FBRyxFQUFFO0VBQy9CLEtBQUssTUFBTTdCLENBQUMsSUFBSVEsR0FBRyxDQUFDVCxTQUFTLEVBQUU7SUFDN0IsSUFBSUMsQ0FBQyxDQUFDRSxRQUFRLENBQUNDLE1BQU0sR0FBRyxDQUFDLEVBQUU7TUFDekIwQixVQUFVLENBQUNGLElBQUksQ0FDYiwrQkFBK0IzQixDQUFDLENBQUNVLEVBQUUsU0FBU1YsQ0FBQyxDQUFDRSxRQUFRLENBQUNDLE1BQU0sZ0JBQy9ELENBQUM7SUFDSDtFQUNGO0VBQ0EsT0FBTzBCLFVBQVU7QUFDbkI7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0EsT0FBTyxTQUFTZ0Isb0JBQW9CQSxDQUFDckMsR0FBWSxFQUFZO0VBQzNELE9BQU8sQ0FDTCxHQUFHb0IseUJBQXlCLENBQUNwQixHQUFHLENBQUMsRUFDakMsR0FBR3VCLGFBQWEsQ0FBQ3ZCLEdBQUcsQ0FBQyxFQUNyQixHQUFHMEIsNEJBQTRCLENBQUMxQixHQUFHLENBQUMsRUFDcEMsR0FBRzZCLGdCQUFnQixDQUFDN0IsR0FBRyxDQUFDLEVBQ3hCLEdBQUdvQyxvQkFBb0IsQ0FBQ3BDLEdBQUcsQ0FBQyxDQUM3QjtBQUNIIiwiaWdub3JlTGlzdCI6W119