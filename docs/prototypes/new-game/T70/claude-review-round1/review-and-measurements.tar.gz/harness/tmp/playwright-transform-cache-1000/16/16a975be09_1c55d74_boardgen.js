// a49574b8465bf34a1aa5dfc4ce4c1fd79a47f590
import { DeterministicRng } from "./rng";
import { runAllFairnessChecks } from "./board-fairness";

// ---------------------------------------------------------------------------
// Structural constants — each cites the claim it traces to (rule 17).
// ---------------------------------------------------------------------------

/** C-BRD-03: nine islands of these sizes; the design's sorted partition. */
export const ISLAND_SIZES = [3, 3, 3, 3, 5, 5, 7, 7, 10];

/** C-BRD-04: exactly this many undirected inter-island sea lanes. */
export const SEA_LANE_COUNT = 16;

// ---------------------------------------------------------------------------
// Degree constraints (C-BRD-04)
// ---------------------------------------------------------------------------

/** C-BRD-04: minimum total degree (borders + sea lanes) per province. */
export const DEGREE_MIN = 2;
/** C-BRD-04: maximum total degree (borders + sea lanes) per province. */
export const DEGREE_MAX = 5;
/**
 * C-BRD-04: borders consume at most DEGREE_MAX - 2 degree slots, leaving
 * two slots per province for sea lanes.  The original T05a value was
 * DEGREE_MAX - 1; that left each province only one sea-lane slot, which
 * Phase 2 cannot use to reach SEA_LANE_COUNT=16 once the four structural
 * constraints (MAX_LANES_PER_COUNTRY=2, MAX_ENTRANCES_BY_SIZE, MIN_ENTRANCES=2,
 * MAX_ISLAND_GRAPH_DEGREE=5) are in place.  With two slots per province
 * Phase 2 has headroom to fill to 16 lanes on the tested seeds.  Every
 * province still has degree ≥ 2 from borders alone (within-island
 * connectivity), so connectivity within each island is always maintained.
 */
export const BORDER_MAX = DEGREE_MAX - 2;

/**
 * C-BON-02: island bonus = max(2, floor(size/2) + cross-island-entrances).
 * The divisor 2 is the design constant from decision 12.
 */
export const BONUS_DIVISOR = 2;

/**
 * C-BRD-01: the generator must find a valid board within this many attempts
 * on a 200-seed sweep (≥ 99 % success rate).  The cap is a named export so
 * a rule-9 mutation can set it to 0 and prove the loop is live.  The test
 * suite pins the value to [1, 200].
 *
 * The task's selection rule: the smallest number that, on a 200-seed
 * sweep, gives a success rate ≥ 99 %.  Sweep of seeds 1..200 through
 * `generateBoardInternal(seed, { attempts: cap })` after round 4's
 * generator change (Phase 2 picks only addable province pairs):
 *
 *   cap=0  →    0/200  rate=0.000
 *   cap=1  →  200/200  rate=1.000  (smallest cap ≥ 99 %)
 *   cap=2..5, 10 → 200/200
 *
 * Wider look, not the selection rule: seeds 1..5000 give 4996/5000
 * (99.92 %) at cap=1, the four failures all fairness (eccentricity 5 on
 * seeds 1506, 1597, 2779, 4557), none structural; 5000/5000 at cap=2, 3.
 *
 * `tests/core/board-gen.test.ts` re-runs this sweep at the pinned cap and
 * at one below it, so a different value fails the suite.
 */
export const MAX_BOARD_ATTEMPTS = 1;

/**
 * C-BRD-01: a province carries at most 2 sea lanes.  Phase 2 skips any
 * candidate pair where either endpoint already has 2 lanes.  This is the
 * structural precondition for checkCrowdedCrossing.
 */
export const MAX_LANES_PER_COUNTRY = 2;

/**
 * C-BRD-01, C-BON-02: per-island cap on the number of distinct provinces
 * that have at least one sea lane to another island.  Derived from
 * C-BON-02 so that `bonus = max(2, floor(size/2) + entrances) ≤ size`
 * always holds:
 *   size 3 → max(2, 1+2)=3 ≤ 3  → cap 2
 *   size 5 → max(2, 2+3)=5 ≤ 5  → cap 3
 *   size 7 → max(2, 3+4)=7 ≤ 7  → cap 4
 *   size 10 → max(2, 5+5)=10 ≤ 10 → cap 5
 * Phase 2 skips any candidate where the destination island would exceed its cap.
 */
export const MAX_ENTRANCES_BY_SIZE = {
  3: 2,
  5: 3,
  7: 4,
  10: 5
};

/**
 * C-BRD-01: every island must have at least 2 countries with a sea lane
 * (anti-fortress).  Phase 1's spanning tree guarantees at least one lane
 * on each island; Phase 2 keeps adding lanes until every island reaches 2.
 * This is the structural precondition for checkFortress.
 */
export const MIN_ENTRANCES_PER_ISLAND = 2;

/**
 * C-BRD-01: in the island graph, no island may have degree > 5.
 * Phase 1's spanning tree must keep each island's degree ≤ 5
 * (8 edges on 9 islands, max degree 5); Phase 2 must skip any
 * candidate pair where the resulting degree of either endpoint
 * would exceed the cap.  This is the structural precondition for
 * checkRemoteOrHub.  Amendment 2026-10-13: raised from 4 to 5 after
 * the M3 round reached 76 % at cap = 4 (random greedy + 1-level
 * backtracking cannot reliably saturate the island graph at cap = 4);
 * eccentricity threshold (4) did not move in lockstep.
 */
export const MAX_ISLAND_GRAPH_DEGREE = 5;

// ---------------------------------------------------------------------------
// Result type
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Island names (ours — not T03's)
// ---------------------------------------------------------------------------

const ISLAND_NAMES = ["North Isle", "East Isle", "West Isle", "South Isle", "Central Isle", "Harbor Isle", "Palm Isle", "Cliff Isle", "Great Isle"];

// ---------------------------------------------------------------------------
// Province name fragments (ours; reused deterministically)
// ---------------------------------------------------------------------------

const NAME_PREFIXES = ["North", "South", "East", "West", "Upper", "Lower", "Old", "New", "Port", "Fort", "Gold", "Silver", "Iron", "Stone", "Wind", "Sun", "Moon", "Star", "River", "Lake", "Bay", "Cape", "Rock", "Marsh", "High", "Low", "Dark", "Light", "Red", "Blue"];
const NAME_SUFFIXES = ["port", "town", "hill", "vale", "ford", "point", "bay", "rock", "shore", "haven", "gate", "keep", "march", "dale", "fell", "wood", "field", "glen", "moor", "peak", "ridge", "reach", "watch", "rest"];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

/** Fisher-Yates shuffle using the supplied RNG. */
function shuffled(rng, items) {
  const out = [...items];
  for (let i = out.length - 1; i > 0; i--) {
    const j = rng.nextInt(0, i);
    const tmp = out[i];
    out[i] = out[j];
    out[j] = tmp;
  }
  return out;
}

/**
 * Simple placeholder polygon: a small regular polygon of `sides` points
 * centred on (cx, cy) with radius `r`. Display only (C-BRD-06).
 */
function placeholderPolygon(cx, cy, r, sides) {
  const pts = [];
  for (let i = 0; i < sides; i++) {
    const angle = 2 * Math.PI * i / sides - Math.PI / 2;
    pts.push([cx + r * Math.cos(angle), cy + r * Math.sin(angle)]);
  }
  return pts;
}

/** Spread n items across [minX, maxX] × [minY, maxY] using deterministic jitter. */
function spreadPoints(rng, n, minX, maxX, minY, maxY) {
  const pts = [];
  const cols = Math.ceil(Math.sqrt(n * 1.5));
  const cellW = (maxX - minX) / cols;
  const cellH = (maxY - minY) / Math.ceil(n / cols);
  for (let i = 0; i < n; i++) {
    const col = i % cols;
    const row = Math.floor(i / cols);
    const x = minX + col * cellW + rng.nextInt(0, cellW * 0.5);
    const y = minY + row * cellH + rng.nextInt(0, cellH * 0.5);
    pts.push([x, y]);
  }
  return pts;
}

// ---------------------------------------------------------------------------
// Border-graph builder (within one island)
// ---------------------------------------------------------------------------

/**
 * Build a connected graph on `provinceIds` where every vertex ends up with
 * degree in `[2, maxDegree]`. Returns a symmetric adjacency map.
 *
 * Order matters (fix for the seed 7 / 21 / 33 / 42 saturation bug, 2026-10-12):
 * 1. Spanning tree. Every node has degree 1+.
 * 2. Raise every degree-1 node to degree 2 using only partners with
 *    headroom (`degree < maxDegree`). Doing this *before* the cap-packing
 *    means the cap is never violated by the straggler fix (the previous
 *    rework pushed some partners past the cap, leaving later sea-lane
 *    phases no headroom).
 * 3. Pack extra random edges up to the cap. Every node is at degree ≥ 2,
 *    so headroom always exists for random pairs.
 */
function buildBorders(rng, provinceIds, maxDegree) {
  const n = provinceIds.length;
  const adj = new Map(provinceIds.map(id => [id, new Set()]));
  if (n === 1) return adj; // single-province island: no borders
  if (n === 2) {
    adj.get(provinceIds[0]).add(provinceIds[1]);
    adj.get(provinceIds[1]).add(provinceIds[0]);
    return adj; // one edge: both at degree 1; island-2 is not in ISLAND_SIZES but guard the case.
  }

  // Step 1: random spanning tree (guarantees connectivity, every node ≥ 1).
  // Pick each child's parent only from earlier nodes whose degree is still
  // below `maxDegree`, so the tree itself can never produce a hub past the
  // cap. (Without this filter, a random tree on a size-10 island can give
  // one node degree 5+, which is what the seed-12 / seed-45 bug exploited:
  // the tree step overshot, Step 2 (straggler fix) only raises nodes
  // already at degree < 2, and Step 3 (pack) respects the cap so the hub
  // stuck above maxDegree forever.)
  const order = shuffled(rng, [...provinceIds]);
  for (let i = 1; i < order.length; i++) {
    const child = order[i];
    // attach to an earlier node with headroom (parent degree < maxDegree)
    const headroomParents = order.slice(0, i).filter(p => adj.get(p).size < maxDegree);
    let parent;
    if (headroomParents.length > 0) {
      parent = headroomParents[rng.nextInt(0, headroomParents.length - 1)];
    } else {
      // Defensive fallback: only reachable when maxDegree < 3, which never
      // happens in this generator (BORDER_MAX ≥ 3 here).
      parent = order[rng.nextInt(0, i - 1)];
    }
    adj.get(parent).add(child);
    adj.get(child).add(parent);
  }
  const ids = [...provinceIds];

  // Step 2: raise degree-1 nodes to degree ≥ 2 using partners with headroom.
  // The tree leaves at most n-1 leaves; each has degree 1, all other nodes
  // have degree in [1, maxDegree] (some potentially at the cap), so the
  // partner pool is almost always non-empty. We loop and break only when
  // every node is at degree ≥ 2 or the partner pool is exhausted.
  let stragglerPasses = 0;
  const MAX_STRAGGLER_PASSES = 50;
  let remainingStragglers = ids.filter(id => adj.get(id).size < 2);
  while (remainingStragglers.length > 0 && stragglerPasses < MAX_STRAGGLER_PASSES) {
    stragglerPasses++;
    let progress = false;
    for (const id of remainingStragglers) {
      if (adj.get(id).size >= 2) continue;
      const partners = ids.filter(p => p !== id && !adj.get(id).has(p) && adj.get(p).size < maxDegree);
      if (partners.length === 0) continue;
      const partner = partners[rng.nextInt(0, partners.length - 1)];
      adj.get(id).add(partner);
      adj.get(partner).add(id);
      progress = true;
    }
    if (!progress) break;
    remainingStragglers = ids.filter(id => adj.get(id).size < 2);
  }

  // Step 3: pack extra random edges up to the cap. Every node is at degree
  // ≥ 2 with at least one unsaturated partner (or fully saturated, in which
  // case the random pick naturally skips).
  const MAX_PACK_ATTEMPTS = n * 200;
  for (let attempt = 0; attempt < MAX_PACK_ATTEMPTS; attempt++) {
    const a = ids[rng.nextInt(0, n - 1)];
    const b = ids[rng.nextInt(0, n - 1)];
    if (a === b) continue;
    if (adj.get(a).size >= maxDegree) continue;
    if (adj.get(b).size >= maxDegree) continue;
    if (adj.get(a).has(b)) continue;
    adj.get(a).add(b);
    adj.get(b).add(a);
  }
  return adj;
}

// ---------------------------------------------------------------------------
// Main generator
// ---------------------------------------------------------------------------

/**
 * Internal, test-only observation of one `generateBoardBody` run.  Not
 * re-exported from `src/core/index.ts`.  The body only writes to it.
 */

/**
 * The structural invariants every board the generator accepts must meet, read
 * from the finished map: province degree in [DEGREE_MIN, DEGREE_MAX] and
 * exactly SEA_LANE_COUNT lanes (C-BRD-04), a connected graph (C-BRD-04),
 * and at least MIN_ENTRANCES_PER_ISLAND entrances per island (C-BRD-01).
 * Returns the violations; an empty list means the map is accepted.
 *
 * Internal: exported from this module for tests (R3, round 3), never
 * re-exported from `src/core/index.ts`.  The retry loop
 * (`generateBoardInternal`) runs it on every map a body returns, before the
 * fairness checks (round 4, R1).
 */
export function structuralErrors(map) {
  const errors = [];
  const {
    provinces
  } = map;

  // Degree check (C-BRD-04)
  for (const p of provinces) {
    const deg = p.borders.length + p.seaLanes.length;
    if (deg < DEGREE_MIN || deg > DEGREE_MAX) {
      errors.push(`province '${p.id}' has degree ${deg}, outside [${DEGREE_MIN}, ${DEGREE_MAX}]`);
    }
  }

  // Sea lane count check (C-BRD-04)
  const undirectedSeaLanes = new Set();
  for (const p of provinces) {
    for (const t of p.seaLanes) {
      const key = p.id < t ? `${p.id}|${t}` : `${t}|${p.id}`;
      undirectedSeaLanes.add(key);
    }
  }
  if (undirectedSeaLanes.size !== SEA_LANE_COUNT) errors.push(`has ${undirectedSeaLanes.size} undirected sea lanes, expected ${SEA_LANE_COUNT}`);

  // Connectivity check (C-BRD-04)
  const byId = new Map(provinces.map(p => [p.id, p]));
  if (provinces.length > 0) {
    const seen = new Set([provinces[0].id]);
    const queue = [provinces[0].id];
    while (queue.length > 0) {
      const current = queue.shift();
      const prov = byId.get(current);
      if (!prov) continue;
      for (const n of [...prov.borders, ...prov.seaLanes]) {
        if (!seen.has(n)) {
          seen.add(n);
          queue.push(n);
        }
      }
    }
    if (seen.size !== provinces.length) errors.push(`graph has ${seen.size} reachable provinces, expected ${provinces.length}`);
  }

  // Entrance minimum (C-BRD-01, anti-fortress).  An entrance is a province
  // with a sea lane to another island.  Phase 2's scoring aims for this
  // minimum; this guard refuses any map that still misses it, so the retry
  // loop never relies on checkFortress alone.
  const below = [];
  for (const island of map.islands) {
    let entrances = 0;
    for (const pid of island.provinces) {
      const p = byId.get(pid);
      if (p && p.seaLanes.some(t => {
        var _byId$get;
        return ((_byId$get = byId.get(t)) === null || _byId$get === void 0 ? void 0 : _byId$get.island) !== island.id;
      })) entrances++;
    }
    if (entrances < MIN_ENTRANCES_PER_ISLAND) below.push(`${island.id}=${entrances}`);
  }
  if (below.length > 0) {
    errors.push(`island entrance minimum not met: ${below.join(", ")} (need >= ${MIN_ENTRANCES_PER_ISLAND})`);
  }
  return errors;
}

/**
 * Inner generator body.  Takes a live `DeterministicRng` (already seeded by
 * the caller) and produces either a built `GameMap` or the list of errors
 * that stopped it (island sizes, lanes it could not place).  Neither the
 * structural acceptance step nor the fairness checks run here; both run on
 * its map in the retry loop below.
 *
 * Internal: exported from this module for tests, never re-exported from
 * `src/core/index.ts`.  The optional `trace` is filled with observations
 * of this run (see `BodyTrace`); it never changes what the body does.
 */
export function generateBoardBody(rng, trace) {
  const errors = [];

  // ---- Assign province IDs to islands ------------------------------------
  const shuffledProvinceIds = shuffled(rng, Array.from({
    length: 46
  }, (_, i) => `province_${i}`));
  const islandStructs = [];
  let cursor = 0;
  for (let i = 0; i < ISLAND_SIZES.length; i++) {
    var _ISLAND_NAMES$i;
    const size = ISLAND_SIZES[i];
    islandStructs.push({
      id: `island_${i}`,
      name: (_ISLAND_NAMES$i = ISLAND_NAMES[i]) !== null && _ISLAND_NAMES$i !== void 0 ? _ISLAND_NAMES$i : `Isle ${i}`,
      size,
      provinceIds: shuffledProvinceIds.slice(cursor, cursor + size)
    });
    cursor += size;
  }
  if (cursor !== 46) errors.push(`island sizes sum to ${cursor}, expected 46`);

  // ---- Build within-island borders --------------------------------------
  // Capping at BORDER_MAX (= DEGREE_MAX - 2) reserves two degree slots per
  // province for sea lanes; otherwise buildBorders packs some provinces to
  // DEGREE_MAX and leaves Phase 1 unable to find a spanning-tree endpoint
  // (saturation; see BORDER_MAX above).
  const allBorders = new Map();
  for (const island of islandStructs) {
    const adj = buildBorders(rng, island.provinceIds, BORDER_MAX);
    for (const [id, neighbours] of adj) {
      if (!allBorders.has(id)) allBorders.set(id, new Set());
      for (const n of neighbours) allBorders.get(id).add(n);
    }
  }

  // ---- Add inter-island sea lanes ----------------------------------------
  // C-BRD-01: sea lanes are always between different islands.
  // Phase 1: build a guaranteed spanning tree so the graph is always connected.
  // Phase 2: fill remaining slots randomly up to SEA_LANE_COUNT.
  const allSeaLanes = new Map();
  for (const id of shuffledProvinceIds) {
    allSeaLanes.set(id, new Set());
  }

  // Track island-graph degree as DISTINCT island neighbours per island.
  // R11 (rework round, Sol 2026-10-13): the previous round tracked the
  // total lane count, not distinct neighbours.  A size-10 island with
  // 5 lanes all going to the same 3 other islands had
  // `islandDegree = 5` even though the island-graph degree was only 3.
  // Fix: track distinct neighbours as a Set, derive the count via
  // `islandDegreeOf(id)` when comparing to MAX_ISLAND_GRAPH_DEGREE.
  const islandNeighbours = new Map(islandStructs.map(isl => [isl.id, new Set()]));
  function islandDegreeOf(islandId) {
    var _islandNeighbours$get, _islandNeighbours$get2;
    return (_islandNeighbours$get = (_islandNeighbours$get2 = islandNeighbours.get(islandId)) === null || _islandNeighbours$get2 === void 0 ? void 0 : _islandNeighbours$get2.size) !== null && _islandNeighbours$get !== void 0 ? _islandNeighbours$get : 0;
  }
  function addNeighbour(islandA, islandB) {
    var _islandNeighbours$get3, _islandNeighbours$get4;
    (_islandNeighbours$get3 = islandNeighbours.get(islandA)) === null || _islandNeighbours$get3 === void 0 || _islandNeighbours$get3.add(islandB);
    (_islandNeighbours$get4 = islandNeighbours.get(islandB)) === null || _islandNeighbours$get4 === void 0 || _islandNeighbours$get4.add(islandA);
  }
  function removeNeighbour(islandA, islandB) {
    var _islandNeighbours$get5, _islandNeighbours$get6;
    (_islandNeighbours$get5 = islandNeighbours.get(islandA)) === null || _islandNeighbours$get5 === void 0 || _islandNeighbours$get5.delete(islandB);
    (_islandNeighbours$get6 = islandNeighbours.get(islandB)) === null || _islandNeighbours$get6 === void 0 || _islandNeighbours$get6.delete(islandA);
  }

  // Track distinct provinces per island that have at least one sea lane to another island.
  // Used to enforce MAX_ENTRANCES_BY_SIZE and MIN_ENTRANCES_PER_ISLAND.
  const islandEntranceCount = new Map(islandStructs.map(isl => [isl.id, 0]));

  /** Record that province `prov` now has a sea lane to another island. */
  function recordEntrance(prov) {
    const isl = islandStructs.find(s => [...s.provinceIds].includes(prov));
    if (!isl) return;
    const existing = allSeaLanes.get(prov).size;
    if (existing === 1) {
      var _islandEntranceCount$;
      // First sea lane for this province → this island gains an entrance
      islandEntranceCount.set(isl.id, ((_islandEntranceCount$ = islandEntranceCount.get(isl.id)) !== null && _islandEntranceCount$ !== void 0 ? _islandEntranceCount$ : 0) + 1);
    }
  }
  function entranceCapOf(islandId) {
    var _MAX_ENTRANCES_BY_SIZ, _islandStructs$find$s, _islandStructs$find;
    return (_MAX_ENTRANCES_BY_SIZ = MAX_ENTRANCES_BY_SIZE[(_islandStructs$find$s = (_islandStructs$find = islandStructs.find(s => s.id === islandId)) === null || _islandStructs$find === void 0 ? void 0 : _islandStructs$find.size) !== null && _islandStructs$find$s !== void 0 ? _islandStructs$find$s : 0]) !== null && _MAX_ENTRANCES_BY_SIZ !== void 0 ? _MAX_ENTRANCES_BY_SIZ : 99;
  }
  function atEntranceCap(islandId) {
    var _islandEntranceCount$2;
    return ((_islandEntranceCount$2 = islandEntranceCount.get(islandId)) !== null && _islandEntranceCount$2 !== void 0 ? _islandEntranceCount$2 : 0) >= entranceCapOf(islandId);
  }

  /** True when a lane on `prov` would give `islandId` an entrance past its cap. */
  function wouldExceedEntranceCap(prov, islandId) {
    var _allSeaLanes$get$size, _allSeaLanes$get;
    return ((_allSeaLanes$get$size = (_allSeaLanes$get = allSeaLanes.get(prov)) === null || _allSeaLanes$get === void 0 ? void 0 : _allSeaLanes$get.size) !== null && _allSeaLanes$get$size !== void 0 ? _allSeaLanes$get$size : 0) === 0 && atEntranceCap(islandId);
  }

  /**
   * The provinces of `isl` that can take one more lane: below the lane cap,
   * and not a new entrance on an island already at its entrance cap.
   */
  function laneCandidates(isl) {
    return isl.provinceIds.filter(p => {
      var _allSeaLanes$get$size2, _allSeaLanes$get2;
      return ((_allSeaLanes$get$size2 = (_allSeaLanes$get2 = allSeaLanes.get(p)) === null || _allSeaLanes$get2 === void 0 ? void 0 : _allSeaLanes$get2.size) !== null && _allSeaLanes$get$size2 !== void 0 ? _allSeaLanes$get$size2 : 0) < MAX_LANES_PER_COUNTRY && !wouldExceedEntranceCap(p, isl.id);
    });
  }

  /**
   * Add a sea lane between two provinces if all four structural constraints permit.
   * Returns true on success.
   *
   * Constraints enforced here (C-BRD-01):
   * 1. MAX_LANES_PER_COUNTRY: neither endpoint province may already have ≥ 2 lanes.
   * 2. MAX_ENTRANCES_BY_SIZE: neither island may exceed its entrance cap.
   * 3. MAX_ISLAND_GRAPH_DEGREE: neither island may exceed degree 5 in the island graph.
   * 4. DEGREE_MAX: total degree (borders + lanes) of each endpoint stays ≤ DEGREE_MAX.
   */
  function tryAddLane(provA, provB, islandA, islandB) {
    if (!canAddLane(provA, provB, islandA, islandB)) return false;
    allSeaLanes.get(provA).add(provB);
    allSeaLanes.get(provB).add(provA);
    addNeighbour(islandA, islandB);
    recordEntrance(provA);
    recordEntrance(provB);
    return true;
  }

  /** The four constraints of `tryAddLane`, without committing the lane. */
  function canAddLane(provA, provB, islandA, islandB) {
    var _allSeaLanes$get$size3, _allSeaLanes$get3, _allSeaLanes$get$size4, _allSeaLanes$get4, _allBorders$get$size, _allBorders$get, _allSeaLanes$get$size5, _allSeaLanes$get5, _allBorders$get$size2, _allBorders$get2, _allSeaLanes$get$size6, _allSeaLanes$get6, _allSeaLanes$get7;
    if (islandA === islandB) return false;
    // Constraint 1: per-province lane cap
    if (((_allSeaLanes$get$size3 = (_allSeaLanes$get3 = allSeaLanes.get(provA)) === null || _allSeaLanes$get3 === void 0 ? void 0 : _allSeaLanes$get3.size) !== null && _allSeaLanes$get$size3 !== void 0 ? _allSeaLanes$get$size3 : 0) >= MAX_LANES_PER_COUNTRY) return false;
    if (((_allSeaLanes$get$size4 = (_allSeaLanes$get4 = allSeaLanes.get(provB)) === null || _allSeaLanes$get4 === void 0 ? void 0 : _allSeaLanes$get4.size) !== null && _allSeaLanes$get$size4 !== void 0 ? _allSeaLanes$get$size4 : 0) >= MAX_LANES_PER_COUNTRY) return false;
    // Constraint 2: per-island entrance cap.  Only a province with no lane
    // yet would add an entrance; one that already has a lane is an existing
    // entrance and may take a second lane even when its island is at its
    // cap (R9 follow-up of R11, round 3).
    if (wouldExceedEntranceCap(provA, islandA)) return false;
    if (wouldExceedEntranceCap(provB, islandB)) return false;
    // Constraint 3: island-graph degree cap (R11: distinct neighbours).
    if (islandDegreeOf(islandA) >= MAX_ISLAND_GRAPH_DEGREE) return false;
    if (islandDegreeOf(islandB) >= MAX_ISLAND_GRAPH_DEGREE) return false;
    // Constraint 4: DEGREE_MAX
    const degA = ((_allBorders$get$size = (_allBorders$get = allBorders.get(provA)) === null || _allBorders$get === void 0 ? void 0 : _allBorders$get.size) !== null && _allBorders$get$size !== void 0 ? _allBorders$get$size : 0) + ((_allSeaLanes$get$size5 = (_allSeaLanes$get5 = allSeaLanes.get(provA)) === null || _allSeaLanes$get5 === void 0 ? void 0 : _allSeaLanes$get5.size) !== null && _allSeaLanes$get$size5 !== void 0 ? _allSeaLanes$get$size5 : 0);
    const degB = ((_allBorders$get$size2 = (_allBorders$get2 = allBorders.get(provB)) === null || _allBorders$get2 === void 0 ? void 0 : _allBorders$get2.size) !== null && _allBorders$get$size2 !== void 0 ? _allBorders$get$size2 : 0) + ((_allSeaLanes$get$size6 = (_allSeaLanes$get6 = allSeaLanes.get(provB)) === null || _allSeaLanes$get6 === void 0 ? void 0 : _allSeaLanes$get6.size) !== null && _allSeaLanes$get$size6 !== void 0 ? _allSeaLanes$get$size6 : 0);
    if (degA >= DEGREE_MAX || degB >= DEGREE_MAX) return false;
    if ((_allSeaLanes$get7 = allSeaLanes.get(provA)) !== null && _allSeaLanes$get7 !== void 0 && _allSeaLanes$get7.has(provB)) return false;
    return true;
  }

  /**
   * Every province pair (one on `src`, one on `dst`) that `tryAddLane`
   * would accept now.  Round 4 (Sol R2): Phase 2 counts an island pair as
   * viable only when this list is non-empty and picks its provinces from
   * it, so a pass never ends on a refused lane; when no island pair has
   * such a province pair, Phase 2 backtracks.
   */
  function addableProvincePairs(src, dst) {
    const out = [];
    for (const a of laneCandidates(src)) {
      for (const b of laneCandidates(dst)) {
        if (canAddLane(a, b, src.id, dst.id)) out.push([a, b]);
      }
    }
    return out;
  }

  // Phase 1: build a balanced spanning tree using Kruskal's-style random
  // pair selection.  Generate all possible island pairs, shuffle, pick the
  // first 8 that connect distinct components while respecting
  // MAX_ISLAND_GRAPH_DEGREE (the cap is enforced by tryAddLane).  Unlike
  // Prim's from a fixed root, this produces trees where no island is
  // pre-disposed to be a hub — every island has the same chance of high
  // degree, which leaves Phase 2 more headroom.
  const allPairs = [];
  for (let i = 0; i < islandStructs.length; i++) {
    for (let j = i + 1; j < islandStructs.length; j++) {
      allPairs.push({
        i,
        j
      });
    }
  }
  // R7 (rework round, Sol 2026-10-13): the previous round called
  // `shuffled(rng, allPairs)` and discarded the result. The shuffled
  // copy is now used below in the Phase 1 loop.

  // Union-find for components. `compParent` always has `islandStructs.length`
  // entries and indices in `[0, length)` are always set, but
  // `noUncheckedIndexedAccess` widens the read to `number | undefined`
  // even with that invariant; the `!` asserts the well-defined read.
  const compParent = Array.from({
    length: islandStructs.length
  }, (_, i) => i);
  function compFind(x) {
    return compParent[x] === x ? x : compParent[x] = compFind(compParent[x]);
  }
  function compUnion(a, b) {
    const ra = compFind(a);
    const rb = compFind(b);
    if (ra !== rb) compParent[ra] = rb;
  }
  let treeEdges = 0;
  // R7 (rework round, Sol 2026-10-13): the previous round called
  // `shuffled(rng, allPairs)` but discarded the result and iterated
  // `allPairs` directly.  The spanning tree therefore always
  // traversed pairs in fixed lexicographic order, and Phase 1's
  // "random spanning tree" was deterministic regardless of the seed.
  // Fix: iterate the shuffled copy, never the original.
  const shuffledPairs = shuffled(rng, allPairs);
  for (const pair of shuffledPairs) {
    if (treeEdges >= islandStructs.length - 1) break;
    const fromIsland = islandStructs[pair.i].id;
    const toIsland = islandStructs[pair.j].id;
    trace === null || trace === void 0 || trace.phase1Pairs.push([fromIsland, toIsland]);
    if (compFind(pair.i) === compFind(pair.j)) continue; // already connected
    const from = islandStructs[pair.i];
    const to = islandStructs[pair.j];
    const provA_arr = laneCandidates(from);
    const provB_arr = laneCandidates(to);
    if (provA_arr.length === 0 || provB_arr.length === 0) continue;
    const provA = provA_arr[rng.nextInt(0, provA_arr.length - 1)];
    const provB = provB_arr[rng.nextInt(0, provB_arr.length - 1)];
    if (tryAddLane(provA, provB, fromIsland, toIsland)) {
      compUnion(pair.i, pair.j);
      treeEdges++;
    }
  }

  // Phase 2: fill remaining slots up to SEA_LANE_COUNT, while also ensuring
  // every island reaches MIN_ENTRANCES_PER_ISLAND (anti-fortress).
  //
  // Two-phase approach (C-BRD-01):
  //   2A. Anti-fortress: for each island with < MIN_ENTRANCES_PER_ISLAND
  //       entrances, add a sea lane from a province that currently has
  //       0 lanes (a NEW entrance) to a province on a different island
  //       that has lane headroom.
  //   2B. Fill: while below SEA_LANE_COUNT, add random lanes between viable
  //       pairs until the count is reached or no viable pair exists.
  //
  // Both phases enforce the four constraints via tryAddLane.
  let seaLaneCount = islandStructs.length - 1; // spanning tree used this many lanes
  let phase2Passes = 0;
  /**
   * C-BRD-01 [designed]: maximum Phase 2 passes (one C-BRD-01 / fairness
   * top-level retry cap = MAX_BOARD_ATTEMPTS, but Phase 2 has its own
   * inner budget).  The original T05a generator had no Phase 2 cap; the
   * 5000 value was chosen empirically on the 200-seed wide sweep: at
   * cap=5 we observed all 200 seeds complete Phase 2 in < 200 passes
   * (logs not retained; the value is a safety bound, not a tuning
   * parameter).  Searched for published guidance: none.
   */
  const MAX_PHASE2_PASSES = 5000;

  // Phase 2: fill to SEA_LANE_COUNT while satisfying the four structural
  // constraints.  The scoring below steers lanes to islands still under
  // MIN_ENTRANCES_PER_ISLAND; `structuralErrors` refuses any finished map
  // that misses the minimum.
  //
  // Approach: greedy + backtracking.  Each pass picks a viable island pair.
  // When no viable pair remains, undo the most recent lane and try a
  // different lane from the same state.  This explores multiple plans within
  // the same body call.

  const phase2History = [];
  /**
   * C-BRD-01 [removed]: the previous round had `MAX_PHASE2_UNDO = 200`
   * but the body unconditionally `break`s after the first undo, so
   * the bound is never reached.  R10 (Sol 2026-10-13): the no-op
   * bound is misleading — implement the bound properly or remove
   * it.  We keep the undo pattern (one lane per invocation) and
   * document why: multi-undo would be too aggressive for the small
   * island graph, and the retry loop at the top level
   * (MAX_BOARD_ATTEMPTS) bounds total wasted effort.  If a future
   * test demonstrates Phase 2 gets stuck in a loop that one undo
   * cannot escape, restore the bound with a real implementation
   * (loop until cap or until a viable pair exists).
   */

  while (seaLaneCount < SEA_LANE_COUNT && phase2Passes < MAX_PHASE2_PASSES) {
    var _allSeaLanes$get$size9, _allSeaLanes$get10, _allSeaLanes$get$size0, _allSeaLanes$get11;
    phase2Passes++;
    const viablePairs = [];
    for (const src of islandStructs) {
      for (const dst of islandStructs) {
        var _islandEntranceCount$3, _islandEntranceCount$4;
        if (src.id === dst.id) continue;
        if (islandDegreeOf(src.id) >= MAX_ISLAND_GRAPH_DEGREE) continue;
        if (islandDegreeOf(dst.id) >= MAX_ISLAND_GRAPH_DEGREE) continue;
        // An island at its entrance cap stays viable through an existing
        // entrance with lane headroom (R9 follow-up of R11, round 3).
        if (laneCandidates(src).length === 0 || laneCandidates(dst).length === 0) continue;
        if (addableProvincePairs(src, dst).length === 0) continue;
        const entrSrc = (_islandEntranceCount$3 = islandEntranceCount.get(src.id)) !== null && _islandEntranceCount$3 !== void 0 ? _islandEntranceCount$3 : 0;
        const entrDst = (_islandEntranceCount$4 = islandEntranceCount.get(dst.id)) !== null && _islandEntranceCount$4 !== void 0 ? _islandEntranceCount$4 : 0;
        const degSrc = islandDegreeOf(src.id);
        const degDst = islandDegreeOf(dst.id);
        let score = 0;
        // C-BRD-01 [designed]: priority weights for picking the next
        // Phase 2 lane.  Source-under-min gets 1000 (a large bonus so
        // every under-cap island is filled first); destination-under-
        // min gets 500 (lower because once the source's island is
        // filled, the destination becomes the next under-cap source).
        // The degree penalty `-= degSrc + degDst` spreads lanes across
        // islands to avoid hubs.  Weights chosen so any pair involving
        // an under-cap island outscores any pair that does not — the
        // 2:1 ratio ensures tie-breaking prefers the more under-cap
        // endpoint.  Searched: no published guidance.
        if (entrSrc < MIN_ENTRANCES_PER_ISLAND) score += 1000;
        if (entrDst < MIN_ENTRANCES_PER_ISLAND) score += 500;
        score -= degSrc + degDst;
        viablePairs.push({
          src,
          dst,
          score
        });
      }
    }
    if (viablePairs.length === 0) {
      var _allSeaLanes$get8, _allSeaLanes$get9;
      // Stuck. Backtrack: undo the most recent lane and try again.
      // R10: undo exactly ONE lane per invocation, then retry greedy.
      // The previous round had a `MAX_PHASE2_UNDO` bound that was
      // never reached because of the unconditional `break`; that
      // bound has been removed (see comment above).  The retry loop's
      // overall `MAX_BOARD_ATTEMPTS` caps wasted effort.
      if (phase2History.length === 0) break;
      const last = phase2History.pop();
      // Undo the lane
      (_allSeaLanes$get8 = allSeaLanes.get(last.provA)) === null || _allSeaLanes$get8 === void 0 || _allSeaLanes$get8.delete(last.provB);
      (_allSeaLanes$get9 = allSeaLanes.get(last.provB)) === null || _allSeaLanes$get9 === void 0 || _allSeaLanes$get9.delete(last.provA);
      removeNeighbour(last.islandA, last.islandB);
      if (last.provANewEntrance) {
        var _islandEntranceCount$5;
        islandEntranceCount.set(last.islandA, ((_islandEntranceCount$5 = islandEntranceCount.get(last.islandA)) !== null && _islandEntranceCount$5 !== void 0 ? _islandEntranceCount$5 : 0) - 1);
      }
      if (last.provBNewEntrance) {
        var _islandEntranceCount$6;
        islandEntranceCount.set(last.islandB, ((_islandEntranceCount$6 = islandEntranceCount.get(last.islandB)) !== null && _islandEntranceCount$6 !== void 0 ? _islandEntranceCount$6 : 0) - 1);
      }
      seaLaneCount--;
      continue;
    }
    let bestScore = -Infinity;
    for (const p of viablePairs) if (p.score > bestScore) bestScore = p.score;
    const bestPairs = viablePairs.filter(p => p.score === bestScore);
    const pair = bestPairs[rng.nextInt(0, bestPairs.length - 1)];
    // Provinces come only from pairs tryAddLane accepts (round 4, R2), with
    // the same preferences as before: a source with no lane yet (a new
    // entrance), then a destination that already has one lane.
    const addable = addableProvincePairs(pair.src, pair.dst);
    const provsSrc = [...new Set(addable.map(([a]) => a))];
    const srcZero = provsSrc.filter(p => {
      var _allSeaLanes$get$size7, _allSeaLanes$get0;
      return ((_allSeaLanes$get$size7 = (_allSeaLanes$get0 = allSeaLanes.get(p)) === null || _allSeaLanes$get0 === void 0 ? void 0 : _allSeaLanes$get0.size) !== null && _allSeaLanes$get$size7 !== void 0 ? _allSeaLanes$get$size7 : 0) === 0;
    });
    const provA = srcZero.length > 0 ? srcZero[rng.nextInt(0, srcZero.length - 1)] : provsSrc[rng.nextInt(0, provsSrc.length - 1)];
    const provsDst = addable.filter(([a]) => a === provA).map(([, b]) => b);
    const dstOne = provsDst.filter(p => {
      var _allSeaLanes$get$size8, _allSeaLanes$get1;
      return ((_allSeaLanes$get$size8 = (_allSeaLanes$get1 = allSeaLanes.get(p)) === null || _allSeaLanes$get1 === void 0 ? void 0 : _allSeaLanes$get1.size) !== null && _allSeaLanes$get$size8 !== void 0 ? _allSeaLanes$get$size8 : 0) === 1;
    });
    const provB = dstOne.length > 0 ? dstOne[rng.nextInt(0, dstOne.length - 1)] : provsDst[rng.nextInt(0, provsDst.length - 1)];
    const provAWas0Lane = ((_allSeaLanes$get$size9 = (_allSeaLanes$get10 = allSeaLanes.get(provA)) === null || _allSeaLanes$get10 === void 0 ? void 0 : _allSeaLanes$get10.size) !== null && _allSeaLanes$get$size9 !== void 0 ? _allSeaLanes$get$size9 : 0) === 0;
    const provBWas0Lane = ((_allSeaLanes$get$size0 = (_allSeaLanes$get11 = allSeaLanes.get(provB)) === null || _allSeaLanes$get11 === void 0 ? void 0 : _allSeaLanes$get11.size) !== null && _allSeaLanes$get$size0 !== void 0 ? _allSeaLanes$get$size0 : 0) === 0;
    const atCapA = atEntranceCap(pair.src.id);
    const atCapB = atEntranceCap(pair.dst.id);
    if (!tryAddLane(provA, provB, pair.src.id, pair.dst.id)) continue;
    trace === null || trace === void 0 || trace.phase2Lanes.push({
      islandA: pair.src.id,
      islandB: pair.dst.id,
      atCapA,
      atCapB
    });
    phase2History.push({
      provA,
      provB,
      islandA: pair.src.id,
      islandB: pair.dst.id,
      provANewEntrance: provAWas0Lane,
      provBNewEntrance: provBWas0Lane
    });
    seaLaneCount++;
  }
  if (seaLaneCount < SEA_LANE_COUNT) errors.push(`could not place ${SEA_LANE_COUNT} sea lanes in ${MAX_PHASE2_PASSES} passes (placed ${seaLaneCount})`);
  // ---- Build island records ------------------------------------------------
  // islandEntranceCount is maintained live during Phase 1 and Phase 2;
  // it already reflects the correct count of distinct provinces with sea lanes.
  const islands = islandStructs.map(isl => {
    var _islandEntranceCount$7;
    return {
      id: isl.id,
      name: isl.name,
      bonus: Math.max(2, Math.floor(isl.size / BONUS_DIVISOR) + ((_islandEntranceCount$7 = islandEntranceCount.get(isl.id)) !== null && _islandEntranceCount$7 !== void 0 ? _islandEntranceCount$7 : 0)),
      provinces: isl.provinceIds
    };
  });

  // ---- Build province records ----------------------------------------------
  // Assign each province a position within a grid derived from the island index.
  const provinces = [];
  for (let ii = 0; ii < islandStructs.length; ii++) {
    const island = islandStructs[ii];
    const islandX = ii % 3 * 220 + 60;
    const islandY = Math.floor(ii / 3) * 180 + 60;
    const pts = spreadPoints(rng, island.size, islandX, islandX + 160, islandY, islandY + 130);
    for (let pi = 0; pi < island.provinceIds.length; pi++) {
      var _allBorders$get3, _allSeaLanes$get12;
      const id = island.provinceIds[pi];
      const [px, py] = pts[pi];
      const prefix = NAME_PREFIXES[rng.nextInt(0, NAME_PREFIXES.length - 1)];
      const suffix = NAME_SUFFIXES[rng.nextInt(0, NAME_SUFFIXES.length - 1)];
      const borders = [...((_allBorders$get3 = allBorders.get(id)) !== null && _allBorders$get3 !== void 0 ? _allBorders$get3 : [])];
      const seaLanes = [...((_allSeaLanes$get12 = allSeaLanes.get(id)) !== null && _allSeaLanes$get12 !== void 0 ? _allSeaLanes$get12 : [])];
      const polygon = placeholderPolygon(px, py, rng.nextInt(12, 22), rng.nextInt(3, 6));
      const labelAt = [px, py];
      provinces.push({
        id,
        name: `${prefix} ${suffix}`,
        island: island.id,
        borders,
        seaLanes,
        polygon,
        labelAt
      });
    }
  }

  // ---- Bounds --------------------------------------------------------------
  const allX = provinces.flatMap(p => p.polygon.map(pt => pt[0]));
  const allY = provinces.flatMap(p => p.polygon.map(pt => pt[1]));
  const minX = Math.min(...allX) - 30;
  const minY = Math.min(...allY) - 30;
  const maxX = Math.max(...allX) + 30;
  const maxY = Math.max(...allY) + 30;
  const bounds = {
    x: minX,
    y: minY,
    width: maxX - minX,
    height: maxY - minY
  };
  const map = {
    id: "generated",
    name: "Generated Archipelago",
    bounds,
    provinces,
    islands
  };

  // The structural acceptance step (`structuralErrors`) runs in the retry
  // loop on every map a body returns (round 4, R1).
  if (errors.length > 0) return {
    ok: false,
    errors
  };
  return {
    ok: true,
    map
  };
}

/**
 * Generate a `GameMap` from a seed. The map always meets the structural
 * invariants from `design/core-rules.md § The board` on every seed:
 * - 46 provinces in 9 islands of sizes [3,3,3,3,5,5,7,7,10] (C-BRD-03)
 * - every province has 2–5 neighbours in total (C-BRD-04)
 * - exactly 16 undirected inter-island sea lanes, symmetric (C-BRD-04)
 * - the border-plus-sea-lane graph is connected (C-BRD-04)
 * - island bonuses follow C-BON-02
 * - all polygons have ≥3 points; all labels inside bounds (C-BRD-06)
 *
 * Plus the 5 fairness checks from `board-fairness.ts` (C-BRD-01).
 * The retry loop draws a new plan each attempt by advancing the RNG.
 *
 * Takes the seed only: it always runs the real body, the real five checks
 * and the real `MAX_BOARD_ATTEMPTS` cap (R1, round 3).  Arguments past the
 * seed are ignored.
 */
export function generateBoard(seed) {
  return generateBoardWithRng(new DeterministicRng(seed));
}

/** Shared-stream seam for generated games; retries keep consuming the caller's RNG. */
export function generateBoardWithRng(rng, parts = {}) {
  return generateBoardUsingRng(rng, parts);
}

/**
 * Internal testing boundary: the retry loop with replaceable parts.  It is
 * exported from this module for tests only and is NOT re-exported from
 * `src/core/index.ts`; the public entry is `generateBoard(seed)`.  Every
 * part left out defaults to the production one, so a test that replaces
 * only the body still runs the real `runAllFairnessChecks` (R2, round 3).
 * `structuralErrors` is not replaceable: it runs on every body's map.
 */
export function generateBoardInternal(seed, parts = {}) {
  var _parts$body, _parts$fairnessCheck, _parts$attempts;
  const body = (_parts$body = parts.body) !== null && _parts$body !== void 0 ? _parts$body : generateBoardBody;
  const fairnessCheck = (_parts$fairnessCheck = parts.fairnessCheck) !== null && _parts$fairnessCheck !== void 0 ? _parts$fairnessCheck : runAllFairnessChecks;
  const cap = (_parts$attempts = parts.attempts) !== null && _parts$attempts !== void 0 ? _parts$attempts : MAX_BOARD_ATTEMPTS;
  const rng = new DeterministicRng(seed);
  return generateBoardUsingRng(rng, {
    body,
    fairnessCheck,
    attempts: cap
  });
}
function generateBoardUsingRng(rng, parts = {}) {
  var _parts$body2, _parts$fairnessCheck2, _parts$attempts2;
  const body = (_parts$body2 = parts.body) !== null && _parts$body2 !== void 0 ? _parts$body2 : generateBoardBody;
  const fairnessCheck = (_parts$fairnessCheck2 = parts.fairnessCheck) !== null && _parts$fairnessCheck2 !== void 0 ? _parts$fairnessCheck2 : runAllFairnessChecks;
  const cap = (_parts$attempts2 = parts.attempts) !== null && _parts$attempts2 !== void 0 ? _parts$attempts2 : MAX_BOARD_ATTEMPTS;
  let lastResult = null;
  for (let attempt = 1; attempt <= cap; attempt++) {
    let result = body(rng);
    // Structural acceptance (C-BRD-04, C-BRD-01): a body's map that misses
    // an invariant is a failed attempt, whatever the fairness checks say.
    const structural = result.ok ? structuralErrors(result.map) : [];
    if (structural.length > 0) result = {
      ok: false,
      errors: structural
    };
    if (result.ok) {
      const fairnessErrors = fairnessCheck(result.map);
      if (fairnessErrors.length === 0) return result;
    }
    lastResult = result;
    // Advance the RNG to draw a different plan next attempt (C-BRD-01).
    // One draw is enough: the body always consumes a deterministic
    // sequence, so skipping one state guarantees a different plan on the
    // next attempt — whether the previous attempt failed structurally
    // (e.g. could not place 16 lanes) or failed the fairness checks.
    rng.nextInt(0, 0xffffffff);
  }
  if (lastResult && lastResult.ok) {
    const fairnessErrors = fairnessCheck(lastResult.map);
    return {
      ok: false,
      errors: [`fairness checks failed after ${cap} attempts: ${fairnessErrors.join("; ")}`]
    };
  }
  return {
    ok: false,
    errors: [`failed after ${cap} attempts: ${lastResult ? lastResult.errors.join("; ") : "no body output"}`]
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJEZXRlcm1pbmlzdGljUm5nIiwicnVuQWxsRmFpcm5lc3NDaGVja3MiLCJJU0xBTkRfU0laRVMiLCJTRUFfTEFORV9DT1VOVCIsIkRFR1JFRV9NSU4iLCJERUdSRUVfTUFYIiwiQk9SREVSX01BWCIsIkJPTlVTX0RJVklTT1IiLCJNQVhfQk9BUkRfQVRURU1QVFMiLCJNQVhfTEFORVNfUEVSX0NPVU5UUlkiLCJNQVhfRU5UUkFOQ0VTX0JZX1NJWkUiLCJNSU5fRU5UUkFOQ0VTX1BFUl9JU0xBTkQiLCJNQVhfSVNMQU5EX0dSQVBIX0RFR1JFRSIsIklTTEFORF9OQU1FUyIsIk5BTUVfUFJFRklYRVMiLCJOQU1FX1NVRkZJWEVTIiwic2h1ZmZsZWQiLCJybmciLCJpdGVtcyIsIm91dCIsImkiLCJsZW5ndGgiLCJqIiwibmV4dEludCIsInRtcCIsInBsYWNlaG9sZGVyUG9seWdvbiIsImN4IiwiY3kiLCJyIiwic2lkZXMiLCJwdHMiLCJhbmdsZSIsIk1hdGgiLCJQSSIsInB1c2giLCJjb3MiLCJzaW4iLCJzcHJlYWRQb2ludHMiLCJuIiwibWluWCIsIm1heFgiLCJtaW5ZIiwibWF4WSIsImNvbHMiLCJjZWlsIiwic3FydCIsImNlbGxXIiwiY2VsbEgiLCJjb2wiLCJyb3ciLCJmbG9vciIsIngiLCJ5IiwiYnVpbGRCb3JkZXJzIiwicHJvdmluY2VJZHMiLCJtYXhEZWdyZWUiLCJhZGoiLCJNYXAiLCJtYXAiLCJpZCIsIlNldCIsImdldCIsImFkZCIsIm9yZGVyIiwiY2hpbGQiLCJoZWFkcm9vbVBhcmVudHMiLCJzbGljZSIsImZpbHRlciIsInAiLCJzaXplIiwicGFyZW50IiwiaWRzIiwic3RyYWdnbGVyUGFzc2VzIiwiTUFYX1NUUkFHR0xFUl9QQVNTRVMiLCJyZW1haW5pbmdTdHJhZ2dsZXJzIiwicHJvZ3Jlc3MiLCJwYXJ0bmVycyIsImhhcyIsInBhcnRuZXIiLCJNQVhfUEFDS19BVFRFTVBUUyIsImF0dGVtcHQiLCJhIiwiYiIsInN0cnVjdHVyYWxFcnJvcnMiLCJlcnJvcnMiLCJwcm92aW5jZXMiLCJkZWciLCJib3JkZXJzIiwic2VhTGFuZXMiLCJ1bmRpcmVjdGVkU2VhTGFuZXMiLCJ0Iiwia2V5IiwiYnlJZCIsInNlZW4iLCJxdWV1ZSIsImN1cnJlbnQiLCJzaGlmdCIsInByb3YiLCJiZWxvdyIsImlzbGFuZCIsImlzbGFuZHMiLCJlbnRyYW5jZXMiLCJwaWQiLCJzb21lIiwiX2J5SWQkZ2V0Iiwiam9pbiIsImdlbmVyYXRlQm9hcmRCb2R5IiwidHJhY2UiLCJzaHVmZmxlZFByb3ZpbmNlSWRzIiwiQXJyYXkiLCJmcm9tIiwiXyIsImlzbGFuZFN0cnVjdHMiLCJjdXJzb3IiLCJfSVNMQU5EX05BTUVTJGkiLCJuYW1lIiwiYWxsQm9yZGVycyIsIm5laWdoYm91cnMiLCJzZXQiLCJhbGxTZWFMYW5lcyIsImlzbGFuZE5laWdoYm91cnMiLCJpc2wiLCJpc2xhbmREZWdyZWVPZiIsImlzbGFuZElkIiwiX2lzbGFuZE5laWdoYm91cnMkZ2V0IiwiX2lzbGFuZE5laWdoYm91cnMkZ2V0MiIsImFkZE5laWdoYm91ciIsImlzbGFuZEEiLCJpc2xhbmRCIiwiX2lzbGFuZE5laWdoYm91cnMkZ2V0MyIsIl9pc2xhbmROZWlnaGJvdXJzJGdldDQiLCJyZW1vdmVOZWlnaGJvdXIiLCJfaXNsYW5kTmVpZ2hib3VycyRnZXQ1IiwiX2lzbGFuZE5laWdoYm91cnMkZ2V0NiIsImRlbGV0ZSIsImlzbGFuZEVudHJhbmNlQ291bnQiLCJyZWNvcmRFbnRyYW5jZSIsImZpbmQiLCJzIiwiaW5jbHVkZXMiLCJleGlzdGluZyIsIl9pc2xhbmRFbnRyYW5jZUNvdW50JCIsImVudHJhbmNlQ2FwT2YiLCJfTUFYX0VOVFJBTkNFU19CWV9TSVoiLCJfaXNsYW5kU3RydWN0cyRmaW5kJHMiLCJfaXNsYW5kU3RydWN0cyRmaW5kIiwiYXRFbnRyYW5jZUNhcCIsIl9pc2xhbmRFbnRyYW5jZUNvdW50JDIiLCJ3b3VsZEV4Y2VlZEVudHJhbmNlQ2FwIiwiX2FsbFNlYUxhbmVzJGdldCRzaXplIiwiX2FsbFNlYUxhbmVzJGdldCIsImxhbmVDYW5kaWRhdGVzIiwiX2FsbFNlYUxhbmVzJGdldCRzaXplMiIsIl9hbGxTZWFMYW5lcyRnZXQyIiwidHJ5QWRkTGFuZSIsInByb3ZBIiwicHJvdkIiLCJjYW5BZGRMYW5lIiwiX2FsbFNlYUxhbmVzJGdldCRzaXplMyIsIl9hbGxTZWFMYW5lcyRnZXQzIiwiX2FsbFNlYUxhbmVzJGdldCRzaXplNCIsIl9hbGxTZWFMYW5lcyRnZXQ0IiwiX2FsbEJvcmRlcnMkZ2V0JHNpemUiLCJfYWxsQm9yZGVycyRnZXQiLCJfYWxsU2VhTGFuZXMkZ2V0JHNpemU1IiwiX2FsbFNlYUxhbmVzJGdldDUiLCJfYWxsQm9yZGVycyRnZXQkc2l6ZTIiLCJfYWxsQm9yZGVycyRnZXQyIiwiX2FsbFNlYUxhbmVzJGdldCRzaXplNiIsIl9hbGxTZWFMYW5lcyRnZXQ2IiwiX2FsbFNlYUxhbmVzJGdldDciLCJkZWdBIiwiZGVnQiIsImFkZGFibGVQcm92aW5jZVBhaXJzIiwic3JjIiwiZHN0IiwiYWxsUGFpcnMiLCJjb21wUGFyZW50IiwiY29tcEZpbmQiLCJjb21wVW5pb24iLCJyYSIsInJiIiwidHJlZUVkZ2VzIiwic2h1ZmZsZWRQYWlycyIsInBhaXIiLCJmcm9tSXNsYW5kIiwidG9Jc2xhbmQiLCJwaGFzZTFQYWlycyIsInRvIiwicHJvdkFfYXJyIiwicHJvdkJfYXJyIiwic2VhTGFuZUNvdW50IiwicGhhc2UyUGFzc2VzIiwiTUFYX1BIQVNFMl9QQVNTRVMiLCJwaGFzZTJIaXN0b3J5IiwiX2FsbFNlYUxhbmVzJGdldCRzaXplOSIsIl9hbGxTZWFMYW5lcyRnZXQxMCIsIl9hbGxTZWFMYW5lcyRnZXQkc2l6ZTAiLCJfYWxsU2VhTGFuZXMkZ2V0MTEiLCJ2aWFibGVQYWlycyIsIl9pc2xhbmRFbnRyYW5jZUNvdW50JDMiLCJfaXNsYW5kRW50cmFuY2VDb3VudCQ0IiwiZW50clNyYyIsImVudHJEc3QiLCJkZWdTcmMiLCJkZWdEc3QiLCJzY29yZSIsIl9hbGxTZWFMYW5lcyRnZXQ4IiwiX2FsbFNlYUxhbmVzJGdldDkiLCJsYXN0IiwicG9wIiwicHJvdkFOZXdFbnRyYW5jZSIsIl9pc2xhbmRFbnRyYW5jZUNvdW50JDUiLCJwcm92Qk5ld0VudHJhbmNlIiwiX2lzbGFuZEVudHJhbmNlQ291bnQkNiIsImJlc3RTY29yZSIsIkluZmluaXR5IiwiYmVzdFBhaXJzIiwiYWRkYWJsZSIsInByb3ZzU3JjIiwic3JjWmVybyIsIl9hbGxTZWFMYW5lcyRnZXQkc2l6ZTciLCJfYWxsU2VhTGFuZXMkZ2V0MCIsInByb3ZzRHN0IiwiZHN0T25lIiwiX2FsbFNlYUxhbmVzJGdldCRzaXplOCIsIl9hbGxTZWFMYW5lcyRnZXQxIiwicHJvdkFXYXMwTGFuZSIsInByb3ZCV2FzMExhbmUiLCJhdENhcEEiLCJhdENhcEIiLCJwaGFzZTJMYW5lcyIsIl9pc2xhbmRFbnRyYW5jZUNvdW50JDciLCJib251cyIsIm1heCIsImlpIiwiaXNsYW5kWCIsImlzbGFuZFkiLCJwaSIsIl9hbGxCb3JkZXJzJGdldDMiLCJfYWxsU2VhTGFuZXMkZ2V0MTIiLCJweCIsInB5IiwicHJlZml4Iiwic3VmZml4IiwicG9seWdvbiIsImxhYmVsQXQiLCJhbGxYIiwiZmxhdE1hcCIsInB0IiwiYWxsWSIsIm1pbiIsImJvdW5kcyIsIndpZHRoIiwiaGVpZ2h0Iiwib2siLCJnZW5lcmF0ZUJvYXJkIiwic2VlZCIsImdlbmVyYXRlQm9hcmRXaXRoUm5nIiwicGFydHMiLCJnZW5lcmF0ZUJvYXJkVXNpbmdSbmciLCJnZW5lcmF0ZUJvYXJkSW50ZXJuYWwiLCJfcGFydHMkYm9keSIsIl9wYXJ0cyRmYWlybmVzc0NoZWNrIiwiX3BhcnRzJGF0dGVtcHRzIiwiYm9keSIsImZhaXJuZXNzQ2hlY2siLCJjYXAiLCJhdHRlbXB0cyIsIl9wYXJ0cyRib2R5MiIsIl9wYXJ0cyRmYWlybmVzc0NoZWNrMiIsIl9wYXJ0cyRhdHRlbXB0czIiLCJsYXN0UmVzdWx0IiwicmVzdWx0Iiwic3RydWN0dXJhbCIsImZhaXJuZXNzRXJyb3JzIl0sInNvdXJjZXMiOlsiYm9hcmQtZ2VuLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERldGVybWluaXN0aWNSbmcgfSBmcm9tIFwiLi9ybmdcIjtcbmltcG9ydCB0eXBlIHsgR2FtZU1hcCwgSXNsYW5kLCBQb2ludCwgUHJvdmluY2UgfSBmcm9tIFwiLi90eXBlc1wiO1xuaW1wb3J0IHsgcnVuQWxsRmFpcm5lc3NDaGVja3MgfSBmcm9tIFwiLi9ib2FyZC1mYWlybmVzc1wiO1xuXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIFN0cnVjdHVyYWwgY29uc3RhbnRzIOKAlCBlYWNoIGNpdGVzIHRoZSBjbGFpbSBpdCB0cmFjZXMgdG8gKHJ1bGUgMTcpLlxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbi8qKiBDLUJSRC0wMzogbmluZSBpc2xhbmRzIG9mIHRoZXNlIHNpemVzOyB0aGUgZGVzaWduJ3Mgc29ydGVkIHBhcnRpdGlvbi4gKi9cbmV4cG9ydCBjb25zdCBJU0xBTkRfU0laRVMgPSBbMywgMywgMywgMywgNSwgNSwgNywgNywgMTBdIGFzIGNvbnN0O1xuXG4vKiogQy1CUkQtMDQ6IGV4YWN0bHkgdGhpcyBtYW55IHVuZGlyZWN0ZWQgaW50ZXItaXNsYW5kIHNlYSBsYW5lcy4gKi9cbmV4cG9ydCBjb25zdCBTRUFfTEFORV9DT1VOVCA9IDE2O1xuXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIERlZ3JlZSBjb25zdHJhaW50cyAoQy1CUkQtMDQpXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuLyoqIEMtQlJELTA0OiBtaW5pbXVtIHRvdGFsIGRlZ3JlZSAoYm9yZGVycyArIHNlYSBsYW5lcykgcGVyIHByb3ZpbmNlLiAqL1xuZXhwb3J0IGNvbnN0IERFR1JFRV9NSU4gPSAyO1xuLyoqIEMtQlJELTA0OiBtYXhpbXVtIHRvdGFsIGRlZ3JlZSAoYm9yZGVycyArIHNlYSBsYW5lcykgcGVyIHByb3ZpbmNlLiAqL1xuZXhwb3J0IGNvbnN0IERFR1JFRV9NQVggPSA1O1xuLyoqXG4gKiBDLUJSRC0wNDogYm9yZGVycyBjb25zdW1lIGF0IG1vc3QgREVHUkVFX01BWCAtIDIgZGVncmVlIHNsb3RzLCBsZWF2aW5nXG4gKiB0d28gc2xvdHMgcGVyIHByb3ZpbmNlIGZvciBzZWEgbGFuZXMuICBUaGUgb3JpZ2luYWwgVDA1YSB2YWx1ZSB3YXNcbiAqIERFR1JFRV9NQVggLSAxOyB0aGF0IGxlZnQgZWFjaCBwcm92aW5jZSBvbmx5IG9uZSBzZWEtbGFuZSBzbG90LCB3aGljaFxuICogUGhhc2UgMiBjYW5ub3QgdXNlIHRvIHJlYWNoIFNFQV9MQU5FX0NPVU5UPTE2IG9uY2UgdGhlIGZvdXIgc3RydWN0dXJhbFxuICogY29uc3RyYWludHMgKE1BWF9MQU5FU19QRVJfQ09VTlRSWT0yLCBNQVhfRU5UUkFOQ0VTX0JZX1NJWkUsIE1JTl9FTlRSQU5DRVM9MixcbiAqIE1BWF9JU0xBTkRfR1JBUEhfREVHUkVFPTUpIGFyZSBpbiBwbGFjZS4gIFdpdGggdHdvIHNsb3RzIHBlciBwcm92aW5jZVxuICogUGhhc2UgMiBoYXMgaGVhZHJvb20gdG8gZmlsbCB0byAxNiBsYW5lcyBvbiB0aGUgdGVzdGVkIHNlZWRzLiAgRXZlcnlcbiAqIHByb3ZpbmNlIHN0aWxsIGhhcyBkZWdyZWUg4omlIDIgZnJvbSBib3JkZXJzIGFsb25lICh3aXRoaW4taXNsYW5kXG4gKiBjb25uZWN0aXZpdHkpLCBzbyBjb25uZWN0aXZpdHkgd2l0aGluIGVhY2ggaXNsYW5kIGlzIGFsd2F5cyBtYWludGFpbmVkLlxuICovXG5leHBvcnQgY29uc3QgQk9SREVSX01BWCA9IERFR1JFRV9NQVggLSAyO1xuXG4vKipcbiAqIEMtQk9OLTAyOiBpc2xhbmQgYm9udXMgPSBtYXgoMiwgZmxvb3Ioc2l6ZS8yKSArIGNyb3NzLWlzbGFuZC1lbnRyYW5jZXMpLlxuICogVGhlIGRpdmlzb3IgMiBpcyB0aGUgZGVzaWduIGNvbnN0YW50IGZyb20gZGVjaXNpb24gMTIuXG4gKi9cbmV4cG9ydCBjb25zdCBCT05VU19ESVZJU09SID0gMjtcblxuLyoqXG4gKiBDLUJSRC0wMTogdGhlIGdlbmVyYXRvciBtdXN0IGZpbmQgYSB2YWxpZCBib2FyZCB3aXRoaW4gdGhpcyBtYW55IGF0dGVtcHRzXG4gKiBvbiBhIDIwMC1zZWVkIHN3ZWVwICjiiaUgOTkgJSBzdWNjZXNzIHJhdGUpLiAgVGhlIGNhcCBpcyBhIG5hbWVkIGV4cG9ydCBzb1xuICogYSBydWxlLTkgbXV0YXRpb24gY2FuIHNldCBpdCB0byAwIGFuZCBwcm92ZSB0aGUgbG9vcCBpcyBsaXZlLiAgVGhlIHRlc3RcbiAqIHN1aXRlIHBpbnMgdGhlIHZhbHVlIHRvIFsxLCAyMDBdLlxuICpcbiAqIFRoZSB0YXNrJ3Mgc2VsZWN0aW9uIHJ1bGU6IHRoZSBzbWFsbGVzdCBudW1iZXIgdGhhdCwgb24gYSAyMDAtc2VlZFxuICogc3dlZXAsIGdpdmVzIGEgc3VjY2VzcyByYXRlIOKJpSA5OSAlLiAgU3dlZXAgb2Ygc2VlZHMgMS4uMjAwIHRocm91Z2hcbiAqIGBnZW5lcmF0ZUJvYXJkSW50ZXJuYWwoc2VlZCwgeyBhdHRlbXB0czogY2FwIH0pYCBhZnRlciByb3VuZCA0J3NcbiAqIGdlbmVyYXRvciBjaGFuZ2UgKFBoYXNlIDIgcGlja3Mgb25seSBhZGRhYmxlIHByb3ZpbmNlIHBhaXJzKTpcbiAqXG4gKiAgIGNhcD0wICDihpIgICAgMC8yMDAgIHJhdGU9MC4wMDBcbiAqICAgY2FwPTEgIOKGkiAgMjAwLzIwMCAgcmF0ZT0xLjAwMCAgKHNtYWxsZXN0IGNhcCDiiaUgOTkgJSlcbiAqICAgY2FwPTIuLjUsIDEwIOKGkiAyMDAvMjAwXG4gKlxuICogV2lkZXIgbG9vaywgbm90IHRoZSBzZWxlY3Rpb24gcnVsZTogc2VlZHMgMS4uNTAwMCBnaXZlIDQ5OTYvNTAwMFxuICogKDk5LjkyICUpIGF0IGNhcD0xLCB0aGUgZm91ciBmYWlsdXJlcyBhbGwgZmFpcm5lc3MgKGVjY2VudHJpY2l0eSA1IG9uXG4gKiBzZWVkcyAxNTA2LCAxNTk3LCAyNzc5LCA0NTU3KSwgbm9uZSBzdHJ1Y3R1cmFsOyA1MDAwLzUwMDAgYXQgY2FwPTIsIDMuXG4gKlxuICogYHRlc3RzL2NvcmUvYm9hcmQtZ2VuLnRlc3QudHNgIHJlLXJ1bnMgdGhpcyBzd2VlcCBhdCB0aGUgcGlubmVkIGNhcCBhbmRcbiAqIGF0IG9uZSBiZWxvdyBpdCwgc28gYSBkaWZmZXJlbnQgdmFsdWUgZmFpbHMgdGhlIHN1aXRlLlxuICovXG5leHBvcnQgY29uc3QgTUFYX0JPQVJEX0FUVEVNUFRTID0gMTtcblxuLyoqXG4gKiBDLUJSRC0wMTogYSBwcm92aW5jZSBjYXJyaWVzIGF0IG1vc3QgMiBzZWEgbGFuZXMuICBQaGFzZSAyIHNraXBzIGFueVxuICogY2FuZGlkYXRlIHBhaXIgd2hlcmUgZWl0aGVyIGVuZHBvaW50IGFscmVhZHkgaGFzIDIgbGFuZXMuICBUaGlzIGlzIHRoZVxuICogc3RydWN0dXJhbCBwcmVjb25kaXRpb24gZm9yIGNoZWNrQ3Jvd2RlZENyb3NzaW5nLlxuICovXG5leHBvcnQgY29uc3QgTUFYX0xBTkVTX1BFUl9DT1VOVFJZID0gMjtcblxuLyoqXG4gKiBDLUJSRC0wMSwgQy1CT04tMDI6IHBlci1pc2xhbmQgY2FwIG9uIHRoZSBudW1iZXIgb2YgZGlzdGluY3QgcHJvdmluY2VzXG4gKiB0aGF0IGhhdmUgYXQgbGVhc3Qgb25lIHNlYSBsYW5lIHRvIGFub3RoZXIgaXNsYW5kLiAgRGVyaXZlZCBmcm9tXG4gKiBDLUJPTi0wMiBzbyB0aGF0IGBib251cyA9IG1heCgyLCBmbG9vcihzaXplLzIpICsgZW50cmFuY2VzKSDiiaQgc2l6ZWBcbiAqIGFsd2F5cyBob2xkczpcbiAqICAgc2l6ZSAzIOKGkiBtYXgoMiwgMSsyKT0zIOKJpCAzICDihpIgY2FwIDJcbiAqICAgc2l6ZSA1IOKGkiBtYXgoMiwgMiszKT01IOKJpCA1ICDihpIgY2FwIDNcbiAqICAgc2l6ZSA3IOKGkiBtYXgoMiwgMys0KT03IOKJpCA3ICDihpIgY2FwIDRcbiAqICAgc2l6ZSAxMCDihpIgbWF4KDIsIDUrNSk9MTAg4omkIDEwIOKGkiBjYXAgNVxuICogUGhhc2UgMiBza2lwcyBhbnkgY2FuZGlkYXRlIHdoZXJlIHRoZSBkZXN0aW5hdGlvbiBpc2xhbmQgd291bGQgZXhjZWVkIGl0cyBjYXAuXG4gKi9cbmV4cG9ydCBjb25zdCBNQVhfRU5UUkFOQ0VTX0JZX1NJWkU6IFJlYWRvbmx5PFJlY29yZDxudW1iZXIsIG51bWJlcj4+ID0ge1xuICAzOiAyLFxuICA1OiAzLFxuICA3OiA0LFxuICAxMDogNSxcbn07XG5cbi8qKlxuICogQy1CUkQtMDE6IGV2ZXJ5IGlzbGFuZCBtdXN0IGhhdmUgYXQgbGVhc3QgMiBjb3VudHJpZXMgd2l0aCBhIHNlYSBsYW5lXG4gKiAoYW50aS1mb3J0cmVzcykuICBQaGFzZSAxJ3Mgc3Bhbm5pbmcgdHJlZSBndWFyYW50ZWVzIGF0IGxlYXN0IG9uZSBsYW5lXG4gKiBvbiBlYWNoIGlzbGFuZDsgUGhhc2UgMiBrZWVwcyBhZGRpbmcgbGFuZXMgdW50aWwgZXZlcnkgaXNsYW5kIHJlYWNoZXMgMi5cbiAqIFRoaXMgaXMgdGhlIHN0cnVjdHVyYWwgcHJlY29uZGl0aW9uIGZvciBjaGVja0ZvcnRyZXNzLlxuICovXG5leHBvcnQgY29uc3QgTUlOX0VOVFJBTkNFU19QRVJfSVNMQU5EID0gMjtcblxuLyoqXG4gKiBDLUJSRC0wMTogaW4gdGhlIGlzbGFuZCBncmFwaCwgbm8gaXNsYW5kIG1heSBoYXZlIGRlZ3JlZSA+IDUuXG4gKiBQaGFzZSAxJ3Mgc3Bhbm5pbmcgdHJlZSBtdXN0IGtlZXAgZWFjaCBpc2xhbmQncyBkZWdyZWUg4omkIDVcbiAqICg4IGVkZ2VzIG9uIDkgaXNsYW5kcywgbWF4IGRlZ3JlZSA1KTsgUGhhc2UgMiBtdXN0IHNraXAgYW55XG4gKiBjYW5kaWRhdGUgcGFpciB3aGVyZSB0aGUgcmVzdWx0aW5nIGRlZ3JlZSBvZiBlaXRoZXIgZW5kcG9pbnRcbiAqIHdvdWxkIGV4Y2VlZCB0aGUgY2FwLiAgVGhpcyBpcyB0aGUgc3RydWN0dXJhbCBwcmVjb25kaXRpb24gZm9yXG4gKiBjaGVja1JlbW90ZU9ySHViLiAgQW1lbmRtZW50IDIwMjYtMTAtMTM6IHJhaXNlZCBmcm9tIDQgdG8gNSBhZnRlclxuICogdGhlIE0zIHJvdW5kIHJlYWNoZWQgNzYgJSBhdCBjYXAgPSA0IChyYW5kb20gZ3JlZWR5ICsgMS1sZXZlbFxuICogYmFja3RyYWNraW5nIGNhbm5vdCByZWxpYWJseSBzYXR1cmF0ZSB0aGUgaXNsYW5kIGdyYXBoIGF0IGNhcCA9IDQpO1xuICogZWNjZW50cmljaXR5IHRocmVzaG9sZCAoNCkgZGlkIG5vdCBtb3ZlIGluIGxvY2tzdGVwLlxuICovXG5leHBvcnQgY29uc3QgTUFYX0lTTEFORF9HUkFQSF9ERUdSRUUgPSA1O1xuXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIFJlc3VsdCB0eXBlXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IHR5cGUgQm9hcmRHZW5SZXN1bHQgPVxuICB8IHsgcmVhZG9ubHkgb2s6IHRydWU7IHJlYWRvbmx5IG1hcDogR2FtZU1hcCB9XG4gIHwgeyByZWFkb25seSBvazogZmFsc2U7IHJlYWRvbmx5IGVycm9yczogcmVhZG9ubHkgc3RyaW5nW10gfTtcblxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyBJc2xhbmQgbmFtZXMgKG91cnMg4oCUIG5vdCBUMDMncylcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5jb25zdCBJU0xBTkRfTkFNRVMgPSBbXG4gIFwiTm9ydGggSXNsZVwiLFxuICBcIkVhc3QgSXNsZVwiLFxuICBcIldlc3QgSXNsZVwiLFxuICBcIlNvdXRoIElzbGVcIixcbiAgXCJDZW50cmFsIElzbGVcIixcbiAgXCJIYXJib3IgSXNsZVwiLFxuICBcIlBhbG0gSXNsZVwiLFxuICBcIkNsaWZmIElzbGVcIixcbiAgXCJHcmVhdCBJc2xlXCIsXG5dO1xuXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIFByb3ZpbmNlIG5hbWUgZnJhZ21lbnRzIChvdXJzOyByZXVzZWQgZGV0ZXJtaW5pc3RpY2FsbHkpXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuY29uc3QgTkFNRV9QUkVGSVhFUyA9IFtcbiAgXCJOb3J0aFwiLCBcIlNvdXRoXCIsIFwiRWFzdFwiLCBcIldlc3RcIiwgXCJVcHBlclwiLCBcIkxvd2VyXCIsIFwiT2xkXCIsIFwiTmV3XCIsXG4gIFwiUG9ydFwiLCBcIkZvcnRcIiwgXCJHb2xkXCIsIFwiU2lsdmVyXCIsIFwiSXJvblwiLCBcIlN0b25lXCIsIFwiV2luZFwiLCBcIlN1blwiLFxuICBcIk1vb25cIiwgXCJTdGFyXCIsIFwiUml2ZXJcIiwgXCJMYWtlXCIsIFwiQmF5XCIsIFwiQ2FwZVwiLCBcIlJvY2tcIiwgXCJNYXJzaFwiLFxuICBcIkhpZ2hcIiwgXCJMb3dcIiwgXCJEYXJrXCIsIFwiTGlnaHRcIiwgXCJSZWRcIiwgXCJCbHVlXCIsXG5dO1xuY29uc3QgTkFNRV9TVUZGSVhFUyA9IFtcbiAgXCJwb3J0XCIsIFwidG93blwiLCBcImhpbGxcIiwgXCJ2YWxlXCIsIFwiZm9yZFwiLCBcInBvaW50XCIsIFwiYmF5XCIsIFwicm9ja1wiLFxuICBcInNob3JlXCIsIFwiaGF2ZW5cIiwgXCJnYXRlXCIsIFwia2VlcFwiLCBcIm1hcmNoXCIsIFwiZGFsZVwiLCBcImZlbGxcIiwgXCJ3b29kXCIsXG4gIFwiZmllbGRcIiwgXCJnbGVuXCIsIFwibW9vclwiLCBcInBlYWtcIiwgXCJyaWRnZVwiLCBcInJlYWNoXCIsIFwid2F0Y2hcIiwgXCJyZXN0XCIsXG5dO1xuXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIEludGVybmFsIGhlbHBlcnNcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4vKiogRmlzaGVyLVlhdGVzIHNodWZmbGUgdXNpbmcgdGhlIHN1cHBsaWVkIFJORy4gKi9cbmZ1bmN0aW9uIHNodWZmbGVkPFQ+KHJuZzogRGV0ZXJtaW5pc3RpY1JuZywgaXRlbXM6IHJlYWRvbmx5IFRbXSk6IFRbXSB7XG4gIGNvbnN0IG91dCA9IFsuLi5pdGVtc107XG4gIGZvciAobGV0IGkgPSBvdXQubGVuZ3RoIC0gMTsgaSA+IDA7IGktLSkge1xuICAgIGNvbnN0IGogPSBybmcubmV4dEludCgwLCBpKTtcbiAgICBjb25zdCB0bXAgPSBvdXRbaV0gYXMgVDtcbiAgICBvdXRbaV0gPSBvdXRbal0gYXMgVDtcbiAgICBvdXRbal0gPSB0bXA7XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBTaW1wbGUgcGxhY2Vob2xkZXIgcG9seWdvbjogYSBzbWFsbCByZWd1bGFyIHBvbHlnb24gb2YgYHNpZGVzYCBwb2ludHNcbiAqIGNlbnRyZWQgb24gKGN4LCBjeSkgd2l0aCByYWRpdXMgYHJgLiBEaXNwbGF5IG9ubHkgKEMtQlJELTA2KS5cbiAqL1xuZnVuY3Rpb24gcGxhY2Vob2xkZXJQb2x5Z29uKGN4OiBudW1iZXIsIGN5OiBudW1iZXIsIHI6IG51bWJlciwgc2lkZXM6IG51bWJlcik6IFBvaW50W10ge1xuICBjb25zdCBwdHM6IFBvaW50W10gPSBbXTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBzaWRlczsgaSsrKSB7XG4gICAgY29uc3QgYW5nbGUgPSAoMiAqIE1hdGguUEkgKiBpKSAvIHNpZGVzIC0gTWF0aC5QSSAvIDI7XG4gICAgcHRzLnB1c2goW2N4ICsgciAqIE1hdGguY29zKGFuZ2xlKSwgY3kgKyByICogTWF0aC5zaW4oYW5nbGUpXSk7XG4gIH1cbiAgcmV0dXJuIHB0cztcbn1cblxuLyoqIFNwcmVhZCBuIGl0ZW1zIGFjcm9zcyBbbWluWCwgbWF4WF0gw5cgW21pblksIG1heFldIHVzaW5nIGRldGVybWluaXN0aWMgaml0dGVyLiAqL1xuZnVuY3Rpb24gc3ByZWFkUG9pbnRzKFxuICBybmc6IERldGVybWluaXN0aWNSbmcsXG4gIG46IG51bWJlcixcbiAgbWluWDogbnVtYmVyLFxuICBtYXhYOiBudW1iZXIsXG4gIG1pblk6IG51bWJlcixcbiAgbWF4WTogbnVtYmVyLFxuKTogUG9pbnRbXSB7XG4gIGNvbnN0IHB0czogUG9pbnRbXSA9IFtdO1xuICBjb25zdCBjb2xzID0gTWF0aC5jZWlsKE1hdGguc3FydChuICogMS41KSk7XG4gIGNvbnN0IGNlbGxXID0gKG1heFggLSBtaW5YKSAvIGNvbHM7XG4gIGNvbnN0IGNlbGxIID0gKG1heFkgLSBtaW5ZKSAvIE1hdGguY2VpbChuIC8gY29scyk7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbjsgaSsrKSB7XG4gICAgY29uc3QgY29sID0gaSAlIGNvbHM7XG4gICAgY29uc3Qgcm93ID0gTWF0aC5mbG9vcihpIC8gY29scyk7XG4gICAgY29uc3QgeCA9IG1pblggKyBjb2wgKiBjZWxsVyArIHJuZy5uZXh0SW50KDAsIGNlbGxXICogMC41KTtcbiAgICBjb25zdCB5ID0gbWluWSArIHJvdyAqIGNlbGxIICsgcm5nLm5leHRJbnQoMCwgY2VsbEggKiAwLjUpO1xuICAgIHB0cy5wdXNoKFt4LCB5XSk7XG4gIH1cbiAgcmV0dXJuIHB0cztcbn1cblxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyBCb3JkZXItZ3JhcGggYnVpbGRlciAod2l0aGluIG9uZSBpc2xhbmQpXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuLyoqXG4gKiBCdWlsZCBhIGNvbm5lY3RlZCBncmFwaCBvbiBgcHJvdmluY2VJZHNgIHdoZXJlIGV2ZXJ5IHZlcnRleCBlbmRzIHVwIHdpdGhcbiAqIGRlZ3JlZSBpbiBgWzIsIG1heERlZ3JlZV1gLiBSZXR1cm5zIGEgc3ltbWV0cmljIGFkamFjZW5jeSBtYXAuXG4gKlxuICogT3JkZXIgbWF0dGVycyAoZml4IGZvciB0aGUgc2VlZCA3IC8gMjEgLyAzMyAvIDQyIHNhdHVyYXRpb24gYnVnLCAyMDI2LTEwLTEyKTpcbiAqIDEuIFNwYW5uaW5nIHRyZWUuIEV2ZXJ5IG5vZGUgaGFzIGRlZ3JlZSAxKy5cbiAqIDIuIFJhaXNlIGV2ZXJ5IGRlZ3JlZS0xIG5vZGUgdG8gZGVncmVlIDIgdXNpbmcgb25seSBwYXJ0bmVycyB3aXRoXG4gKiAgICBoZWFkcm9vbSAoYGRlZ3JlZSA8IG1heERlZ3JlZWApLiBEb2luZyB0aGlzICpiZWZvcmUqIHRoZSBjYXAtcGFja2luZ1xuICogICAgbWVhbnMgdGhlIGNhcCBpcyBuZXZlciB2aW9sYXRlZCBieSB0aGUgc3RyYWdnbGVyIGZpeCAodGhlIHByZXZpb3VzXG4gKiAgICByZXdvcmsgcHVzaGVkIHNvbWUgcGFydG5lcnMgcGFzdCB0aGUgY2FwLCBsZWF2aW5nIGxhdGVyIHNlYS1sYW5lXG4gKiAgICBwaGFzZXMgbm8gaGVhZHJvb20pLlxuICogMy4gUGFjayBleHRyYSByYW5kb20gZWRnZXMgdXAgdG8gdGhlIGNhcC4gRXZlcnkgbm9kZSBpcyBhdCBkZWdyZWUg4omlIDIsXG4gKiAgICBzbyBoZWFkcm9vbSBhbHdheXMgZXhpc3RzIGZvciByYW5kb20gcGFpcnMuXG4gKi9cbmZ1bmN0aW9uIGJ1aWxkQm9yZGVycyhcbiAgcm5nOiBEZXRlcm1pbmlzdGljUm5nLFxuICBwcm92aW5jZUlkczogcmVhZG9ubHkgc3RyaW5nW10sXG4gIG1heERlZ3JlZTogbnVtYmVyLFxuKTogTWFwPHN0cmluZywgU2V0PHN0cmluZz4+IHtcbiAgY29uc3QgbiA9IHByb3ZpbmNlSWRzLmxlbmd0aDtcbiAgY29uc3QgYWRqID0gbmV3IE1hcDxzdHJpbmcsIFNldDxzdHJpbmc+Pihwcm92aW5jZUlkcy5tYXAoKGlkKSA9PiBbaWQsIG5ldyBTZXQ8c3RyaW5nPigpXSkpO1xuXG4gIGlmIChuID09PSAxKSByZXR1cm4gYWRqOyAvLyBzaW5nbGUtcHJvdmluY2UgaXNsYW5kOiBubyBib3JkZXJzXG4gIGlmIChuID09PSAyKSB7XG4gICAgYWRqLmdldChwcm92aW5jZUlkc1swXSEpIS5hZGQocHJvdmluY2VJZHNbMV0hKTtcbiAgICBhZGouZ2V0KHByb3ZpbmNlSWRzWzFdISkhLmFkZChwcm92aW5jZUlkc1swXSEpO1xuICAgIHJldHVybiBhZGo7IC8vIG9uZSBlZGdlOiBib3RoIGF0IGRlZ3JlZSAxOyBpc2xhbmQtMiBpcyBub3QgaW4gSVNMQU5EX1NJWkVTIGJ1dCBndWFyZCB0aGUgY2FzZS5cbiAgfVxuXG4gIC8vIFN0ZXAgMTogcmFuZG9tIHNwYW5uaW5nIHRyZWUgKGd1YXJhbnRlZXMgY29ubmVjdGl2aXR5LCBldmVyeSBub2RlIOKJpSAxKS5cbiAgLy8gUGljayBlYWNoIGNoaWxkJ3MgcGFyZW50IG9ubHkgZnJvbSBlYXJsaWVyIG5vZGVzIHdob3NlIGRlZ3JlZSBpcyBzdGlsbFxuICAvLyBiZWxvdyBgbWF4RGVncmVlYCwgc28gdGhlIHRyZWUgaXRzZWxmIGNhbiBuZXZlciBwcm9kdWNlIGEgaHViIHBhc3QgdGhlXG4gIC8vIGNhcC4gKFdpdGhvdXQgdGhpcyBmaWx0ZXIsIGEgcmFuZG9tIHRyZWUgb24gYSBzaXplLTEwIGlzbGFuZCBjYW4gZ2l2ZVxuICAvLyBvbmUgbm9kZSBkZWdyZWUgNSssIHdoaWNoIGlzIHdoYXQgdGhlIHNlZWQtMTIgLyBzZWVkLTQ1IGJ1ZyBleHBsb2l0ZWQ6XG4gIC8vIHRoZSB0cmVlIHN0ZXAgb3ZlcnNob3QsIFN0ZXAgMiAoc3RyYWdnbGVyIGZpeCkgb25seSByYWlzZXMgbm9kZXNcbiAgLy8gYWxyZWFkeSBhdCBkZWdyZWUgPCAyLCBhbmQgU3RlcCAzIChwYWNrKSByZXNwZWN0cyB0aGUgY2FwIHNvIHRoZSBodWJcbiAgLy8gc3R1Y2sgYWJvdmUgbWF4RGVncmVlIGZvcmV2ZXIuKVxuICBjb25zdCBvcmRlciA9IHNodWZmbGVkKHJuZywgWy4uLnByb3ZpbmNlSWRzXSk7XG4gIGZvciAobGV0IGkgPSAxOyBpIDwgb3JkZXIubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBjaGlsZCA9IG9yZGVyW2ldITtcbiAgICAvLyBhdHRhY2ggdG8gYW4gZWFybGllciBub2RlIHdpdGggaGVhZHJvb20gKHBhcmVudCBkZWdyZWUgPCBtYXhEZWdyZWUpXG4gICAgY29uc3QgaGVhZHJvb21QYXJlbnRzID0gb3JkZXIuc2xpY2UoMCwgaSkuZmlsdGVyKChwKSA9PiBhZGouZ2V0KHApIS5zaXplIDwgbWF4RGVncmVlKTtcbiAgICBsZXQgcGFyZW50OiBzdHJpbmc7XG4gICAgaWYgKGhlYWRyb29tUGFyZW50cy5sZW5ndGggPiAwKSB7XG4gICAgICBwYXJlbnQgPSBoZWFkcm9vbVBhcmVudHNbcm5nLm5leHRJbnQoMCwgaGVhZHJvb21QYXJlbnRzLmxlbmd0aCAtIDEpXSE7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIERlZmVuc2l2ZSBmYWxsYmFjazogb25seSByZWFjaGFibGUgd2hlbiBtYXhEZWdyZWUgPCAzLCB3aGljaCBuZXZlclxuICAgICAgLy8gaGFwcGVucyBpbiB0aGlzIGdlbmVyYXRvciAoQk9SREVSX01BWCDiiaUgMyBoZXJlKS5cbiAgICAgIHBhcmVudCA9IG9yZGVyW3JuZy5uZXh0SW50KDAsIGkgLSAxKV0hO1xuICAgIH1cbiAgICBhZGouZ2V0KHBhcmVudCkhLmFkZChjaGlsZCk7XG4gICAgYWRqLmdldChjaGlsZCkhLmFkZChwYXJlbnQpO1xuICB9XG5cbiAgY29uc3QgaWRzID0gWy4uLnByb3ZpbmNlSWRzXTtcblxuICAvLyBTdGVwIDI6IHJhaXNlIGRlZ3JlZS0xIG5vZGVzIHRvIGRlZ3JlZSDiiaUgMiB1c2luZyBwYXJ0bmVycyB3aXRoIGhlYWRyb29tLlxuICAvLyBUaGUgdHJlZSBsZWF2ZXMgYXQgbW9zdCBuLTEgbGVhdmVzOyBlYWNoIGhhcyBkZWdyZWUgMSwgYWxsIG90aGVyIG5vZGVzXG4gIC8vIGhhdmUgZGVncmVlIGluIFsxLCBtYXhEZWdyZWVdIChzb21lIHBvdGVudGlhbGx5IGF0IHRoZSBjYXApLCBzbyB0aGVcbiAgLy8gcGFydG5lciBwb29sIGlzIGFsbW9zdCBhbHdheXMgbm9uLWVtcHR5LiBXZSBsb29wIGFuZCBicmVhayBvbmx5IHdoZW5cbiAgLy8gZXZlcnkgbm9kZSBpcyBhdCBkZWdyZWUg4omlIDIgb3IgdGhlIHBhcnRuZXIgcG9vbCBpcyBleGhhdXN0ZWQuXG4gIGxldCBzdHJhZ2dsZXJQYXNzZXMgPSAwO1xuICBjb25zdCBNQVhfU1RSQUdHTEVSX1BBU1NFUyA9IDUwO1xuICBsZXQgcmVtYWluaW5nU3RyYWdnbGVycyA9IGlkcy5maWx0ZXIoKGlkKSA9PiBhZGouZ2V0KGlkKSEuc2l6ZSA8IDIpO1xuICB3aGlsZSAocmVtYWluaW5nU3RyYWdnbGVycy5sZW5ndGggPiAwICYmIHN0cmFnZ2xlclBhc3NlcyA8IE1BWF9TVFJBR0dMRVJfUEFTU0VTKSB7XG4gICAgc3RyYWdnbGVyUGFzc2VzKys7XG4gICAgbGV0IHByb2dyZXNzID0gZmFsc2U7XG4gICAgZm9yIChjb25zdCBpZCBvZiByZW1haW5pbmdTdHJhZ2dsZXJzKSB7XG4gICAgICBpZiAoYWRqLmdldChpZCkhLnNpemUgPj0gMikgY29udGludWU7XG4gICAgICBjb25zdCBwYXJ0bmVycyA9IGlkcy5maWx0ZXIoXG4gICAgICAgIChwKSA9PiBwICE9PSBpZCAmJiAhYWRqLmdldChpZCkhLmhhcyhwKSAmJiBhZGouZ2V0KHApIS5zaXplIDwgbWF4RGVncmVlLFxuICAgICAgKTtcbiAgICAgIGlmIChwYXJ0bmVycy5sZW5ndGggPT09IDApIGNvbnRpbnVlO1xuICAgICAgY29uc3QgcGFydG5lciA9IHBhcnRuZXJzW3JuZy5uZXh0SW50KDAsIHBhcnRuZXJzLmxlbmd0aCAtIDEpXSE7XG4gICAgICBhZGouZ2V0KGlkKSEuYWRkKHBhcnRuZXIpO1xuICAgICAgYWRqLmdldChwYXJ0bmVyKSEuYWRkKGlkKTtcbiAgICAgIHByb2dyZXNzID0gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKCFwcm9ncmVzcykgYnJlYWs7XG4gICAgcmVtYWluaW5nU3RyYWdnbGVycyA9IGlkcy5maWx0ZXIoKGlkKSA9PiBhZGouZ2V0KGlkKSEuc2l6ZSA8IDIpO1xuICB9XG5cbiAgLy8gU3RlcCAzOiBwYWNrIGV4dHJhIHJhbmRvbSBlZGdlcyB1cCB0byB0aGUgY2FwLiBFdmVyeSBub2RlIGlzIGF0IGRlZ3JlZVxuICAvLyDiiaUgMiB3aXRoIGF0IGxlYXN0IG9uZSB1bnNhdHVyYXRlZCBwYXJ0bmVyIChvciBmdWxseSBzYXR1cmF0ZWQsIGluIHdoaWNoXG4gIC8vIGNhc2UgdGhlIHJhbmRvbSBwaWNrIG5hdHVyYWxseSBza2lwcykuXG4gIGNvbnN0IE1BWF9QQUNLX0FUVEVNUFRTID0gbiAqIDIwMDtcbiAgZm9yIChsZXQgYXR0ZW1wdCA9IDA7IGF0dGVtcHQgPCBNQVhfUEFDS19BVFRFTVBUUzsgYXR0ZW1wdCsrKSB7XG4gICAgY29uc3QgYSA9IGlkc1tybmcubmV4dEludCgwLCBuIC0gMSldITtcbiAgICBjb25zdCBiID0gaWRzW3JuZy5uZXh0SW50KDAsIG4gLSAxKV0hO1xuICAgIGlmIChhID09PSBiKSBjb250aW51ZTtcbiAgICBpZiAoYWRqLmdldChhKSEuc2l6ZSA+PSBtYXhEZWdyZWUpIGNvbnRpbnVlO1xuICAgIGlmIChhZGouZ2V0KGIpIS5zaXplID49IG1heERlZ3JlZSkgY29udGludWU7XG4gICAgaWYgKGFkai5nZXQoYSkhLmhhcyhiKSkgY29udGludWU7XG4gICAgYWRqLmdldChhKSEuYWRkKGIpO1xuICAgIGFkai5nZXQoYikhLmFkZChhKTtcbiAgfVxuXG4gIHJldHVybiBhZGo7XG59XG5cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gTWFpbiBnZW5lcmF0b3Jcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4vKipcbiAqIEludGVybmFsLCB0ZXN0LW9ubHkgb2JzZXJ2YXRpb24gb2Ygb25lIGBnZW5lcmF0ZUJvYXJkQm9keWAgcnVuLiAgTm90XG4gKiByZS1leHBvcnRlZCBmcm9tIGBzcmMvY29yZS9pbmRleC50c2AuICBUaGUgYm9keSBvbmx5IHdyaXRlcyB0byBpdC5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBCb2R5VHJhY2Uge1xuICAvKiogSXNsYW5kLWlkIHBhaXJzIGluIHRoZSBvcmRlciBQaGFzZSAxIHZpc2l0ZWQgdGhlbSAoYmVmb3JlIGFueSBza2lwKS4gKi9cbiAgcGhhc2UxUGFpcnM6IFtzdHJpbmcsIHN0cmluZ11bXTtcbiAgLyoqXG4gICAqIEVhY2ggUGhhc2UgMiBsYW5lIGtlcHQgb3IgdW5kb25lLCBpbiBvcmRlcjogdGhlIGlzbGFuZHMsIGFuZCBmb3IgZWFjaFxuICAgKiBlbmRwb2ludCB3aGV0aGVyIGl0cyBpc2xhbmQgd2FzIGFscmVhZHkgYXQgaXRzIGVudHJhbmNlIGNhcCB3aGVuIHRoZVxuICAgKiBsYW5lIHdhcyBhZGRlZCAoc28gdGhlIGxhbmUgaGFkIHRvIHJldXNlIGFuIGV4aXN0aW5nIGVudHJhbmNlKS5cbiAgICovXG4gIHBoYXNlMkxhbmVzOiB7XG4gICAgaXNsYW5kQTogc3RyaW5nO1xuICAgIGlzbGFuZEI6IHN0cmluZztcbiAgICBhdENhcEE6IGJvb2xlYW47XG4gICAgYXRDYXBCOiBib29sZWFuO1xuICB9W107XG59XG5cbi8qKlxuICogVGhlIHN0cnVjdHVyYWwgaW52YXJpYW50cyBldmVyeSBib2FyZCB0aGUgZ2VuZXJhdG9yIGFjY2VwdHMgbXVzdCBtZWV0LCByZWFkXG4gKiBmcm9tIHRoZSBmaW5pc2hlZCBtYXA6IHByb3ZpbmNlIGRlZ3JlZSBpbiBbREVHUkVFX01JTiwgREVHUkVFX01BWF0gYW5kXG4gKiBleGFjdGx5IFNFQV9MQU5FX0NPVU5UIGxhbmVzIChDLUJSRC0wNCksIGEgY29ubmVjdGVkIGdyYXBoIChDLUJSRC0wNCksXG4gKiBhbmQgYXQgbGVhc3QgTUlOX0VOVFJBTkNFU19QRVJfSVNMQU5EIGVudHJhbmNlcyBwZXIgaXNsYW5kIChDLUJSRC0wMSkuXG4gKiBSZXR1cm5zIHRoZSB2aW9sYXRpb25zOyBhbiBlbXB0eSBsaXN0IG1lYW5zIHRoZSBtYXAgaXMgYWNjZXB0ZWQuXG4gKlxuICogSW50ZXJuYWw6IGV4cG9ydGVkIGZyb20gdGhpcyBtb2R1bGUgZm9yIHRlc3RzIChSMywgcm91bmQgMyksIG5ldmVyXG4gKiByZS1leHBvcnRlZCBmcm9tIGBzcmMvY29yZS9pbmRleC50c2AuICBUaGUgcmV0cnkgbG9vcFxuICogKGBnZW5lcmF0ZUJvYXJkSW50ZXJuYWxgKSBydW5zIGl0IG9uIGV2ZXJ5IG1hcCBhIGJvZHkgcmV0dXJucywgYmVmb3JlIHRoZVxuICogZmFpcm5lc3MgY2hlY2tzIChyb3VuZCA0LCBSMSkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzdHJ1Y3R1cmFsRXJyb3JzKG1hcDogR2FtZU1hcCk6IHN0cmluZ1tdIHtcbiAgY29uc3QgZXJyb3JzOiBzdHJpbmdbXSA9IFtdO1xuICBjb25zdCB7IHByb3ZpbmNlcyB9ID0gbWFwO1xuXG4gIC8vIERlZ3JlZSBjaGVjayAoQy1CUkQtMDQpXG4gIGZvciAoY29uc3QgcCBvZiBwcm92aW5jZXMpIHtcbiAgICBjb25zdCBkZWcgPSBwLmJvcmRlcnMubGVuZ3RoICsgcC5zZWFMYW5lcy5sZW5ndGg7XG4gICAgaWYgKGRlZyA8IERFR1JFRV9NSU4gfHwgZGVnID4gREVHUkVFX01BWCkge1xuICAgICAgZXJyb3JzLnB1c2goYHByb3ZpbmNlICcke3AuaWR9JyBoYXMgZGVncmVlICR7ZGVnfSwgb3V0c2lkZSBbJHtERUdSRUVfTUlOfSwgJHtERUdSRUVfTUFYfV1gKTtcbiAgICB9XG4gIH1cblxuICAvLyBTZWEgbGFuZSBjb3VudCBjaGVjayAoQy1CUkQtMDQpXG4gIGNvbnN0IHVuZGlyZWN0ZWRTZWFMYW5lcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBmb3IgKGNvbnN0IHAgb2YgcHJvdmluY2VzKSB7XG4gICAgZm9yIChjb25zdCB0IG9mIHAuc2VhTGFuZXMpIHtcbiAgICAgIGNvbnN0IGtleSA9IHAuaWQgPCB0ID8gYCR7cC5pZH18JHt0fWAgOiBgJHt0fXwke3AuaWR9YDtcbiAgICAgIHVuZGlyZWN0ZWRTZWFMYW5lcy5hZGQoa2V5KTtcbiAgICB9XG4gIH1cbiAgaWYgKHVuZGlyZWN0ZWRTZWFMYW5lcy5zaXplICE9PSBTRUFfTEFORV9DT1VOVClcbiAgICBlcnJvcnMucHVzaChgaGFzICR7dW5kaXJlY3RlZFNlYUxhbmVzLnNpemV9IHVuZGlyZWN0ZWQgc2VhIGxhbmVzLCBleHBlY3RlZCAke1NFQV9MQU5FX0NPVU5UfWApO1xuXG4gIC8vIENvbm5lY3Rpdml0eSBjaGVjayAoQy1CUkQtMDQpXG4gIGNvbnN0IGJ5SWQgPSBuZXcgTWFwKHByb3ZpbmNlcy5tYXAoKHApID0+IFtwLmlkLCBwXSkpO1xuICBpZiAocHJvdmluY2VzLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBzZWVuID0gbmV3IFNldDxzdHJpbmc+KFtwcm92aW5jZXNbMF0hLmlkXSk7XG4gICAgY29uc3QgcXVldWUgPSBbcHJvdmluY2VzWzBdIS5pZF07XG4gICAgd2hpbGUgKHF1ZXVlLmxlbmd0aCA+IDApIHtcbiAgICAgIGNvbnN0IGN1cnJlbnQgPSBxdWV1ZS5zaGlmdCgpITtcbiAgICAgIGNvbnN0IHByb3YgPSBieUlkLmdldChjdXJyZW50KTtcbiAgICAgIGlmICghcHJvdikgY29udGludWU7XG4gICAgICBmb3IgKGNvbnN0IG4gb2YgWy4uLnByb3YuYm9yZGVycywgLi4ucHJvdi5zZWFMYW5lc10pIHtcbiAgICAgICAgaWYgKCFzZWVuLmhhcyhuKSkge1xuICAgICAgICAgIHNlZW4uYWRkKG4pO1xuICAgICAgICAgIHF1ZXVlLnB1c2gobik7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHNlZW4uc2l6ZSAhPT0gcHJvdmluY2VzLmxlbmd0aClcbiAgICAgIGVycm9ycy5wdXNoKGBncmFwaCBoYXMgJHtzZWVuLnNpemV9IHJlYWNoYWJsZSBwcm92aW5jZXMsIGV4cGVjdGVkICR7cHJvdmluY2VzLmxlbmd0aH1gKTtcbiAgfVxuXG4gIC8vIEVudHJhbmNlIG1pbmltdW0gKEMtQlJELTAxLCBhbnRpLWZvcnRyZXNzKS4gIEFuIGVudHJhbmNlIGlzIGEgcHJvdmluY2VcbiAgLy8gd2l0aCBhIHNlYSBsYW5lIHRvIGFub3RoZXIgaXNsYW5kLiAgUGhhc2UgMidzIHNjb3JpbmcgYWltcyBmb3IgdGhpc1xuICAvLyBtaW5pbXVtOyB0aGlzIGd1YXJkIHJlZnVzZXMgYW55IG1hcCB0aGF0IHN0aWxsIG1pc3NlcyBpdCwgc28gdGhlIHJldHJ5XG4gIC8vIGxvb3AgbmV2ZXIgcmVsaWVzIG9uIGNoZWNrRm9ydHJlc3MgYWxvbmUuXG4gIGNvbnN0IGJlbG93OiBzdHJpbmdbXSA9IFtdO1xuICBmb3IgKGNvbnN0IGlzbGFuZCBvZiBtYXAuaXNsYW5kcykge1xuICAgIGxldCBlbnRyYW5jZXMgPSAwO1xuICAgIGZvciAoY29uc3QgcGlkIG9mIGlzbGFuZC5wcm92aW5jZXMpIHtcbiAgICAgIGNvbnN0IHAgPSBieUlkLmdldChwaWQpO1xuICAgICAgaWYgKHAgJiYgcC5zZWFMYW5lcy5zb21lKCh0KSA9PiBieUlkLmdldCh0KT8uaXNsYW5kICE9PSBpc2xhbmQuaWQpKSBlbnRyYW5jZXMrKztcbiAgICB9XG4gICAgaWYgKGVudHJhbmNlcyA8IE1JTl9FTlRSQU5DRVNfUEVSX0lTTEFORCkgYmVsb3cucHVzaChgJHtpc2xhbmQuaWR9PSR7ZW50cmFuY2VzfWApO1xuICB9XG4gIGlmIChiZWxvdy5sZW5ndGggPiAwKSB7XG4gICAgZXJyb3JzLnB1c2goXG4gICAgICBgaXNsYW5kIGVudHJhbmNlIG1pbmltdW0gbm90IG1ldDogJHtiZWxvdy5qb2luKFwiLCBcIil9IChuZWVkID49ICR7TUlOX0VOVFJBTkNFU19QRVJfSVNMQU5EfSlgLFxuICAgICk7XG4gIH1cblxuICByZXR1cm4gZXJyb3JzO1xufVxuXG4vKipcbiAqIElubmVyIGdlbmVyYXRvciBib2R5LiAgVGFrZXMgYSBsaXZlIGBEZXRlcm1pbmlzdGljUm5nYCAoYWxyZWFkeSBzZWVkZWQgYnlcbiAqIHRoZSBjYWxsZXIpIGFuZCBwcm9kdWNlcyBlaXRoZXIgYSBidWlsdCBgR2FtZU1hcGAgb3IgdGhlIGxpc3Qgb2YgZXJyb3JzXG4gKiB0aGF0IHN0b3BwZWQgaXQgKGlzbGFuZCBzaXplcywgbGFuZXMgaXQgY291bGQgbm90IHBsYWNlKS4gIE5laXRoZXIgdGhlXG4gKiBzdHJ1Y3R1cmFsIGFjY2VwdGFuY2Ugc3RlcCBub3IgdGhlIGZhaXJuZXNzIGNoZWNrcyBydW4gaGVyZTsgYm90aCBydW4gb25cbiAqIGl0cyBtYXAgaW4gdGhlIHJldHJ5IGxvb3AgYmVsb3cuXG4gKlxuICogSW50ZXJuYWw6IGV4cG9ydGVkIGZyb20gdGhpcyBtb2R1bGUgZm9yIHRlc3RzLCBuZXZlciByZS1leHBvcnRlZCBmcm9tXG4gKiBgc3JjL2NvcmUvaW5kZXgudHNgLiAgVGhlIG9wdGlvbmFsIGB0cmFjZWAgaXMgZmlsbGVkIHdpdGggb2JzZXJ2YXRpb25zXG4gKiBvZiB0aGlzIHJ1biAoc2VlIGBCb2R5VHJhY2VgKTsgaXQgbmV2ZXIgY2hhbmdlcyB3aGF0IHRoZSBib2R5IGRvZXMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZW5lcmF0ZUJvYXJkQm9keShybmc6IERldGVybWluaXN0aWNSbmcsIHRyYWNlPzogQm9keVRyYWNlKTogQm9hcmRHZW5SZXN1bHQge1xuICBjb25zdCBlcnJvcnM6IHN0cmluZ1tdID0gW107XG5cbiAgLy8gLS0tLSBBc3NpZ24gcHJvdmluY2UgSURzIHRvIGlzbGFuZHMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIGNvbnN0IHNodWZmbGVkUHJvdmluY2VJZHMgPSBzaHVmZmxlZChybmcsIEFycmF5LmZyb20oeyBsZW5ndGg6IDQ2IH0sIChfLCBpKSA9PiBgcHJvdmluY2VfJHtpfWApKTtcbiAgY29uc3QgaXNsYW5kU3RydWN0czogeyBpZDogc3RyaW5nOyBuYW1lOiBzdHJpbmc7IHNpemU6IG51bWJlcjsgcHJvdmluY2VJZHM6IHN0cmluZ1tdIH1bXSA9IFtdO1xuICBsZXQgY3Vyc29yID0gMDtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBJU0xBTkRfU0laRVMubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBzaXplID0gSVNMQU5EX1NJWkVTW2ldITtcbiAgICBpc2xhbmRTdHJ1Y3RzLnB1c2goe1xuICAgICAgaWQ6IGBpc2xhbmRfJHtpfWAsXG4gICAgICBuYW1lOiBJU0xBTkRfTkFNRVNbaV0gPz8gYElzbGUgJHtpfWAsXG4gICAgICBzaXplLFxuICAgICAgcHJvdmluY2VJZHM6IHNodWZmbGVkUHJvdmluY2VJZHMuc2xpY2UoY3Vyc29yLCBjdXJzb3IgKyBzaXplKSxcbiAgICB9KTtcbiAgICBjdXJzb3IgKz0gc2l6ZTtcbiAgfVxuICBpZiAoY3Vyc29yICE9PSA0NikgZXJyb3JzLnB1c2goYGlzbGFuZCBzaXplcyBzdW0gdG8gJHtjdXJzb3J9LCBleHBlY3RlZCA0NmApO1xuXG4gIC8vIC0tLS0gQnVpbGQgd2l0aGluLWlzbGFuZCBib3JkZXJzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIENhcHBpbmcgYXQgQk9SREVSX01BWCAoPSBERUdSRUVfTUFYIC0gMikgcmVzZXJ2ZXMgdHdvIGRlZ3JlZSBzbG90cyBwZXJcbiAgLy8gcHJvdmluY2UgZm9yIHNlYSBsYW5lczsgb3RoZXJ3aXNlIGJ1aWxkQm9yZGVycyBwYWNrcyBzb21lIHByb3ZpbmNlcyB0b1xuICAvLyBERUdSRUVfTUFYIGFuZCBsZWF2ZXMgUGhhc2UgMSB1bmFibGUgdG8gZmluZCBhIHNwYW5uaW5nLXRyZWUgZW5kcG9pbnRcbiAgLy8gKHNhdHVyYXRpb247IHNlZSBCT1JERVJfTUFYIGFib3ZlKS5cbiAgY29uc3QgYWxsQm9yZGVycyA9IG5ldyBNYXA8c3RyaW5nLCBTZXQ8c3RyaW5nPj4oKTtcbiAgZm9yIChjb25zdCBpc2xhbmQgb2YgaXNsYW5kU3RydWN0cykge1xuICAgIGNvbnN0IGFkaiA9IGJ1aWxkQm9yZGVycyhybmcsIGlzbGFuZC5wcm92aW5jZUlkcywgQk9SREVSX01BWCk7XG4gICAgZm9yIChjb25zdCBbaWQsIG5laWdoYm91cnNdIG9mIGFkaikge1xuICAgICAgaWYgKCFhbGxCb3JkZXJzLmhhcyhpZCkpIGFsbEJvcmRlcnMuc2V0KGlkLCBuZXcgU2V0PHN0cmluZz4oKSk7XG4gICAgICBmb3IgKGNvbnN0IG4gb2YgbmVpZ2hib3VycykgYWxsQm9yZGVycy5nZXQoaWQpIS5hZGQobik7XG4gICAgfVxuICB9XG5cbiAgLy8gLS0tLSBBZGQgaW50ZXItaXNsYW5kIHNlYSBsYW5lcyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIEMtQlJELTAxOiBzZWEgbGFuZXMgYXJlIGFsd2F5cyBiZXR3ZWVuIGRpZmZlcmVudCBpc2xhbmRzLlxuICAvLyBQaGFzZSAxOiBidWlsZCBhIGd1YXJhbnRlZWQgc3Bhbm5pbmcgdHJlZSBzbyB0aGUgZ3JhcGggaXMgYWx3YXlzIGNvbm5lY3RlZC5cbiAgLy8gUGhhc2UgMjogZmlsbCByZW1haW5pbmcgc2xvdHMgcmFuZG9tbHkgdXAgdG8gU0VBX0xBTkVfQ09VTlQuXG4gIGNvbnN0IGFsbFNlYUxhbmVzID0gbmV3IE1hcDxzdHJpbmcsIFNldDxzdHJpbmc+PigpO1xuICBmb3IgKGNvbnN0IGlkIG9mIHNodWZmbGVkUHJvdmluY2VJZHMpIHtcbiAgICBhbGxTZWFMYW5lcy5zZXQoaWQsIG5ldyBTZXQ8c3RyaW5nPigpKTtcbiAgfVxuXG4gIC8vIFRyYWNrIGlzbGFuZC1ncmFwaCBkZWdyZWUgYXMgRElTVElOQ1QgaXNsYW5kIG5laWdoYm91cnMgcGVyIGlzbGFuZC5cbiAgLy8gUjExIChyZXdvcmsgcm91bmQsIFNvbCAyMDI2LTEwLTEzKTogdGhlIHByZXZpb3VzIHJvdW5kIHRyYWNrZWQgdGhlXG4gIC8vIHRvdGFsIGxhbmUgY291bnQsIG5vdCBkaXN0aW5jdCBuZWlnaGJvdXJzLiAgQSBzaXplLTEwIGlzbGFuZCB3aXRoXG4gIC8vIDUgbGFuZXMgYWxsIGdvaW5nIHRvIHRoZSBzYW1lIDMgb3RoZXIgaXNsYW5kcyBoYWRcbiAgLy8gYGlzbGFuZERlZ3JlZSA9IDVgIGV2ZW4gdGhvdWdoIHRoZSBpc2xhbmQtZ3JhcGggZGVncmVlIHdhcyBvbmx5IDMuXG4gIC8vIEZpeDogdHJhY2sgZGlzdGluY3QgbmVpZ2hib3VycyBhcyBhIFNldCwgZGVyaXZlIHRoZSBjb3VudCB2aWFcbiAgLy8gYGlzbGFuZERlZ3JlZU9mKGlkKWAgd2hlbiBjb21wYXJpbmcgdG8gTUFYX0lTTEFORF9HUkFQSF9ERUdSRUUuXG4gIGNvbnN0IGlzbGFuZE5laWdoYm91cnMgPSBuZXcgTWFwPHN0cmluZywgU2V0PHN0cmluZz4+KFxuICAgIGlzbGFuZFN0cnVjdHMubWFwKChpc2wpID0+IFtpc2wuaWQsIG5ldyBTZXQ8c3RyaW5nPigpXSksXG4gICk7XG5cbiAgZnVuY3Rpb24gaXNsYW5kRGVncmVlT2YoaXNsYW5kSWQ6IHN0cmluZyk6IG51bWJlciB7XG4gICAgcmV0dXJuIGlzbGFuZE5laWdoYm91cnMuZ2V0KGlzbGFuZElkKT8uc2l6ZSA/PyAwO1xuICB9XG5cbiAgZnVuY3Rpb24gYWRkTmVpZ2hib3VyKGlzbGFuZEE6IHN0cmluZywgaXNsYW5kQjogc3RyaW5nKSB7XG4gICAgaXNsYW5kTmVpZ2hib3Vycy5nZXQoaXNsYW5kQSk/LmFkZChpc2xhbmRCKTtcbiAgICBpc2xhbmROZWlnaGJvdXJzLmdldChpc2xhbmRCKT8uYWRkKGlzbGFuZEEpO1xuICB9XG5cbiAgZnVuY3Rpb24gcmVtb3ZlTmVpZ2hib3VyKGlzbGFuZEE6IHN0cmluZywgaXNsYW5kQjogc3RyaW5nKSB7XG4gICAgaXNsYW5kTmVpZ2hib3Vycy5nZXQoaXNsYW5kQSk/LmRlbGV0ZShpc2xhbmRCKTtcbiAgICBpc2xhbmROZWlnaGJvdXJzLmdldChpc2xhbmRCKT8uZGVsZXRlKGlzbGFuZEEpO1xuICB9XG5cbiAgLy8gVHJhY2sgZGlzdGluY3QgcHJvdmluY2VzIHBlciBpc2xhbmQgdGhhdCBoYXZlIGF0IGxlYXN0IG9uZSBzZWEgbGFuZSB0byBhbm90aGVyIGlzbGFuZC5cbiAgLy8gVXNlZCB0byBlbmZvcmNlIE1BWF9FTlRSQU5DRVNfQllfU0laRSBhbmQgTUlOX0VOVFJBTkNFU19QRVJfSVNMQU5ELlxuICBjb25zdCBpc2xhbmRFbnRyYW5jZUNvdW50ID0gbmV3IE1hcDxzdHJpbmcsIG51bWJlcj4oaXNsYW5kU3RydWN0cy5tYXAoKGlzbCkgPT4gW2lzbC5pZCwgMF0pKTtcblxuICAvKiogUmVjb3JkIHRoYXQgcHJvdmluY2UgYHByb3ZgIG5vdyBoYXMgYSBzZWEgbGFuZSB0byBhbm90aGVyIGlzbGFuZC4gKi9cbiAgZnVuY3Rpb24gcmVjb3JkRW50cmFuY2UocHJvdjogc3RyaW5nKSB7XG4gICAgY29uc3QgaXNsID0gaXNsYW5kU3RydWN0cy5maW5kKChzKSA9PiBbLi4ucy5wcm92aW5jZUlkc10uaW5jbHVkZXMocHJvdikpO1xuICAgIGlmICghaXNsKSByZXR1cm47XG4gICAgY29uc3QgZXhpc3RpbmcgPSBhbGxTZWFMYW5lcy5nZXQocHJvdikhLnNpemU7XG4gICAgaWYgKGV4aXN0aW5nID09PSAxKSB7XG4gICAgICAvLyBGaXJzdCBzZWEgbGFuZSBmb3IgdGhpcyBwcm92aW5jZSDihpIgdGhpcyBpc2xhbmQgZ2FpbnMgYW4gZW50cmFuY2VcbiAgICAgIGlzbGFuZEVudHJhbmNlQ291bnQuc2V0KGlzbC5pZCwgKGlzbGFuZEVudHJhbmNlQ291bnQuZ2V0KGlzbC5pZCkgPz8gMCkgKyAxKTtcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBlbnRyYW5jZUNhcE9mKGlzbGFuZElkOiBzdHJpbmcpOiBudW1iZXIge1xuICAgIHJldHVybiBNQVhfRU5UUkFOQ0VTX0JZX1NJWkVbaXNsYW5kU3RydWN0cy5maW5kKChzKSA9PiBzLmlkID09PSBpc2xhbmRJZCk/LnNpemUgPz8gMF0gPz8gOTk7XG4gIH1cblxuICBmdW5jdGlvbiBhdEVudHJhbmNlQ2FwKGlzbGFuZElkOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgICByZXR1cm4gKGlzbGFuZEVudHJhbmNlQ291bnQuZ2V0KGlzbGFuZElkKSA/PyAwKSA+PSBlbnRyYW5jZUNhcE9mKGlzbGFuZElkKTtcbiAgfVxuXG4gIC8qKiBUcnVlIHdoZW4gYSBsYW5lIG9uIGBwcm92YCB3b3VsZCBnaXZlIGBpc2xhbmRJZGAgYW4gZW50cmFuY2UgcGFzdCBpdHMgY2FwLiAqL1xuICBmdW5jdGlvbiB3b3VsZEV4Y2VlZEVudHJhbmNlQ2FwKHByb3Y6IHN0cmluZywgaXNsYW5kSWQ6IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgIHJldHVybiAoYWxsU2VhTGFuZXMuZ2V0KHByb3YpPy5zaXplID8/IDApID09PSAwICYmIGF0RW50cmFuY2VDYXAoaXNsYW5kSWQpO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoZSBwcm92aW5jZXMgb2YgYGlzbGAgdGhhdCBjYW4gdGFrZSBvbmUgbW9yZSBsYW5lOiBiZWxvdyB0aGUgbGFuZSBjYXAsXG4gICAqIGFuZCBub3QgYSBuZXcgZW50cmFuY2Ugb24gYW4gaXNsYW5kIGFscmVhZHkgYXQgaXRzIGVudHJhbmNlIGNhcC5cbiAgICovXG4gIGZ1bmN0aW9uIGxhbmVDYW5kaWRhdGVzKGlzbDogeyBpZDogc3RyaW5nOyBwcm92aW5jZUlkczogcmVhZG9ubHkgc3RyaW5nW10gfSk6IHN0cmluZ1tdIHtcbiAgICByZXR1cm4gaXNsLnByb3ZpbmNlSWRzLmZpbHRlcihcbiAgICAgIChwKSA9PlxuICAgICAgICAoYWxsU2VhTGFuZXMuZ2V0KHApPy5zaXplID8/IDApIDwgTUFYX0xBTkVTX1BFUl9DT1VOVFJZICYmICF3b3VsZEV4Y2VlZEVudHJhbmNlQ2FwKHAsIGlzbC5pZCksXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGQgYSBzZWEgbGFuZSBiZXR3ZWVuIHR3byBwcm92aW5jZXMgaWYgYWxsIGZvdXIgc3RydWN0dXJhbCBjb25zdHJhaW50cyBwZXJtaXQuXG4gICAqIFJldHVybnMgdHJ1ZSBvbiBzdWNjZXNzLlxuICAgKlxuICAgKiBDb25zdHJhaW50cyBlbmZvcmNlZCBoZXJlIChDLUJSRC0wMSk6XG4gICAqIDEuIE1BWF9MQU5FU19QRVJfQ09VTlRSWTogbmVpdGhlciBlbmRwb2ludCBwcm92aW5jZSBtYXkgYWxyZWFkeSBoYXZlIOKJpSAyIGxhbmVzLlxuICAgKiAyLiBNQVhfRU5UUkFOQ0VTX0JZX1NJWkU6IG5laXRoZXIgaXNsYW5kIG1heSBleGNlZWQgaXRzIGVudHJhbmNlIGNhcC5cbiAgICogMy4gTUFYX0lTTEFORF9HUkFQSF9ERUdSRUU6IG5laXRoZXIgaXNsYW5kIG1heSBleGNlZWQgZGVncmVlIDUgaW4gdGhlIGlzbGFuZCBncmFwaC5cbiAgICogNC4gREVHUkVFX01BWDogdG90YWwgZGVncmVlIChib3JkZXJzICsgbGFuZXMpIG9mIGVhY2ggZW5kcG9pbnQgc3RheXMg4omkIERFR1JFRV9NQVguXG4gICAqL1xuICBmdW5jdGlvbiB0cnlBZGRMYW5lKHByb3ZBOiBzdHJpbmcsIHByb3ZCOiBzdHJpbmcsIGlzbGFuZEE6IHN0cmluZywgaXNsYW5kQjogc3RyaW5nKTogYm9vbGVhbiB7XG4gICAgaWYgKCFjYW5BZGRMYW5lKHByb3ZBLCBwcm92QiwgaXNsYW5kQSwgaXNsYW5kQikpIHJldHVybiBmYWxzZTtcbiAgICBhbGxTZWFMYW5lcy5nZXQocHJvdkEpIS5hZGQocHJvdkIpO1xuICAgIGFsbFNlYUxhbmVzLmdldChwcm92QikhLmFkZChwcm92QSk7XG4gICAgYWRkTmVpZ2hib3VyKGlzbGFuZEEsIGlzbGFuZEIpO1xuICAgIHJlY29yZEVudHJhbmNlKHByb3ZBKTtcbiAgICByZWNvcmRFbnRyYW5jZShwcm92Qik7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cblxuICAvKiogVGhlIGZvdXIgY29uc3RyYWludHMgb2YgYHRyeUFkZExhbmVgLCB3aXRob3V0IGNvbW1pdHRpbmcgdGhlIGxhbmUuICovXG4gIGZ1bmN0aW9uIGNhbkFkZExhbmUocHJvdkE6IHN0cmluZywgcHJvdkI6IHN0cmluZywgaXNsYW5kQTogc3RyaW5nLCBpc2xhbmRCOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgICBpZiAoaXNsYW5kQSA9PT0gaXNsYW5kQikgcmV0dXJuIGZhbHNlO1xuICAgIC8vIENvbnN0cmFpbnQgMTogcGVyLXByb3ZpbmNlIGxhbmUgY2FwXG4gICAgaWYgKChhbGxTZWFMYW5lcy5nZXQocHJvdkEpPy5zaXplID8/IDApID49IE1BWF9MQU5FU19QRVJfQ09VTlRSWSkgcmV0dXJuIGZhbHNlO1xuICAgIGlmICgoYWxsU2VhTGFuZXMuZ2V0KHByb3ZCKT8uc2l6ZSA/PyAwKSA+PSBNQVhfTEFORVNfUEVSX0NPVU5UUlkpIHJldHVybiBmYWxzZTtcbiAgICAvLyBDb25zdHJhaW50IDI6IHBlci1pc2xhbmQgZW50cmFuY2UgY2FwLiAgT25seSBhIHByb3ZpbmNlIHdpdGggbm8gbGFuZVxuICAgIC8vIHlldCB3b3VsZCBhZGQgYW4gZW50cmFuY2U7IG9uZSB0aGF0IGFscmVhZHkgaGFzIGEgbGFuZSBpcyBhbiBleGlzdGluZ1xuICAgIC8vIGVudHJhbmNlIGFuZCBtYXkgdGFrZSBhIHNlY29uZCBsYW5lIGV2ZW4gd2hlbiBpdHMgaXNsYW5kIGlzIGF0IGl0c1xuICAgIC8vIGNhcCAoUjkgZm9sbG93LXVwIG9mIFIxMSwgcm91bmQgMykuXG4gICAgaWYgKHdvdWxkRXhjZWVkRW50cmFuY2VDYXAocHJvdkEsIGlzbGFuZEEpKSByZXR1cm4gZmFsc2U7XG4gICAgaWYgKHdvdWxkRXhjZWVkRW50cmFuY2VDYXAocHJvdkIsIGlzbGFuZEIpKSByZXR1cm4gZmFsc2U7XG4gICAgLy8gQ29uc3RyYWludCAzOiBpc2xhbmQtZ3JhcGggZGVncmVlIGNhcCAoUjExOiBkaXN0aW5jdCBuZWlnaGJvdXJzKS5cbiAgICBpZiAoaXNsYW5kRGVncmVlT2YoaXNsYW5kQSkgPj0gTUFYX0lTTEFORF9HUkFQSF9ERUdSRUUpIHJldHVybiBmYWxzZTtcbiAgICBpZiAoaXNsYW5kRGVncmVlT2YoaXNsYW5kQikgPj0gTUFYX0lTTEFORF9HUkFQSF9ERUdSRUUpIHJldHVybiBmYWxzZTtcbiAgICAvLyBDb25zdHJhaW50IDQ6IERFR1JFRV9NQVhcbiAgICBjb25zdCBkZWdBID0gKGFsbEJvcmRlcnMuZ2V0KHByb3ZBKT8uc2l6ZSA/PyAwKSArIChhbGxTZWFMYW5lcy5nZXQocHJvdkEpPy5zaXplID8/IDApO1xuICAgIGNvbnN0IGRlZ0IgPSAoYWxsQm9yZGVycy5nZXQocHJvdkIpPy5zaXplID8/IDApICsgKGFsbFNlYUxhbmVzLmdldChwcm92Qik/LnNpemUgPz8gMCk7XG4gICAgaWYgKGRlZ0EgPj0gREVHUkVFX01BWCB8fCBkZWdCID49IERFR1JFRV9NQVgpIHJldHVybiBmYWxzZTtcbiAgICBpZiAoYWxsU2VhTGFuZXMuZ2V0KHByb3ZBKT8uaGFzKHByb3ZCKSkgcmV0dXJuIGZhbHNlO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG5cbiAgLyoqXG4gICAqIEV2ZXJ5IHByb3ZpbmNlIHBhaXIgKG9uZSBvbiBgc3JjYCwgb25lIG9uIGBkc3RgKSB0aGF0IGB0cnlBZGRMYW5lYFxuICAgKiB3b3VsZCBhY2NlcHQgbm93LiAgUm91bmQgNCAoU29sIFIyKTogUGhhc2UgMiBjb3VudHMgYW4gaXNsYW5kIHBhaXIgYXNcbiAgICogdmlhYmxlIG9ubHkgd2hlbiB0aGlzIGxpc3QgaXMgbm9uLWVtcHR5IGFuZCBwaWNrcyBpdHMgcHJvdmluY2VzIGZyb21cbiAgICogaXQsIHNvIGEgcGFzcyBuZXZlciBlbmRzIG9uIGEgcmVmdXNlZCBsYW5lOyB3aGVuIG5vIGlzbGFuZCBwYWlyIGhhc1xuICAgKiBzdWNoIGEgcHJvdmluY2UgcGFpciwgUGhhc2UgMiBiYWNrdHJhY2tzLlxuICAgKi9cbiAgZnVuY3Rpb24gYWRkYWJsZVByb3ZpbmNlUGFpcnMoXG4gICAgc3JjOiB7IGlkOiBzdHJpbmc7IHByb3ZpbmNlSWRzOiByZWFkb25seSBzdHJpbmdbXSB9LFxuICAgIGRzdDogeyBpZDogc3RyaW5nOyBwcm92aW5jZUlkczogcmVhZG9ubHkgc3RyaW5nW10gfSxcbiAgKTogW3N0cmluZywgc3RyaW5nXVtdIHtcbiAgICBjb25zdCBvdXQ6IFtzdHJpbmcsIHN0cmluZ11bXSA9IFtdO1xuICAgIGZvciAoY29uc3QgYSBvZiBsYW5lQ2FuZGlkYXRlcyhzcmMpKSB7XG4gICAgICBmb3IgKGNvbnN0IGIgb2YgbGFuZUNhbmRpZGF0ZXMoZHN0KSkge1xuICAgICAgICBpZiAoY2FuQWRkTGFuZShhLCBiLCBzcmMuaWQsIGRzdC5pZCkpIG91dC5wdXNoKFthLCBiXSk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBvdXQ7XG4gIH1cblxuICAvLyBQaGFzZSAxOiBidWlsZCBhIGJhbGFuY2VkIHNwYW5uaW5nIHRyZWUgdXNpbmcgS3J1c2thbCdzLXN0eWxlIHJhbmRvbVxuICAvLyBwYWlyIHNlbGVjdGlvbi4gIEdlbmVyYXRlIGFsbCBwb3NzaWJsZSBpc2xhbmQgcGFpcnMsIHNodWZmbGUsIHBpY2sgdGhlXG4gIC8vIGZpcnN0IDggdGhhdCBjb25uZWN0IGRpc3RpbmN0IGNvbXBvbmVudHMgd2hpbGUgcmVzcGVjdGluZ1xuICAvLyBNQVhfSVNMQU5EX0dSQVBIX0RFR1JFRSAodGhlIGNhcCBpcyBlbmZvcmNlZCBieSB0cnlBZGRMYW5lKS4gIFVubGlrZVxuICAvLyBQcmltJ3MgZnJvbSBhIGZpeGVkIHJvb3QsIHRoaXMgcHJvZHVjZXMgdHJlZXMgd2hlcmUgbm8gaXNsYW5kIGlzXG4gIC8vIHByZS1kaXNwb3NlZCB0byBiZSBhIGh1YiDigJQgZXZlcnkgaXNsYW5kIGhhcyB0aGUgc2FtZSBjaGFuY2Ugb2YgaGlnaFxuICAvLyBkZWdyZWUsIHdoaWNoIGxlYXZlcyBQaGFzZSAyIG1vcmUgaGVhZHJvb20uXG4gIGNvbnN0IGFsbFBhaXJzOiB7IGk6IG51bWJlcjsgajogbnVtYmVyIH1bXSA9IFtdO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGlzbGFuZFN0cnVjdHMubGVuZ3RoOyBpKyspIHtcbiAgICBmb3IgKGxldCBqID0gaSArIDE7IGogPCBpc2xhbmRTdHJ1Y3RzLmxlbmd0aDsgaisrKSB7XG4gICAgICBhbGxQYWlycy5wdXNoKHsgaSwgaiB9KTtcbiAgICB9XG4gIH1cbiAgLy8gUjcgKHJld29yayByb3VuZCwgU29sIDIwMjYtMTAtMTMpOiB0aGUgcHJldmlvdXMgcm91bmQgY2FsbGVkXG4gIC8vIGBzaHVmZmxlZChybmcsIGFsbFBhaXJzKWAgYW5kIGRpc2NhcmRlZCB0aGUgcmVzdWx0LiBUaGUgc2h1ZmZsZWRcbiAgLy8gY29weSBpcyBub3cgdXNlZCBiZWxvdyBpbiB0aGUgUGhhc2UgMSBsb29wLlxuXG4gIC8vIFVuaW9uLWZpbmQgZm9yIGNvbXBvbmVudHMuIGBjb21wUGFyZW50YCBhbHdheXMgaGFzIGBpc2xhbmRTdHJ1Y3RzLmxlbmd0aGBcbiAgLy8gZW50cmllcyBhbmQgaW5kaWNlcyBpbiBgWzAsIGxlbmd0aClgIGFyZSBhbHdheXMgc2V0LCBidXRcbiAgLy8gYG5vVW5jaGVja2VkSW5kZXhlZEFjY2Vzc2Agd2lkZW5zIHRoZSByZWFkIHRvIGBudW1iZXIgfCB1bmRlZmluZWRgXG4gIC8vIGV2ZW4gd2l0aCB0aGF0IGludmFyaWFudDsgdGhlIGAhYCBhc3NlcnRzIHRoZSB3ZWxsLWRlZmluZWQgcmVhZC5cbiAgY29uc3QgY29tcFBhcmVudDogbnVtYmVyW10gPSBBcnJheS5mcm9tKHsgbGVuZ3RoOiBpc2xhbmRTdHJ1Y3RzLmxlbmd0aCB9LCAoXywgaSkgPT4gaSk7XG4gIGZ1bmN0aW9uIGNvbXBGaW5kKHg6IG51bWJlcik6IG51bWJlciB7XG4gICAgcmV0dXJuIGNvbXBQYXJlbnRbeF0gPT09IHggPyB4IDogKGNvbXBQYXJlbnRbeF0hID0gY29tcEZpbmQoY29tcFBhcmVudFt4XSEpKTtcbiAgfVxuICBmdW5jdGlvbiBjb21wVW5pb24oYTogbnVtYmVyLCBiOiBudW1iZXIpIHtcbiAgICBjb25zdCByYSA9IGNvbXBGaW5kKGEpO1xuICAgIGNvbnN0IHJiID0gY29tcEZpbmQoYik7XG4gICAgaWYgKHJhICE9PSByYikgY29tcFBhcmVudFtyYV0gPSByYjtcbiAgfVxuXG4gIGxldCB0cmVlRWRnZXMgPSAwO1xuICAvLyBSNyAocmV3b3JrIHJvdW5kLCBTb2wgMjAyNi0xMC0xMyk6IHRoZSBwcmV2aW91cyByb3VuZCBjYWxsZWRcbiAgLy8gYHNodWZmbGVkKHJuZywgYWxsUGFpcnMpYCBidXQgZGlzY2FyZGVkIHRoZSByZXN1bHQgYW5kIGl0ZXJhdGVkXG4gIC8vIGBhbGxQYWlyc2AgZGlyZWN0bHkuICBUaGUgc3Bhbm5pbmcgdHJlZSB0aGVyZWZvcmUgYWx3YXlzXG4gIC8vIHRyYXZlcnNlZCBwYWlycyBpbiBmaXhlZCBsZXhpY29ncmFwaGljIG9yZGVyLCBhbmQgUGhhc2UgMSdzXG4gIC8vIFwicmFuZG9tIHNwYW5uaW5nIHRyZWVcIiB3YXMgZGV0ZXJtaW5pc3RpYyByZWdhcmRsZXNzIG9mIHRoZSBzZWVkLlxuICAvLyBGaXg6IGl0ZXJhdGUgdGhlIHNodWZmbGVkIGNvcHksIG5ldmVyIHRoZSBvcmlnaW5hbC5cbiAgY29uc3Qgc2h1ZmZsZWRQYWlycyA9IHNodWZmbGVkKHJuZywgYWxsUGFpcnMpO1xuICBmb3IgKGNvbnN0IHBhaXIgb2Ygc2h1ZmZsZWRQYWlycykge1xuICAgIGlmICh0cmVlRWRnZXMgPj0gaXNsYW5kU3RydWN0cy5sZW5ndGggLSAxKSBicmVhaztcbiAgICBjb25zdCBmcm9tSXNsYW5kID0gaXNsYW5kU3RydWN0c1twYWlyLmldIS5pZDtcbiAgICBjb25zdCB0b0lzbGFuZCA9IGlzbGFuZFN0cnVjdHNbcGFpci5qXSEuaWQ7XG4gICAgdHJhY2U/LnBoYXNlMVBhaXJzLnB1c2goW2Zyb21Jc2xhbmQsIHRvSXNsYW5kXSk7XG4gICAgaWYgKGNvbXBGaW5kKHBhaXIuaSkgPT09IGNvbXBGaW5kKHBhaXIuaikpIGNvbnRpbnVlOyAvLyBhbHJlYWR5IGNvbm5lY3RlZFxuICAgIGNvbnN0IGZyb20gPSBpc2xhbmRTdHJ1Y3RzW3BhaXIuaV0hO1xuICAgIGNvbnN0IHRvID0gaXNsYW5kU3RydWN0c1twYWlyLmpdITtcbiAgICBjb25zdCBwcm92QV9hcnIgPSBsYW5lQ2FuZGlkYXRlcyhmcm9tKTtcbiAgICBjb25zdCBwcm92Ql9hcnIgPSBsYW5lQ2FuZGlkYXRlcyh0byk7XG4gICAgaWYgKHByb3ZBX2Fyci5sZW5ndGggPT09IDAgfHwgcHJvdkJfYXJyLmxlbmd0aCA9PT0gMCkgY29udGludWU7XG4gICAgY29uc3QgcHJvdkEgPSBwcm92QV9hcnJbcm5nLm5leHRJbnQoMCwgcHJvdkFfYXJyLmxlbmd0aCAtIDEpXSE7XG4gICAgY29uc3QgcHJvdkIgPSBwcm92Ql9hcnJbcm5nLm5leHRJbnQoMCwgcHJvdkJfYXJyLmxlbmd0aCAtIDEpXSE7XG4gICAgaWYgKHRyeUFkZExhbmUocHJvdkEsIHByb3ZCLCBmcm9tSXNsYW5kLCB0b0lzbGFuZCkpIHtcbiAgICAgIGNvbXBVbmlvbihwYWlyLmksIHBhaXIuaik7XG4gICAgICB0cmVlRWRnZXMrKztcbiAgICB9XG4gIH1cblxuICAvLyBQaGFzZSAyOiBmaWxsIHJlbWFpbmluZyBzbG90cyB1cCB0byBTRUFfTEFORV9DT1VOVCwgd2hpbGUgYWxzbyBlbnN1cmluZ1xuICAvLyBldmVyeSBpc2xhbmQgcmVhY2hlcyBNSU5fRU5UUkFOQ0VTX1BFUl9JU0xBTkQgKGFudGktZm9ydHJlc3MpLlxuICAvL1xuICAvLyBUd28tcGhhc2UgYXBwcm9hY2ggKEMtQlJELTAxKTpcbiAgLy8gICAyQS4gQW50aS1mb3J0cmVzczogZm9yIGVhY2ggaXNsYW5kIHdpdGggPCBNSU5fRU5UUkFOQ0VTX1BFUl9JU0xBTkRcbiAgLy8gICAgICAgZW50cmFuY2VzLCBhZGQgYSBzZWEgbGFuZSBmcm9tIGEgcHJvdmluY2UgdGhhdCBjdXJyZW50bHkgaGFzXG4gIC8vICAgICAgIDAgbGFuZXMgKGEgTkVXIGVudHJhbmNlKSB0byBhIHByb3ZpbmNlIG9uIGEgZGlmZmVyZW50IGlzbGFuZFxuICAvLyAgICAgICB0aGF0IGhhcyBsYW5lIGhlYWRyb29tLlxuICAvLyAgIDJCLiBGaWxsOiB3aGlsZSBiZWxvdyBTRUFfTEFORV9DT1VOVCwgYWRkIHJhbmRvbSBsYW5lcyBiZXR3ZWVuIHZpYWJsZVxuICAvLyAgICAgICBwYWlycyB1bnRpbCB0aGUgY291bnQgaXMgcmVhY2hlZCBvciBubyB2aWFibGUgcGFpciBleGlzdHMuXG4gIC8vXG4gIC8vIEJvdGggcGhhc2VzIGVuZm9yY2UgdGhlIGZvdXIgY29uc3RyYWludHMgdmlhIHRyeUFkZExhbmUuXG4gIGxldCBzZWFMYW5lQ291bnQgPSBpc2xhbmRTdHJ1Y3RzLmxlbmd0aCAtIDE7IC8vIHNwYW5uaW5nIHRyZWUgdXNlZCB0aGlzIG1hbnkgbGFuZXNcbiAgbGV0IHBoYXNlMlBhc3NlcyA9IDA7XG4gIC8qKlxuICAgKiBDLUJSRC0wMSBbZGVzaWduZWRdOiBtYXhpbXVtIFBoYXNlIDIgcGFzc2VzIChvbmUgQy1CUkQtMDEgLyBmYWlybmVzc1xuICAgKiB0b3AtbGV2ZWwgcmV0cnkgY2FwID0gTUFYX0JPQVJEX0FUVEVNUFRTLCBidXQgUGhhc2UgMiBoYXMgaXRzIG93blxuICAgKiBpbm5lciBidWRnZXQpLiAgVGhlIG9yaWdpbmFsIFQwNWEgZ2VuZXJhdG9yIGhhZCBubyBQaGFzZSAyIGNhcDsgdGhlXG4gICAqIDUwMDAgdmFsdWUgd2FzIGNob3NlbiBlbXBpcmljYWxseSBvbiB0aGUgMjAwLXNlZWQgd2lkZSBzd2VlcDogYXRcbiAgICogY2FwPTUgd2Ugb2JzZXJ2ZWQgYWxsIDIwMCBzZWVkcyBjb21wbGV0ZSBQaGFzZSAyIGluIDwgMjAwIHBhc3Nlc1xuICAgKiAobG9ncyBub3QgcmV0YWluZWQ7IHRoZSB2YWx1ZSBpcyBhIHNhZmV0eSBib3VuZCwgbm90IGEgdHVuaW5nXG4gICAqIHBhcmFtZXRlcikuICBTZWFyY2hlZCBmb3IgcHVibGlzaGVkIGd1aWRhbmNlOiBub25lLlxuICAgKi9cbiAgY29uc3QgTUFYX1BIQVNFMl9QQVNTRVMgPSA1MDAwO1xuXG4gIC8vIFBoYXNlIDI6IGZpbGwgdG8gU0VBX0xBTkVfQ09VTlQgd2hpbGUgc2F0aXNmeWluZyB0aGUgZm91ciBzdHJ1Y3R1cmFsXG4gIC8vIGNvbnN0cmFpbnRzLiAgVGhlIHNjb3JpbmcgYmVsb3cgc3RlZXJzIGxhbmVzIHRvIGlzbGFuZHMgc3RpbGwgdW5kZXJcbiAgLy8gTUlOX0VOVFJBTkNFU19QRVJfSVNMQU5EOyBgc3RydWN0dXJhbEVycm9yc2AgcmVmdXNlcyBhbnkgZmluaXNoZWQgbWFwXG4gIC8vIHRoYXQgbWlzc2VzIHRoZSBtaW5pbXVtLlxuICAvL1xuICAvLyBBcHByb2FjaDogZ3JlZWR5ICsgYmFja3RyYWNraW5nLiAgRWFjaCBwYXNzIHBpY2tzIGEgdmlhYmxlIGlzbGFuZCBwYWlyLlxuICAvLyBXaGVuIG5vIHZpYWJsZSBwYWlyIHJlbWFpbnMsIHVuZG8gdGhlIG1vc3QgcmVjZW50IGxhbmUgYW5kIHRyeSBhXG4gIC8vIGRpZmZlcmVudCBsYW5lIGZyb20gdGhlIHNhbWUgc3RhdGUuICBUaGlzIGV4cGxvcmVzIG11bHRpcGxlIHBsYW5zIHdpdGhpblxuICAvLyB0aGUgc2FtZSBib2R5IGNhbGwuXG4gIHR5cGUgTGFuZVJlY29yZCA9IHtcbiAgICBwcm92QTogc3RyaW5nO1xuICAgIHByb3ZCOiBzdHJpbmc7XG4gICAgaXNsYW5kQTogc3RyaW5nO1xuICAgIGlzbGFuZEI6IHN0cmluZztcbiAgICBwcm92QU5ld0VudHJhbmNlOiBib29sZWFuO1xuICAgIHByb3ZCTmV3RW50cmFuY2U6IGJvb2xlYW47XG4gIH07XG4gIGNvbnN0IHBoYXNlMkhpc3Rvcnk6IExhbmVSZWNvcmRbXSA9IFtdO1xuICAvKipcbiAgICogQy1CUkQtMDEgW3JlbW92ZWRdOiB0aGUgcHJldmlvdXMgcm91bmQgaGFkIGBNQVhfUEhBU0UyX1VORE8gPSAyMDBgXG4gICAqIGJ1dCB0aGUgYm9keSB1bmNvbmRpdGlvbmFsbHkgYGJyZWFrYHMgYWZ0ZXIgdGhlIGZpcnN0IHVuZG8sIHNvXG4gICAqIHRoZSBib3VuZCBpcyBuZXZlciByZWFjaGVkLiAgUjEwIChTb2wgMjAyNi0xMC0xMyk6IHRoZSBuby1vcFxuICAgKiBib3VuZCBpcyBtaXNsZWFkaW5nIOKAlCBpbXBsZW1lbnQgdGhlIGJvdW5kIHByb3Blcmx5IG9yIHJlbW92ZVxuICAgKiBpdC4gIFdlIGtlZXAgdGhlIHVuZG8gcGF0dGVybiAob25lIGxhbmUgcGVyIGludm9jYXRpb24pIGFuZFxuICAgKiBkb2N1bWVudCB3aHk6IG11bHRpLXVuZG8gd291bGQgYmUgdG9vIGFnZ3Jlc3NpdmUgZm9yIHRoZSBzbWFsbFxuICAgKiBpc2xhbmQgZ3JhcGgsIGFuZCB0aGUgcmV0cnkgbG9vcCBhdCB0aGUgdG9wIGxldmVsXG4gICAqIChNQVhfQk9BUkRfQVRURU1QVFMpIGJvdW5kcyB0b3RhbCB3YXN0ZWQgZWZmb3J0LiAgSWYgYSBmdXR1cmVcbiAgICogdGVzdCBkZW1vbnN0cmF0ZXMgUGhhc2UgMiBnZXRzIHN0dWNrIGluIGEgbG9vcCB0aGF0IG9uZSB1bmRvXG4gICAqIGNhbm5vdCBlc2NhcGUsIHJlc3RvcmUgdGhlIGJvdW5kIHdpdGggYSByZWFsIGltcGxlbWVudGF0aW9uXG4gICAqIChsb29wIHVudGlsIGNhcCBvciB1bnRpbCBhIHZpYWJsZSBwYWlyIGV4aXN0cykuXG4gICAqL1xuXG4gIHdoaWxlIChzZWFMYW5lQ291bnQgPCBTRUFfTEFORV9DT1VOVCAmJiBwaGFzZTJQYXNzZXMgPCBNQVhfUEhBU0UyX1BBU1NFUykge1xuICAgIHBoYXNlMlBhc3NlcysrO1xuICAgIGNvbnN0IHZpYWJsZVBhaXJzOiB7IHNyYzogdHlwZW9mIGlzbGFuZFN0cnVjdHNbMF07IGRzdDogdHlwZW9mIGlzbGFuZFN0cnVjdHNbMF07IHNjb3JlOiBudW1iZXIgfVtdID0gW107XG4gICAgZm9yIChjb25zdCBzcmMgb2YgaXNsYW5kU3RydWN0cykge1xuICAgICAgZm9yIChjb25zdCBkc3Qgb2YgaXNsYW5kU3RydWN0cykge1xuICAgICAgICBpZiAoc3JjLmlkID09PSBkc3QuaWQpIGNvbnRpbnVlO1xuICAgICAgICBpZiAoaXNsYW5kRGVncmVlT2Yoc3JjLmlkKSA+PSBNQVhfSVNMQU5EX0dSQVBIX0RFR1JFRSkgY29udGludWU7XG4gICAgICAgIGlmIChpc2xhbmREZWdyZWVPZihkc3QuaWQpID49IE1BWF9JU0xBTkRfR1JBUEhfREVHUkVFKSBjb250aW51ZTtcbiAgICAgICAgLy8gQW4gaXNsYW5kIGF0IGl0cyBlbnRyYW5jZSBjYXAgc3RheXMgdmlhYmxlIHRocm91Z2ggYW4gZXhpc3RpbmdcbiAgICAgICAgLy8gZW50cmFuY2Ugd2l0aCBsYW5lIGhlYWRyb29tIChSOSBmb2xsb3ctdXAgb2YgUjExLCByb3VuZCAzKS5cbiAgICAgICAgaWYgKGxhbmVDYW5kaWRhdGVzKHNyYykubGVuZ3RoID09PSAwIHx8IGxhbmVDYW5kaWRhdGVzKGRzdCkubGVuZ3RoID09PSAwKSBjb250aW51ZTtcbiAgICAgICAgaWYgKGFkZGFibGVQcm92aW5jZVBhaXJzKHNyYywgZHN0KS5sZW5ndGggPT09IDApIGNvbnRpbnVlO1xuICAgICAgICBjb25zdCBlbnRyU3JjID0gaXNsYW5kRW50cmFuY2VDb3VudC5nZXQoc3JjLmlkKSA/PyAwO1xuICAgICAgICBjb25zdCBlbnRyRHN0ID0gaXNsYW5kRW50cmFuY2VDb3VudC5nZXQoZHN0LmlkKSA/PyAwO1xuICAgICAgICBjb25zdCBkZWdTcmMgPSBpc2xhbmREZWdyZWVPZihzcmMuaWQpO1xuICAgICAgICBjb25zdCBkZWdEc3QgPSBpc2xhbmREZWdyZWVPZihkc3QuaWQpO1xuICAgICAgICBsZXQgc2NvcmUgPSAwO1xuICAgICAgICAvLyBDLUJSRC0wMSBbZGVzaWduZWRdOiBwcmlvcml0eSB3ZWlnaHRzIGZvciBwaWNraW5nIHRoZSBuZXh0XG4gICAgICAgIC8vIFBoYXNlIDIgbGFuZS4gIFNvdXJjZS11bmRlci1taW4gZ2V0cyAxMDAwIChhIGxhcmdlIGJvbnVzIHNvXG4gICAgICAgIC8vIGV2ZXJ5IHVuZGVyLWNhcCBpc2xhbmQgaXMgZmlsbGVkIGZpcnN0KTsgZGVzdGluYXRpb24tdW5kZXItXG4gICAgICAgIC8vIG1pbiBnZXRzIDUwMCAobG93ZXIgYmVjYXVzZSBvbmNlIHRoZSBzb3VyY2UncyBpc2xhbmQgaXNcbiAgICAgICAgLy8gZmlsbGVkLCB0aGUgZGVzdGluYXRpb24gYmVjb21lcyB0aGUgbmV4dCB1bmRlci1jYXAgc291cmNlKS5cbiAgICAgICAgLy8gVGhlIGRlZ3JlZSBwZW5hbHR5IGAtPSBkZWdTcmMgKyBkZWdEc3RgIHNwcmVhZHMgbGFuZXMgYWNyb3NzXG4gICAgICAgIC8vIGlzbGFuZHMgdG8gYXZvaWQgaHVicy4gIFdlaWdodHMgY2hvc2VuIHNvIGFueSBwYWlyIGludm9sdmluZ1xuICAgICAgICAvLyBhbiB1bmRlci1jYXAgaXNsYW5kIG91dHNjb3JlcyBhbnkgcGFpciB0aGF0IGRvZXMgbm90IOKAlCB0aGVcbiAgICAgICAgLy8gMjoxIHJhdGlvIGVuc3VyZXMgdGllLWJyZWFraW5nIHByZWZlcnMgdGhlIG1vcmUgdW5kZXItY2FwXG4gICAgICAgIC8vIGVuZHBvaW50LiAgU2VhcmNoZWQ6IG5vIHB1Ymxpc2hlZCBndWlkYW5jZS5cbiAgICAgICAgaWYgKGVudHJTcmMgPCBNSU5fRU5UUkFOQ0VTX1BFUl9JU0xBTkQpIHNjb3JlICs9IDEwMDA7XG4gICAgICAgIGlmIChlbnRyRHN0IDwgTUlOX0VOVFJBTkNFU19QRVJfSVNMQU5EKSBzY29yZSArPSA1MDA7XG4gICAgICAgIHNjb3JlIC09IGRlZ1NyYyArIGRlZ0RzdDtcbiAgICAgICAgdmlhYmxlUGFpcnMucHVzaCh7IHNyYywgZHN0LCBzY29yZSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHZpYWJsZVBhaXJzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgLy8gU3R1Y2suIEJhY2t0cmFjazogdW5kbyB0aGUgbW9zdCByZWNlbnQgbGFuZSBhbmQgdHJ5IGFnYWluLlxuICAgICAgLy8gUjEwOiB1bmRvIGV4YWN0bHkgT05FIGxhbmUgcGVyIGludm9jYXRpb24sIHRoZW4gcmV0cnkgZ3JlZWR5LlxuICAgICAgLy8gVGhlIHByZXZpb3VzIHJvdW5kIGhhZCBhIGBNQVhfUEhBU0UyX1VORE9gIGJvdW5kIHRoYXQgd2FzXG4gICAgICAvLyBuZXZlciByZWFjaGVkIGJlY2F1c2Ugb2YgdGhlIHVuY29uZGl0aW9uYWwgYGJyZWFrYDsgdGhhdFxuICAgICAgLy8gYm91bmQgaGFzIGJlZW4gcmVtb3ZlZCAoc2VlIGNvbW1lbnQgYWJvdmUpLiAgVGhlIHJldHJ5IGxvb3Anc1xuICAgICAgLy8gb3ZlcmFsbCBgTUFYX0JPQVJEX0FUVEVNUFRTYCBjYXBzIHdhc3RlZCBlZmZvcnQuXG4gICAgICBpZiAocGhhc2UySGlzdG9yeS5sZW5ndGggPT09IDApIGJyZWFrO1xuICAgICAgY29uc3QgbGFzdCA9IHBoYXNlMkhpc3RvcnkucG9wKCkhO1xuICAgICAgLy8gVW5kbyB0aGUgbGFuZVxuICAgICAgYWxsU2VhTGFuZXMuZ2V0KGxhc3QucHJvdkEpPy5kZWxldGUobGFzdC5wcm92Qik7XG4gICAgICBhbGxTZWFMYW5lcy5nZXQobGFzdC5wcm92Qik/LmRlbGV0ZShsYXN0LnByb3ZBKTtcbiAgICAgIHJlbW92ZU5laWdoYm91cihsYXN0LmlzbGFuZEEsIGxhc3QuaXNsYW5kQik7XG4gICAgICBpZiAobGFzdC5wcm92QU5ld0VudHJhbmNlKSB7XG4gICAgICAgIGlzbGFuZEVudHJhbmNlQ291bnQuc2V0KFxuICAgICAgICAgIGxhc3QuaXNsYW5kQSxcbiAgICAgICAgICAoaXNsYW5kRW50cmFuY2VDb3VudC5nZXQobGFzdC5pc2xhbmRBKSA/PyAwKSAtIDEsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBpZiAobGFzdC5wcm92Qk5ld0VudHJhbmNlKSB7XG4gICAgICAgIGlzbGFuZEVudHJhbmNlQ291bnQuc2V0KFxuICAgICAgICAgIGxhc3QuaXNsYW5kQixcbiAgICAgICAgICAoaXNsYW5kRW50cmFuY2VDb3VudC5nZXQobGFzdC5pc2xhbmRCKSA/PyAwKSAtIDEsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBzZWFMYW5lQ291bnQtLTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBsZXQgYmVzdFNjb3JlID0gLUluZmluaXR5O1xuICAgIGZvciAoY29uc3QgcCBvZiB2aWFibGVQYWlycykgaWYgKHAuc2NvcmUgPiBiZXN0U2NvcmUpIGJlc3RTY29yZSA9IHAuc2NvcmU7XG4gICAgY29uc3QgYmVzdFBhaXJzID0gdmlhYmxlUGFpcnMuZmlsdGVyKChwKSA9PiBwLnNjb3JlID09PSBiZXN0U2NvcmUpO1xuICAgIGNvbnN0IHBhaXIgPSBiZXN0UGFpcnNbcm5nLm5leHRJbnQoMCwgYmVzdFBhaXJzLmxlbmd0aCAtIDEpXSE7XG4gICAgLy8gUHJvdmluY2VzIGNvbWUgb25seSBmcm9tIHBhaXJzIHRyeUFkZExhbmUgYWNjZXB0cyAocm91bmQgNCwgUjIpLCB3aXRoXG4gICAgLy8gdGhlIHNhbWUgcHJlZmVyZW5jZXMgYXMgYmVmb3JlOiBhIHNvdXJjZSB3aXRoIG5vIGxhbmUgeWV0IChhIG5ld1xuICAgIC8vIGVudHJhbmNlKSwgdGhlbiBhIGRlc3RpbmF0aW9uIHRoYXQgYWxyZWFkeSBoYXMgb25lIGxhbmUuXG4gICAgY29uc3QgYWRkYWJsZSA9IGFkZGFibGVQcm92aW5jZVBhaXJzKHBhaXIuc3JjLCBwYWlyLmRzdCk7XG4gICAgY29uc3QgcHJvdnNTcmMgPSBbLi4ubmV3IFNldChhZGRhYmxlLm1hcCgoW2FdKSA9PiBhKSldO1xuICAgIGNvbnN0IHNyY1plcm8gPSBwcm92c1NyYy5maWx0ZXIoKHApID0+IChhbGxTZWFMYW5lcy5nZXQocCk/LnNpemUgPz8gMCkgPT09IDApO1xuICAgIGNvbnN0IHByb3ZBID1cbiAgICAgIHNyY1plcm8ubGVuZ3RoID4gMFxuICAgICAgICA/IHNyY1plcm9bcm5nLm5leHRJbnQoMCwgc3JjWmVyby5sZW5ndGggLSAxKV0hXG4gICAgICAgIDogcHJvdnNTcmNbcm5nLm5leHRJbnQoMCwgcHJvdnNTcmMubGVuZ3RoIC0gMSldITtcbiAgICBjb25zdCBwcm92c0RzdCA9IGFkZGFibGUuZmlsdGVyKChbYV0pID0+IGEgPT09IHByb3ZBKS5tYXAoKFssIGJdKSA9PiBiKTtcbiAgICBjb25zdCBkc3RPbmUgPSBwcm92c0RzdC5maWx0ZXIoKHApID0+IChhbGxTZWFMYW5lcy5nZXQocCk/LnNpemUgPz8gMCkgPT09IDEpO1xuICAgIGNvbnN0IHByb3ZCID1cbiAgICAgIGRzdE9uZS5sZW5ndGggPiAwXG4gICAgICAgID8gZHN0T25lW3JuZy5uZXh0SW50KDAsIGRzdE9uZS5sZW5ndGggLSAxKV0hXG4gICAgICAgIDogcHJvdnNEc3Rbcm5nLm5leHRJbnQoMCwgcHJvdnNEc3QubGVuZ3RoIC0gMSldITtcbiAgICBjb25zdCBwcm92QVdhczBMYW5lID0gKGFsbFNlYUxhbmVzLmdldChwcm92QSk/LnNpemUgPz8gMCkgPT09IDA7XG4gICAgY29uc3QgcHJvdkJXYXMwTGFuZSA9IChhbGxTZWFMYW5lcy5nZXQocHJvdkIpPy5zaXplID8/IDApID09PSAwO1xuICAgIGNvbnN0IGF0Q2FwQSA9IGF0RW50cmFuY2VDYXAocGFpci5zcmMuaWQpO1xuICAgIGNvbnN0IGF0Q2FwQiA9IGF0RW50cmFuY2VDYXAocGFpci5kc3QuaWQpO1xuICAgIGlmICghdHJ5QWRkTGFuZShwcm92QSwgcHJvdkIsIHBhaXIuc3JjLmlkLCBwYWlyLmRzdC5pZCkpIGNvbnRpbnVlO1xuICAgIHRyYWNlPy5waGFzZTJMYW5lcy5wdXNoKHsgaXNsYW5kQTogcGFpci5zcmMuaWQsIGlzbGFuZEI6IHBhaXIuZHN0LmlkLCBhdENhcEEsIGF0Q2FwQiB9KTtcbiAgICBwaGFzZTJIaXN0b3J5LnB1c2goe1xuICAgICAgcHJvdkEsXG4gICAgICBwcm92QixcbiAgICAgIGlzbGFuZEE6IHBhaXIuc3JjLmlkLFxuICAgICAgaXNsYW5kQjogcGFpci5kc3QuaWQsXG4gICAgICBwcm92QU5ld0VudHJhbmNlOiBwcm92QVdhczBMYW5lLFxuICAgICAgcHJvdkJOZXdFbnRyYW5jZTogcHJvdkJXYXMwTGFuZSxcbiAgICB9KTtcbiAgICBzZWFMYW5lQ291bnQrKztcbiAgfVxuXG4gIGlmIChzZWFMYW5lQ291bnQgPCBTRUFfTEFORV9DT1VOVClcbiAgICBlcnJvcnMucHVzaChcbiAgICAgIGBjb3VsZCBub3QgcGxhY2UgJHtTRUFfTEFORV9DT1VOVH0gc2VhIGxhbmVzIGluICR7TUFYX1BIQVNFMl9QQVNTRVN9IHBhc3NlcyAocGxhY2VkICR7c2VhTGFuZUNvdW50fSlgLFxuICAgICk7XG4gIC8vIC0tLS0gQnVpbGQgaXNsYW5kIHJlY29yZHMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIGlzbGFuZEVudHJhbmNlQ291bnQgaXMgbWFpbnRhaW5lZCBsaXZlIGR1cmluZyBQaGFzZSAxIGFuZCBQaGFzZSAyO1xuICAvLyBpdCBhbHJlYWR5IHJlZmxlY3RzIHRoZSBjb3JyZWN0IGNvdW50IG9mIGRpc3RpbmN0IHByb3ZpbmNlcyB3aXRoIHNlYSBsYW5lcy5cbiAgY29uc3QgaXNsYW5kczogSXNsYW5kW10gPSBpc2xhbmRTdHJ1Y3RzLm1hcCgoaXNsKSA9PiAoe1xuICAgIGlkOiBpc2wuaWQsXG4gICAgbmFtZTogaXNsLm5hbWUsXG4gICAgYm9udXM6IE1hdGgubWF4KDIsIE1hdGguZmxvb3IoaXNsLnNpemUgLyBCT05VU19ESVZJU09SKSArIChpc2xhbmRFbnRyYW5jZUNvdW50LmdldChpc2wuaWQpID8/IDApKSxcbiAgICBwcm92aW5jZXM6IGlzbC5wcm92aW5jZUlkcyxcbiAgfSkpO1xuXG4gIC8vIC0tLS0gQnVpbGQgcHJvdmluY2UgcmVjb3JkcyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIEFzc2lnbiBlYWNoIHByb3ZpbmNlIGEgcG9zaXRpb24gd2l0aGluIGEgZ3JpZCBkZXJpdmVkIGZyb20gdGhlIGlzbGFuZCBpbmRleC5cbiAgY29uc3QgcHJvdmluY2VzOiBQcm92aW5jZVtdID0gW107XG4gIGZvciAobGV0IGlpID0gMDsgaWkgPCBpc2xhbmRTdHJ1Y3RzLmxlbmd0aDsgaWkrKykge1xuICAgIGNvbnN0IGlzbGFuZCA9IGlzbGFuZFN0cnVjdHNbaWldITtcbiAgICBjb25zdCBpc2xhbmRYID0gKGlpICUgMykgKiAyMjAgKyA2MDtcbiAgICBjb25zdCBpc2xhbmRZID0gTWF0aC5mbG9vcihpaSAvIDMpICogMTgwICsgNjA7XG4gICAgY29uc3QgcHRzID0gc3ByZWFkUG9pbnRzKHJuZywgaXNsYW5kLnNpemUsIGlzbGFuZFgsIGlzbGFuZFggKyAxNjAsIGlzbGFuZFksIGlzbGFuZFkgKyAxMzApO1xuICAgIGZvciAobGV0IHBpID0gMDsgcGkgPCBpc2xhbmQucHJvdmluY2VJZHMubGVuZ3RoOyBwaSsrKSB7XG4gICAgICBjb25zdCBpZCA9IGlzbGFuZC5wcm92aW5jZUlkc1twaV0hO1xuICAgICAgY29uc3QgW3B4LCBweV0gPSBwdHNbcGldITtcbiAgICAgIGNvbnN0IHByZWZpeCA9IE5BTUVfUFJFRklYRVNbcm5nLm5leHRJbnQoMCwgTkFNRV9QUkVGSVhFUy5sZW5ndGggLSAxKV0hO1xuICAgICAgY29uc3Qgc3VmZml4ID0gTkFNRV9TVUZGSVhFU1tybmcubmV4dEludCgwLCBOQU1FX1NVRkZJWEVTLmxlbmd0aCAtIDEpXSE7XG4gICAgICBjb25zdCBib3JkZXJzID0gWy4uLihhbGxCb3JkZXJzLmdldChpZCkgPz8gW10pXTtcbiAgICAgIGNvbnN0IHNlYUxhbmVzID0gWy4uLihhbGxTZWFMYW5lcy5nZXQoaWQpID8/IFtdKV07XG4gICAgICBjb25zdCBwb2x5Z29uID0gcGxhY2Vob2xkZXJQb2x5Z29uKHB4LCBweSwgcm5nLm5leHRJbnQoMTIsIDIyKSwgcm5nLm5leHRJbnQoMywgNikpO1xuICAgICAgY29uc3QgbGFiZWxBdDogUG9pbnQgPSBbcHgsIHB5XTtcbiAgICAgIHByb3ZpbmNlcy5wdXNoKHsgaWQsIG5hbWU6IGAke3ByZWZpeH0gJHtzdWZmaXh9YCwgaXNsYW5kOiBpc2xhbmQuaWQsIGJvcmRlcnMsIHNlYUxhbmVzLCBwb2x5Z29uLCBsYWJlbEF0IH0pO1xuICAgIH1cbiAgfVxuXG4gIC8vIC0tLS0gQm91bmRzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIGNvbnN0IGFsbFggPSBwcm92aW5jZXMuZmxhdE1hcCgocCkgPT4gcC5wb2x5Z29uLm1hcCgocHQpID0+IHB0WzBdKSk7XG4gIGNvbnN0IGFsbFkgPSBwcm92aW5jZXMuZmxhdE1hcCgocCkgPT4gcC5wb2x5Z29uLm1hcCgocHQpID0+IHB0WzFdKSk7XG4gIGNvbnN0IG1pblggPSBNYXRoLm1pbiguLi5hbGxYKSAtIDMwO1xuICBjb25zdCBtaW5ZID0gTWF0aC5taW4oLi4uYWxsWSkgLSAzMDtcbiAgY29uc3QgbWF4WCA9IE1hdGgubWF4KC4uLmFsbFgpICsgMzA7XG4gIGNvbnN0IG1heFkgPSBNYXRoLm1heCguLi5hbGxZKSArIDMwO1xuICBjb25zdCBib3VuZHMgPSB7IHg6IG1pblgsIHk6IG1pblksIHdpZHRoOiBtYXhYIC0gbWluWCwgaGVpZ2h0OiBtYXhZIC0gbWluWSB9O1xuXG4gIGNvbnN0IG1hcDogR2FtZU1hcCA9IHtcbiAgICBpZDogXCJnZW5lcmF0ZWRcIixcbiAgICBuYW1lOiBcIkdlbmVyYXRlZCBBcmNoaXBlbGFnb1wiLFxuICAgIGJvdW5kcyxcbiAgICBwcm92aW5jZXMsXG4gICAgaXNsYW5kcyxcbiAgfTtcblxuICAvLyBUaGUgc3RydWN0dXJhbCBhY2NlcHRhbmNlIHN0ZXAgKGBzdHJ1Y3R1cmFsRXJyb3JzYCkgcnVucyBpbiB0aGUgcmV0cnlcbiAgLy8gbG9vcCBvbiBldmVyeSBtYXAgYSBib2R5IHJldHVybnMgKHJvdW5kIDQsIFIxKS5cbiAgaWYgKGVycm9ycy5sZW5ndGggPiAwKSByZXR1cm4geyBvazogZmFsc2UsIGVycm9ycyB9O1xuXG4gIHJldHVybiB7IG9rOiB0cnVlLCBtYXAgfTtcbn1cblxuLyoqXG4gKiBHZW5lcmF0ZSBhIGBHYW1lTWFwYCBmcm9tIGEgc2VlZC4gVGhlIG1hcCBhbHdheXMgbWVldHMgdGhlIHN0cnVjdHVyYWxcbiAqIGludmFyaWFudHMgZnJvbSBgZGVzaWduL2NvcmUtcnVsZXMubWQgwqcgVGhlIGJvYXJkYCBvbiBldmVyeSBzZWVkOlxuICogLSA0NiBwcm92aW5jZXMgaW4gOSBpc2xhbmRzIG9mIHNpemVzIFszLDMsMywzLDUsNSw3LDcsMTBdIChDLUJSRC0wMylcbiAqIC0gZXZlcnkgcHJvdmluY2UgaGFzIDLigJM1IG5laWdoYm91cnMgaW4gdG90YWwgKEMtQlJELTA0KVxuICogLSBleGFjdGx5IDE2IHVuZGlyZWN0ZWQgaW50ZXItaXNsYW5kIHNlYSBsYW5lcywgc3ltbWV0cmljIChDLUJSRC0wNClcbiAqIC0gdGhlIGJvcmRlci1wbHVzLXNlYS1sYW5lIGdyYXBoIGlzIGNvbm5lY3RlZCAoQy1CUkQtMDQpXG4gKiAtIGlzbGFuZCBib251c2VzIGZvbGxvdyBDLUJPTi0wMlxuICogLSBhbGwgcG9seWdvbnMgaGF2ZSDiiaUzIHBvaW50czsgYWxsIGxhYmVscyBpbnNpZGUgYm91bmRzIChDLUJSRC0wNilcbiAqXG4gKiBQbHVzIHRoZSA1IGZhaXJuZXNzIGNoZWNrcyBmcm9tIGBib2FyZC1mYWlybmVzcy50c2AgKEMtQlJELTAxKS5cbiAqIFRoZSByZXRyeSBsb29wIGRyYXdzIGEgbmV3IHBsYW4gZWFjaCBhdHRlbXB0IGJ5IGFkdmFuY2luZyB0aGUgUk5HLlxuICpcbiAqIFRha2VzIHRoZSBzZWVkIG9ubHk6IGl0IGFsd2F5cyBydW5zIHRoZSByZWFsIGJvZHksIHRoZSByZWFsIGZpdmUgY2hlY2tzXG4gKiBhbmQgdGhlIHJlYWwgYE1BWF9CT0FSRF9BVFRFTVBUU2AgY2FwIChSMSwgcm91bmQgMykuICBBcmd1bWVudHMgcGFzdCB0aGVcbiAqIHNlZWQgYXJlIGlnbm9yZWQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZW5lcmF0ZUJvYXJkKHNlZWQ6IG51bWJlcik6IEJvYXJkR2VuUmVzdWx0IHtcbiAgcmV0dXJuIGdlbmVyYXRlQm9hcmRXaXRoUm5nKG5ldyBEZXRlcm1pbmlzdGljUm5nKHNlZWQpKTtcbn1cblxuLyoqIFNoYXJlZC1zdHJlYW0gc2VhbSBmb3IgZ2VuZXJhdGVkIGdhbWVzOyByZXRyaWVzIGtlZXAgY29uc3VtaW5nIHRoZSBjYWxsZXIncyBSTkcuICovXG5leHBvcnQgZnVuY3Rpb24gZ2VuZXJhdGVCb2FyZFdpdGhSbmcoXG4gIHJuZzogRGV0ZXJtaW5pc3RpY1JuZyxcbiAgcGFydHM6IHtcbiAgICByZWFkb25seSBib2R5PzogKHJuZzogRGV0ZXJtaW5pc3RpY1JuZykgPT4gQm9hcmRHZW5SZXN1bHQ7XG4gICAgcmVhZG9ubHkgZmFpcm5lc3NDaGVjaz86IChtYXA6IEdhbWVNYXApID0+IHN0cmluZ1tdO1xuICAgIHJlYWRvbmx5IGF0dGVtcHRzPzogbnVtYmVyO1xuICB9ID0ge30sXG4pOiBCb2FyZEdlblJlc3VsdCB7XG4gIHJldHVybiBnZW5lcmF0ZUJvYXJkVXNpbmdSbmcocm5nLCBwYXJ0cyk7XG59XG5cbi8qKlxuICogSW50ZXJuYWwgdGVzdGluZyBib3VuZGFyeTogdGhlIHJldHJ5IGxvb3Agd2l0aCByZXBsYWNlYWJsZSBwYXJ0cy4gIEl0IGlzXG4gKiBleHBvcnRlZCBmcm9tIHRoaXMgbW9kdWxlIGZvciB0ZXN0cyBvbmx5IGFuZCBpcyBOT1QgcmUtZXhwb3J0ZWQgZnJvbVxuICogYHNyYy9jb3JlL2luZGV4LnRzYDsgdGhlIHB1YmxpYyBlbnRyeSBpcyBgZ2VuZXJhdGVCb2FyZChzZWVkKWAuICBFdmVyeVxuICogcGFydCBsZWZ0IG91dCBkZWZhdWx0cyB0byB0aGUgcHJvZHVjdGlvbiBvbmUsIHNvIGEgdGVzdCB0aGF0IHJlcGxhY2VzXG4gKiBvbmx5IHRoZSBib2R5IHN0aWxsIHJ1bnMgdGhlIHJlYWwgYHJ1bkFsbEZhaXJuZXNzQ2hlY2tzYCAoUjIsIHJvdW5kIDMpLlxuICogYHN0cnVjdHVyYWxFcnJvcnNgIGlzIG5vdCByZXBsYWNlYWJsZTogaXQgcnVucyBvbiBldmVyeSBib2R5J3MgbWFwLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2VuZXJhdGVCb2FyZEludGVybmFsKFxuICBzZWVkOiBudW1iZXIsXG4gIHBhcnRzOiB7XG4gICAgcmVhZG9ubHkgYm9keT86IChybmc6IERldGVybWluaXN0aWNSbmcpID0+IEJvYXJkR2VuUmVzdWx0O1xuICAgIHJlYWRvbmx5IGZhaXJuZXNzQ2hlY2s/OiAobWFwOiBHYW1lTWFwKSA9PiBzdHJpbmdbXTtcbiAgICByZWFkb25seSBhdHRlbXB0cz86IG51bWJlcjtcbiAgfSA9IHt9LFxuKTogQm9hcmRHZW5SZXN1bHQge1xuICBjb25zdCBib2R5ID0gcGFydHMuYm9keSA/PyBnZW5lcmF0ZUJvYXJkQm9keTtcbiAgY29uc3QgZmFpcm5lc3NDaGVjayA9IHBhcnRzLmZhaXJuZXNzQ2hlY2sgPz8gcnVuQWxsRmFpcm5lc3NDaGVja3M7XG4gIGNvbnN0IGNhcCA9IHBhcnRzLmF0dGVtcHRzID8/IE1BWF9CT0FSRF9BVFRFTVBUUztcbiAgY29uc3Qgcm5nID0gbmV3IERldGVybWluaXN0aWNSbmcoc2VlZCk7XG4gIHJldHVybiBnZW5lcmF0ZUJvYXJkVXNpbmdSbmcocm5nLCB7IGJvZHksIGZhaXJuZXNzQ2hlY2ssIGF0dGVtcHRzOiBjYXAgfSk7XG59XG5cbmZ1bmN0aW9uIGdlbmVyYXRlQm9hcmRVc2luZ1JuZyhcbiAgcm5nOiBEZXRlcm1pbmlzdGljUm5nLFxuICBwYXJ0czoge1xuICAgIHJlYWRvbmx5IGJvZHk/OiAocm5nOiBEZXRlcm1pbmlzdGljUm5nKSA9PiBCb2FyZEdlblJlc3VsdDtcbiAgICByZWFkb25seSBmYWlybmVzc0NoZWNrPzogKG1hcDogR2FtZU1hcCkgPT4gc3RyaW5nW107XG4gICAgcmVhZG9ubHkgYXR0ZW1wdHM/OiBudW1iZXI7XG4gIH0gPSB7fSxcbik6IEJvYXJkR2VuUmVzdWx0IHtcbiAgY29uc3QgYm9keSA9IHBhcnRzLmJvZHkgPz8gZ2VuZXJhdGVCb2FyZEJvZHk7XG4gIGNvbnN0IGZhaXJuZXNzQ2hlY2sgPSBwYXJ0cy5mYWlybmVzc0NoZWNrID8/IHJ1bkFsbEZhaXJuZXNzQ2hlY2tzO1xuICBjb25zdCBjYXAgPSBwYXJ0cy5hdHRlbXB0cyA/PyBNQVhfQk9BUkRfQVRURU1QVFM7XG4gIGxldCBsYXN0UmVzdWx0OiBCb2FyZEdlblJlc3VsdCB8IG51bGwgPSBudWxsO1xuICBmb3IgKGxldCBhdHRlbXB0ID0gMTsgYXR0ZW1wdCA8PSBjYXA7IGF0dGVtcHQrKykge1xuICAgIGxldCByZXN1bHQgPSBib2R5KHJuZyk7XG4gICAgLy8gU3RydWN0dXJhbCBhY2NlcHRhbmNlIChDLUJSRC0wNCwgQy1CUkQtMDEpOiBhIGJvZHkncyBtYXAgdGhhdCBtaXNzZXNcbiAgICAvLyBhbiBpbnZhcmlhbnQgaXMgYSBmYWlsZWQgYXR0ZW1wdCwgd2hhdGV2ZXIgdGhlIGZhaXJuZXNzIGNoZWNrcyBzYXkuXG4gICAgY29uc3Qgc3RydWN0dXJhbCA9IHJlc3VsdC5vayA/IHN0cnVjdHVyYWxFcnJvcnMocmVzdWx0Lm1hcCkgOiBbXTtcbiAgICBpZiAoc3RydWN0dXJhbC5sZW5ndGggPiAwKSByZXN1bHQgPSB7IG9rOiBmYWxzZSwgZXJyb3JzOiBzdHJ1Y3R1cmFsIH07XG4gICAgaWYgKHJlc3VsdC5vaykge1xuICAgICAgY29uc3QgZmFpcm5lc3NFcnJvcnMgPSBmYWlybmVzc0NoZWNrKHJlc3VsdC5tYXApO1xuICAgICAgaWYgKGZhaXJuZXNzRXJyb3JzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgbGFzdFJlc3VsdCA9IHJlc3VsdDtcbiAgICAvLyBBZHZhbmNlIHRoZSBSTkcgdG8gZHJhdyBhIGRpZmZlcmVudCBwbGFuIG5leHQgYXR0ZW1wdCAoQy1CUkQtMDEpLlxuICAgIC8vIE9uZSBkcmF3IGlzIGVub3VnaDogdGhlIGJvZHkgYWx3YXlzIGNvbnN1bWVzIGEgZGV0ZXJtaW5pc3RpY1xuICAgIC8vIHNlcXVlbmNlLCBzbyBza2lwcGluZyBvbmUgc3RhdGUgZ3VhcmFudGVlcyBhIGRpZmZlcmVudCBwbGFuIG9uIHRoZVxuICAgIC8vIG5leHQgYXR0ZW1wdCDigJQgd2hldGhlciB0aGUgcHJldmlvdXMgYXR0ZW1wdCBmYWlsZWQgc3RydWN0dXJhbGx5XG4gICAgLy8gKGUuZy4gY291bGQgbm90IHBsYWNlIDE2IGxhbmVzKSBvciBmYWlsZWQgdGhlIGZhaXJuZXNzIGNoZWNrcy5cbiAgICBybmcubmV4dEludCgwLCAweGZmZmZmZmZmKTtcbiAgfVxuICBpZiAobGFzdFJlc3VsdCAmJiBsYXN0UmVzdWx0Lm9rKSB7XG4gICAgY29uc3QgZmFpcm5lc3NFcnJvcnMgPSBmYWlybmVzc0NoZWNrKGxhc3RSZXN1bHQubWFwKTtcbiAgICByZXR1cm4ge1xuICAgICAgb2s6IGZhbHNlLFxuICAgICAgZXJyb3JzOiBbYGZhaXJuZXNzIGNoZWNrcyBmYWlsZWQgYWZ0ZXIgJHtjYXB9IGF0dGVtcHRzOiAke2ZhaXJuZXNzRXJyb3JzLmpvaW4oXCI7IFwiKX1gXSxcbiAgICB9O1xuICB9XG4gIHJldHVybiB7XG4gICAgb2s6IGZhbHNlLFxuICAgIGVycm9yczogW1xuICAgICAgYGZhaWxlZCBhZnRlciAke2NhcH0gYXR0ZW1wdHM6ICR7bGFzdFJlc3VsdCA/IGxhc3RSZXN1bHQuZXJyb3JzLmpvaW4oXCI7IFwiKSA6IFwibm8gYm9keSBvdXRwdXRcIn1gLFxuICAgIF0sXG4gIH07XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVNBLGdCQUFnQixRQUFRLE9BQU87QUFFeEMsU0FBU0Msb0JBQW9CLFFBQVEsa0JBQWtCOztBQUV2RDtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxPQUFPLE1BQU1DLFlBQVksR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFVOztBQUVqRTtBQUNBLE9BQU8sTUFBTUMsY0FBYyxHQUFHLEVBQUU7O0FBRWhDO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLE9BQU8sTUFBTUMsVUFBVSxHQUFHLENBQUM7QUFDM0I7QUFDQSxPQUFPLE1BQU1DLFVBQVUsR0FBRyxDQUFDO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPLE1BQU1DLFVBQVUsR0FBR0QsVUFBVSxHQUFHLENBQUM7O0FBRXhDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTyxNQUFNRSxhQUFhLEdBQUcsQ0FBQzs7QUFFOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPLE1BQU1DLGtCQUFrQixHQUFHLENBQUM7O0FBRW5DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPLE1BQU1DLHFCQUFxQixHQUFHLENBQUM7O0FBRXRDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPLE1BQU1DLHFCQUF1RCxHQUFHO0VBQ3JFLENBQUMsRUFBRSxDQUFDO0VBQ0osQ0FBQyxFQUFFLENBQUM7RUFDSixDQUFDLEVBQUUsQ0FBQztFQUNKLEVBQUUsRUFBRTtBQUNOLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTyxNQUFNQyx3QkFBd0IsR0FBRyxDQUFDOztBQUV6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTyxNQUFNQyx1QkFBdUIsR0FBRyxDQUFDOztBQUV4QztBQUNBO0FBQ0E7O0FBTUE7QUFDQTtBQUNBOztBQUVBLE1BQU1DLFlBQVksR0FBRyxDQUNuQixZQUFZLEVBQ1osV0FBVyxFQUNYLFdBQVcsRUFDWCxZQUFZLEVBQ1osY0FBYyxFQUNkLGFBQWEsRUFDYixXQUFXLEVBQ1gsWUFBWSxFQUNaLFlBQVksQ0FDYjs7QUFFRDtBQUNBO0FBQ0E7O0FBRUEsTUFBTUMsYUFBYSxHQUFHLENBQ3BCLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQ2hFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQ2hFLE1BQU0sRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQy9ELE1BQU0sRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUM5QztBQUNELE1BQU1DLGFBQWEsR0FBRyxDQUNwQixNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUM5RCxPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUNqRSxPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxDQUNuRTs7QUFFRDtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxTQUFTQyxRQUFRQSxDQUFJQyxHQUFxQixFQUFFQyxLQUFtQixFQUFPO0VBQ3BFLE1BQU1DLEdBQUcsR0FBRyxDQUFDLEdBQUdELEtBQUssQ0FBQztFQUN0QixLQUFLLElBQUlFLENBQUMsR0FBR0QsR0FBRyxDQUFDRSxNQUFNLEdBQUcsQ0FBQyxFQUFFRCxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEVBQUUsRUFBRTtJQUN2QyxNQUFNRSxDQUFDLEdBQUdMLEdBQUcsQ0FBQ00sT0FBTyxDQUFDLENBQUMsRUFBRUgsQ0FBQyxDQUFDO0lBQzNCLE1BQU1JLEdBQUcsR0FBR0wsR0FBRyxDQUFDQyxDQUFDLENBQU07SUFDdkJELEdBQUcsQ0FBQ0MsQ0FBQyxDQUFDLEdBQUdELEdBQUcsQ0FBQ0csQ0FBQyxDQUFNO0lBQ3BCSCxHQUFHLENBQUNHLENBQUMsQ0FBQyxHQUFHRSxHQUFHO0VBQ2Q7RUFDQSxPQUFPTCxHQUFHO0FBQ1o7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTTSxrQkFBa0JBLENBQUNDLEVBQVUsRUFBRUMsRUFBVSxFQUFFQyxDQUFTLEVBQUVDLEtBQWEsRUFBVztFQUNyRixNQUFNQyxHQUFZLEdBQUcsRUFBRTtFQUN2QixLQUFLLElBQUlWLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBR1MsS0FBSyxFQUFFVCxDQUFDLEVBQUUsRUFBRTtJQUM5QixNQUFNVyxLQUFLLEdBQUksQ0FBQyxHQUFHQyxJQUFJLENBQUNDLEVBQUUsR0FBR2IsQ0FBQyxHQUFJUyxLQUFLLEdBQUdHLElBQUksQ0FBQ0MsRUFBRSxHQUFHLENBQUM7SUFDckRILEdBQUcsQ0FBQ0ksSUFBSSxDQUFDLENBQUNSLEVBQUUsR0FBR0UsQ0FBQyxHQUFHSSxJQUFJLENBQUNHLEdBQUcsQ0FBQ0osS0FBSyxDQUFDLEVBQUVKLEVBQUUsR0FBR0MsQ0FBQyxHQUFHSSxJQUFJLENBQUNJLEdBQUcsQ0FBQ0wsS0FBSyxDQUFDLENBQUMsQ0FBQztFQUNoRTtFQUNBLE9BQU9ELEdBQUc7QUFDWjs7QUFFQTtBQUNBLFNBQVNPLFlBQVlBLENBQ25CcEIsR0FBcUIsRUFDckJxQixDQUFTLEVBQ1RDLElBQVksRUFDWkMsSUFBWSxFQUNaQyxJQUFZLEVBQ1pDLElBQVksRUFDSDtFQUNULE1BQU1aLEdBQVksR0FBRyxFQUFFO0VBQ3ZCLE1BQU1hLElBQUksR0FBR1gsSUFBSSxDQUFDWSxJQUFJLENBQUNaLElBQUksQ0FBQ2EsSUFBSSxDQUFDUCxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7RUFDMUMsTUFBTVEsS0FBSyxHQUFHLENBQUNOLElBQUksR0FBR0QsSUFBSSxJQUFJSSxJQUFJO0VBQ2xDLE1BQU1JLEtBQUssR0FBRyxDQUFDTCxJQUFJLEdBQUdELElBQUksSUFBSVQsSUFBSSxDQUFDWSxJQUFJLENBQUNOLENBQUMsR0FBR0ssSUFBSSxDQUFDO0VBQ2pELEtBQUssSUFBSXZCLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBR2tCLENBQUMsRUFBRWxCLENBQUMsRUFBRSxFQUFFO0lBQzFCLE1BQU00QixHQUFHLEdBQUc1QixDQUFDLEdBQUd1QixJQUFJO0lBQ3BCLE1BQU1NLEdBQUcsR0FBR2pCLElBQUksQ0FBQ2tCLEtBQUssQ0FBQzlCLENBQUMsR0FBR3VCLElBQUksQ0FBQztJQUNoQyxNQUFNUSxDQUFDLEdBQUdaLElBQUksR0FBR1MsR0FBRyxHQUFHRixLQUFLLEdBQUc3QixHQUFHLENBQUNNLE9BQU8sQ0FBQyxDQUFDLEVBQUV1QixLQUFLLEdBQUcsR0FBRyxDQUFDO0lBQzFELE1BQU1NLENBQUMsR0FBR1gsSUFBSSxHQUFHUSxHQUFHLEdBQUdGLEtBQUssR0FBRzlCLEdBQUcsQ0FBQ00sT0FBTyxDQUFDLENBQUMsRUFBRXdCLEtBQUssR0FBRyxHQUFHLENBQUM7SUFDMURqQixHQUFHLENBQUNJLElBQUksQ0FBQyxDQUFDaUIsQ0FBQyxFQUFFQyxDQUFDLENBQUMsQ0FBQztFQUNsQjtFQUNBLE9BQU90QixHQUFHO0FBQ1o7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTdUIsWUFBWUEsQ0FDbkJwQyxHQUFxQixFQUNyQnFDLFdBQThCLEVBQzlCQyxTQUFpQixFQUNTO0VBQzFCLE1BQU1qQixDQUFDLEdBQUdnQixXQUFXLENBQUNqQyxNQUFNO0VBQzVCLE1BQU1tQyxHQUFHLEdBQUcsSUFBSUMsR0FBRyxDQUFzQkgsV0FBVyxDQUFDSSxHQUFHLENBQUVDLEVBQUUsSUFBSyxDQUFDQSxFQUFFLEVBQUUsSUFBSUMsR0FBRyxDQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFFMUYsSUFBSXRCLENBQUMsS0FBSyxDQUFDLEVBQUUsT0FBT2tCLEdBQUcsQ0FBQyxDQUFDO0VBQ3pCLElBQUlsQixDQUFDLEtBQUssQ0FBQyxFQUFFO0lBQ1hrQixHQUFHLENBQUNLLEdBQUcsQ0FBQ1AsV0FBVyxDQUFDLENBQUMsQ0FBRSxDQUFDLENBQUVRLEdBQUcsQ0FBQ1IsV0FBVyxDQUFDLENBQUMsQ0FBRSxDQUFDO0lBQzlDRSxHQUFHLENBQUNLLEdBQUcsQ0FBQ1AsV0FBVyxDQUFDLENBQUMsQ0FBRSxDQUFDLENBQUVRLEdBQUcsQ0FBQ1IsV0FBVyxDQUFDLENBQUMsQ0FBRSxDQUFDO0lBQzlDLE9BQU9FLEdBQUcsQ0FBQyxDQUFDO0VBQ2Q7O0VBRUE7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1PLEtBQUssR0FBRy9DLFFBQVEsQ0FBQ0MsR0FBRyxFQUFFLENBQUMsR0FBR3FDLFdBQVcsQ0FBQyxDQUFDO0VBQzdDLEtBQUssSUFBSWxDLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBRzJDLEtBQUssQ0FBQzFDLE1BQU0sRUFBRUQsQ0FBQyxFQUFFLEVBQUU7SUFDckMsTUFBTTRDLEtBQUssR0FBR0QsS0FBSyxDQUFDM0MsQ0FBQyxDQUFFO0lBQ3ZCO0lBQ0EsTUFBTTZDLGVBQWUsR0FBR0YsS0FBSyxDQUFDRyxLQUFLLENBQUMsQ0FBQyxFQUFFOUMsQ0FBQyxDQUFDLENBQUMrQyxNQUFNLENBQUVDLENBQUMsSUFBS1osR0FBRyxDQUFDSyxHQUFHLENBQUNPLENBQUMsQ0FBQyxDQUFFQyxJQUFJLEdBQUdkLFNBQVMsQ0FBQztJQUNyRixJQUFJZSxNQUFjO0lBQ2xCLElBQUlMLGVBQWUsQ0FBQzVDLE1BQU0sR0FBRyxDQUFDLEVBQUU7TUFDOUJpRCxNQUFNLEdBQUdMLGVBQWUsQ0FBQ2hELEdBQUcsQ0FBQ00sT0FBTyxDQUFDLENBQUMsRUFBRTBDLGVBQWUsQ0FBQzVDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBRTtJQUN2RSxDQUFDLE1BQU07TUFDTDtNQUNBO01BQ0FpRCxNQUFNLEdBQUdQLEtBQUssQ0FBQzlDLEdBQUcsQ0FBQ00sT0FBTyxDQUFDLENBQUMsRUFBRUgsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFFO0lBQ3hDO0lBQ0FvQyxHQUFHLENBQUNLLEdBQUcsQ0FBQ1MsTUFBTSxDQUFDLENBQUVSLEdBQUcsQ0FBQ0UsS0FBSyxDQUFDO0lBQzNCUixHQUFHLENBQUNLLEdBQUcsQ0FBQ0csS0FBSyxDQUFDLENBQUVGLEdBQUcsQ0FBQ1EsTUFBTSxDQUFDO0VBQzdCO0VBRUEsTUFBTUMsR0FBRyxHQUFHLENBQUMsR0FBR2pCLFdBQVcsQ0FBQzs7RUFFNUI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLElBQUlrQixlQUFlLEdBQUcsQ0FBQztFQUN2QixNQUFNQyxvQkFBb0IsR0FBRyxFQUFFO0VBQy9CLElBQUlDLG1CQUFtQixHQUFHSCxHQUFHLENBQUNKLE1BQU0sQ0FBRVIsRUFBRSxJQUFLSCxHQUFHLENBQUNLLEdBQUcsQ0FBQ0YsRUFBRSxDQUFDLENBQUVVLElBQUksR0FBRyxDQUFDLENBQUM7RUFDbkUsT0FBT0ssbUJBQW1CLENBQUNyRCxNQUFNLEdBQUcsQ0FBQyxJQUFJbUQsZUFBZSxHQUFHQyxvQkFBb0IsRUFBRTtJQUMvRUQsZUFBZSxFQUFFO0lBQ2pCLElBQUlHLFFBQVEsR0FBRyxLQUFLO0lBQ3BCLEtBQUssTUFBTWhCLEVBQUUsSUFBSWUsbUJBQW1CLEVBQUU7TUFDcEMsSUFBSWxCLEdBQUcsQ0FBQ0ssR0FBRyxDQUFDRixFQUFFLENBQUMsQ0FBRVUsSUFBSSxJQUFJLENBQUMsRUFBRTtNQUM1QixNQUFNTyxRQUFRLEdBQUdMLEdBQUcsQ0FBQ0osTUFBTSxDQUN4QkMsQ0FBQyxJQUFLQSxDQUFDLEtBQUtULEVBQUUsSUFBSSxDQUFDSCxHQUFHLENBQUNLLEdBQUcsQ0FBQ0YsRUFBRSxDQUFDLENBQUVrQixHQUFHLENBQUNULENBQUMsQ0FBQyxJQUFJWixHQUFHLENBQUNLLEdBQUcsQ0FBQ08sQ0FBQyxDQUFDLENBQUVDLElBQUksR0FBR2QsU0FDaEUsQ0FBQztNQUNELElBQUlxQixRQUFRLENBQUN2RCxNQUFNLEtBQUssQ0FBQyxFQUFFO01BQzNCLE1BQU15RCxPQUFPLEdBQUdGLFFBQVEsQ0FBQzNELEdBQUcsQ0FBQ00sT0FBTyxDQUFDLENBQUMsRUFBRXFELFFBQVEsQ0FBQ3ZELE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBRTtNQUM5RG1DLEdBQUcsQ0FBQ0ssR0FBRyxDQUFDRixFQUFFLENBQUMsQ0FBRUcsR0FBRyxDQUFDZ0IsT0FBTyxDQUFDO01BQ3pCdEIsR0FBRyxDQUFDSyxHQUFHLENBQUNpQixPQUFPLENBQUMsQ0FBRWhCLEdBQUcsQ0FBQ0gsRUFBRSxDQUFDO01BQ3pCZ0IsUUFBUSxHQUFHLElBQUk7SUFDakI7SUFDQSxJQUFJLENBQUNBLFFBQVEsRUFBRTtJQUNmRCxtQkFBbUIsR0FBR0gsR0FBRyxDQUFDSixNQUFNLENBQUVSLEVBQUUsSUFBS0gsR0FBRyxDQUFDSyxHQUFHLENBQUNGLEVBQUUsQ0FBQyxDQUFFVSxJQUFJLEdBQUcsQ0FBQyxDQUFDO0VBQ2pFOztFQUVBO0VBQ0E7RUFDQTtFQUNBLE1BQU1VLGlCQUFpQixHQUFHekMsQ0FBQyxHQUFHLEdBQUc7RUFDakMsS0FBSyxJQUFJMEMsT0FBTyxHQUFHLENBQUMsRUFBRUEsT0FBTyxHQUFHRCxpQkFBaUIsRUFBRUMsT0FBTyxFQUFFLEVBQUU7SUFDNUQsTUFBTUMsQ0FBQyxHQUFHVixHQUFHLENBQUN0RCxHQUFHLENBQUNNLE9BQU8sQ0FBQyxDQUFDLEVBQUVlLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBRTtJQUNyQyxNQUFNNEMsQ0FBQyxHQUFHWCxHQUFHLENBQUN0RCxHQUFHLENBQUNNLE9BQU8sQ0FBQyxDQUFDLEVBQUVlLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBRTtJQUNyQyxJQUFJMkMsQ0FBQyxLQUFLQyxDQUFDLEVBQUU7SUFDYixJQUFJMUIsR0FBRyxDQUFDSyxHQUFHLENBQUNvQixDQUFDLENBQUMsQ0FBRVosSUFBSSxJQUFJZCxTQUFTLEVBQUU7SUFDbkMsSUFBSUMsR0FBRyxDQUFDSyxHQUFHLENBQUNxQixDQUFDLENBQUMsQ0FBRWIsSUFBSSxJQUFJZCxTQUFTLEVBQUU7SUFDbkMsSUFBSUMsR0FBRyxDQUFDSyxHQUFHLENBQUNvQixDQUFDLENBQUMsQ0FBRUosR0FBRyxDQUFDSyxDQUFDLENBQUMsRUFBRTtJQUN4QjFCLEdBQUcsQ0FBQ0ssR0FBRyxDQUFDb0IsQ0FBQyxDQUFDLENBQUVuQixHQUFHLENBQUNvQixDQUFDLENBQUM7SUFDbEIxQixHQUFHLENBQUNLLEdBQUcsQ0FBQ3FCLENBQUMsQ0FBQyxDQUFFcEIsR0FBRyxDQUFDbUIsQ0FBQyxDQUFDO0VBQ3BCO0VBRUEsT0FBT3pCLEdBQUc7QUFDWjs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBaUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU8sU0FBUzJCLGdCQUFnQkEsQ0FBQ3pCLEdBQVksRUFBWTtFQUN2RCxNQUFNMEIsTUFBZ0IsR0FBRyxFQUFFO0VBQzNCLE1BQU07SUFBRUM7RUFBVSxDQUFDLEdBQUczQixHQUFHOztFQUV6QjtFQUNBLEtBQUssTUFBTVUsQ0FBQyxJQUFJaUIsU0FBUyxFQUFFO0lBQ3pCLE1BQU1DLEdBQUcsR0FBR2xCLENBQUMsQ0FBQ21CLE9BQU8sQ0FBQ2xFLE1BQU0sR0FBRytDLENBQUMsQ0FBQ29CLFFBQVEsQ0FBQ25FLE1BQU07SUFDaEQsSUFBSWlFLEdBQUcsR0FBR2xGLFVBQVUsSUFBSWtGLEdBQUcsR0FBR2pGLFVBQVUsRUFBRTtNQUN4QytFLE1BQU0sQ0FBQ2xELElBQUksQ0FBQyxhQUFha0MsQ0FBQyxDQUFDVCxFQUFFLGdCQUFnQjJCLEdBQUcsY0FBY2xGLFVBQVUsS0FBS0MsVUFBVSxHQUFHLENBQUM7SUFDN0Y7RUFDRjs7RUFFQTtFQUNBLE1BQU1vRixrQkFBa0IsR0FBRyxJQUFJN0IsR0FBRyxDQUFTLENBQUM7RUFDNUMsS0FBSyxNQUFNUSxDQUFDLElBQUlpQixTQUFTLEVBQUU7SUFDekIsS0FBSyxNQUFNSyxDQUFDLElBQUl0QixDQUFDLENBQUNvQixRQUFRLEVBQUU7TUFDMUIsTUFBTUcsR0FBRyxHQUFHdkIsQ0FBQyxDQUFDVCxFQUFFLEdBQUcrQixDQUFDLEdBQUcsR0FBR3RCLENBQUMsQ0FBQ1QsRUFBRSxJQUFJK0IsQ0FBQyxFQUFFLEdBQUcsR0FBR0EsQ0FBQyxJQUFJdEIsQ0FBQyxDQUFDVCxFQUFFLEVBQUU7TUFDdEQ4QixrQkFBa0IsQ0FBQzNCLEdBQUcsQ0FBQzZCLEdBQUcsQ0FBQztJQUM3QjtFQUNGO0VBQ0EsSUFBSUYsa0JBQWtCLENBQUNwQixJQUFJLEtBQUtsRSxjQUFjLEVBQzVDaUYsTUFBTSxDQUFDbEQsSUFBSSxDQUFDLE9BQU91RCxrQkFBa0IsQ0FBQ3BCLElBQUksbUNBQW1DbEUsY0FBYyxFQUFFLENBQUM7O0VBRWhHO0VBQ0EsTUFBTXlGLElBQUksR0FBRyxJQUFJbkMsR0FBRyxDQUFDNEIsU0FBUyxDQUFDM0IsR0FBRyxDQUFFVSxDQUFDLElBQUssQ0FBQ0EsQ0FBQyxDQUFDVCxFQUFFLEVBQUVTLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDckQsSUFBSWlCLFNBQVMsQ0FBQ2hFLE1BQU0sR0FBRyxDQUFDLEVBQUU7SUFDeEIsTUFBTXdFLElBQUksR0FBRyxJQUFJakMsR0FBRyxDQUFTLENBQUN5QixTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUUxQixFQUFFLENBQUMsQ0FBQztJQUNoRCxNQUFNbUMsS0FBSyxHQUFHLENBQUNULFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBRTFCLEVBQUUsQ0FBQztJQUNoQyxPQUFPbUMsS0FBSyxDQUFDekUsTUFBTSxHQUFHLENBQUMsRUFBRTtNQUN2QixNQUFNMEUsT0FBTyxHQUFHRCxLQUFLLENBQUNFLEtBQUssQ0FBQyxDQUFFO01BQzlCLE1BQU1DLElBQUksR0FBR0wsSUFBSSxDQUFDL0IsR0FBRyxDQUFDa0MsT0FBTyxDQUFDO01BQzlCLElBQUksQ0FBQ0UsSUFBSSxFQUFFO01BQ1gsS0FBSyxNQUFNM0QsQ0FBQyxJQUFJLENBQUMsR0FBRzJELElBQUksQ0FBQ1YsT0FBTyxFQUFFLEdBQUdVLElBQUksQ0FBQ1QsUUFBUSxDQUFDLEVBQUU7UUFDbkQsSUFBSSxDQUFDSyxJQUFJLENBQUNoQixHQUFHLENBQUN2QyxDQUFDLENBQUMsRUFBRTtVQUNoQnVELElBQUksQ0FBQy9CLEdBQUcsQ0FBQ3hCLENBQUMsQ0FBQztVQUNYd0QsS0FBSyxDQUFDNUQsSUFBSSxDQUFDSSxDQUFDLENBQUM7UUFDZjtNQUNGO0lBQ0Y7SUFDQSxJQUFJdUQsSUFBSSxDQUFDeEIsSUFBSSxLQUFLZ0IsU0FBUyxDQUFDaEUsTUFBTSxFQUNoQytELE1BQU0sQ0FBQ2xELElBQUksQ0FBQyxhQUFhMkQsSUFBSSxDQUFDeEIsSUFBSSxrQ0FBa0NnQixTQUFTLENBQUNoRSxNQUFNLEVBQUUsQ0FBQztFQUMzRjs7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU02RSxLQUFlLEdBQUcsRUFBRTtFQUMxQixLQUFLLE1BQU1DLE1BQU0sSUFBSXpDLEdBQUcsQ0FBQzBDLE9BQU8sRUFBRTtJQUNoQyxJQUFJQyxTQUFTLEdBQUcsQ0FBQztJQUNqQixLQUFLLE1BQU1DLEdBQUcsSUFBSUgsTUFBTSxDQUFDZCxTQUFTLEVBQUU7TUFDbEMsTUFBTWpCLENBQUMsR0FBR3dCLElBQUksQ0FBQy9CLEdBQUcsQ0FBQ3lDLEdBQUcsQ0FBQztNQUN2QixJQUFJbEMsQ0FBQyxJQUFJQSxDQUFDLENBQUNvQixRQUFRLENBQUNlLElBQUksQ0FBRWIsQ0FBQztRQUFBLElBQUFjLFNBQUE7UUFBQSxPQUFLLEVBQUFBLFNBQUEsR0FBQVosSUFBSSxDQUFDL0IsR0FBRyxDQUFDNkIsQ0FBQyxDQUFDLGNBQUFjLFNBQUEsdUJBQVhBLFNBQUEsQ0FBYUwsTUFBTSxNQUFLQSxNQUFNLENBQUN4QyxFQUFFO01BQUEsRUFBQyxFQUFFMEMsU0FBUyxFQUFFO0lBQ2pGO0lBQ0EsSUFBSUEsU0FBUyxHQUFHMUYsd0JBQXdCLEVBQUV1RixLQUFLLENBQUNoRSxJQUFJLENBQUMsR0FBR2lFLE1BQU0sQ0FBQ3hDLEVBQUUsSUFBSTBDLFNBQVMsRUFBRSxDQUFDO0VBQ25GO0VBQ0EsSUFBSUgsS0FBSyxDQUFDN0UsTUFBTSxHQUFHLENBQUMsRUFBRTtJQUNwQitELE1BQU0sQ0FBQ2xELElBQUksQ0FDVCxvQ0FBb0NnRSxLQUFLLENBQUNPLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYTlGLHdCQUF3QixHQUMzRixDQUFDO0VBQ0g7RUFFQSxPQUFPeUUsTUFBTTtBQUNmOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPLFNBQVNzQixpQkFBaUJBLENBQUN6RixHQUFxQixFQUFFMEYsS0FBaUIsRUFBa0I7RUFDMUYsTUFBTXZCLE1BQWdCLEdBQUcsRUFBRTs7RUFFM0I7RUFDQSxNQUFNd0IsbUJBQW1CLEdBQUc1RixRQUFRLENBQUNDLEdBQUcsRUFBRTRGLEtBQUssQ0FBQ0MsSUFBSSxDQUFDO0lBQUV6RixNQUFNLEVBQUU7RUFBRyxDQUFDLEVBQUUsQ0FBQzBGLENBQUMsRUFBRTNGLENBQUMsS0FBSyxZQUFZQSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0VBQ2hHLE1BQU00RixhQUFrRixHQUFHLEVBQUU7RUFDN0YsSUFBSUMsTUFBTSxHQUFHLENBQUM7RUFDZCxLQUFLLElBQUk3RixDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUdsQixZQUFZLENBQUNtQixNQUFNLEVBQUVELENBQUMsRUFBRSxFQUFFO0lBQUEsSUFBQThGLGVBQUE7SUFDNUMsTUFBTTdDLElBQUksR0FBR25FLFlBQVksQ0FBQ2tCLENBQUMsQ0FBRTtJQUM3QjRGLGFBQWEsQ0FBQzlFLElBQUksQ0FBQztNQUNqQnlCLEVBQUUsRUFBRSxVQUFVdkMsQ0FBQyxFQUFFO01BQ2pCK0YsSUFBSSxHQUFBRCxlQUFBLEdBQUVyRyxZQUFZLENBQUNPLENBQUMsQ0FBQyxjQUFBOEYsZUFBQSxjQUFBQSxlQUFBLEdBQUksUUFBUTlGLENBQUMsRUFBRTtNQUNwQ2lELElBQUk7TUFDSmYsV0FBVyxFQUFFc0QsbUJBQW1CLENBQUMxQyxLQUFLLENBQUMrQyxNQUFNLEVBQUVBLE1BQU0sR0FBRzVDLElBQUk7SUFDOUQsQ0FBQyxDQUFDO0lBQ0Y0QyxNQUFNLElBQUk1QyxJQUFJO0VBQ2hCO0VBQ0EsSUFBSTRDLE1BQU0sS0FBSyxFQUFFLEVBQUU3QixNQUFNLENBQUNsRCxJQUFJLENBQUMsdUJBQXVCK0UsTUFBTSxlQUFlLENBQUM7O0VBRTVFO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNRyxVQUFVLEdBQUcsSUFBSTNELEdBQUcsQ0FBc0IsQ0FBQztFQUNqRCxLQUFLLE1BQU0wQyxNQUFNLElBQUlhLGFBQWEsRUFBRTtJQUNsQyxNQUFNeEQsR0FBRyxHQUFHSCxZQUFZLENBQUNwQyxHQUFHLEVBQUVrRixNQUFNLENBQUM3QyxXQUFXLEVBQUVoRCxVQUFVLENBQUM7SUFDN0QsS0FBSyxNQUFNLENBQUNxRCxFQUFFLEVBQUUwRCxVQUFVLENBQUMsSUFBSTdELEdBQUcsRUFBRTtNQUNsQyxJQUFJLENBQUM0RCxVQUFVLENBQUN2QyxHQUFHLENBQUNsQixFQUFFLENBQUMsRUFBRXlELFVBQVUsQ0FBQ0UsR0FBRyxDQUFDM0QsRUFBRSxFQUFFLElBQUlDLEdBQUcsQ0FBUyxDQUFDLENBQUM7TUFDOUQsS0FBSyxNQUFNdEIsQ0FBQyxJQUFJK0UsVUFBVSxFQUFFRCxVQUFVLENBQUN2RCxHQUFHLENBQUNGLEVBQUUsQ0FBQyxDQUFFRyxHQUFHLENBQUN4QixDQUFDLENBQUM7SUFDeEQ7RUFDRjs7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1pRixXQUFXLEdBQUcsSUFBSTlELEdBQUcsQ0FBc0IsQ0FBQztFQUNsRCxLQUFLLE1BQU1FLEVBQUUsSUFBSWlELG1CQUFtQixFQUFFO0lBQ3BDVyxXQUFXLENBQUNELEdBQUcsQ0FBQzNELEVBQUUsRUFBRSxJQUFJQyxHQUFHLENBQVMsQ0FBQyxDQUFDO0VBQ3hDOztFQUVBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTTRELGdCQUFnQixHQUFHLElBQUkvRCxHQUFHLENBQzlCdUQsYUFBYSxDQUFDdEQsR0FBRyxDQUFFK0QsR0FBRyxJQUFLLENBQUNBLEdBQUcsQ0FBQzlELEVBQUUsRUFBRSxJQUFJQyxHQUFHLENBQVMsQ0FBQyxDQUFDLENBQ3hELENBQUM7RUFFRCxTQUFTOEQsY0FBY0EsQ0FBQ0MsUUFBZ0IsRUFBVTtJQUFBLElBQUFDLHFCQUFBLEVBQUFDLHNCQUFBO0lBQ2hELFFBQUFELHFCQUFBLElBQUFDLHNCQUFBLEdBQU9MLGdCQUFnQixDQUFDM0QsR0FBRyxDQUFDOEQsUUFBUSxDQUFDLGNBQUFFLHNCQUFBLHVCQUE5QkEsc0JBQUEsQ0FBZ0N4RCxJQUFJLGNBQUF1RCxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLENBQUM7RUFDbEQ7RUFFQSxTQUFTRSxZQUFZQSxDQUFDQyxPQUFlLEVBQUVDLE9BQWUsRUFBRTtJQUFBLElBQUFDLHNCQUFBLEVBQUFDLHNCQUFBO0lBQ3RELENBQUFELHNCQUFBLEdBQUFULGdCQUFnQixDQUFDM0QsR0FBRyxDQUFDa0UsT0FBTyxDQUFDLGNBQUFFLHNCQUFBLGVBQTdCQSxzQkFBQSxDQUErQm5FLEdBQUcsQ0FBQ2tFLE9BQU8sQ0FBQztJQUMzQyxDQUFBRSxzQkFBQSxHQUFBVixnQkFBZ0IsQ0FBQzNELEdBQUcsQ0FBQ21FLE9BQU8sQ0FBQyxjQUFBRSxzQkFBQSxlQUE3QkEsc0JBQUEsQ0FBK0JwRSxHQUFHLENBQUNpRSxPQUFPLENBQUM7RUFDN0M7RUFFQSxTQUFTSSxlQUFlQSxDQUFDSixPQUFlLEVBQUVDLE9BQWUsRUFBRTtJQUFBLElBQUFJLHNCQUFBLEVBQUFDLHNCQUFBO0lBQ3pELENBQUFELHNCQUFBLEdBQUFaLGdCQUFnQixDQUFDM0QsR0FBRyxDQUFDa0UsT0FBTyxDQUFDLGNBQUFLLHNCQUFBLGVBQTdCQSxzQkFBQSxDQUErQkUsTUFBTSxDQUFDTixPQUFPLENBQUM7SUFDOUMsQ0FBQUssc0JBQUEsR0FBQWIsZ0JBQWdCLENBQUMzRCxHQUFHLENBQUNtRSxPQUFPLENBQUMsY0FBQUssc0JBQUEsZUFBN0JBLHNCQUFBLENBQStCQyxNQUFNLENBQUNQLE9BQU8sQ0FBQztFQUNoRDs7RUFFQTtFQUNBO0VBQ0EsTUFBTVEsbUJBQW1CLEdBQUcsSUFBSTlFLEdBQUcsQ0FBaUJ1RCxhQUFhLENBQUN0RCxHQUFHLENBQUUrRCxHQUFHLElBQUssQ0FBQ0EsR0FBRyxDQUFDOUQsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7O0VBRTVGO0VBQ0EsU0FBUzZFLGNBQWNBLENBQUN2QyxJQUFZLEVBQUU7SUFDcEMsTUFBTXdCLEdBQUcsR0FBR1QsYUFBYSxDQUFDeUIsSUFBSSxDQUFFQyxDQUFDLElBQUssQ0FBQyxHQUFHQSxDQUFDLENBQUNwRixXQUFXLENBQUMsQ0FBQ3FGLFFBQVEsQ0FBQzFDLElBQUksQ0FBQyxDQUFDO0lBQ3hFLElBQUksQ0FBQ3dCLEdBQUcsRUFBRTtJQUNWLE1BQU1tQixRQUFRLEdBQUdyQixXQUFXLENBQUMxRCxHQUFHLENBQUNvQyxJQUFJLENBQUMsQ0FBRTVCLElBQUk7SUFDNUMsSUFBSXVFLFFBQVEsS0FBSyxDQUFDLEVBQUU7TUFBQSxJQUFBQyxxQkFBQTtNQUNsQjtNQUNBTixtQkFBbUIsQ0FBQ2pCLEdBQUcsQ0FBQ0csR0FBRyxDQUFDOUQsRUFBRSxFQUFFLEVBQUFrRixxQkFBQSxHQUFDTixtQkFBbUIsQ0FBQzFFLEdBQUcsQ0FBQzRELEdBQUcsQ0FBQzlELEVBQUUsQ0FBQyxjQUFBa0YscUJBQUEsY0FBQUEscUJBQUEsR0FBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzdFO0VBQ0Y7RUFFQSxTQUFTQyxhQUFhQSxDQUFDbkIsUUFBZ0IsRUFBVTtJQUFBLElBQUFvQixxQkFBQSxFQUFBQyxxQkFBQSxFQUFBQyxtQkFBQTtJQUMvQyxRQUFBRixxQkFBQSxHQUFPckkscUJBQXFCLEVBQUFzSSxxQkFBQSxJQUFBQyxtQkFBQSxHQUFDakMsYUFBYSxDQUFDeUIsSUFBSSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQy9FLEVBQUUsS0FBS2dFLFFBQVEsQ0FBQyxjQUFBc0IsbUJBQUEsdUJBQTVDQSxtQkFBQSxDQUE4QzVFLElBQUksY0FBQTJFLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksQ0FBQyxDQUFDLGNBQUFELHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksRUFBRTtFQUM3RjtFQUVBLFNBQVNHLGFBQWFBLENBQUN2QixRQUFnQixFQUFXO0lBQUEsSUFBQXdCLHNCQUFBO0lBQ2hELE9BQU8sRUFBQUEsc0JBQUEsR0FBQ1osbUJBQW1CLENBQUMxRSxHQUFHLENBQUM4RCxRQUFRLENBQUMsY0FBQXdCLHNCQUFBLGNBQUFBLHNCQUFBLEdBQUksQ0FBQyxLQUFLTCxhQUFhLENBQUNuQixRQUFRLENBQUM7RUFDNUU7O0VBRUE7RUFDQSxTQUFTeUIsc0JBQXNCQSxDQUFDbkQsSUFBWSxFQUFFMEIsUUFBZ0IsRUFBVztJQUFBLElBQUEwQixxQkFBQSxFQUFBQyxnQkFBQTtJQUN2RSxPQUFPLEVBQUFELHFCQUFBLElBQUFDLGdCQUFBLEdBQUMvQixXQUFXLENBQUMxRCxHQUFHLENBQUNvQyxJQUFJLENBQUMsY0FBQXFELGdCQUFBLHVCQUFyQkEsZ0JBQUEsQ0FBdUJqRixJQUFJLGNBQUFnRixxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLENBQUMsTUFBTSxDQUFDLElBQUlILGFBQWEsQ0FBQ3ZCLFFBQVEsQ0FBQztFQUM1RTs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtFQUNFLFNBQVM0QixjQUFjQSxDQUFDOUIsR0FBbUQsRUFBWTtJQUNyRixPQUFPQSxHQUFHLENBQUNuRSxXQUFXLENBQUNhLE1BQU0sQ0FDMUJDLENBQUM7TUFBQSxJQUFBb0Ysc0JBQUEsRUFBQUMsaUJBQUE7TUFBQSxPQUNBLEVBQUFELHNCQUFBLElBQUFDLGlCQUFBLEdBQUNsQyxXQUFXLENBQUMxRCxHQUFHLENBQUNPLENBQUMsQ0FBQyxjQUFBcUYsaUJBQUEsdUJBQWxCQSxpQkFBQSxDQUFvQnBGLElBQUksY0FBQW1GLHNCQUFBLGNBQUFBLHNCQUFBLEdBQUksQ0FBQyxJQUFJL0kscUJBQXFCLElBQUksQ0FBQzJJLHNCQUFzQixDQUFDaEYsQ0FBQyxFQUFFcUQsR0FBRyxDQUFDOUQsRUFBRSxDQUFDO0lBQUEsQ0FDakcsQ0FBQztFQUNIOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsU0FBUytGLFVBQVVBLENBQUNDLEtBQWEsRUFBRUMsS0FBYSxFQUFFN0IsT0FBZSxFQUFFQyxPQUFlLEVBQVc7SUFDM0YsSUFBSSxDQUFDNkIsVUFBVSxDQUFDRixLQUFLLEVBQUVDLEtBQUssRUFBRTdCLE9BQU8sRUFBRUMsT0FBTyxDQUFDLEVBQUUsT0FBTyxLQUFLO0lBQzdEVCxXQUFXLENBQUMxRCxHQUFHLENBQUM4RixLQUFLLENBQUMsQ0FBRTdGLEdBQUcsQ0FBQzhGLEtBQUssQ0FBQztJQUNsQ3JDLFdBQVcsQ0FBQzFELEdBQUcsQ0FBQytGLEtBQUssQ0FBQyxDQUFFOUYsR0FBRyxDQUFDNkYsS0FBSyxDQUFDO0lBQ2xDN0IsWUFBWSxDQUFDQyxPQUFPLEVBQUVDLE9BQU8sQ0FBQztJQUM5QlEsY0FBYyxDQUFDbUIsS0FBSyxDQUFDO0lBQ3JCbkIsY0FBYyxDQUFDb0IsS0FBSyxDQUFDO0lBQ3JCLE9BQU8sSUFBSTtFQUNiOztFQUVBO0VBQ0EsU0FBU0MsVUFBVUEsQ0FBQ0YsS0FBYSxFQUFFQyxLQUFhLEVBQUU3QixPQUFlLEVBQUVDLE9BQWUsRUFBVztJQUFBLElBQUE4QixzQkFBQSxFQUFBQyxpQkFBQSxFQUFBQyxzQkFBQSxFQUFBQyxpQkFBQSxFQUFBQyxvQkFBQSxFQUFBQyxlQUFBLEVBQUFDLHNCQUFBLEVBQUFDLGlCQUFBLEVBQUFDLHFCQUFBLEVBQUFDLGdCQUFBLEVBQUFDLHNCQUFBLEVBQUFDLGlCQUFBLEVBQUFDLGlCQUFBO0lBQzNGLElBQUkzQyxPQUFPLEtBQUtDLE9BQU8sRUFBRSxPQUFPLEtBQUs7SUFDckM7SUFDQSxJQUFJLEVBQUE4QixzQkFBQSxJQUFBQyxpQkFBQSxHQUFDeEMsV0FBVyxDQUFDMUQsR0FBRyxDQUFDOEYsS0FBSyxDQUFDLGNBQUFJLGlCQUFBLHVCQUF0QkEsaUJBQUEsQ0FBd0IxRixJQUFJLGNBQUF5RixzQkFBQSxjQUFBQSxzQkFBQSxHQUFJLENBQUMsS0FBS3JKLHFCQUFxQixFQUFFLE9BQU8sS0FBSztJQUM5RSxJQUFJLEVBQUF1SixzQkFBQSxJQUFBQyxpQkFBQSxHQUFDMUMsV0FBVyxDQUFDMUQsR0FBRyxDQUFDK0YsS0FBSyxDQUFDLGNBQUFLLGlCQUFBLHVCQUF0QkEsaUJBQUEsQ0FBd0I1RixJQUFJLGNBQUEyRixzQkFBQSxjQUFBQSxzQkFBQSxHQUFJLENBQUMsS0FBS3ZKLHFCQUFxQixFQUFFLE9BQU8sS0FBSztJQUM5RTtJQUNBO0lBQ0E7SUFDQTtJQUNBLElBQUkySSxzQkFBc0IsQ0FBQ08sS0FBSyxFQUFFNUIsT0FBTyxDQUFDLEVBQUUsT0FBTyxLQUFLO0lBQ3hELElBQUlxQixzQkFBc0IsQ0FBQ1EsS0FBSyxFQUFFNUIsT0FBTyxDQUFDLEVBQUUsT0FBTyxLQUFLO0lBQ3hEO0lBQ0EsSUFBSU4sY0FBYyxDQUFDSyxPQUFPLENBQUMsSUFBSW5ILHVCQUF1QixFQUFFLE9BQU8sS0FBSztJQUNwRSxJQUFJOEcsY0FBYyxDQUFDTSxPQUFPLENBQUMsSUFBSXBILHVCQUF1QixFQUFFLE9BQU8sS0FBSztJQUNwRTtJQUNBLE1BQU0rSixJQUFJLEdBQUcsRUFBQVQsb0JBQUEsSUFBQUMsZUFBQSxHQUFDL0MsVUFBVSxDQUFDdkQsR0FBRyxDQUFDOEYsS0FBSyxDQUFDLGNBQUFRLGVBQUEsdUJBQXJCQSxlQUFBLENBQXVCOUYsSUFBSSxjQUFBNkYsb0JBQUEsY0FBQUEsb0JBQUEsR0FBSSxDQUFDLE1BQUFFLHNCQUFBLElBQUFDLGlCQUFBLEdBQUs5QyxXQUFXLENBQUMxRCxHQUFHLENBQUM4RixLQUFLLENBQUMsY0FBQVUsaUJBQUEsdUJBQXRCQSxpQkFBQSxDQUF3QmhHLElBQUksY0FBQStGLHNCQUFBLGNBQUFBLHNCQUFBLEdBQUksQ0FBQyxDQUFDO0lBQ3JGLE1BQU1RLElBQUksR0FBRyxFQUFBTixxQkFBQSxJQUFBQyxnQkFBQSxHQUFDbkQsVUFBVSxDQUFDdkQsR0FBRyxDQUFDK0YsS0FBSyxDQUFDLGNBQUFXLGdCQUFBLHVCQUFyQkEsZ0JBQUEsQ0FBdUJsRyxJQUFJLGNBQUFpRyxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLENBQUMsTUFBQUUsc0JBQUEsSUFBQUMsaUJBQUEsR0FBS2xELFdBQVcsQ0FBQzFELEdBQUcsQ0FBQytGLEtBQUssQ0FBQyxjQUFBYSxpQkFBQSx1QkFBdEJBLGlCQUFBLENBQXdCcEcsSUFBSSxjQUFBbUcsc0JBQUEsY0FBQUEsc0JBQUEsR0FBSSxDQUFDLENBQUM7SUFDckYsSUFBSUcsSUFBSSxJQUFJdEssVUFBVSxJQUFJdUssSUFBSSxJQUFJdkssVUFBVSxFQUFFLE9BQU8sS0FBSztJQUMxRCxLQUFBcUssaUJBQUEsR0FBSW5ELFdBQVcsQ0FBQzFELEdBQUcsQ0FBQzhGLEtBQUssQ0FBQyxjQUFBZSxpQkFBQSxlQUF0QkEsaUJBQUEsQ0FBd0I3RixHQUFHLENBQUMrRSxLQUFLLENBQUMsRUFBRSxPQUFPLEtBQUs7SUFDcEQsT0FBTyxJQUFJO0VBQ2I7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxTQUFTaUIsb0JBQW9CQSxDQUMzQkMsR0FBbUQsRUFDbkRDLEdBQW1ELEVBQy9CO0lBQ3BCLE1BQU01SixHQUF1QixHQUFHLEVBQUU7SUFDbEMsS0FBSyxNQUFNOEQsQ0FBQyxJQUFJc0UsY0FBYyxDQUFDdUIsR0FBRyxDQUFDLEVBQUU7TUFDbkMsS0FBSyxNQUFNNUYsQ0FBQyxJQUFJcUUsY0FBYyxDQUFDd0IsR0FBRyxDQUFDLEVBQUU7UUFDbkMsSUFBSWxCLFVBQVUsQ0FBQzVFLENBQUMsRUFBRUMsQ0FBQyxFQUFFNEYsR0FBRyxDQUFDbkgsRUFBRSxFQUFFb0gsR0FBRyxDQUFDcEgsRUFBRSxDQUFDLEVBQUV4QyxHQUFHLENBQUNlLElBQUksQ0FBQyxDQUFDK0MsQ0FBQyxFQUFFQyxDQUFDLENBQUMsQ0FBQztNQUN4RDtJQUNGO0lBQ0EsT0FBTy9ELEdBQUc7RUFDWjs7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU02SixRQUFvQyxHQUFHLEVBQUU7RUFDL0MsS0FBSyxJQUFJNUosQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHNEYsYUFBYSxDQUFDM0YsTUFBTSxFQUFFRCxDQUFDLEVBQUUsRUFBRTtJQUM3QyxLQUFLLElBQUlFLENBQUMsR0FBR0YsQ0FBQyxHQUFHLENBQUMsRUFBRUUsQ0FBQyxHQUFHMEYsYUFBYSxDQUFDM0YsTUFBTSxFQUFFQyxDQUFDLEVBQUUsRUFBRTtNQUNqRDBKLFFBQVEsQ0FBQzlJLElBQUksQ0FBQztRQUFFZCxDQUFDO1FBQUVFO01BQUUsQ0FBQyxDQUFDO0lBQ3pCO0VBQ0Y7RUFDQTtFQUNBO0VBQ0E7O0VBRUE7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNMkosVUFBb0IsR0FBR3BFLEtBQUssQ0FBQ0MsSUFBSSxDQUFDO0lBQUV6RixNQUFNLEVBQUUyRixhQUFhLENBQUMzRjtFQUFPLENBQUMsRUFBRSxDQUFDMEYsQ0FBQyxFQUFFM0YsQ0FBQyxLQUFLQSxDQUFDLENBQUM7RUFDdEYsU0FBUzhKLFFBQVFBLENBQUMvSCxDQUFTLEVBQVU7SUFDbkMsT0FBTzhILFVBQVUsQ0FBQzlILENBQUMsQ0FBQyxLQUFLQSxDQUFDLEdBQUdBLENBQUMsR0FBSThILFVBQVUsQ0FBQzlILENBQUMsQ0FBQyxHQUFJK0gsUUFBUSxDQUFDRCxVQUFVLENBQUM5SCxDQUFDLENBQUUsQ0FBRTtFQUM5RTtFQUNBLFNBQVNnSSxTQUFTQSxDQUFDbEcsQ0FBUyxFQUFFQyxDQUFTLEVBQUU7SUFDdkMsTUFBTWtHLEVBQUUsR0FBR0YsUUFBUSxDQUFDakcsQ0FBQyxDQUFDO0lBQ3RCLE1BQU1vRyxFQUFFLEdBQUdILFFBQVEsQ0FBQ2hHLENBQUMsQ0FBQztJQUN0QixJQUFJa0csRUFBRSxLQUFLQyxFQUFFLEVBQUVKLFVBQVUsQ0FBQ0csRUFBRSxDQUFDLEdBQUdDLEVBQUU7RUFDcEM7RUFFQSxJQUFJQyxTQUFTLEdBQUcsQ0FBQztFQUNqQjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNQyxhQUFhLEdBQUd2SyxRQUFRLENBQUNDLEdBQUcsRUFBRStKLFFBQVEsQ0FBQztFQUM3QyxLQUFLLE1BQU1RLElBQUksSUFBSUQsYUFBYSxFQUFFO0lBQ2hDLElBQUlELFNBQVMsSUFBSXRFLGFBQWEsQ0FBQzNGLE1BQU0sR0FBRyxDQUFDLEVBQUU7SUFDM0MsTUFBTW9LLFVBQVUsR0FBR3pFLGFBQWEsQ0FBQ3dFLElBQUksQ0FBQ3BLLENBQUMsQ0FBQyxDQUFFdUMsRUFBRTtJQUM1QyxNQUFNK0gsUUFBUSxHQUFHMUUsYUFBYSxDQUFDd0UsSUFBSSxDQUFDbEssQ0FBQyxDQUFDLENBQUVxQyxFQUFFO0lBQzFDZ0QsS0FBSyxhQUFMQSxLQUFLLGVBQUxBLEtBQUssQ0FBRWdGLFdBQVcsQ0FBQ3pKLElBQUksQ0FBQyxDQUFDdUosVUFBVSxFQUFFQyxRQUFRLENBQUMsQ0FBQztJQUMvQyxJQUFJUixRQUFRLENBQUNNLElBQUksQ0FBQ3BLLENBQUMsQ0FBQyxLQUFLOEosUUFBUSxDQUFDTSxJQUFJLENBQUNsSyxDQUFDLENBQUMsRUFBRSxTQUFTLENBQUM7SUFDckQsTUFBTXdGLElBQUksR0FBR0UsYUFBYSxDQUFDd0UsSUFBSSxDQUFDcEssQ0FBQyxDQUFFO0lBQ25DLE1BQU13SyxFQUFFLEdBQUc1RSxhQUFhLENBQUN3RSxJQUFJLENBQUNsSyxDQUFDLENBQUU7SUFDakMsTUFBTXVLLFNBQVMsR0FBR3RDLGNBQWMsQ0FBQ3pDLElBQUksQ0FBQztJQUN0QyxNQUFNZ0YsU0FBUyxHQUFHdkMsY0FBYyxDQUFDcUMsRUFBRSxDQUFDO0lBQ3BDLElBQUlDLFNBQVMsQ0FBQ3hLLE1BQU0sS0FBSyxDQUFDLElBQUl5SyxTQUFTLENBQUN6SyxNQUFNLEtBQUssQ0FBQyxFQUFFO0lBQ3RELE1BQU1zSSxLQUFLLEdBQUdrQyxTQUFTLENBQUM1SyxHQUFHLENBQUNNLE9BQU8sQ0FBQyxDQUFDLEVBQUVzSyxTQUFTLENBQUN4SyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUU7SUFDOUQsTUFBTXVJLEtBQUssR0FBR2tDLFNBQVMsQ0FBQzdLLEdBQUcsQ0FBQ00sT0FBTyxDQUFDLENBQUMsRUFBRXVLLFNBQVMsQ0FBQ3pLLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBRTtJQUM5RCxJQUFJcUksVUFBVSxDQUFDQyxLQUFLLEVBQUVDLEtBQUssRUFBRTZCLFVBQVUsRUFBRUMsUUFBUSxDQUFDLEVBQUU7TUFDbERQLFNBQVMsQ0FBQ0ssSUFBSSxDQUFDcEssQ0FBQyxFQUFFb0ssSUFBSSxDQUFDbEssQ0FBQyxDQUFDO01BQ3pCZ0ssU0FBUyxFQUFFO0lBQ2I7RUFDRjs7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxJQUFJUyxZQUFZLEdBQUcvRSxhQUFhLENBQUMzRixNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7RUFDN0MsSUFBSTJLLFlBQVksR0FBRyxDQUFDO0VBQ3BCO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLE1BQU1DLGlCQUFpQixHQUFHLElBQUk7O0VBRTlCO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTs7RUFTQSxNQUFNQyxhQUEyQixHQUFHLEVBQUU7RUFDdEM7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0VBRUUsT0FBT0gsWUFBWSxHQUFHNUwsY0FBYyxJQUFJNkwsWUFBWSxHQUFHQyxpQkFBaUIsRUFBRTtJQUFBLElBQUFFLHNCQUFBLEVBQUFDLGtCQUFBLEVBQUFDLHNCQUFBLEVBQUFDLGtCQUFBO0lBQ3hFTixZQUFZLEVBQUU7SUFDZCxNQUFNTyxXQUE0RixHQUFHLEVBQUU7SUFDdkcsS0FBSyxNQUFNekIsR0FBRyxJQUFJOUQsYUFBYSxFQUFFO01BQy9CLEtBQUssTUFBTStELEdBQUcsSUFBSS9ELGFBQWEsRUFBRTtRQUFBLElBQUF3RixzQkFBQSxFQUFBQyxzQkFBQTtRQUMvQixJQUFJM0IsR0FBRyxDQUFDbkgsRUFBRSxLQUFLb0gsR0FBRyxDQUFDcEgsRUFBRSxFQUFFO1FBQ3ZCLElBQUkrRCxjQUFjLENBQUNvRCxHQUFHLENBQUNuSCxFQUFFLENBQUMsSUFBSS9DLHVCQUF1QixFQUFFO1FBQ3ZELElBQUk4RyxjQUFjLENBQUNxRCxHQUFHLENBQUNwSCxFQUFFLENBQUMsSUFBSS9DLHVCQUF1QixFQUFFO1FBQ3ZEO1FBQ0E7UUFDQSxJQUFJMkksY0FBYyxDQUFDdUIsR0FBRyxDQUFDLENBQUN6SixNQUFNLEtBQUssQ0FBQyxJQUFJa0ksY0FBYyxDQUFDd0IsR0FBRyxDQUFDLENBQUMxSixNQUFNLEtBQUssQ0FBQyxFQUFFO1FBQzFFLElBQUl3SixvQkFBb0IsQ0FBQ0MsR0FBRyxFQUFFQyxHQUFHLENBQUMsQ0FBQzFKLE1BQU0sS0FBSyxDQUFDLEVBQUU7UUFDakQsTUFBTXFMLE9BQU8sSUFBQUYsc0JBQUEsR0FBR2pFLG1CQUFtQixDQUFDMUUsR0FBRyxDQUFDaUgsR0FBRyxDQUFDbkgsRUFBRSxDQUFDLGNBQUE2SSxzQkFBQSxjQUFBQSxzQkFBQSxHQUFJLENBQUM7UUFDcEQsTUFBTUcsT0FBTyxJQUFBRixzQkFBQSxHQUFHbEUsbUJBQW1CLENBQUMxRSxHQUFHLENBQUNrSCxHQUFHLENBQUNwSCxFQUFFLENBQUMsY0FBQThJLHNCQUFBLGNBQUFBLHNCQUFBLEdBQUksQ0FBQztRQUNwRCxNQUFNRyxNQUFNLEdBQUdsRixjQUFjLENBQUNvRCxHQUFHLENBQUNuSCxFQUFFLENBQUM7UUFDckMsTUFBTWtKLE1BQU0sR0FBR25GLGNBQWMsQ0FBQ3FELEdBQUcsQ0FBQ3BILEVBQUUsQ0FBQztRQUNyQyxJQUFJbUosS0FBSyxHQUFHLENBQUM7UUFDYjtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLElBQUlKLE9BQU8sR0FBRy9MLHdCQUF3QixFQUFFbU0sS0FBSyxJQUFJLElBQUk7UUFDckQsSUFBSUgsT0FBTyxHQUFHaE0sd0JBQXdCLEVBQUVtTSxLQUFLLElBQUksR0FBRztRQUNwREEsS0FBSyxJQUFJRixNQUFNLEdBQUdDLE1BQU07UUFDeEJOLFdBQVcsQ0FBQ3JLLElBQUksQ0FBQztVQUFFNEksR0FBRztVQUFFQyxHQUFHO1VBQUUrQjtRQUFNLENBQUMsQ0FBQztNQUN2QztJQUNGO0lBQ0EsSUFBSVAsV0FBVyxDQUFDbEwsTUFBTSxLQUFLLENBQUMsRUFBRTtNQUFBLElBQUEwTCxpQkFBQSxFQUFBQyxpQkFBQTtNQUM1QjtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQSxJQUFJZCxhQUFhLENBQUM3SyxNQUFNLEtBQUssQ0FBQyxFQUFFO01BQ2hDLE1BQU00TCxJQUFJLEdBQUdmLGFBQWEsQ0FBQ2dCLEdBQUcsQ0FBQyxDQUFFO01BQ2pDO01BQ0EsQ0FBQUgsaUJBQUEsR0FBQXhGLFdBQVcsQ0FBQzFELEdBQUcsQ0FBQ29KLElBQUksQ0FBQ3RELEtBQUssQ0FBQyxjQUFBb0QsaUJBQUEsZUFBM0JBLGlCQUFBLENBQTZCekUsTUFBTSxDQUFDMkUsSUFBSSxDQUFDckQsS0FBSyxDQUFDO01BQy9DLENBQUFvRCxpQkFBQSxHQUFBekYsV0FBVyxDQUFDMUQsR0FBRyxDQUFDb0osSUFBSSxDQUFDckQsS0FBSyxDQUFDLGNBQUFvRCxpQkFBQSxlQUEzQkEsaUJBQUEsQ0FBNkIxRSxNQUFNLENBQUMyRSxJQUFJLENBQUN0RCxLQUFLLENBQUM7TUFDL0N4QixlQUFlLENBQUM4RSxJQUFJLENBQUNsRixPQUFPLEVBQUVrRixJQUFJLENBQUNqRixPQUFPLENBQUM7TUFDM0MsSUFBSWlGLElBQUksQ0FBQ0UsZ0JBQWdCLEVBQUU7UUFBQSxJQUFBQyxzQkFBQTtRQUN6QjdFLG1CQUFtQixDQUFDakIsR0FBRyxDQUNyQjJGLElBQUksQ0FBQ2xGLE9BQU8sRUFDWixFQUFBcUYsc0JBQUEsR0FBQzdFLG1CQUFtQixDQUFDMUUsR0FBRyxDQUFDb0osSUFBSSxDQUFDbEYsT0FBTyxDQUFDLGNBQUFxRixzQkFBQSxjQUFBQSxzQkFBQSxHQUFJLENBQUMsSUFBSSxDQUNqRCxDQUFDO01BQ0g7TUFDQSxJQUFJSCxJQUFJLENBQUNJLGdCQUFnQixFQUFFO1FBQUEsSUFBQUMsc0JBQUE7UUFDekIvRSxtQkFBbUIsQ0FBQ2pCLEdBQUcsQ0FDckIyRixJQUFJLENBQUNqRixPQUFPLEVBQ1osRUFBQXNGLHNCQUFBLEdBQUMvRSxtQkFBbUIsQ0FBQzFFLEdBQUcsQ0FBQ29KLElBQUksQ0FBQ2pGLE9BQU8sQ0FBQyxjQUFBc0Ysc0JBQUEsY0FBQUEsc0JBQUEsR0FBSSxDQUFDLElBQUksQ0FDakQsQ0FBQztNQUNIO01BQ0F2QixZQUFZLEVBQUU7TUFDZDtJQUNGO0lBQ0EsSUFBSXdCLFNBQVMsR0FBRyxDQUFDQyxRQUFRO0lBQ3pCLEtBQUssTUFBTXBKLENBQUMsSUFBSW1JLFdBQVcsRUFBRSxJQUFJbkksQ0FBQyxDQUFDMEksS0FBSyxHQUFHUyxTQUFTLEVBQUVBLFNBQVMsR0FBR25KLENBQUMsQ0FBQzBJLEtBQUs7SUFDekUsTUFBTVcsU0FBUyxHQUFHbEIsV0FBVyxDQUFDcEksTUFBTSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQzBJLEtBQUssS0FBS1MsU0FBUyxDQUFDO0lBQ2xFLE1BQU0vQixJQUFJLEdBQUdpQyxTQUFTLENBQUN4TSxHQUFHLENBQUNNLE9BQU8sQ0FBQyxDQUFDLEVBQUVrTSxTQUFTLENBQUNwTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUU7SUFDN0Q7SUFDQTtJQUNBO0lBQ0EsTUFBTXFNLE9BQU8sR0FBRzdDLG9CQUFvQixDQUFDVyxJQUFJLENBQUNWLEdBQUcsRUFBRVUsSUFBSSxDQUFDVCxHQUFHLENBQUM7SUFDeEQsTUFBTTRDLFFBQVEsR0FBRyxDQUFDLEdBQUcsSUFBSS9KLEdBQUcsQ0FBQzhKLE9BQU8sQ0FBQ2hLLEdBQUcsQ0FBQyxDQUFDLENBQUN1QixDQUFDLENBQUMsS0FBS0EsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN0RCxNQUFNMkksT0FBTyxHQUFHRCxRQUFRLENBQUN4SixNQUFNLENBQUVDLENBQUM7TUFBQSxJQUFBeUosc0JBQUEsRUFBQUMsaUJBQUE7TUFBQSxPQUFLLEVBQUFELHNCQUFBLElBQUFDLGlCQUFBLEdBQUN2RyxXQUFXLENBQUMxRCxHQUFHLENBQUNPLENBQUMsQ0FBQyxjQUFBMEosaUJBQUEsdUJBQWxCQSxpQkFBQSxDQUFvQnpKLElBQUksY0FBQXdKLHNCQUFBLGNBQUFBLHNCQUFBLEdBQUksQ0FBQyxNQUFNLENBQUM7SUFBQSxFQUFDO0lBQzdFLE1BQU1sRSxLQUFLLEdBQ1RpRSxPQUFPLENBQUN2TSxNQUFNLEdBQUcsQ0FBQyxHQUNkdU0sT0FBTyxDQUFDM00sR0FBRyxDQUFDTSxPQUFPLENBQUMsQ0FBQyxFQUFFcU0sT0FBTyxDQUFDdk0sTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQzNDc00sUUFBUSxDQUFDMU0sR0FBRyxDQUFDTSxPQUFPLENBQUMsQ0FBQyxFQUFFb00sUUFBUSxDQUFDdE0sTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFFO0lBQ3BELE1BQU0wTSxRQUFRLEdBQUdMLE9BQU8sQ0FBQ3ZKLE1BQU0sQ0FBQyxDQUFDLENBQUNjLENBQUMsQ0FBQyxLQUFLQSxDQUFDLEtBQUswRSxLQUFLLENBQUMsQ0FBQ2pHLEdBQUcsQ0FBQyxDQUFDLEdBQUd3QixDQUFDLENBQUMsS0FBS0EsQ0FBQyxDQUFDO0lBQ3ZFLE1BQU04SSxNQUFNLEdBQUdELFFBQVEsQ0FBQzVKLE1BQU0sQ0FBRUMsQ0FBQztNQUFBLElBQUE2SixzQkFBQSxFQUFBQyxpQkFBQTtNQUFBLE9BQUssRUFBQUQsc0JBQUEsSUFBQUMsaUJBQUEsR0FBQzNHLFdBQVcsQ0FBQzFELEdBQUcsQ0FBQ08sQ0FBQyxDQUFDLGNBQUE4SixpQkFBQSx1QkFBbEJBLGlCQUFBLENBQW9CN0osSUFBSSxjQUFBNEosc0JBQUEsY0FBQUEsc0JBQUEsR0FBSSxDQUFDLE1BQU0sQ0FBQztJQUFBLEVBQUM7SUFDNUUsTUFBTXJFLEtBQUssR0FDVG9FLE1BQU0sQ0FBQzNNLE1BQU0sR0FBRyxDQUFDLEdBQ2IyTSxNQUFNLENBQUMvTSxHQUFHLENBQUNNLE9BQU8sQ0FBQyxDQUFDLEVBQUV5TSxNQUFNLENBQUMzTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FDekMwTSxRQUFRLENBQUM5TSxHQUFHLENBQUNNLE9BQU8sQ0FBQyxDQUFDLEVBQUV3TSxRQUFRLENBQUMxTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUU7SUFDcEQsTUFBTThNLGFBQWEsR0FBRyxFQUFBaEMsc0JBQUEsSUFBQUMsa0JBQUEsR0FBQzdFLFdBQVcsQ0FBQzFELEdBQUcsQ0FBQzhGLEtBQUssQ0FBQyxjQUFBeUMsa0JBQUEsdUJBQXRCQSxrQkFBQSxDQUF3Qi9ILElBQUksY0FBQThILHNCQUFBLGNBQUFBLHNCQUFBLEdBQUksQ0FBQyxNQUFNLENBQUM7SUFDL0QsTUFBTWlDLGFBQWEsR0FBRyxFQUFBL0Isc0JBQUEsSUFBQUMsa0JBQUEsR0FBQy9FLFdBQVcsQ0FBQzFELEdBQUcsQ0FBQytGLEtBQUssQ0FBQyxjQUFBMEMsa0JBQUEsdUJBQXRCQSxrQkFBQSxDQUF3QmpJLElBQUksY0FBQWdJLHNCQUFBLGNBQUFBLHNCQUFBLEdBQUksQ0FBQyxNQUFNLENBQUM7SUFDL0QsTUFBTWdDLE1BQU0sR0FBR25GLGFBQWEsQ0FBQ3NDLElBQUksQ0FBQ1YsR0FBRyxDQUFDbkgsRUFBRSxDQUFDO0lBQ3pDLE1BQU0ySyxNQUFNLEdBQUdwRixhQUFhLENBQUNzQyxJQUFJLENBQUNULEdBQUcsQ0FBQ3BILEVBQUUsQ0FBQztJQUN6QyxJQUFJLENBQUMrRixVQUFVLENBQUNDLEtBQUssRUFBRUMsS0FBSyxFQUFFNEIsSUFBSSxDQUFDVixHQUFHLENBQUNuSCxFQUFFLEVBQUU2SCxJQUFJLENBQUNULEdBQUcsQ0FBQ3BILEVBQUUsQ0FBQyxFQUFFO0lBQ3pEZ0QsS0FBSyxhQUFMQSxLQUFLLGVBQUxBLEtBQUssQ0FBRTRILFdBQVcsQ0FBQ3JNLElBQUksQ0FBQztNQUFFNkYsT0FBTyxFQUFFeUQsSUFBSSxDQUFDVixHQUFHLENBQUNuSCxFQUFFO01BQUVxRSxPQUFPLEVBQUV3RCxJQUFJLENBQUNULEdBQUcsQ0FBQ3BILEVBQUU7TUFBRTBLLE1BQU07TUFBRUM7SUFBTyxDQUFDLENBQUM7SUFDdkZwQyxhQUFhLENBQUNoSyxJQUFJLENBQUM7TUFDakJ5SCxLQUFLO01BQ0xDLEtBQUs7TUFDTDdCLE9BQU8sRUFBRXlELElBQUksQ0FBQ1YsR0FBRyxDQUFDbkgsRUFBRTtNQUNwQnFFLE9BQU8sRUFBRXdELElBQUksQ0FBQ1QsR0FBRyxDQUFDcEgsRUFBRTtNQUNwQndKLGdCQUFnQixFQUFFZ0IsYUFBYTtNQUMvQmQsZ0JBQWdCLEVBQUVlO0lBQ3BCLENBQUMsQ0FBQztJQUNGckMsWUFBWSxFQUFFO0VBQ2hCO0VBRUEsSUFBSUEsWUFBWSxHQUFHNUwsY0FBYyxFQUMvQmlGLE1BQU0sQ0FBQ2xELElBQUksQ0FDVCxtQkFBbUIvQixjQUFjLGlCQUFpQjhMLGlCQUFpQixtQkFBbUJGLFlBQVksR0FDcEcsQ0FBQztFQUNIO0VBQ0E7RUFDQTtFQUNBLE1BQU0zRixPQUFpQixHQUFHWSxhQUFhLENBQUN0RCxHQUFHLENBQUUrRCxHQUFHO0lBQUEsSUFBQStHLHNCQUFBO0lBQUEsT0FBTTtNQUNwRDdLLEVBQUUsRUFBRThELEdBQUcsQ0FBQzlELEVBQUU7TUFDVndELElBQUksRUFBRU0sR0FBRyxDQUFDTixJQUFJO01BQ2RzSCxLQUFLLEVBQUV6TSxJQUFJLENBQUMwTSxHQUFHLENBQUMsQ0FBQyxFQUFFMU0sSUFBSSxDQUFDa0IsS0FBSyxDQUFDdUUsR0FBRyxDQUFDcEQsSUFBSSxHQUFHOUQsYUFBYSxDQUFDLEtBQUFpTyxzQkFBQSxHQUFJakcsbUJBQW1CLENBQUMxRSxHQUFHLENBQUM0RCxHQUFHLENBQUM5RCxFQUFFLENBQUMsY0FBQTZLLHNCQUFBLGNBQUFBLHNCQUFBLEdBQUksQ0FBQyxDQUFDLENBQUM7TUFDakduSixTQUFTLEVBQUVvQyxHQUFHLENBQUNuRTtJQUNqQixDQUFDO0VBQUEsQ0FBQyxDQUFDOztFQUVIO0VBQ0E7RUFDQSxNQUFNK0IsU0FBcUIsR0FBRyxFQUFFO0VBQ2hDLEtBQUssSUFBSXNKLEVBQUUsR0FBRyxDQUFDLEVBQUVBLEVBQUUsR0FBRzNILGFBQWEsQ0FBQzNGLE1BQU0sRUFBRXNOLEVBQUUsRUFBRSxFQUFFO0lBQ2hELE1BQU14SSxNQUFNLEdBQUdhLGFBQWEsQ0FBQzJILEVBQUUsQ0FBRTtJQUNqQyxNQUFNQyxPQUFPLEdBQUlELEVBQUUsR0FBRyxDQUFDLEdBQUksR0FBRyxHQUFHLEVBQUU7SUFDbkMsTUFBTUUsT0FBTyxHQUFHN00sSUFBSSxDQUFDa0IsS0FBSyxDQUFDeUwsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxFQUFFO0lBQzdDLE1BQU03TSxHQUFHLEdBQUdPLFlBQVksQ0FBQ3BCLEdBQUcsRUFBRWtGLE1BQU0sQ0FBQzlCLElBQUksRUFBRXVLLE9BQU8sRUFBRUEsT0FBTyxHQUFHLEdBQUcsRUFBRUMsT0FBTyxFQUFFQSxPQUFPLEdBQUcsR0FBRyxDQUFDO0lBQzFGLEtBQUssSUFBSUMsRUFBRSxHQUFHLENBQUMsRUFBRUEsRUFBRSxHQUFHM0ksTUFBTSxDQUFDN0MsV0FBVyxDQUFDakMsTUFBTSxFQUFFeU4sRUFBRSxFQUFFLEVBQUU7TUFBQSxJQUFBQyxnQkFBQSxFQUFBQyxrQkFBQTtNQUNyRCxNQUFNckwsRUFBRSxHQUFHd0MsTUFBTSxDQUFDN0MsV0FBVyxDQUFDd0wsRUFBRSxDQUFFO01BQ2xDLE1BQU0sQ0FBQ0csRUFBRSxFQUFFQyxFQUFFLENBQUMsR0FBR3BOLEdBQUcsQ0FBQ2dOLEVBQUUsQ0FBRTtNQUN6QixNQUFNSyxNQUFNLEdBQUdyTyxhQUFhLENBQUNHLEdBQUcsQ0FBQ00sT0FBTyxDQUFDLENBQUMsRUFBRVQsYUFBYSxDQUFDTyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUU7TUFDdkUsTUFBTStOLE1BQU0sR0FBR3JPLGFBQWEsQ0FBQ0UsR0FBRyxDQUFDTSxPQUFPLENBQUMsQ0FBQyxFQUFFUixhQUFhLENBQUNNLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBRTtNQUN2RSxNQUFNa0UsT0FBTyxHQUFHLENBQUMsS0FBQXdKLGdCQUFBLEdBQUkzSCxVQUFVLENBQUN2RCxHQUFHLENBQUNGLEVBQUUsQ0FBQyxjQUFBb0wsZ0JBQUEsY0FBQUEsZ0JBQUEsR0FBSSxFQUFFLENBQUMsQ0FBQztNQUMvQyxNQUFNdkosUUFBUSxHQUFHLENBQUMsS0FBQXdKLGtCQUFBLEdBQUl6SCxXQUFXLENBQUMxRCxHQUFHLENBQUNGLEVBQUUsQ0FBQyxjQUFBcUwsa0JBQUEsY0FBQUEsa0JBQUEsR0FBSSxFQUFFLENBQUMsQ0FBQztNQUNqRCxNQUFNSyxPQUFPLEdBQUc1TixrQkFBa0IsQ0FBQ3dOLEVBQUUsRUFBRUMsRUFBRSxFQUFFak8sR0FBRyxDQUFDTSxPQUFPLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxFQUFFTixHQUFHLENBQUNNLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7TUFDbEYsTUFBTStOLE9BQWMsR0FBRyxDQUFDTCxFQUFFLEVBQUVDLEVBQUUsQ0FBQztNQUMvQjdKLFNBQVMsQ0FBQ25ELElBQUksQ0FBQztRQUFFeUIsRUFBRTtRQUFFd0QsSUFBSSxFQUFFLEdBQUdnSSxNQUFNLElBQUlDLE1BQU0sRUFBRTtRQUFFakosTUFBTSxFQUFFQSxNQUFNLENBQUN4QyxFQUFFO1FBQUU0QixPQUFPO1FBQUVDLFFBQVE7UUFBRTZKLE9BQU87UUFBRUM7TUFBUSxDQUFDLENBQUM7SUFDN0c7RUFDRjs7RUFFQTtFQUNBLE1BQU1DLElBQUksR0FBR2xLLFNBQVMsQ0FBQ21LLE9BQU8sQ0FBRXBMLENBQUMsSUFBS0EsQ0FBQyxDQUFDaUwsT0FBTyxDQUFDM0wsR0FBRyxDQUFFK0wsRUFBRSxJQUFLQSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNuRSxNQUFNQyxJQUFJLEdBQUdySyxTQUFTLENBQUNtSyxPQUFPLENBQUVwTCxDQUFDLElBQUtBLENBQUMsQ0FBQ2lMLE9BQU8sQ0FBQzNMLEdBQUcsQ0FBRStMLEVBQUUsSUFBS0EsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDbkUsTUFBTWxOLElBQUksR0FBR1AsSUFBSSxDQUFDMk4sR0FBRyxDQUFDLEdBQUdKLElBQUksQ0FBQyxHQUFHLEVBQUU7RUFDbkMsTUFBTTlNLElBQUksR0FBR1QsSUFBSSxDQUFDMk4sR0FBRyxDQUFDLEdBQUdELElBQUksQ0FBQyxHQUFHLEVBQUU7RUFDbkMsTUFBTWxOLElBQUksR0FBR1IsSUFBSSxDQUFDME0sR0FBRyxDQUFDLEdBQUdhLElBQUksQ0FBQyxHQUFHLEVBQUU7RUFDbkMsTUFBTTdNLElBQUksR0FBR1YsSUFBSSxDQUFDME0sR0FBRyxDQUFDLEdBQUdnQixJQUFJLENBQUMsR0FBRyxFQUFFO0VBQ25DLE1BQU1FLE1BQU0sR0FBRztJQUFFek0sQ0FBQyxFQUFFWixJQUFJO0lBQUVhLENBQUMsRUFBRVgsSUFBSTtJQUFFb04sS0FBSyxFQUFFck4sSUFBSSxHQUFHRCxJQUFJO0lBQUV1TixNQUFNLEVBQUVwTixJQUFJLEdBQUdEO0VBQUssQ0FBQztFQUU1RSxNQUFNaUIsR0FBWSxHQUFHO0lBQ25CQyxFQUFFLEVBQUUsV0FBVztJQUNmd0QsSUFBSSxFQUFFLHVCQUF1QjtJQUM3QnlJLE1BQU07SUFDTnZLLFNBQVM7SUFDVGU7RUFDRixDQUFDOztFQUVEO0VBQ0E7RUFDQSxJQUFJaEIsTUFBTSxDQUFDL0QsTUFBTSxHQUFHLENBQUMsRUFBRSxPQUFPO0lBQUUwTyxFQUFFLEVBQUUsS0FBSztJQUFFM0s7RUFBTyxDQUFDO0VBRW5ELE9BQU87SUFBRTJLLEVBQUUsRUFBRSxJQUFJO0lBQUVyTTtFQUFJLENBQUM7QUFDMUI7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU8sU0FBU3NNLGFBQWFBLENBQUNDLElBQVksRUFBa0I7RUFDMUQsT0FBT0Msb0JBQW9CLENBQUMsSUFBSWxRLGdCQUFnQixDQUFDaVEsSUFBSSxDQUFDLENBQUM7QUFDekQ7O0FBRUE7QUFDQSxPQUFPLFNBQVNDLG9CQUFvQkEsQ0FDbENqUCxHQUFxQixFQUNyQmtQLEtBSUMsR0FBRyxDQUFDLENBQUMsRUFDVTtFQUNoQixPQUFPQyxxQkFBcUIsQ0FBQ25QLEdBQUcsRUFBRWtQLEtBQUssQ0FBQztBQUMxQzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTyxTQUFTRSxxQkFBcUJBLENBQ25DSixJQUFZLEVBQ1pFLEtBSUMsR0FBRyxDQUFDLENBQUMsRUFDVTtFQUFBLElBQUFHLFdBQUEsRUFBQUMsb0JBQUEsRUFBQUMsZUFBQTtFQUNoQixNQUFNQyxJQUFJLElBQUFILFdBQUEsR0FBR0gsS0FBSyxDQUFDTSxJQUFJLGNBQUFILFdBQUEsY0FBQUEsV0FBQSxHQUFJNUosaUJBQWlCO0VBQzVDLE1BQU1nSyxhQUFhLElBQUFILG9CQUFBLEdBQUdKLEtBQUssQ0FBQ08sYUFBYSxjQUFBSCxvQkFBQSxjQUFBQSxvQkFBQSxHQUFJdFEsb0JBQW9CO0VBQ2pFLE1BQU0wUSxHQUFHLElBQUFILGVBQUEsR0FBR0wsS0FBSyxDQUFDUyxRQUFRLGNBQUFKLGVBQUEsY0FBQUEsZUFBQSxHQUFJaFEsa0JBQWtCO0VBQ2hELE1BQU1TLEdBQUcsR0FBRyxJQUFJakIsZ0JBQWdCLENBQUNpUSxJQUFJLENBQUM7RUFDdEMsT0FBT0cscUJBQXFCLENBQUNuUCxHQUFHLEVBQUU7SUFBRXdQLElBQUk7SUFBRUMsYUFBYTtJQUFFRSxRQUFRLEVBQUVEO0VBQUksQ0FBQyxDQUFDO0FBQzNFO0FBRUEsU0FBU1AscUJBQXFCQSxDQUM1Qm5QLEdBQXFCLEVBQ3JCa1AsS0FJQyxHQUFHLENBQUMsQ0FBQyxFQUNVO0VBQUEsSUFBQVUsWUFBQSxFQUFBQyxxQkFBQSxFQUFBQyxnQkFBQTtFQUNoQixNQUFNTixJQUFJLElBQUFJLFlBQUEsR0FBR1YsS0FBSyxDQUFDTSxJQUFJLGNBQUFJLFlBQUEsY0FBQUEsWUFBQSxHQUFJbkssaUJBQWlCO0VBQzVDLE1BQU1nSyxhQUFhLElBQUFJLHFCQUFBLEdBQUdYLEtBQUssQ0FBQ08sYUFBYSxjQUFBSSxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJN1Esb0JBQW9CO0VBQ2pFLE1BQU0wUSxHQUFHLElBQUFJLGdCQUFBLEdBQUdaLEtBQUssQ0FBQ1MsUUFBUSxjQUFBRyxnQkFBQSxjQUFBQSxnQkFBQSxHQUFJdlEsa0JBQWtCO0VBQ2hELElBQUl3USxVQUFpQyxHQUFHLElBQUk7RUFDNUMsS0FBSyxJQUFJaE0sT0FBTyxHQUFHLENBQUMsRUFBRUEsT0FBTyxJQUFJMkwsR0FBRyxFQUFFM0wsT0FBTyxFQUFFLEVBQUU7SUFDL0MsSUFBSWlNLE1BQU0sR0FBR1IsSUFBSSxDQUFDeFAsR0FBRyxDQUFDO0lBQ3RCO0lBQ0E7SUFDQSxNQUFNaVEsVUFBVSxHQUFHRCxNQUFNLENBQUNsQixFQUFFLEdBQUc1SyxnQkFBZ0IsQ0FBQzhMLE1BQU0sQ0FBQ3ZOLEdBQUcsQ0FBQyxHQUFHLEVBQUU7SUFDaEUsSUFBSXdOLFVBQVUsQ0FBQzdQLE1BQU0sR0FBRyxDQUFDLEVBQUU0UCxNQUFNLEdBQUc7TUFBRWxCLEVBQUUsRUFBRSxLQUFLO01BQUUzSyxNQUFNLEVBQUU4TDtJQUFXLENBQUM7SUFDckUsSUFBSUQsTUFBTSxDQUFDbEIsRUFBRSxFQUFFO01BQ2IsTUFBTW9CLGNBQWMsR0FBR1QsYUFBYSxDQUFDTyxNQUFNLENBQUN2TixHQUFHLENBQUM7TUFDaEQsSUFBSXlOLGNBQWMsQ0FBQzlQLE1BQU0sS0FBSyxDQUFDLEVBQUUsT0FBTzRQLE1BQU07SUFDaEQ7SUFDQUQsVUFBVSxHQUFHQyxNQUFNO0lBQ25CO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQWhRLEdBQUcsQ0FBQ00sT0FBTyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUM7RUFDNUI7RUFDQSxJQUFJeVAsVUFBVSxJQUFJQSxVQUFVLENBQUNqQixFQUFFLEVBQUU7SUFDL0IsTUFBTW9CLGNBQWMsR0FBR1QsYUFBYSxDQUFDTSxVQUFVLENBQUN0TixHQUFHLENBQUM7SUFDcEQsT0FBTztNQUNMcU0sRUFBRSxFQUFFLEtBQUs7TUFDVDNLLE1BQU0sRUFBRSxDQUFDLGdDQUFnQ3VMLEdBQUcsY0FBY1EsY0FBYyxDQUFDMUssSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0lBQ3ZGLENBQUM7RUFDSDtFQUNBLE9BQU87SUFDTHNKLEVBQUUsRUFBRSxLQUFLO0lBQ1QzSyxNQUFNLEVBQUUsQ0FDTixnQkFBZ0J1TCxHQUFHLGNBQWNLLFVBQVUsR0FBR0EsVUFBVSxDQUFDNUwsTUFBTSxDQUFDcUIsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLGdCQUFnQixFQUFFO0VBRW5HLENBQUM7QUFDSCIsImlnbm9yZUxpc3QiOltdfQ==