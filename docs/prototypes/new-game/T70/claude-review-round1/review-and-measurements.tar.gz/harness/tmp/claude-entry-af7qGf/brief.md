T69 review (Claude)
You review PR #1 at 2a24b4d59813f81f1f553c9d4a6aea11c2e28b6d.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
