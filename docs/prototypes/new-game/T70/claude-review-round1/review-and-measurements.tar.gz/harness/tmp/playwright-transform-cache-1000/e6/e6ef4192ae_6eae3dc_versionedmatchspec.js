// 6ad323690fc915ff7202cf91caef26a87825151d
import { expect, test } from "@playwright/test";
import { mkdirSync, mkdtempSync, readFileSync } from "node:fs";
import { join } from "node:path";
import * as codec from "../../src/core/match-save";
import { apply } from "../../src/core";
import { envelope, logicalState, pinned } from "../core/versioned-match-fixture";
const country = (page, id) => page.locator(`[data-country="${id}"]`);
const api = codec;
const decode = text => {
  var _api$deserializeVersi, _api$deserializeVersi2;
  return ((_api$deserializeVersi = (_api$deserializeVersi2 = api.deserializeVersionedMatch) === null || _api$deserializeVersi2 === void 0 ? void 0 : _api$deserializeVersi2.call(api, text)) !== null && _api$deserializeVersi !== void 0 ? _api$deserializeVersi : codec.deserializeMatch(text)).state;
};
async function download(page) {
  const pending = page.waitForEvent("download");
  await page.getByRole("button", {
    name: "Save game",
    exact: true
  }).click();
  const file = await pending;
  expect(file.suggestedFilename()).toMatch(/^malpaco-\d+\.json$/);
  return readFileSync(await file.path(), "utf8");
}
async function upload(page, text, name = "resume.json") {
  await page.getByLabel("Load game", {
    exact: true
  }).setInputFiles({
    name,
    mimeType: "application/json",
    buffer: Buffer.from(text)
  });
}
async function paint(page, expected) {
  const owners = expected["ownerOf"],
    armies = expected["armies"];
  const actual = await page.locator("[data-country]").evaluateAll(nodes => Object.fromEntries(nodes.map(n => [n.getAttribute("data-country"), [n.getAttribute("data-owner"), Number(n.getAttribute("data-armies"))]])));
  expect(actual).toEqual(Object.fromEntries(Object.keys(owners).map(id => [id, [owners[id], armies[id]]])));
}
async function check(page, fixture) {
  await expect(page.locator("[data-country]")).toHaveCount(46);
  await expect.poll(async () => await page.locator("[data-country]").evaluateAll(nodes => Object.fromEntries(nodes.map(n => [n.getAttribute("data-country"), Number(n.getAttribute("data-armies"))])))).toEqual(fixture.expected["armies"]);
  await paint(page, fixture.expected);
  const text = await download(page);
  expect(JSON.parse(text)).toEqual(envelope(fixture.options, fixture.actions));
  expect(logicalState(decode(text))).toEqual(fixture.expected);
  return text;
}
async function setup(page) {
  await page.goto("/?view=reference-game&control=manual");
  await expect(page.getByRole("heading", {
    name: "New reference game",
    exact: true
  })).toBeVisible();
}
async function capture(page, label, project) {
  var _process$env$VERSIONE;
  const root = (_process$env$VERSIONE = process.env["VERSIONED_MATCH_EVIDENCE_DIR"]) !== null && _process$env$VERSIONE !== void 0 ? _process$env$VERSIONE : "screenshots";
  mkdirSync(root, {
    recursive: true
  });
  const selectors = "#reference-save-game,#reference-load-game-file,.match-error:not(:empty),#turn-title,#confirm-capture-button,#confirm-friendly-move-button,#victory-reason";
  const boxes = await page.locator(selectors).evaluateAll(nodes => nodes.filter(n => n.getClientRects().length).map(n => {
    const r = n.getBoundingClientRect();
    return {
      id: n.id,
      font: parseFloat(getComputedStyle(n).fontSize),
      fits: r.left >= 0 && r.top >= 0 && r.right <= innerWidth + 1 && r.bottom <= innerHeight + 1
    };
  }));
  expect(boxes.length).toBeGreaterThanOrEqual(3);
  expect(boxes.filter(b => !b.fits || b.font < 12)).toEqual([]);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.screenshot({
    path: join(mkdtempSync(join(root, "versioned-")), `${label}-${project}.png`)
  });
}
function errorsOn(page) {
  const errors = [];
  page.on("pageerror", error => errors.push(error.message));
  page.on("console", message => {
    if (message.type() === "error") errors.push(message.text());
  });
  return errors;
}
test("placement download/upload retains full original options and continues placement", async ({
  page
}, info) => {
  const errors = errorsOn(page),
    fixture = pinned("placement");
  await setup(page);
  await upload(page, fixture.text);
  const text = await check(page, fixture);
  await capture(page, "placement", info.project.name);
  await page.getByRole("button", {
    name: "New game",
    exact: true
  }).click();
  await page.getByLabel("Seed", {
    exact: true
  }).fill("42");
  await upload(page, text);
  await check(page, fixture);
  const action = fixture.next.action;
  if (action.kind !== "reinforce") throw Error("Pinned placement must continue reinforcement");
  await country(page, action.province).click();
  expect(logicalState(decode(await download(page)))).toEqual(fixture.next.expected);
  await paint(page, fixture.next.expected);
  expect(errors).toEqual([]);
});
test("pending capture reload keeps the choice and rejects a detached old confirm", async ({
  page
}, info) => {
  const errors = errorsOn(page),
    fixture = pinned("pending-capture");
  await setup(page);
  await upload(page, fixture.text);
  const text = await check(page, fixture);
  const pending = fixture.expected["pendingCapture"];
  await expect(page.locator("#capture-amount")).toHaveValue(String(pending.defaultAmount));
  const oldConfirm = await page.locator("#confirm-capture-button").elementHandle();
  await upload(page, text);
  await check(page, fixture);
  await oldConfirm.evaluate(n => n.dispatchEvent(new MouseEvent("click", {
    bubbles: true
  })));
  await check(page, fixture);
  await capture(page, "pending-capture", info.project.name);
  await page.locator("#capture-amount").fill("1");
  await page.locator("#confirm-capture-button").click();
  expect(logicalState(decode(await download(page)))).toEqual(fixture.next.expected);
  await paint(page, fixture.next.expected);
  expect(errors).toEqual([]);
});
test("friendly move draft is transient; completed move restores exact next turn", async ({
  page
}, info) => {
  const errors = errorsOn(page),
    fixture = pinned("move-ready"),
    completed = pinned("move-completed");
  const action = fixture.next.action;
  if (action.kind !== "friendlyMove") throw Error("Pinned move must be friendlyMove");
  await setup(page);
  await upload(page, fixture.text);
  await check(page, fixture);
  await page.locator("#start-friendly-move-button").click();
  await country(page, action.from).click();
  await country(page, action.to).click();
  await page.locator("#friendly-move-amount").fill("1");
  const stale = await page.locator("#confirm-friendly-move-button").elementHandle();
  const draft = await check(page, fixture);
  await capture(page, "move-draft", info.project.name);
  await upload(page, draft);
  await check(page, fixture);
  await expect(page.locator("#start-friendly-move-button")).toBeVisible();
  await expect(page.locator("#confirm-friendly-move-button")).not.toBeVisible();
  await stale.evaluate(n => n.dispatchEvent(new MouseEvent("click", {
    bubbles: true
  })));
  await check(page, fixture);
  await page.locator("#start-friendly-move-button").click();
  await country(page, action.from).click();
  await country(page, action.to).click();
  await page.locator("#friendly-move-amount").fill("1");
  await page.locator("#confirm-friendly-move-button").click();
  const moved = await check(page, completed);
  await page.reload();
  await upload(page, moved);
  await check(page, completed);
  await capture(page, "move-completed", info.project.name);
  expect(errors).toEqual([]);
});
test("victory and human-loss choices survive real files and remain usable", async ({
  page
}, info) => {
  const errors = errorsOn(page);
  for (const name of ["domination", "round-limit", "stop"]) {
    const fixture = pinned(name);
    await setup(page);
    await upload(page, fixture.text);
    const text = await check(page, fixture);
    await expect(page.locator("#victory-reason")).toBeVisible();
    await page.reload();
    await upload(page, text);
    await check(page, fixture);
    await expect(page.locator("#end-turn-button")).not.toBeVisible();
    await capture(page, name, info.project.name);
  }
  const loss = pinned("human-loss");
  await setup(page);
  await upload(page, loss.text);
  await check(page, loss);
  await page.locator("#watch-computers-button").click();
  await check(page, pinned("watch"));
  await upload(page, loss.text);
  await check(page, loss);
  await page.locator("#stop-game-button").click();
  await check(page, pinned("stop"));
  expect(errors).toEqual([]);
});
test("bad loads and generated-map files preserve the live match, draft and controls", async ({
  page
}, info) => {
  const errors = errorsOn(page),
    fixture = pinned("move-ready");
  const action = fixture.next.action;
  if (action.kind !== "friendlyMove") throw Error("Expected friendly move fixture");
  await setup(page);
  await upload(page, fixture.text);
  const before = await check(page, fixture);
  await page.locator("#start-friendly-move-button").click();
  await country(page, action.from).click();
  await country(page, action.to).click();
  const valid = envelope(fixture.options, fixture.actions);
  for (const invalid of ["{", JSON.stringify({
    ...valid,
    version: 99
  }), JSON.stringify({
    ...valid,
    boardGenerator: {
      id: "fixed-reference",
      version: 99
    }
  }), JSON.stringify({
    ...valid,
    actions: [{
      kind: "attack",
      from: "missing",
      to: "missing"
    }]
  }), pinned("legacy-progress").text]) {
    await upload(page, invalid);
    await expect(page.getByRole("alert")).toContainText(/Load failed:/i);
    if (invalid === pinned("legacy-progress").text) await expect(page.getByRole("alert")).toContainText(/generated.*map|map.*generated/i);
    expect(await download(page)).toBe(before);
    await paint(page, fixture.expected);
    await expect(page.locator("#confirm-friendly-move-button")).toBeEnabled();
  }
  await capture(page, "failed-load", info.project.name);
  await page.locator("#friendly-move-amount").fill("1");
  await page.locator("#confirm-friendly-move-button").click();
  await check(page, pinned("move-completed"));
  expect(errors).toEqual([]);
});
test("new game and a successful later load invalidate slow file readers", async ({
  page
}) => {
  const errors = errorsOn(page);
  await page.addInitScript(() => {
    const original = File.prototype.text;
    File.prototype.text = function () {
      if (this.name !== "slow.json") return original.call(this);
      return new Promise((resolve, reject) => {
        Reflect.set(window, "releaseT31Read", () => {
          original.call(this).then(resolve, reject);
        });
      });
    };
  });
  const placement = pinned("placement"),
    pending = pinned("pending-capture");
  await setup(page);
  await upload(page, placement.text);
  await check(page, placement);
  await upload(page, pending.text, "slow.json");
  await page.getByRole("button", {
    name: "New game",
    exact: true
  }).click();
  await page.getByLabel("Seed", {
    exact: true
  }).fill("42");
  await page.getByRole("button", {
    name: "Start game",
    exact: true
  }).click();
  const fresh = await download(page);
  await page.evaluate(() => Reflect.get(window, "releaseT31Read")());
  await page.evaluate(() => new Promise(resolve => setTimeout(resolve, 0)));
  expect(await download(page)).toBe(fresh);
  await upload(page, pending.text, "slow.json");
  await upload(page, placement.text);
  await check(page, placement);
  await page.evaluate(() => Reflect.get(window, "releaseT31Read")());
  await page.evaluate(() => new Promise(resolve => setTimeout(resolve, 0)));
  await check(page, placement);
  expect(errors).toEqual([]);
});
test("successful load cancels queued fight-on work from the prior match", async ({
  page
}) => {
  const errors = errorsOn(page),
    fixture = pinned("move-ready"),
    restored = pinned("placement");
  await page.clock.install();
  await page.clock.pauseAt(new Date());
  await setup(page);
  await upload(page, fixture.text);
  await check(page, fixture);
  const state = decode(fixture.text),
    mover = state.players[state.currentPlayer].id;
  const attacks = state.map.provinces.filter(p => state.ownerOf[p.id] === mover && state.armies[p.id] > 2).flatMap(p => [...p.borders, ...p.seaLanes].filter(id => state.ownerOf[id] !== mover).map(to => ({
    kind: "attack",
    from: p.id,
    to
  })));
  const queued = attacks.find(action => {
    const result = apply(state, action);
    return result.ok && result.state.phase === "attack" && result.state.armies[action.from] > 1;
  });
  if (!queued) throw Error("Pinned move-ready must permit a queued exchange for stale-timer acceptance");
  await country(page, queued.from).click();
  await country(page, queued.to).click({
    modifiers: ["Shift"]
  });
  await page.locator("#battle-stop-threshold").fill("1");
  await page.locator("#battle-stop-threshold").press("Tab");
  await page.locator("#fight-on-button").click();
  await expect(page.getByRole("region", {
    name: "Battle controls",
    exact: true
  })).toHaveAttribute("data-running", "true");
  await upload(page, restored.text);
  await check(page, restored);
  await page.clock.runFor(10000);
  await check(page, restored);
  const next = restored.next.action;
  if (next.kind !== "reinforce") throw Error("Expected reinforcement continuation");
  const result = apply(decode(restored.text), next);
  expect(result.ok).toBe(true);
  await country(page, next.province).click();
  expect(logicalState(decode(await download(page)))).toEqual(restored.next.expected);
  expect(errors).toEqual([]);
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJleHBlY3QiLCJ0ZXN0IiwibWtkaXJTeW5jIiwibWtkdGVtcFN5bmMiLCJyZWFkRmlsZVN5bmMiLCJqb2luIiwiY29kZWMiLCJhcHBseSIsImVudmVsb3BlIiwibG9naWNhbFN0YXRlIiwicGlubmVkIiwiY291bnRyeSIsInBhZ2UiLCJpZCIsImxvY2F0b3IiLCJhcGkiLCJkZWNvZGUiLCJ0ZXh0IiwiX2FwaSRkZXNlcmlhbGl6ZVZlcnNpIiwiX2FwaSRkZXNlcmlhbGl6ZVZlcnNpMiIsImRlc2VyaWFsaXplVmVyc2lvbmVkTWF0Y2giLCJjYWxsIiwiZGVzZXJpYWxpemVNYXRjaCIsInN0YXRlIiwiZG93bmxvYWQiLCJwZW5kaW5nIiwid2FpdEZvckV2ZW50IiwiZ2V0QnlSb2xlIiwibmFtZSIsImV4YWN0IiwiY2xpY2siLCJmaWxlIiwic3VnZ2VzdGVkRmlsZW5hbWUiLCJ0b01hdGNoIiwicGF0aCIsInVwbG9hZCIsImdldEJ5TGFiZWwiLCJzZXRJbnB1dEZpbGVzIiwibWltZVR5cGUiLCJidWZmZXIiLCJCdWZmZXIiLCJmcm9tIiwicGFpbnQiLCJleHBlY3RlZCIsIm93bmVycyIsImFybWllcyIsImFjdHVhbCIsImV2YWx1YXRlQWxsIiwibm9kZXMiLCJPYmplY3QiLCJmcm9tRW50cmllcyIsIm1hcCIsIm4iLCJnZXRBdHRyaWJ1dGUiLCJOdW1iZXIiLCJ0b0VxdWFsIiwia2V5cyIsImNoZWNrIiwiZml4dHVyZSIsInRvSGF2ZUNvdW50IiwicG9sbCIsIkpTT04iLCJwYXJzZSIsIm9wdGlvbnMiLCJhY3Rpb25zIiwic2V0dXAiLCJnb3RvIiwidG9CZVZpc2libGUiLCJjYXB0dXJlIiwibGFiZWwiLCJwcm9qZWN0IiwiX3Byb2Nlc3MkZW52JFZFUlNJT05FIiwicm9vdCIsInByb2Nlc3MiLCJlbnYiLCJyZWN1cnNpdmUiLCJzZWxlY3RvcnMiLCJib3hlcyIsImZpbHRlciIsImdldENsaWVudFJlY3RzIiwibGVuZ3RoIiwiciIsImdldEJvdW5kaW5nQ2xpZW50UmVjdCIsImZvbnQiLCJwYXJzZUZsb2F0IiwiZ2V0Q29tcHV0ZWRTdHlsZSIsImZvbnRTaXplIiwiZml0cyIsImxlZnQiLCJ0b3AiLCJyaWdodCIsImlubmVyV2lkdGgiLCJib3R0b20iLCJpbm5lckhlaWdodCIsInRvQmVHcmVhdGVyVGhhbk9yRXF1YWwiLCJiIiwiZXZhbHVhdGUiLCJkb2N1bWVudCIsImRvY3VtZW50RWxlbWVudCIsInNjcm9sbFdpZHRoIiwidG9CZSIsInNjcmVlbnNob3QiLCJlcnJvcnNPbiIsImVycm9ycyIsIm9uIiwiZXJyb3IiLCJwdXNoIiwibWVzc2FnZSIsInR5cGUiLCJpbmZvIiwiZmlsbCIsImFjdGlvbiIsIm5leHQiLCJraW5kIiwiRXJyb3IiLCJwcm92aW5jZSIsInRvSGF2ZVZhbHVlIiwiU3RyaW5nIiwiZGVmYXVsdEFtb3VudCIsIm9sZENvbmZpcm0iLCJlbGVtZW50SGFuZGxlIiwiZGlzcGF0Y2hFdmVudCIsIk1vdXNlRXZlbnQiLCJidWJibGVzIiwiY29tcGxldGVkIiwidG8iLCJzdGFsZSIsImRyYWZ0Iiwibm90IiwibW92ZWQiLCJyZWxvYWQiLCJsb3NzIiwiYmVmb3JlIiwidmFsaWQiLCJpbnZhbGlkIiwic3RyaW5naWZ5IiwidmVyc2lvbiIsImJvYXJkR2VuZXJhdG9yIiwidG9Db250YWluVGV4dCIsInRvQmVFbmFibGVkIiwiYWRkSW5pdFNjcmlwdCIsIm9yaWdpbmFsIiwiRmlsZSIsInByb3RvdHlwZSIsIlByb21pc2UiLCJyZXNvbHZlIiwicmVqZWN0IiwiUmVmbGVjdCIsInNldCIsIndpbmRvdyIsInRoZW4iLCJwbGFjZW1lbnQiLCJmcmVzaCIsImdldCIsInNldFRpbWVvdXQiLCJyZXN0b3JlZCIsImNsb2NrIiwiaW5zdGFsbCIsInBhdXNlQXQiLCJEYXRlIiwibW92ZXIiLCJwbGF5ZXJzIiwiY3VycmVudFBsYXllciIsImF0dGFja3MiLCJwcm92aW5jZXMiLCJwIiwib3duZXJPZiIsImZsYXRNYXAiLCJib3JkZXJzIiwic2VhTGFuZXMiLCJxdWV1ZWQiLCJmaW5kIiwicmVzdWx0Iiwib2siLCJwaGFzZSIsIm1vZGlmaWVycyIsInByZXNzIiwidG9IYXZlQXR0cmlidXRlIiwicnVuRm9yIl0sInNvdXJjZXMiOlsidmVyc2lvbmVkLW1hdGNoLnNwZWMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZXhwZWN0LCB0ZXN0IH0gZnJvbSBcIkBwbGF5d3JpZ2h0L3Rlc3RcIjtcbmltcG9ydCB0eXBlIHsgUGFnZSB9IGZyb20gXCJAcGxheXdyaWdodC90ZXN0XCI7XG5pbXBvcnQgeyBta2RpclN5bmMsIG1rZHRlbXBTeW5jLCByZWFkRmlsZVN5bmMgfSBmcm9tIFwibm9kZTpmc1wiO1xuaW1wb3J0IHsgam9pbiB9IGZyb20gXCJub2RlOnBhdGhcIjtcbmltcG9ydCAqIGFzIGNvZGVjIGZyb20gXCIuLi8uLi9zcmMvY29yZS9tYXRjaC1zYXZlXCI7XG5pbXBvcnQgeyBhcHBseSB9IGZyb20gXCIuLi8uLi9zcmMvY29yZVwiO1xuaW1wb3J0IHR5cGUgeyBHYW1lU3RhdGUgfSBmcm9tIFwiLi4vLi4vc3JjL2NvcmVcIjtcbmltcG9ydCB7IGVudmVsb3BlLCBsb2dpY2FsU3RhdGUsIHBpbm5lZCB9IGZyb20gXCIuLi9jb3JlL3ZlcnNpb25lZC1tYXRjaC1maXh0dXJlXCI7XG5pbXBvcnQgdHlwZSB7IFBpbm5lZE1hdGNoIH0gZnJvbSBcIi4uL2NvcmUvdmVyc2lvbmVkLW1hdGNoLWZpeHR1cmVcIjtcblxuY29uc3QgY291bnRyeSA9IChwYWdlOiBQYWdlLCBpZDogc3RyaW5nKSA9PiBwYWdlLmxvY2F0b3IoYFtkYXRhLWNvdW50cnk9XCIke2lkfVwiXWApO1xuY29uc3QgYXBpID0gY29kZWMgYXMgdHlwZW9mIGNvZGVjICYgeyBkZXNlcmlhbGl6ZVZlcnNpb25lZE1hdGNoPzogKHRleHQ6IHN0cmluZykgPT4geyBzdGF0ZTogR2FtZVN0YXRlIH0gfTtcbmNvbnN0IGRlY29kZSA9ICh0ZXh0OiBzdHJpbmcpID0+IChhcGkuZGVzZXJpYWxpemVWZXJzaW9uZWRNYXRjaD8uKHRleHQpID8/IGNvZGVjLmRlc2VyaWFsaXplTWF0Y2godGV4dCkpLnN0YXRlO1xuYXN5bmMgZnVuY3Rpb24gZG93bmxvYWQocGFnZTogUGFnZSkge1xuICBjb25zdCBwZW5kaW5nID0gcGFnZS53YWl0Rm9yRXZlbnQoXCJkb3dubG9hZFwiKTtcbiAgYXdhaXQgcGFnZS5nZXRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiBcIlNhdmUgZ2FtZVwiLCBleGFjdDogdHJ1ZSB9KS5jbGljaygpO1xuICBjb25zdCBmaWxlID0gYXdhaXQgcGVuZGluZztcbiAgZXhwZWN0KGZpbGUuc3VnZ2VzdGVkRmlsZW5hbWUoKSkudG9NYXRjaCgvXm1hbHBhY28tXFxkK1xcLmpzb24kLyk7XG4gIHJldHVybiByZWFkRmlsZVN5bmMoKGF3YWl0IGZpbGUucGF0aCgpKSEsIFwidXRmOFwiKTtcbn1cbmFzeW5jIGZ1bmN0aW9uIHVwbG9hZChwYWdlOiBQYWdlLCB0ZXh0OiBzdHJpbmcsIG5hbWUgPSBcInJlc3VtZS5qc29uXCIpIHtcbiAgYXdhaXQgcGFnZS5nZXRCeUxhYmVsKFwiTG9hZCBnYW1lXCIsIHsgZXhhY3Q6IHRydWUgfSkuc2V0SW5wdXRGaWxlcyh7IG5hbWUsIG1pbWVUeXBlOiBcImFwcGxpY2F0aW9uL2pzb25cIiwgYnVmZmVyOiBCdWZmZXIuZnJvbSh0ZXh0KSB9KTtcbn1cbmFzeW5jIGZ1bmN0aW9uIHBhaW50KHBhZ2U6IFBhZ2UsIGV4cGVjdGVkOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikge1xuICBjb25zdCBvd25lcnMgPSBleHBlY3RlZFtcIm93bmVyT2ZcIl0gYXMgUmVjb3JkPHN0cmluZywgc3RyaW5nPiwgYXJtaWVzID0gZXhwZWN0ZWRbXCJhcm1pZXNcIl0gYXMgUmVjb3JkPHN0cmluZywgbnVtYmVyPjtcbiAgY29uc3QgYWN0dWFsID0gYXdhaXQgcGFnZS5sb2NhdG9yKFwiW2RhdGEtY291bnRyeV1cIikuZXZhbHVhdGVBbGwobm9kZXMgPT4gT2JqZWN0LmZyb21FbnRyaWVzKG5vZGVzLm1hcChuID0+IFtuLmdldEF0dHJpYnV0ZShcImRhdGEtY291bnRyeVwiKSwgW24uZ2V0QXR0cmlidXRlKFwiZGF0YS1vd25lclwiKSwgTnVtYmVyKG4uZ2V0QXR0cmlidXRlKFwiZGF0YS1hcm1pZXNcIikpXV0pKSk7XG4gIGV4cGVjdChhY3R1YWwpLnRvRXF1YWwoT2JqZWN0LmZyb21FbnRyaWVzKE9iamVjdC5rZXlzKG93bmVycykubWFwKGlkID0+IFtpZCwgW293bmVyc1tpZF0sIGFybWllc1tpZF1dXSkpKTtcbn1cbmFzeW5jIGZ1bmN0aW9uIGNoZWNrKHBhZ2U6IFBhZ2UsIGZpeHR1cmU6IFBpbm5lZE1hdGNoKSB7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoXCJbZGF0YS1jb3VudHJ5XVwiKSkudG9IYXZlQ291bnQoNDYpO1xuICBhd2FpdCBleHBlY3QucG9sbChhc3luYyAoKSA9PiBhd2FpdCBwYWdlLmxvY2F0b3IoXCJbZGF0YS1jb3VudHJ5XVwiKS5ldmFsdWF0ZUFsbChub2RlcyA9PiBPYmplY3QuZnJvbUVudHJpZXMobm9kZXMubWFwKG4gPT4gW24uZ2V0QXR0cmlidXRlKFwiZGF0YS1jb3VudHJ5XCIpLCBOdW1iZXIobi5nZXRBdHRyaWJ1dGUoXCJkYXRhLWFybWllc1wiKSldKSkpKS50b0VxdWFsKGZpeHR1cmUuZXhwZWN0ZWRbXCJhcm1pZXNcIl0pO1xuICBhd2FpdCBwYWludChwYWdlLCBmaXh0dXJlLmV4cGVjdGVkKTtcbiAgY29uc3QgdGV4dCA9IGF3YWl0IGRvd25sb2FkKHBhZ2UpO1xuICBleHBlY3QoSlNPTi5wYXJzZSh0ZXh0KSkudG9FcXVhbChlbnZlbG9wZShmaXh0dXJlLm9wdGlvbnMsIGZpeHR1cmUuYWN0aW9ucykpO1xuICBleHBlY3QobG9naWNhbFN0YXRlKGRlY29kZSh0ZXh0KSkpLnRvRXF1YWwoZml4dHVyZS5leHBlY3RlZCk7XG4gIHJldHVybiB0ZXh0O1xufVxuYXN5bmMgZnVuY3Rpb24gc2V0dXAocGFnZTogUGFnZSkge1xuICBhd2FpdCBwYWdlLmdvdG8oXCIvP3ZpZXc9cmVmZXJlbmNlLWdhbWUmY29udHJvbD1tYW51YWxcIik7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5Um9sZShcImhlYWRpbmdcIiwgeyBuYW1lOiBcIk5ldyByZWZlcmVuY2UgZ2FtZVwiLCBleGFjdDogdHJ1ZSB9KSkudG9CZVZpc2libGUoKTtcbn1cbmFzeW5jIGZ1bmN0aW9uIGNhcHR1cmUocGFnZTogUGFnZSwgbGFiZWw6IHN0cmluZywgcHJvamVjdDogc3RyaW5nKSB7XG4gIGNvbnN0IHJvb3QgPSBwcm9jZXNzLmVudltcIlZFUlNJT05FRF9NQVRDSF9FVklERU5DRV9ESVJcIl0gPz8gXCJzY3JlZW5zaG90c1wiO1xuICBta2RpclN5bmMocm9vdCwgeyByZWN1cnNpdmU6IHRydWUgfSk7XG4gIGNvbnN0IHNlbGVjdG9ycyA9IFwiI3JlZmVyZW5jZS1zYXZlLWdhbWUsI3JlZmVyZW5jZS1sb2FkLWdhbWUtZmlsZSwubWF0Y2gtZXJyb3I6bm90KDplbXB0eSksI3R1cm4tdGl0bGUsI2NvbmZpcm0tY2FwdHVyZS1idXR0b24sI2NvbmZpcm0tZnJpZW5kbHktbW92ZS1idXR0b24sI3ZpY3RvcnktcmVhc29uXCI7XG4gIGNvbnN0IGJveGVzID0gYXdhaXQgcGFnZS5sb2NhdG9yKHNlbGVjdG9ycykuZXZhbHVhdGVBbGwobm9kZXMgPT4gbm9kZXMuZmlsdGVyKG4gPT4gbi5nZXRDbGllbnRSZWN0cygpLmxlbmd0aCkubWFwKG4gPT4ge1xuICAgIGNvbnN0IHIgPSBuLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpOyByZXR1cm4geyBpZDogbi5pZCwgZm9udDogcGFyc2VGbG9hdChnZXRDb21wdXRlZFN0eWxlKG4pLmZvbnRTaXplKSwgZml0czogci5sZWZ0ID49IDAgJiYgci50b3AgPj0gMCAmJiByLnJpZ2h0IDw9IGlubmVyV2lkdGggKyAxICYmIHIuYm90dG9tIDw9IGlubmVySGVpZ2h0ICsgMSB9O1xuICB9KSk7XG4gIGV4cGVjdChib3hlcy5sZW5ndGgpLnRvQmVHcmVhdGVyVGhhbk9yRXF1YWwoMyk7XG4gIGV4cGVjdChib3hlcy5maWx0ZXIoYiA9PiAhYi5maXRzIHx8IGIuZm9udCA8IDEyKSkudG9FcXVhbChbXSk7XG4gIGV4cGVjdChhd2FpdCBwYWdlLmV2YWx1YXRlKCgpID0+IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zY3JvbGxXaWR0aCA8PSBpbm5lcldpZHRoKSkudG9CZSh0cnVlKTtcbiAgYXdhaXQgcGFnZS5zY3JlZW5zaG90KHsgcGF0aDogam9pbihta2R0ZW1wU3luYyhqb2luKHJvb3QsIFwidmVyc2lvbmVkLVwiKSksIGAke2xhYmVsfS0ke3Byb2plY3R9LnBuZ2ApIH0pO1xufVxuZnVuY3Rpb24gZXJyb3JzT24ocGFnZTogUGFnZSkge1xuICBjb25zdCBlcnJvcnM6IHN0cmluZ1tdID0gW107XG4gIHBhZ2Uub24oXCJwYWdlZXJyb3JcIiwgZXJyb3IgPT4gZXJyb3JzLnB1c2goZXJyb3IubWVzc2FnZSkpO1xuICBwYWdlLm9uKFwiY29uc29sZVwiLCBtZXNzYWdlID0+IHsgaWYgKG1lc3NhZ2UudHlwZSgpID09PSBcImVycm9yXCIpIGVycm9ycy5wdXNoKG1lc3NhZ2UudGV4dCgpKTsgfSk7XG4gIHJldHVybiBlcnJvcnM7XG59XG5cbnRlc3QoXCJwbGFjZW1lbnQgZG93bmxvYWQvdXBsb2FkIHJldGFpbnMgZnVsbCBvcmlnaW5hbCBvcHRpb25zIGFuZCBjb250aW51ZXMgcGxhY2VtZW50XCIsIGFzeW5jICh7IHBhZ2UgfSwgaW5mbykgPT4ge1xuICBjb25zdCBlcnJvcnMgPSBlcnJvcnNPbihwYWdlKSwgZml4dHVyZSA9IHBpbm5lZChcInBsYWNlbWVudFwiKTtcbiAgYXdhaXQgc2V0dXAocGFnZSk7IGF3YWl0IHVwbG9hZChwYWdlLCBmaXh0dXJlLnRleHQpOyBjb25zdCB0ZXh0ID0gYXdhaXQgY2hlY2socGFnZSwgZml4dHVyZSk7XG4gIGF3YWl0IGNhcHR1cmUocGFnZSwgXCJwbGFjZW1lbnRcIiwgaW5mby5wcm9qZWN0Lm5hbWUpO1xuICBhd2FpdCBwYWdlLmdldEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwiTmV3IGdhbWVcIiwgZXhhY3Q6IHRydWUgfSkuY2xpY2soKTtcbiAgYXdhaXQgcGFnZS5nZXRCeUxhYmVsKFwiU2VlZFwiLCB7IGV4YWN0OiB0cnVlIH0pLmZpbGwoXCI0MlwiKTtcbiAgYXdhaXQgdXBsb2FkKHBhZ2UsIHRleHQpOyBhd2FpdCBjaGVjayhwYWdlLCBmaXh0dXJlKTtcbiAgY29uc3QgYWN0aW9uID0gZml4dHVyZS5uZXh0IS5hY3Rpb247XG4gIGlmIChhY3Rpb24ua2luZCAhPT0gXCJyZWluZm9yY2VcIikgdGhyb3cgRXJyb3IoXCJQaW5uZWQgcGxhY2VtZW50IG11c3QgY29udGludWUgcmVpbmZvcmNlbWVudFwiKTtcbiAgYXdhaXQgY291bnRyeShwYWdlLCBhY3Rpb24ucHJvdmluY2UpLmNsaWNrKCk7XG4gIGV4cGVjdChsb2dpY2FsU3RhdGUoZGVjb2RlKGF3YWl0IGRvd25sb2FkKHBhZ2UpKSkpLnRvRXF1YWwoZml4dHVyZS5uZXh0IS5leHBlY3RlZCk7XG4gIGF3YWl0IHBhaW50KHBhZ2UsIGZpeHR1cmUubmV4dCEuZXhwZWN0ZWQpOyBleHBlY3QoZXJyb3JzKS50b0VxdWFsKFtdKTtcbn0pO1xuXG50ZXN0KFwicGVuZGluZyBjYXB0dXJlIHJlbG9hZCBrZWVwcyB0aGUgY2hvaWNlIGFuZCByZWplY3RzIGEgZGV0YWNoZWQgb2xkIGNvbmZpcm1cIiwgYXN5bmMgKHsgcGFnZSB9LCBpbmZvKSA9PiB7XG4gIGNvbnN0IGVycm9ycyA9IGVycm9yc09uKHBhZ2UpLCBmaXh0dXJlID0gcGlubmVkKFwicGVuZGluZy1jYXB0dXJlXCIpO1xuICBhd2FpdCBzZXR1cChwYWdlKTsgYXdhaXQgdXBsb2FkKHBhZ2UsIGZpeHR1cmUudGV4dCk7IGNvbnN0IHRleHQgPSBhd2FpdCBjaGVjayhwYWdlLCBmaXh0dXJlKTtcbiAgY29uc3QgcGVuZGluZyA9IGZpeHR1cmUuZXhwZWN0ZWRbXCJwZW5kaW5nQ2FwdHVyZVwiXSBhcyB7IGRlZmF1bHRBbW91bnQ6IG51bWJlciB9O1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKFwiI2NhcHR1cmUtYW1vdW50XCIpKS50b0hhdmVWYWx1ZShTdHJpbmcocGVuZGluZy5kZWZhdWx0QW1vdW50KSk7XG4gIGNvbnN0IG9sZENvbmZpcm0gPSBhd2FpdCBwYWdlLmxvY2F0b3IoXCIjY29uZmlybS1jYXB0dXJlLWJ1dHRvblwiKS5lbGVtZW50SGFuZGxlKCk7XG4gIGF3YWl0IHVwbG9hZChwYWdlLCB0ZXh0KTsgYXdhaXQgY2hlY2socGFnZSwgZml4dHVyZSk7XG4gIGF3YWl0IG9sZENvbmZpcm0hLmV2YWx1YXRlKG4gPT4gbi5kaXNwYXRjaEV2ZW50KG5ldyBNb3VzZUV2ZW50KFwiY2xpY2tcIiwgeyBidWJibGVzOiB0cnVlIH0pKSk7XG4gIGF3YWl0IGNoZWNrKHBhZ2UsIGZpeHR1cmUpOyBhd2FpdCBjYXB0dXJlKHBhZ2UsIFwicGVuZGluZy1jYXB0dXJlXCIsIGluZm8ucHJvamVjdC5uYW1lKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKFwiI2NhcHR1cmUtYW1vdW50XCIpLmZpbGwoXCIxXCIpOyBhd2FpdCBwYWdlLmxvY2F0b3IoXCIjY29uZmlybS1jYXB0dXJlLWJ1dHRvblwiKS5jbGljaygpO1xuICBleHBlY3QobG9naWNhbFN0YXRlKGRlY29kZShhd2FpdCBkb3dubG9hZChwYWdlKSkpKS50b0VxdWFsKGZpeHR1cmUubmV4dCEuZXhwZWN0ZWQpO1xuICBhd2FpdCBwYWludChwYWdlLCBmaXh0dXJlLm5leHQhLmV4cGVjdGVkKTsgZXhwZWN0KGVycm9ycykudG9FcXVhbChbXSk7XG59KTtcblxudGVzdChcImZyaWVuZGx5IG1vdmUgZHJhZnQgaXMgdHJhbnNpZW50OyBjb21wbGV0ZWQgbW92ZSByZXN0b3JlcyBleGFjdCBuZXh0IHR1cm5cIiwgYXN5bmMgKHsgcGFnZSB9LCBpbmZvKSA9PiB7XG4gIGNvbnN0IGVycm9ycyA9IGVycm9yc09uKHBhZ2UpLCBmaXh0dXJlID0gcGlubmVkKFwibW92ZS1yZWFkeVwiKSwgY29tcGxldGVkID0gcGlubmVkKFwibW92ZS1jb21wbGV0ZWRcIik7XG4gIGNvbnN0IGFjdGlvbiA9IGZpeHR1cmUubmV4dCEuYWN0aW9uO1xuICBpZiAoYWN0aW9uLmtpbmQgIT09IFwiZnJpZW5kbHlNb3ZlXCIpIHRocm93IEVycm9yKFwiUGlubmVkIG1vdmUgbXVzdCBiZSBmcmllbmRseU1vdmVcIik7XG4gIGF3YWl0IHNldHVwKHBhZ2UpOyBhd2FpdCB1cGxvYWQocGFnZSwgZml4dHVyZS50ZXh0KTsgYXdhaXQgY2hlY2socGFnZSwgZml4dHVyZSk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcihcIiNzdGFydC1mcmllbmRseS1tb3ZlLWJ1dHRvblwiKS5jbGljaygpO1xuICBhd2FpdCBjb3VudHJ5KHBhZ2UsIGFjdGlvbi5mcm9tKS5jbGljaygpOyBhd2FpdCBjb3VudHJ5KHBhZ2UsIGFjdGlvbi50bykuY2xpY2soKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKFwiI2ZyaWVuZGx5LW1vdmUtYW1vdW50XCIpLmZpbGwoXCIxXCIpO1xuICBjb25zdCBzdGFsZSA9IGF3YWl0IHBhZ2UubG9jYXRvcihcIiNjb25maXJtLWZyaWVuZGx5LW1vdmUtYnV0dG9uXCIpLmVsZW1lbnRIYW5kbGUoKTtcbiAgY29uc3QgZHJhZnQgPSBhd2FpdCBjaGVjayhwYWdlLCBmaXh0dXJlKTsgYXdhaXQgY2FwdHVyZShwYWdlLCBcIm1vdmUtZHJhZnRcIiwgaW5mby5wcm9qZWN0Lm5hbWUpO1xuICBhd2FpdCB1cGxvYWQocGFnZSwgZHJhZnQpOyBhd2FpdCBjaGVjayhwYWdlLCBmaXh0dXJlKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcihcIiNzdGFydC1mcmllbmRseS1tb3ZlLWJ1dHRvblwiKSkudG9CZVZpc2libGUoKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcihcIiNjb25maXJtLWZyaWVuZGx5LW1vdmUtYnV0dG9uXCIpKS5ub3QudG9CZVZpc2libGUoKTtcbiAgYXdhaXQgc3RhbGUhLmV2YWx1YXRlKG4gPT4gbi5kaXNwYXRjaEV2ZW50KG5ldyBNb3VzZUV2ZW50KFwiY2xpY2tcIiwgeyBidWJibGVzOiB0cnVlIH0pKSk7XG4gIGF3YWl0IGNoZWNrKHBhZ2UsIGZpeHR1cmUpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoXCIjc3RhcnQtZnJpZW5kbHktbW92ZS1idXR0b25cIikuY2xpY2soKTtcbiAgYXdhaXQgY291bnRyeShwYWdlLCBhY3Rpb24uZnJvbSkuY2xpY2soKTsgYXdhaXQgY291bnRyeShwYWdlLCBhY3Rpb24udG8pLmNsaWNrKCk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcihcIiNmcmllbmRseS1tb3ZlLWFtb3VudFwiKS5maWxsKFwiMVwiKTsgYXdhaXQgcGFnZS5sb2NhdG9yKFwiI2NvbmZpcm0tZnJpZW5kbHktbW92ZS1idXR0b25cIikuY2xpY2soKTtcbiAgY29uc3QgbW92ZWQgPSBhd2FpdCBjaGVjayhwYWdlLCBjb21wbGV0ZWQpO1xuICBhd2FpdCBwYWdlLnJlbG9hZCgpOyBhd2FpdCB1cGxvYWQocGFnZSwgbW92ZWQpOyBhd2FpdCBjaGVjayhwYWdlLCBjb21wbGV0ZWQpO1xuICBhd2FpdCBjYXB0dXJlKHBhZ2UsIFwibW92ZS1jb21wbGV0ZWRcIiwgaW5mby5wcm9qZWN0Lm5hbWUpOyBleHBlY3QoZXJyb3JzKS50b0VxdWFsKFtdKTtcbn0pO1xuXG50ZXN0KFwidmljdG9yeSBhbmQgaHVtYW4tbG9zcyBjaG9pY2VzIHN1cnZpdmUgcmVhbCBmaWxlcyBhbmQgcmVtYWluIHVzYWJsZVwiLCBhc3luYyAoeyBwYWdlIH0sIGluZm8pID0+IHtcbiAgY29uc3QgZXJyb3JzID0gZXJyb3JzT24ocGFnZSk7XG4gIGZvciAoY29uc3QgbmFtZSBvZiBbXCJkb21pbmF0aW9uXCIsIFwicm91bmQtbGltaXRcIiwgXCJzdG9wXCJdKSB7XG4gICAgY29uc3QgZml4dHVyZSA9IHBpbm5lZChuYW1lKTsgYXdhaXQgc2V0dXAocGFnZSk7IGF3YWl0IHVwbG9hZChwYWdlLCBmaXh0dXJlLnRleHQpO1xuICAgIGNvbnN0IHRleHQgPSBhd2FpdCBjaGVjayhwYWdlLCBmaXh0dXJlKTsgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcihcIiN2aWN0b3J5LXJlYXNvblwiKSkudG9CZVZpc2libGUoKTtcbiAgICBhd2FpdCBwYWdlLnJlbG9hZCgpOyBhd2FpdCB1cGxvYWQocGFnZSwgdGV4dCk7IGF3YWl0IGNoZWNrKHBhZ2UsIGZpeHR1cmUpO1xuICAgIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoXCIjZW5kLXR1cm4tYnV0dG9uXCIpKS5ub3QudG9CZVZpc2libGUoKTtcbiAgICBhd2FpdCBjYXB0dXJlKHBhZ2UsIG5hbWUsIGluZm8ucHJvamVjdC5uYW1lKTtcbiAgfVxuICBjb25zdCBsb3NzID0gcGlubmVkKFwiaHVtYW4tbG9zc1wiKTsgYXdhaXQgc2V0dXAocGFnZSk7IGF3YWl0IHVwbG9hZChwYWdlLCBsb3NzLnRleHQpOyBhd2FpdCBjaGVjayhwYWdlLCBsb3NzKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKFwiI3dhdGNoLWNvbXB1dGVycy1idXR0b25cIikuY2xpY2soKTsgYXdhaXQgY2hlY2socGFnZSwgcGlubmVkKFwid2F0Y2hcIikpO1xuICBhd2FpdCB1cGxvYWQocGFnZSwgbG9zcy50ZXh0KTsgYXdhaXQgY2hlY2socGFnZSwgbG9zcyk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcihcIiNzdG9wLWdhbWUtYnV0dG9uXCIpLmNsaWNrKCk7IGF3YWl0IGNoZWNrKHBhZ2UsIHBpbm5lZChcInN0b3BcIikpO1xuICBleHBlY3QoZXJyb3JzKS50b0VxdWFsKFtdKTtcbn0pO1xuXG50ZXN0KFwiYmFkIGxvYWRzIGFuZCBnZW5lcmF0ZWQtbWFwIGZpbGVzIHByZXNlcnZlIHRoZSBsaXZlIG1hdGNoLCBkcmFmdCBhbmQgY29udHJvbHNcIiwgYXN5bmMgKHsgcGFnZSB9LCBpbmZvKSA9PiB7XG4gIGNvbnN0IGVycm9ycyA9IGVycm9yc09uKHBhZ2UpLCBmaXh0dXJlID0gcGlubmVkKFwibW92ZS1yZWFkeVwiKTtcbiAgY29uc3QgYWN0aW9uID0gZml4dHVyZS5uZXh0IS5hY3Rpb247XG4gIGlmIChhY3Rpb24ua2luZCAhPT0gXCJmcmllbmRseU1vdmVcIikgdGhyb3cgRXJyb3IoXCJFeHBlY3RlZCBmcmllbmRseSBtb3ZlIGZpeHR1cmVcIik7XG4gIGF3YWl0IHNldHVwKHBhZ2UpOyBhd2FpdCB1cGxvYWQocGFnZSwgZml4dHVyZS50ZXh0KTsgY29uc3QgYmVmb3JlID0gYXdhaXQgY2hlY2socGFnZSwgZml4dHVyZSk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcihcIiNzdGFydC1mcmllbmRseS1tb3ZlLWJ1dHRvblwiKS5jbGljaygpOyBhd2FpdCBjb3VudHJ5KHBhZ2UsIGFjdGlvbi5mcm9tKS5jbGljaygpOyBhd2FpdCBjb3VudHJ5KHBhZ2UsIGFjdGlvbi50bykuY2xpY2soKTtcbiAgY29uc3QgdmFsaWQgPSBlbnZlbG9wZShmaXh0dXJlLm9wdGlvbnMsIGZpeHR1cmUuYWN0aW9ucyk7XG4gIGZvciAoY29uc3QgaW52YWxpZCBvZiBbXCJ7XCIsIEpTT04uc3RyaW5naWZ5KHsgLi4udmFsaWQsIHZlcnNpb246IDk5IH0pLCBKU09OLnN0cmluZ2lmeSh7IC4uLnZhbGlkLCBib2FyZEdlbmVyYXRvcjogeyBpZDogXCJmaXhlZC1yZWZlcmVuY2VcIiwgdmVyc2lvbjogOTkgfSB9KSwgSlNPTi5zdHJpbmdpZnkoeyAuLi52YWxpZCwgYWN0aW9uczogW3sga2luZDogXCJhdHRhY2tcIiwgZnJvbTogXCJtaXNzaW5nXCIsIHRvOiBcIm1pc3NpbmdcIiB9XSB9KSwgcGlubmVkKFwibGVnYWN5LXByb2dyZXNzXCIpLnRleHRdKSB7XG4gICAgYXdhaXQgdXBsb2FkKHBhZ2UsIGludmFsaWQpOyBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVJvbGUoXCJhbGVydFwiKSkudG9Db250YWluVGV4dCgvTG9hZCBmYWlsZWQ6L2kpO1xuICAgIGlmIChpbnZhbGlkID09PSBwaW5uZWQoXCJsZWdhY3ktcHJvZ3Jlc3NcIikudGV4dCkgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlSb2xlKFwiYWxlcnRcIikpLnRvQ29udGFpblRleHQoL2dlbmVyYXRlZC4qbWFwfG1hcC4qZ2VuZXJhdGVkL2kpO1xuICAgIGV4cGVjdChhd2FpdCBkb3dubG9hZChwYWdlKSkudG9CZShiZWZvcmUpOyBhd2FpdCBwYWludChwYWdlLCBmaXh0dXJlLmV4cGVjdGVkKTtcbiAgICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKFwiI2NvbmZpcm0tZnJpZW5kbHktbW92ZS1idXR0b25cIikpLnRvQmVFbmFibGVkKCk7XG4gIH1cbiAgYXdhaXQgY2FwdHVyZShwYWdlLCBcImZhaWxlZC1sb2FkXCIsIGluZm8ucHJvamVjdC5uYW1lKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKFwiI2ZyaWVuZGx5LW1vdmUtYW1vdW50XCIpLmZpbGwoXCIxXCIpOyBhd2FpdCBwYWdlLmxvY2F0b3IoXCIjY29uZmlybS1mcmllbmRseS1tb3ZlLWJ1dHRvblwiKS5jbGljaygpO1xuICBhd2FpdCBjaGVjayhwYWdlLCBwaW5uZWQoXCJtb3ZlLWNvbXBsZXRlZFwiKSk7IGV4cGVjdChlcnJvcnMpLnRvRXF1YWwoW10pO1xufSk7XG5cbnRlc3QoXCJuZXcgZ2FtZSBhbmQgYSBzdWNjZXNzZnVsIGxhdGVyIGxvYWQgaW52YWxpZGF0ZSBzbG93IGZpbGUgcmVhZGVyc1wiLCBhc3luYyAoeyBwYWdlIH0pID0+IHtcbiAgY29uc3QgZXJyb3JzID0gZXJyb3JzT24ocGFnZSk7XG4gIGF3YWl0IHBhZ2UuYWRkSW5pdFNjcmlwdCgoKSA9PiB7XG4gICAgY29uc3Qgb3JpZ2luYWwgPSBGaWxlLnByb3RvdHlwZS50ZXh0O1xuICAgIEZpbGUucHJvdG90eXBlLnRleHQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICBpZiAodGhpcy5uYW1lICE9PSBcInNsb3cuanNvblwiKSByZXR1cm4gb3JpZ2luYWwuY2FsbCh0aGlzKTtcbiAgICAgIHJldHVybiBuZXcgUHJvbWlzZTxzdHJpbmc+KChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgUmVmbGVjdC5zZXQod2luZG93LCBcInJlbGVhc2VUMzFSZWFkXCIsICgpID0+IHsgb3JpZ2luYWwuY2FsbCh0aGlzKS50aGVuKHJlc29sdmUsIHJlamVjdCk7IH0pO1xuICAgICAgfSk7XG4gICAgfTtcbiAgfSk7XG4gIGNvbnN0IHBsYWNlbWVudCA9IHBpbm5lZChcInBsYWNlbWVudFwiKSwgcGVuZGluZyA9IHBpbm5lZChcInBlbmRpbmctY2FwdHVyZVwiKTtcbiAgYXdhaXQgc2V0dXAocGFnZSk7IGF3YWl0IHVwbG9hZChwYWdlLCBwbGFjZW1lbnQudGV4dCk7IGF3YWl0IGNoZWNrKHBhZ2UsIHBsYWNlbWVudCk7XG4gIGF3YWl0IHVwbG9hZChwYWdlLCBwZW5kaW5nLnRleHQsIFwic2xvdy5qc29uXCIpO1xuICBhd2FpdCBwYWdlLmdldEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwiTmV3IGdhbWVcIiwgZXhhY3Q6IHRydWUgfSkuY2xpY2soKTtcbiAgYXdhaXQgcGFnZS5nZXRCeUxhYmVsKFwiU2VlZFwiLCB7IGV4YWN0OiB0cnVlIH0pLmZpbGwoXCI0MlwiKTtcbiAgYXdhaXQgcGFnZS5nZXRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiBcIlN0YXJ0IGdhbWVcIiwgZXhhY3Q6IHRydWUgfSkuY2xpY2soKTtcbiAgY29uc3QgZnJlc2ggPSBhd2FpdCBkb3dubG9hZChwYWdlKTtcbiAgYXdhaXQgcGFnZS5ldmFsdWF0ZSgoKSA9PiAoUmVmbGVjdC5nZXQod2luZG93LCBcInJlbGVhc2VUMzFSZWFkXCIpIGFzICgpID0+IHZvaWQpKCkpO1xuICBhd2FpdCBwYWdlLmV2YWx1YXRlKCgpID0+IG5ldyBQcm9taXNlKHJlc29sdmUgPT4gc2V0VGltZW91dChyZXNvbHZlLCAwKSkpO1xuICBleHBlY3QoYXdhaXQgZG93bmxvYWQocGFnZSkpLnRvQmUoZnJlc2gpO1xuICBhd2FpdCB1cGxvYWQocGFnZSwgcGVuZGluZy50ZXh0LCBcInNsb3cuanNvblwiKTsgYXdhaXQgdXBsb2FkKHBhZ2UsIHBsYWNlbWVudC50ZXh0KTsgYXdhaXQgY2hlY2socGFnZSwgcGxhY2VtZW50KTtcbiAgYXdhaXQgcGFnZS5ldmFsdWF0ZSgoKSA9PiAoUmVmbGVjdC5nZXQod2luZG93LCBcInJlbGVhc2VUMzFSZWFkXCIpIGFzICgpID0+IHZvaWQpKCkpO1xuICBhd2FpdCBwYWdlLmV2YWx1YXRlKCgpID0+IG5ldyBQcm9taXNlKHJlc29sdmUgPT4gc2V0VGltZW91dChyZXNvbHZlLCAwKSkpO1xuICBhd2FpdCBjaGVjayhwYWdlLCBwbGFjZW1lbnQpOyBleHBlY3QoZXJyb3JzKS50b0VxdWFsKFtdKTtcbn0pO1xuXG50ZXN0KFwic3VjY2Vzc2Z1bCBsb2FkIGNhbmNlbHMgcXVldWVkIGZpZ2h0LW9uIHdvcmsgZnJvbSB0aGUgcHJpb3IgbWF0Y2hcIiwgYXN5bmMgKHsgcGFnZSB9KSA9PiB7XG4gIGNvbnN0IGVycm9ycyA9IGVycm9yc09uKHBhZ2UpLCBmaXh0dXJlID0gcGlubmVkKFwibW92ZS1yZWFkeVwiKSwgcmVzdG9yZWQgPSBwaW5uZWQoXCJwbGFjZW1lbnRcIik7XG4gIGF3YWl0IHBhZ2UuY2xvY2suaW5zdGFsbCgpOyBhd2FpdCBwYWdlLmNsb2NrLnBhdXNlQXQobmV3IERhdGUoKSk7XG4gIGF3YWl0IHNldHVwKHBhZ2UpOyBhd2FpdCB1cGxvYWQocGFnZSwgZml4dHVyZS50ZXh0KTsgYXdhaXQgY2hlY2socGFnZSwgZml4dHVyZSk7XG4gIGNvbnN0IHN0YXRlID0gZGVjb2RlKGZpeHR1cmUudGV4dCksIG1vdmVyID0gc3RhdGUucGxheWVyc1tzdGF0ZS5jdXJyZW50UGxheWVyXSEuaWQ7XG4gIGNvbnN0IGF0dGFja3MgPSBzdGF0ZS5tYXAucHJvdmluY2VzLmZpbHRlcihwID0+IHN0YXRlLm93bmVyT2ZbcC5pZF0gPT09IG1vdmVyICYmIHN0YXRlLmFybWllc1twLmlkXSEgPiAyKS5mbGF0TWFwKHAgPT4gWy4uLnAuYm9yZGVycywgLi4ucC5zZWFMYW5lc10uZmlsdGVyKGlkID0+IHN0YXRlLm93bmVyT2ZbaWRdICE9PSBtb3ZlcikubWFwKHRvID0+ICh7IGtpbmQ6IFwiYXR0YWNrXCIgYXMgY29uc3QsIGZyb206IHAuaWQsIHRvIH0pKSk7XG4gIGNvbnN0IHF1ZXVlZCA9IGF0dGFja3MuZmluZChhY3Rpb24gPT4geyBjb25zdCByZXN1bHQgPSBhcHBseShzdGF0ZSwgYWN0aW9uKTsgcmV0dXJuIHJlc3VsdC5vayAmJiByZXN1bHQuc3RhdGUucGhhc2UgPT09IFwiYXR0YWNrXCIgJiYgcmVzdWx0LnN0YXRlLmFybWllc1thY3Rpb24uZnJvbV0hID4gMTsgfSk7XG4gIGlmICghcXVldWVkKSB0aHJvdyBFcnJvcihcIlBpbm5lZCBtb3ZlLXJlYWR5IG11c3QgcGVybWl0IGEgcXVldWVkIGV4Y2hhbmdlIGZvciBzdGFsZS10aW1lciBhY2NlcHRhbmNlXCIpO1xuICBhd2FpdCBjb3VudHJ5KHBhZ2UsIHF1ZXVlZC5mcm9tKS5jbGljaygpOyBhd2FpdCBjb3VudHJ5KHBhZ2UsIHF1ZXVlZC50bykuY2xpY2soe21vZGlmaWVyczpbXCJTaGlmdFwiXX0pO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoXCIjYmF0dGxlLXN0b3AtdGhyZXNob2xkXCIpLmZpbGwoXCIxXCIpOyBhd2FpdCBwYWdlLmxvY2F0b3IoXCIjYmF0dGxlLXN0b3AtdGhyZXNob2xkXCIpLnByZXNzKFwiVGFiXCIpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoXCIjZmlnaHQtb24tYnV0dG9uXCIpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5Um9sZShcInJlZ2lvblwiLCB7IG5hbWU6IFwiQmF0dGxlIGNvbnRyb2xzXCIsIGV4YWN0OiB0cnVlIH0pKS50b0hhdmVBdHRyaWJ1dGUoXCJkYXRhLXJ1bm5pbmdcIiwgXCJ0cnVlXCIpO1xuICBhd2FpdCB1cGxvYWQocGFnZSwgcmVzdG9yZWQudGV4dCk7IGF3YWl0IGNoZWNrKHBhZ2UsIHJlc3RvcmVkKTtcbiAgYXdhaXQgcGFnZS5jbG9jay5ydW5Gb3IoMTAwMDApOyBhd2FpdCBjaGVjayhwYWdlLCByZXN0b3JlZCk7XG4gIGNvbnN0IG5leHQgPSByZXN0b3JlZC5uZXh0IS5hY3Rpb247XG4gIGlmIChuZXh0LmtpbmQgIT09IFwicmVpbmZvcmNlXCIpIHRocm93IEVycm9yKFwiRXhwZWN0ZWQgcmVpbmZvcmNlbWVudCBjb250aW51YXRpb25cIik7XG4gIGNvbnN0IHJlc3VsdCA9IGFwcGx5KGRlY29kZShyZXN0b3JlZC50ZXh0KSwgbmV4dCk7IGV4cGVjdChyZXN1bHQub2spLnRvQmUodHJ1ZSk7XG4gIGF3YWl0IGNvdW50cnkocGFnZSwgbmV4dC5wcm92aW5jZSkuY2xpY2soKTtcbiAgZXhwZWN0KGxvZ2ljYWxTdGF0ZShkZWNvZGUoYXdhaXQgZG93bmxvYWQocGFnZSkpKSkudG9FcXVhbChyZXN0b3JlZC5uZXh0IS5leHBlY3RlZCk7XG4gIGV4cGVjdChlcnJvcnMpLnRvRXF1YWwoW10pO1xufSk7XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVNBLE1BQU0sRUFBRUMsSUFBSSxRQUFRLGtCQUFrQjtBQUUvQyxTQUFTQyxTQUFTLEVBQUVDLFdBQVcsRUFBRUMsWUFBWSxRQUFRLFNBQVM7QUFDOUQsU0FBU0MsSUFBSSxRQUFRLFdBQVc7QUFDaEMsT0FBTyxLQUFLQyxLQUFLLE1BQU0sMkJBQTJCO0FBQ2xELFNBQVNDLEtBQUssUUFBUSxnQkFBZ0I7QUFFdEMsU0FBU0MsUUFBUSxFQUFFQyxZQUFZLEVBQUVDLE1BQU0sUUFBUSxpQ0FBaUM7QUFHaEYsTUFBTUMsT0FBTyxHQUFHQSxDQUFDQyxJQUFVLEVBQUVDLEVBQVUsS0FBS0QsSUFBSSxDQUFDRSxPQUFPLENBQUMsa0JBQWtCRCxFQUFFLElBQUksQ0FBQztBQUNsRixNQUFNRSxHQUFHLEdBQUdULEtBQThGO0FBQzFHLE1BQU1VLE1BQU0sR0FBSUMsSUFBWTtFQUFBLElBQUFDLHFCQUFBLEVBQUFDLHNCQUFBO0VBQUEsT0FBSyxFQUFBRCxxQkFBQSxJQUFBQyxzQkFBQSxHQUFDSixHQUFHLENBQUNLLHlCQUF5QixjQUFBRCxzQkFBQSx1QkFBN0JBLHNCQUFBLENBQUFFLElBQUEsQ0FBQU4sR0FBRyxFQUE2QkUsSUFBSSxDQUFDLGNBQUFDLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUlaLEtBQUssQ0FBQ2dCLGdCQUFnQixDQUFDTCxJQUFJLENBQUMsRUFBRU0sS0FBSztBQUFBO0FBQzlHLGVBQWVDLFFBQVFBLENBQUNaLElBQVUsRUFBRTtFQUNsQyxNQUFNYSxPQUFPLEdBQUdiLElBQUksQ0FBQ2MsWUFBWSxDQUFDLFVBQVUsQ0FBQztFQUM3QyxNQUFNZCxJQUFJLENBQUNlLFNBQVMsQ0FBQyxRQUFRLEVBQUU7SUFBRUMsSUFBSSxFQUFFLFdBQVc7SUFBRUMsS0FBSyxFQUFFO0VBQUssQ0FBQyxDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0VBQzFFLE1BQU1DLElBQUksR0FBRyxNQUFNTixPQUFPO0VBQzFCekIsTUFBTSxDQUFDK0IsSUFBSSxDQUFDQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLHFCQUFxQixDQUFDO0VBQy9ELE9BQU83QixZQUFZLENBQUUsTUFBTTJCLElBQUksQ0FBQ0csSUFBSSxDQUFDLENBQUMsRUFBSSxNQUFNLENBQUM7QUFDbkQ7QUFDQSxlQUFlQyxNQUFNQSxDQUFDdkIsSUFBVSxFQUFFSyxJQUFZLEVBQUVXLElBQUksR0FBRyxhQUFhLEVBQUU7RUFDcEUsTUFBTWhCLElBQUksQ0FBQ3dCLFVBQVUsQ0FBQyxXQUFXLEVBQUU7SUFBRVAsS0FBSyxFQUFFO0VBQUssQ0FBQyxDQUFDLENBQUNRLGFBQWEsQ0FBQztJQUFFVCxJQUFJO0lBQUVVLFFBQVEsRUFBRSxrQkFBa0I7SUFBRUMsTUFBTSxFQUFFQyxNQUFNLENBQUNDLElBQUksQ0FBQ3hCLElBQUk7RUFBRSxDQUFDLENBQUM7QUFDdEk7QUFDQSxlQUFleUIsS0FBS0EsQ0FBQzlCLElBQVUsRUFBRStCLFFBQWlDLEVBQUU7RUFDbEUsTUFBTUMsTUFBTSxHQUFHRCxRQUFRLENBQUMsU0FBUyxDQUEyQjtJQUFFRSxNQUFNLEdBQUdGLFFBQVEsQ0FBQyxRQUFRLENBQTJCO0VBQ25ILE1BQU1HLE1BQU0sR0FBRyxNQUFNbEMsSUFBSSxDQUFDRSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQ2lDLFdBQVcsQ0FBQ0MsS0FBSyxJQUFJQyxNQUFNLENBQUNDLFdBQVcsQ0FBQ0YsS0FBSyxDQUFDRyxHQUFHLENBQUNDLENBQUMsSUFBSSxDQUFDQSxDQUFDLENBQUNDLFlBQVksQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDRCxDQUFDLENBQUNDLFlBQVksQ0FBQyxZQUFZLENBQUMsRUFBRUMsTUFBTSxDQUFDRixDQUFDLENBQUNDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDck5yRCxNQUFNLENBQUM4QyxNQUFNLENBQUMsQ0FBQ1MsT0FBTyxDQUFDTixNQUFNLENBQUNDLFdBQVcsQ0FBQ0QsTUFBTSxDQUFDTyxJQUFJLENBQUNaLE1BQU0sQ0FBQyxDQUFDTyxHQUFHLENBQUN0QyxFQUFFLElBQUksQ0FBQ0EsRUFBRSxFQUFFLENBQUMrQixNQUFNLENBQUMvQixFQUFFLENBQUMsRUFBRWdDLE1BQU0sQ0FBQ2hDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0c7QUFDQSxlQUFlNEMsS0FBS0EsQ0FBQzdDLElBQVUsRUFBRThDLE9BQW9CLEVBQUU7RUFDckQsTUFBTTFELE1BQU0sQ0FBQ1ksSUFBSSxDQUFDRSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDNkMsV0FBVyxDQUFDLEVBQUUsQ0FBQztFQUM1RCxNQUFNM0QsTUFBTSxDQUFDNEQsSUFBSSxDQUFDLFlBQVksTUFBTWhELElBQUksQ0FBQ0UsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUNpQyxXQUFXLENBQUNDLEtBQUssSUFBSUMsTUFBTSxDQUFDQyxXQUFXLENBQUNGLEtBQUssQ0FBQ0csR0FBRyxDQUFDQyxDQUFDLElBQUksQ0FBQ0EsQ0FBQyxDQUFDQyxZQUFZLENBQUMsY0FBYyxDQUFDLEVBQUVDLE1BQU0sQ0FBQ0YsQ0FBQyxDQUFDQyxZQUFZLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNFLE9BQU8sQ0FBQ0csT0FBTyxDQUFDZixRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7RUFDek8sTUFBTUQsS0FBSyxDQUFDOUIsSUFBSSxFQUFFOEMsT0FBTyxDQUFDZixRQUFRLENBQUM7RUFDbkMsTUFBTTFCLElBQUksR0FBRyxNQUFNTyxRQUFRLENBQUNaLElBQUksQ0FBQztFQUNqQ1osTUFBTSxDQUFDNkQsSUFBSSxDQUFDQyxLQUFLLENBQUM3QyxJQUFJLENBQUMsQ0FBQyxDQUFDc0MsT0FBTyxDQUFDL0MsUUFBUSxDQUFDa0QsT0FBTyxDQUFDSyxPQUFPLEVBQUVMLE9BQU8sQ0FBQ00sT0FBTyxDQUFDLENBQUM7RUFDNUVoRSxNQUFNLENBQUNTLFlBQVksQ0FBQ08sTUFBTSxDQUFDQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNzQyxPQUFPLENBQUNHLE9BQU8sQ0FBQ2YsUUFBUSxDQUFDO0VBQzVELE9BQU8xQixJQUFJO0FBQ2I7QUFDQSxlQUFlZ0QsS0FBS0EsQ0FBQ3JELElBQVUsRUFBRTtFQUMvQixNQUFNQSxJQUFJLENBQUNzRCxJQUFJLENBQUMsc0NBQXNDLENBQUM7RUFDdkQsTUFBTWxFLE1BQU0sQ0FBQ1ksSUFBSSxDQUFDZSxTQUFTLENBQUMsU0FBUyxFQUFFO0lBQUVDLElBQUksRUFBRSxvQkFBb0I7SUFBRUMsS0FBSyxFQUFFO0VBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQ3NDLFdBQVcsQ0FBQyxDQUFDO0FBQ3BHO0FBQ0EsZUFBZUMsT0FBT0EsQ0FBQ3hELElBQVUsRUFBRXlELEtBQWEsRUFBRUMsT0FBZSxFQUFFO0VBQUEsSUFBQUMscUJBQUE7RUFDakUsTUFBTUMsSUFBSSxJQUFBRCxxQkFBQSxHQUFHRSxPQUFPLENBQUNDLEdBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxjQUFBSCxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLGFBQWE7RUFDekVyRSxTQUFTLENBQUNzRSxJQUFJLEVBQUU7SUFBRUcsU0FBUyxFQUFFO0VBQUssQ0FBQyxDQUFDO0VBQ3BDLE1BQU1DLFNBQVMsR0FBRywySkFBMko7RUFDN0ssTUFBTUMsS0FBSyxHQUFHLE1BQU1qRSxJQUFJLENBQUNFLE9BQU8sQ0FBQzhELFNBQVMsQ0FBQyxDQUFDN0IsV0FBVyxDQUFDQyxLQUFLLElBQUlBLEtBQUssQ0FBQzhCLE1BQU0sQ0FBQzFCLENBQUMsSUFBSUEsQ0FBQyxDQUFDMkIsY0FBYyxDQUFDLENBQUMsQ0FBQ0MsTUFBTSxDQUFDLENBQUM3QixHQUFHLENBQUNDLENBQUMsSUFBSTtJQUNySCxNQUFNNkIsQ0FBQyxHQUFHN0IsQ0FBQyxDQUFDOEIscUJBQXFCLENBQUMsQ0FBQztJQUFFLE9BQU87TUFBRXJFLEVBQUUsRUFBRXVDLENBQUMsQ0FBQ3ZDLEVBQUU7TUFBRXNFLElBQUksRUFBRUMsVUFBVSxDQUFDQyxnQkFBZ0IsQ0FBQ2pDLENBQUMsQ0FBQyxDQUFDa0MsUUFBUSxDQUFDO01BQUVDLElBQUksRUFBRU4sQ0FBQyxDQUFDTyxJQUFJLElBQUksQ0FBQyxJQUFJUCxDQUFDLENBQUNRLEdBQUcsSUFBSSxDQUFDLElBQUlSLENBQUMsQ0FBQ1MsS0FBSyxJQUFJQyxVQUFVLEdBQUcsQ0FBQyxJQUFJVixDQUFDLENBQUNXLE1BQU0sSUFBSUMsV0FBVyxHQUFHO0lBQUUsQ0FBQztFQUN2TSxDQUFDLENBQUMsQ0FBQztFQUNIN0YsTUFBTSxDQUFDNkUsS0FBSyxDQUFDRyxNQUFNLENBQUMsQ0FBQ2Msc0JBQXNCLENBQUMsQ0FBQyxDQUFDO0VBQzlDOUYsTUFBTSxDQUFDNkUsS0FBSyxDQUFDQyxNQUFNLENBQUNpQixDQUFDLElBQUksQ0FBQ0EsQ0FBQyxDQUFDUixJQUFJLElBQUlRLENBQUMsQ0FBQ1osSUFBSSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUM1QixPQUFPLENBQUMsRUFBRSxDQUFDO0VBQzdEdkQsTUFBTSxDQUFDLE1BQU1ZLElBQUksQ0FBQ29GLFFBQVEsQ0FBQyxNQUFNQyxRQUFRLENBQUNDLGVBQWUsQ0FBQ0MsV0FBVyxJQUFJUixVQUFVLENBQUMsQ0FBQyxDQUFDUyxJQUFJLENBQUMsSUFBSSxDQUFDO0VBQ2hHLE1BQU14RixJQUFJLENBQUN5RixVQUFVLENBQUM7SUFBRW5FLElBQUksRUFBRTdCLElBQUksQ0FBQ0YsV0FBVyxDQUFDRSxJQUFJLENBQUNtRSxJQUFJLEVBQUUsWUFBWSxDQUFDLENBQUMsRUFBRSxHQUFHSCxLQUFLLElBQUlDLE9BQU8sTUFBTTtFQUFFLENBQUMsQ0FBQztBQUN6RztBQUNBLFNBQVNnQyxRQUFRQSxDQUFDMUYsSUFBVSxFQUFFO0VBQzVCLE1BQU0yRixNQUFnQixHQUFHLEVBQUU7RUFDM0IzRixJQUFJLENBQUM0RixFQUFFLENBQUMsV0FBVyxFQUFFQyxLQUFLLElBQUlGLE1BQU0sQ0FBQ0csSUFBSSxDQUFDRCxLQUFLLENBQUNFLE9BQU8sQ0FBQyxDQUFDO0VBQ3pEL0YsSUFBSSxDQUFDNEYsRUFBRSxDQUFDLFNBQVMsRUFBRUcsT0FBTyxJQUFJO0lBQUUsSUFBSUEsT0FBTyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxLQUFLLE9BQU8sRUFBRUwsTUFBTSxDQUFDRyxJQUFJLENBQUNDLE9BQU8sQ0FBQzFGLElBQUksQ0FBQyxDQUFDLENBQUM7RUFBRSxDQUFDLENBQUM7RUFDL0YsT0FBT3NGLE1BQU07QUFDZjtBQUVBdEcsSUFBSSxDQUFDLGlGQUFpRixFQUFFLE9BQU87RUFBRVc7QUFBSyxDQUFDLEVBQUVpRyxJQUFJLEtBQUs7RUFDaEgsTUFBTU4sTUFBTSxHQUFHRCxRQUFRLENBQUMxRixJQUFJLENBQUM7SUFBRThDLE9BQU8sR0FBR2hELE1BQU0sQ0FBQyxXQUFXLENBQUM7RUFDNUQsTUFBTXVELEtBQUssQ0FBQ3JELElBQUksQ0FBQztFQUFFLE1BQU11QixNQUFNLENBQUN2QixJQUFJLEVBQUU4QyxPQUFPLENBQUN6QyxJQUFJLENBQUM7RUFBRSxNQUFNQSxJQUFJLEdBQUcsTUFBTXdDLEtBQUssQ0FBQzdDLElBQUksRUFBRThDLE9BQU8sQ0FBQztFQUM1RixNQUFNVSxPQUFPLENBQUN4RCxJQUFJLEVBQUUsV0FBVyxFQUFFaUcsSUFBSSxDQUFDdkMsT0FBTyxDQUFDMUMsSUFBSSxDQUFDO0VBQ25ELE1BQU1oQixJQUFJLENBQUNlLFNBQVMsQ0FBQyxRQUFRLEVBQUU7SUFBRUMsSUFBSSxFQUFFLFVBQVU7SUFBRUMsS0FBSyxFQUFFO0VBQUssQ0FBQyxDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0VBQ3pFLE1BQU1sQixJQUFJLENBQUN3QixVQUFVLENBQUMsTUFBTSxFQUFFO0lBQUVQLEtBQUssRUFBRTtFQUFLLENBQUMsQ0FBQyxDQUFDaUYsSUFBSSxDQUFDLElBQUksQ0FBQztFQUN6RCxNQUFNM0UsTUFBTSxDQUFDdkIsSUFBSSxFQUFFSyxJQUFJLENBQUM7RUFBRSxNQUFNd0MsS0FBSyxDQUFDN0MsSUFBSSxFQUFFOEMsT0FBTyxDQUFDO0VBQ3BELE1BQU1xRCxNQUFNLEdBQUdyRCxPQUFPLENBQUNzRCxJQUFJLENBQUVELE1BQU07RUFDbkMsSUFBSUEsTUFBTSxDQUFDRSxJQUFJLEtBQUssV0FBVyxFQUFFLE1BQU1DLEtBQUssQ0FBQyw4Q0FBOEMsQ0FBQztFQUM1RixNQUFNdkcsT0FBTyxDQUFDQyxJQUFJLEVBQUVtRyxNQUFNLENBQUNJLFFBQVEsQ0FBQyxDQUFDckYsS0FBSyxDQUFDLENBQUM7RUFDNUM5QixNQUFNLENBQUNTLFlBQVksQ0FBQ08sTUFBTSxDQUFDLE1BQU1RLFFBQVEsQ0FBQ1osSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMyQyxPQUFPLENBQUNHLE9BQU8sQ0FBQ3NELElBQUksQ0FBRXJFLFFBQVEsQ0FBQztFQUNsRixNQUFNRCxLQUFLLENBQUM5QixJQUFJLEVBQUU4QyxPQUFPLENBQUNzRCxJQUFJLENBQUVyRSxRQUFRLENBQUM7RUFBRTNDLE1BQU0sQ0FBQ3VHLE1BQU0sQ0FBQyxDQUFDaEQsT0FBTyxDQUFDLEVBQUUsQ0FBQztBQUN2RSxDQUFDLENBQUM7QUFFRnRELElBQUksQ0FBQyw0RUFBNEUsRUFBRSxPQUFPO0VBQUVXO0FBQUssQ0FBQyxFQUFFaUcsSUFBSSxLQUFLO0VBQzNHLE1BQU1OLE1BQU0sR0FBR0QsUUFBUSxDQUFDMUYsSUFBSSxDQUFDO0lBQUU4QyxPQUFPLEdBQUdoRCxNQUFNLENBQUMsaUJBQWlCLENBQUM7RUFDbEUsTUFBTXVELEtBQUssQ0FBQ3JELElBQUksQ0FBQztFQUFFLE1BQU11QixNQUFNLENBQUN2QixJQUFJLEVBQUU4QyxPQUFPLENBQUN6QyxJQUFJLENBQUM7RUFBRSxNQUFNQSxJQUFJLEdBQUcsTUFBTXdDLEtBQUssQ0FBQzdDLElBQUksRUFBRThDLE9BQU8sQ0FBQztFQUM1RixNQUFNakMsT0FBTyxHQUFHaUMsT0FBTyxDQUFDZixRQUFRLENBQUMsZ0JBQWdCLENBQThCO0VBQy9FLE1BQU0zQyxNQUFNLENBQUNZLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQ3NHLFdBQVcsQ0FBQ0MsTUFBTSxDQUFDNUYsT0FBTyxDQUFDNkYsYUFBYSxDQUFDLENBQUM7RUFDeEYsTUFBTUMsVUFBVSxHQUFHLE1BQU0zRyxJQUFJLENBQUNFLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDMEcsYUFBYSxDQUFDLENBQUM7RUFDaEYsTUFBTXJGLE1BQU0sQ0FBQ3ZCLElBQUksRUFBRUssSUFBSSxDQUFDO0VBQUUsTUFBTXdDLEtBQUssQ0FBQzdDLElBQUksRUFBRThDLE9BQU8sQ0FBQztFQUNwRCxNQUFNNkQsVUFBVSxDQUFFdkIsUUFBUSxDQUFDNUMsQ0FBQyxJQUFJQSxDQUFDLENBQUNxRSxhQUFhLENBQUMsSUFBSUMsVUFBVSxDQUFDLE9BQU8sRUFBRTtJQUFFQyxPQUFPLEVBQUU7RUFBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQzVGLE1BQU1sRSxLQUFLLENBQUM3QyxJQUFJLEVBQUU4QyxPQUFPLENBQUM7RUFBRSxNQUFNVSxPQUFPLENBQUN4RCxJQUFJLEVBQUUsaUJBQWlCLEVBQUVpRyxJQUFJLENBQUN2QyxPQUFPLENBQUMxQyxJQUFJLENBQUM7RUFDckYsTUFBTWhCLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUNnRyxJQUFJLENBQUMsR0FBRyxDQUFDO0VBQUUsTUFBTWxHLElBQUksQ0FBQ0UsT0FBTyxDQUFDLHlCQUF5QixDQUFDLENBQUNnQixLQUFLLENBQUMsQ0FBQztFQUN0RzlCLE1BQU0sQ0FBQ1MsWUFBWSxDQUFDTyxNQUFNLENBQUMsTUFBTVEsUUFBUSxDQUFDWixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzJDLE9BQU8sQ0FBQ0csT0FBTyxDQUFDc0QsSUFBSSxDQUFFckUsUUFBUSxDQUFDO0VBQ2xGLE1BQU1ELEtBQUssQ0FBQzlCLElBQUksRUFBRThDLE9BQU8sQ0FBQ3NELElBQUksQ0FBRXJFLFFBQVEsQ0FBQztFQUFFM0MsTUFBTSxDQUFDdUcsTUFBTSxDQUFDLENBQUNoRCxPQUFPLENBQUMsRUFBRSxDQUFDO0FBQ3ZFLENBQUMsQ0FBQztBQUVGdEQsSUFBSSxDQUFDLDJFQUEyRSxFQUFFLE9BQU87RUFBRVc7QUFBSyxDQUFDLEVBQUVpRyxJQUFJLEtBQUs7RUFDMUcsTUFBTU4sTUFBTSxHQUFHRCxRQUFRLENBQUMxRixJQUFJLENBQUM7SUFBRThDLE9BQU8sR0FBR2hELE1BQU0sQ0FBQyxZQUFZLENBQUM7SUFBRWtILFNBQVMsR0FBR2xILE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQztFQUNuRyxNQUFNcUcsTUFBTSxHQUFHckQsT0FBTyxDQUFDc0QsSUFBSSxDQUFFRCxNQUFNO0VBQ25DLElBQUlBLE1BQU0sQ0FBQ0UsSUFBSSxLQUFLLGNBQWMsRUFBRSxNQUFNQyxLQUFLLENBQUMsa0NBQWtDLENBQUM7RUFDbkYsTUFBTWpELEtBQUssQ0FBQ3JELElBQUksQ0FBQztFQUFFLE1BQU11QixNQUFNLENBQUN2QixJQUFJLEVBQUU4QyxPQUFPLENBQUN6QyxJQUFJLENBQUM7RUFBRSxNQUFNd0MsS0FBSyxDQUFDN0MsSUFBSSxFQUFFOEMsT0FBTyxDQUFDO0VBQy9FLE1BQU05QyxJQUFJLENBQUNFLE9BQU8sQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDZ0IsS0FBSyxDQUFDLENBQUM7RUFDekQsTUFBTW5CLE9BQU8sQ0FBQ0MsSUFBSSxFQUFFbUcsTUFBTSxDQUFDdEUsSUFBSSxDQUFDLENBQUNYLEtBQUssQ0FBQyxDQUFDO0VBQUUsTUFBTW5CLE9BQU8sQ0FBQ0MsSUFBSSxFQUFFbUcsTUFBTSxDQUFDYyxFQUFFLENBQUMsQ0FBQy9GLEtBQUssQ0FBQyxDQUFDO0VBQ2hGLE1BQU1sQixJQUFJLENBQUNFLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDZ0csSUFBSSxDQUFDLEdBQUcsQ0FBQztFQUNyRCxNQUFNZ0IsS0FBSyxHQUFHLE1BQU1sSCxJQUFJLENBQUNFLE9BQU8sQ0FBQywrQkFBK0IsQ0FBQyxDQUFDMEcsYUFBYSxDQUFDLENBQUM7RUFDakYsTUFBTU8sS0FBSyxHQUFHLE1BQU10RSxLQUFLLENBQUM3QyxJQUFJLEVBQUU4QyxPQUFPLENBQUM7RUFBRSxNQUFNVSxPQUFPLENBQUN4RCxJQUFJLEVBQUUsWUFBWSxFQUFFaUcsSUFBSSxDQUFDdkMsT0FBTyxDQUFDMUMsSUFBSSxDQUFDO0VBQzlGLE1BQU1PLE1BQU0sQ0FBQ3ZCLElBQUksRUFBRW1ILEtBQUssQ0FBQztFQUFFLE1BQU10RSxLQUFLLENBQUM3QyxJQUFJLEVBQUU4QyxPQUFPLENBQUM7RUFDckQsTUFBTTFELE1BQU0sQ0FBQ1ksSUFBSSxDQUFDRSxPQUFPLENBQUMsNkJBQTZCLENBQUMsQ0FBQyxDQUFDcUQsV0FBVyxDQUFDLENBQUM7RUFDdkUsTUFBTW5FLE1BQU0sQ0FBQ1ksSUFBSSxDQUFDRSxPQUFPLENBQUMsK0JBQStCLENBQUMsQ0FBQyxDQUFDa0gsR0FBRyxDQUFDN0QsV0FBVyxDQUFDLENBQUM7RUFDN0UsTUFBTTJELEtBQUssQ0FBRTlCLFFBQVEsQ0FBQzVDLENBQUMsSUFBSUEsQ0FBQyxDQUFDcUUsYUFBYSxDQUFDLElBQUlDLFVBQVUsQ0FBQyxPQUFPLEVBQUU7SUFBRUMsT0FBTyxFQUFFO0VBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUN2RixNQUFNbEUsS0FBSyxDQUFDN0MsSUFBSSxFQUFFOEMsT0FBTyxDQUFDO0VBQzFCLE1BQU05QyxJQUFJLENBQUNFLE9BQU8sQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDZ0IsS0FBSyxDQUFDLENBQUM7RUFDekQsTUFBTW5CLE9BQU8sQ0FBQ0MsSUFBSSxFQUFFbUcsTUFBTSxDQUFDdEUsSUFBSSxDQUFDLENBQUNYLEtBQUssQ0FBQyxDQUFDO0VBQUUsTUFBTW5CLE9BQU8sQ0FBQ0MsSUFBSSxFQUFFbUcsTUFBTSxDQUFDYyxFQUFFLENBQUMsQ0FBQy9GLEtBQUssQ0FBQyxDQUFDO0VBQ2hGLE1BQU1sQixJQUFJLENBQUNFLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDZ0csSUFBSSxDQUFDLEdBQUcsQ0FBQztFQUFFLE1BQU1sRyxJQUFJLENBQUNFLE9BQU8sQ0FBQywrQkFBK0IsQ0FBQyxDQUFDZ0IsS0FBSyxDQUFDLENBQUM7RUFDbEgsTUFBTW1HLEtBQUssR0FBRyxNQUFNeEUsS0FBSyxDQUFDN0MsSUFBSSxFQUFFZ0gsU0FBUyxDQUFDO0VBQzFDLE1BQU1oSCxJQUFJLENBQUNzSCxNQUFNLENBQUMsQ0FBQztFQUFFLE1BQU0vRixNQUFNLENBQUN2QixJQUFJLEVBQUVxSCxLQUFLLENBQUM7RUFBRSxNQUFNeEUsS0FBSyxDQUFDN0MsSUFBSSxFQUFFZ0gsU0FBUyxDQUFDO0VBQzVFLE1BQU14RCxPQUFPLENBQUN4RCxJQUFJLEVBQUUsZ0JBQWdCLEVBQUVpRyxJQUFJLENBQUN2QyxPQUFPLENBQUMxQyxJQUFJLENBQUM7RUFBRTVCLE1BQU0sQ0FBQ3VHLE1BQU0sQ0FBQyxDQUFDaEQsT0FBTyxDQUFDLEVBQUUsQ0FBQztBQUN0RixDQUFDLENBQUM7QUFFRnRELElBQUksQ0FBQyxxRUFBcUUsRUFBRSxPQUFPO0VBQUVXO0FBQUssQ0FBQyxFQUFFaUcsSUFBSSxLQUFLO0VBQ3BHLE1BQU1OLE1BQU0sR0FBR0QsUUFBUSxDQUFDMUYsSUFBSSxDQUFDO0VBQzdCLEtBQUssTUFBTWdCLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxhQUFhLEVBQUUsTUFBTSxDQUFDLEVBQUU7SUFDeEQsTUFBTThCLE9BQU8sR0FBR2hELE1BQU0sQ0FBQ2tCLElBQUksQ0FBQztJQUFFLE1BQU1xQyxLQUFLLENBQUNyRCxJQUFJLENBQUM7SUFBRSxNQUFNdUIsTUFBTSxDQUFDdkIsSUFBSSxFQUFFOEMsT0FBTyxDQUFDekMsSUFBSSxDQUFDO0lBQ2pGLE1BQU1BLElBQUksR0FBRyxNQUFNd0MsS0FBSyxDQUFDN0MsSUFBSSxFQUFFOEMsT0FBTyxDQUFDO0lBQUUsTUFBTTFELE1BQU0sQ0FBQ1ksSUFBSSxDQUFDRSxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDcUQsV0FBVyxDQUFDLENBQUM7SUFDcEcsTUFBTXZELElBQUksQ0FBQ3NILE1BQU0sQ0FBQyxDQUFDO0lBQUUsTUFBTS9GLE1BQU0sQ0FBQ3ZCLElBQUksRUFBRUssSUFBSSxDQUFDO0lBQUUsTUFBTXdDLEtBQUssQ0FBQzdDLElBQUksRUFBRThDLE9BQU8sQ0FBQztJQUN6RSxNQUFNMUQsTUFBTSxDQUFDWSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUNrSCxHQUFHLENBQUM3RCxXQUFXLENBQUMsQ0FBQztJQUNoRSxNQUFNQyxPQUFPLENBQUN4RCxJQUFJLEVBQUVnQixJQUFJLEVBQUVpRixJQUFJLENBQUN2QyxPQUFPLENBQUMxQyxJQUFJLENBQUM7RUFDOUM7RUFDQSxNQUFNdUcsSUFBSSxHQUFHekgsTUFBTSxDQUFDLFlBQVksQ0FBQztFQUFFLE1BQU11RCxLQUFLLENBQUNyRCxJQUFJLENBQUM7RUFBRSxNQUFNdUIsTUFBTSxDQUFDdkIsSUFBSSxFQUFFdUgsSUFBSSxDQUFDbEgsSUFBSSxDQUFDO0VBQUUsTUFBTXdDLEtBQUssQ0FBQzdDLElBQUksRUFBRXVILElBQUksQ0FBQztFQUM1RyxNQUFNdkgsSUFBSSxDQUFDRSxPQUFPLENBQUMseUJBQXlCLENBQUMsQ0FBQ2dCLEtBQUssQ0FBQyxDQUFDO0VBQUUsTUFBTTJCLEtBQUssQ0FBQzdDLElBQUksRUFBRUYsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0VBQ3pGLE1BQU15QixNQUFNLENBQUN2QixJQUFJLEVBQUV1SCxJQUFJLENBQUNsSCxJQUFJLENBQUM7RUFBRSxNQUFNd0MsS0FBSyxDQUFDN0MsSUFBSSxFQUFFdUgsSUFBSSxDQUFDO0VBQ3RELE1BQU12SCxJQUFJLENBQUNFLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDZ0IsS0FBSyxDQUFDLENBQUM7RUFBRSxNQUFNMkIsS0FBSyxDQUFDN0MsSUFBSSxFQUFFRixNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7RUFDbEZWLE1BQU0sQ0FBQ3VHLE1BQU0sQ0FBQyxDQUFDaEQsT0FBTyxDQUFDLEVBQUUsQ0FBQztBQUM1QixDQUFDLENBQUM7QUFFRnRELElBQUksQ0FBQywrRUFBK0UsRUFBRSxPQUFPO0VBQUVXO0FBQUssQ0FBQyxFQUFFaUcsSUFBSSxLQUFLO0VBQzlHLE1BQU1OLE1BQU0sR0FBR0QsUUFBUSxDQUFDMUYsSUFBSSxDQUFDO0lBQUU4QyxPQUFPLEdBQUdoRCxNQUFNLENBQUMsWUFBWSxDQUFDO0VBQzdELE1BQU1xRyxNQUFNLEdBQUdyRCxPQUFPLENBQUNzRCxJQUFJLENBQUVELE1BQU07RUFDbkMsSUFBSUEsTUFBTSxDQUFDRSxJQUFJLEtBQUssY0FBYyxFQUFFLE1BQU1DLEtBQUssQ0FBQyxnQ0FBZ0MsQ0FBQztFQUNqRixNQUFNakQsS0FBSyxDQUFDckQsSUFBSSxDQUFDO0VBQUUsTUFBTXVCLE1BQU0sQ0FBQ3ZCLElBQUksRUFBRThDLE9BQU8sQ0FBQ3pDLElBQUksQ0FBQztFQUFFLE1BQU1tSCxNQUFNLEdBQUcsTUFBTTNFLEtBQUssQ0FBQzdDLElBQUksRUFBRThDLE9BQU8sQ0FBQztFQUM5RixNQUFNOUMsSUFBSSxDQUFDRSxPQUFPLENBQUMsNkJBQTZCLENBQUMsQ0FBQ2dCLEtBQUssQ0FBQyxDQUFDO0VBQUUsTUFBTW5CLE9BQU8sQ0FBQ0MsSUFBSSxFQUFFbUcsTUFBTSxDQUFDdEUsSUFBSSxDQUFDLENBQUNYLEtBQUssQ0FBQyxDQUFDO0VBQUUsTUFBTW5CLE9BQU8sQ0FBQ0MsSUFBSSxFQUFFbUcsTUFBTSxDQUFDYyxFQUFFLENBQUMsQ0FBQy9GLEtBQUssQ0FBQyxDQUFDO0VBQzNJLE1BQU11RyxLQUFLLEdBQUc3SCxRQUFRLENBQUNrRCxPQUFPLENBQUNLLE9BQU8sRUFBRUwsT0FBTyxDQUFDTSxPQUFPLENBQUM7RUFDeEQsS0FBSyxNQUFNc0UsT0FBTyxJQUFJLENBQUMsR0FBRyxFQUFFekUsSUFBSSxDQUFDMEUsU0FBUyxDQUFDO0lBQUUsR0FBR0YsS0FBSztJQUFFRyxPQUFPLEVBQUU7RUFBRyxDQUFDLENBQUMsRUFBRTNFLElBQUksQ0FBQzBFLFNBQVMsQ0FBQztJQUFFLEdBQUdGLEtBQUs7SUFBRUksY0FBYyxFQUFFO01BQUU1SCxFQUFFLEVBQUUsaUJBQWlCO01BQUUySCxPQUFPLEVBQUU7SUFBRztFQUFFLENBQUMsQ0FBQyxFQUFFM0UsSUFBSSxDQUFDMEUsU0FBUyxDQUFDO0lBQUUsR0FBR0YsS0FBSztJQUFFckUsT0FBTyxFQUFFLENBQUM7TUFBRWlELElBQUksRUFBRSxRQUFRO01BQUV4RSxJQUFJLEVBQUUsU0FBUztNQUFFb0YsRUFBRSxFQUFFO0lBQVUsQ0FBQztFQUFFLENBQUMsQ0FBQyxFQUFFbkgsTUFBTSxDQUFDLGlCQUFpQixDQUFDLENBQUNPLElBQUksQ0FBQyxFQUFFO0lBQ3pSLE1BQU1rQixNQUFNLENBQUN2QixJQUFJLEVBQUUwSCxPQUFPLENBQUM7SUFBRSxNQUFNdEksTUFBTSxDQUFDWSxJQUFJLENBQUNlLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDK0csYUFBYSxDQUFDLGVBQWUsQ0FBQztJQUNqRyxJQUFJSixPQUFPLEtBQUs1SCxNQUFNLENBQUMsaUJBQWlCLENBQUMsQ0FBQ08sSUFBSSxFQUFFLE1BQU1qQixNQUFNLENBQUNZLElBQUksQ0FBQ2UsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMrRyxhQUFhLENBQUMsZ0NBQWdDLENBQUM7SUFDckkxSSxNQUFNLENBQUMsTUFBTXdCLFFBQVEsQ0FBQ1osSUFBSSxDQUFDLENBQUMsQ0FBQ3dGLElBQUksQ0FBQ2dDLE1BQU0sQ0FBQztJQUFFLE1BQU0xRixLQUFLLENBQUM5QixJQUFJLEVBQUU4QyxPQUFPLENBQUNmLFFBQVEsQ0FBQztJQUM5RSxNQUFNM0MsTUFBTSxDQUFDWSxJQUFJLENBQUNFLE9BQU8sQ0FBQywrQkFBK0IsQ0FBQyxDQUFDLENBQUM2SCxXQUFXLENBQUMsQ0FBQztFQUMzRTtFQUNBLE1BQU12RSxPQUFPLENBQUN4RCxJQUFJLEVBQUUsYUFBYSxFQUFFaUcsSUFBSSxDQUFDdkMsT0FBTyxDQUFDMUMsSUFBSSxDQUFDO0VBQ3JELE1BQU1oQixJQUFJLENBQUNFLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDZ0csSUFBSSxDQUFDLEdBQUcsQ0FBQztFQUFFLE1BQU1sRyxJQUFJLENBQUNFLE9BQU8sQ0FBQywrQkFBK0IsQ0FBQyxDQUFDZ0IsS0FBSyxDQUFDLENBQUM7RUFDbEgsTUFBTTJCLEtBQUssQ0FBQzdDLElBQUksRUFBRUYsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUM7RUFBRVYsTUFBTSxDQUFDdUcsTUFBTSxDQUFDLENBQUNoRCxPQUFPLENBQUMsRUFBRSxDQUFDO0FBQ3pFLENBQUMsQ0FBQztBQUVGdEQsSUFBSSxDQUFDLG1FQUFtRSxFQUFFLE9BQU87RUFBRVc7QUFBSyxDQUFDLEtBQUs7RUFDNUYsTUFBTTJGLE1BQU0sR0FBR0QsUUFBUSxDQUFDMUYsSUFBSSxDQUFDO0VBQzdCLE1BQU1BLElBQUksQ0FBQ2dJLGFBQWEsQ0FBQyxNQUFNO0lBQzdCLE1BQU1DLFFBQVEsR0FBR0MsSUFBSSxDQUFDQyxTQUFTLENBQUM5SCxJQUFJO0lBQ3BDNkgsSUFBSSxDQUFDQyxTQUFTLENBQUM5SCxJQUFJLEdBQUcsWUFBWTtNQUNoQyxJQUFJLElBQUksQ0FBQ1csSUFBSSxLQUFLLFdBQVcsRUFBRSxPQUFPaUgsUUFBUSxDQUFDeEgsSUFBSSxDQUFDLElBQUksQ0FBQztNQUN6RCxPQUFPLElBQUkySCxPQUFPLENBQVMsQ0FBQ0MsT0FBTyxFQUFFQyxNQUFNLEtBQUs7UUFDOUNDLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDQyxNQUFNLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTTtVQUFFUixRQUFRLENBQUN4SCxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUNpSSxJQUFJLENBQUNMLE9BQU8sRUFBRUMsTUFBTSxDQUFDO1FBQUUsQ0FBQyxDQUFDO01BQzdGLENBQUMsQ0FBQztJQUNKLENBQUM7RUFDSCxDQUFDLENBQUM7RUFDRixNQUFNSyxTQUFTLEdBQUc3SSxNQUFNLENBQUMsV0FBVyxDQUFDO0lBQUVlLE9BQU8sR0FBR2YsTUFBTSxDQUFDLGlCQUFpQixDQUFDO0VBQzFFLE1BQU11RCxLQUFLLENBQUNyRCxJQUFJLENBQUM7RUFBRSxNQUFNdUIsTUFBTSxDQUFDdkIsSUFBSSxFQUFFMkksU0FBUyxDQUFDdEksSUFBSSxDQUFDO0VBQUUsTUFBTXdDLEtBQUssQ0FBQzdDLElBQUksRUFBRTJJLFNBQVMsQ0FBQztFQUNuRixNQUFNcEgsTUFBTSxDQUFDdkIsSUFBSSxFQUFFYSxPQUFPLENBQUNSLElBQUksRUFBRSxXQUFXLENBQUM7RUFDN0MsTUFBTUwsSUFBSSxDQUFDZSxTQUFTLENBQUMsUUFBUSxFQUFFO0lBQUVDLElBQUksRUFBRSxVQUFVO0lBQUVDLEtBQUssRUFBRTtFQUFLLENBQUMsQ0FBQyxDQUFDQyxLQUFLLENBQUMsQ0FBQztFQUN6RSxNQUFNbEIsSUFBSSxDQUFDd0IsVUFBVSxDQUFDLE1BQU0sRUFBRTtJQUFFUCxLQUFLLEVBQUU7RUFBSyxDQUFDLENBQUMsQ0FBQ2lGLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDekQsTUFBTWxHLElBQUksQ0FBQ2UsU0FBUyxDQUFDLFFBQVEsRUFBRTtJQUFFQyxJQUFJLEVBQUUsWUFBWTtJQUFFQyxLQUFLLEVBQUU7RUFBSyxDQUFDLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7RUFDM0UsTUFBTTBILEtBQUssR0FBRyxNQUFNaEksUUFBUSxDQUFDWixJQUFJLENBQUM7RUFDbEMsTUFBTUEsSUFBSSxDQUFDb0YsUUFBUSxDQUFDLE1BQU9tRCxPQUFPLENBQUNNLEdBQUcsQ0FBQ0osTUFBTSxFQUFFLGdCQUFnQixDQUFDLENBQWdCLENBQUMsQ0FBQztFQUNsRixNQUFNekksSUFBSSxDQUFDb0YsUUFBUSxDQUFDLE1BQU0sSUFBSWdELE9BQU8sQ0FBQ0MsT0FBTyxJQUFJUyxVQUFVLENBQUNULE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ3pFakosTUFBTSxDQUFDLE1BQU13QixRQUFRLENBQUNaLElBQUksQ0FBQyxDQUFDLENBQUN3RixJQUFJLENBQUNvRCxLQUFLLENBQUM7RUFDeEMsTUFBTXJILE1BQU0sQ0FBQ3ZCLElBQUksRUFBRWEsT0FBTyxDQUFDUixJQUFJLEVBQUUsV0FBVyxDQUFDO0VBQUUsTUFBTWtCLE1BQU0sQ0FBQ3ZCLElBQUksRUFBRTJJLFNBQVMsQ0FBQ3RJLElBQUksQ0FBQztFQUFFLE1BQU13QyxLQUFLLENBQUM3QyxJQUFJLEVBQUUySSxTQUFTLENBQUM7RUFDL0csTUFBTTNJLElBQUksQ0FBQ29GLFFBQVEsQ0FBQyxNQUFPbUQsT0FBTyxDQUFDTSxHQUFHLENBQUNKLE1BQU0sRUFBRSxnQkFBZ0IsQ0FBQyxDQUFnQixDQUFDLENBQUM7RUFDbEYsTUFBTXpJLElBQUksQ0FBQ29GLFFBQVEsQ0FBQyxNQUFNLElBQUlnRCxPQUFPLENBQUNDLE9BQU8sSUFBSVMsVUFBVSxDQUFDVCxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUN6RSxNQUFNeEYsS0FBSyxDQUFDN0MsSUFBSSxFQUFFMkksU0FBUyxDQUFDO0VBQUV2SixNQUFNLENBQUN1RyxNQUFNLENBQUMsQ0FBQ2hELE9BQU8sQ0FBQyxFQUFFLENBQUM7QUFDMUQsQ0FBQyxDQUFDO0FBRUZ0RCxJQUFJLENBQUMsbUVBQW1FLEVBQUUsT0FBTztFQUFFVztBQUFLLENBQUMsS0FBSztFQUM1RixNQUFNMkYsTUFBTSxHQUFHRCxRQUFRLENBQUMxRixJQUFJLENBQUM7SUFBRThDLE9BQU8sR0FBR2hELE1BQU0sQ0FBQyxZQUFZLENBQUM7SUFBRWlKLFFBQVEsR0FBR2pKLE1BQU0sQ0FBQyxXQUFXLENBQUM7RUFDN0YsTUFBTUUsSUFBSSxDQUFDZ0osS0FBSyxDQUFDQyxPQUFPLENBQUMsQ0FBQztFQUFFLE1BQU1qSixJQUFJLENBQUNnSixLQUFLLENBQUNFLE9BQU8sQ0FBQyxJQUFJQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQ2hFLE1BQU05RixLQUFLLENBQUNyRCxJQUFJLENBQUM7RUFBRSxNQUFNdUIsTUFBTSxDQUFDdkIsSUFBSSxFQUFFOEMsT0FBTyxDQUFDekMsSUFBSSxDQUFDO0VBQUUsTUFBTXdDLEtBQUssQ0FBQzdDLElBQUksRUFBRThDLE9BQU8sQ0FBQztFQUMvRSxNQUFNbkMsS0FBSyxHQUFHUCxNQUFNLENBQUMwQyxPQUFPLENBQUN6QyxJQUFJLENBQUM7SUFBRStJLEtBQUssR0FBR3pJLEtBQUssQ0FBQzBJLE9BQU8sQ0FBQzFJLEtBQUssQ0FBQzJJLGFBQWEsQ0FBQyxDQUFFckosRUFBRTtFQUNsRixNQUFNc0osT0FBTyxHQUFHNUksS0FBSyxDQUFDNEIsR0FBRyxDQUFDaUgsU0FBUyxDQUFDdEYsTUFBTSxDQUFDdUYsQ0FBQyxJQUFJOUksS0FBSyxDQUFDK0ksT0FBTyxDQUFDRCxDQUFDLENBQUN4SixFQUFFLENBQUMsS0FBS21KLEtBQUssSUFBSXpJLEtBQUssQ0FBQ3NCLE1BQU0sQ0FBQ3dILENBQUMsQ0FBQ3hKLEVBQUUsQ0FBQyxHQUFJLENBQUMsQ0FBQyxDQUFDMEosT0FBTyxDQUFDRixDQUFDLElBQUksQ0FBQyxHQUFHQSxDQUFDLENBQUNHLE9BQU8sRUFBRSxHQUFHSCxDQUFDLENBQUNJLFFBQVEsQ0FBQyxDQUFDM0YsTUFBTSxDQUFDakUsRUFBRSxJQUFJVSxLQUFLLENBQUMrSSxPQUFPLENBQUN6SixFQUFFLENBQUMsS0FBS21KLEtBQUssQ0FBQyxDQUFDN0csR0FBRyxDQUFDMEUsRUFBRSxLQUFLO0lBQUVaLElBQUksRUFBRSxRQUFpQjtJQUFFeEUsSUFBSSxFQUFFNEgsQ0FBQyxDQUFDeEosRUFBRTtJQUFFZ0g7RUFBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ3hQLE1BQU02QyxNQUFNLEdBQUdQLE9BQU8sQ0FBQ1EsSUFBSSxDQUFDNUQsTUFBTSxJQUFJO0lBQUUsTUFBTTZELE1BQU0sR0FBR3JLLEtBQUssQ0FBQ2dCLEtBQUssRUFBRXdGLE1BQU0sQ0FBQztJQUFFLE9BQU82RCxNQUFNLENBQUNDLEVBQUUsSUFBSUQsTUFBTSxDQUFDckosS0FBSyxDQUFDdUosS0FBSyxLQUFLLFFBQVEsSUFBSUYsTUFBTSxDQUFDckosS0FBSyxDQUFDc0IsTUFBTSxDQUFDa0UsTUFBTSxDQUFDdEUsSUFBSSxDQUFDLEdBQUksQ0FBQztFQUFFLENBQUMsQ0FBQztFQUM3SyxJQUFJLENBQUNpSSxNQUFNLEVBQUUsTUFBTXhELEtBQUssQ0FBQyw0RUFBNEUsQ0FBQztFQUN0RyxNQUFNdkcsT0FBTyxDQUFDQyxJQUFJLEVBQUU4SixNQUFNLENBQUNqSSxJQUFJLENBQUMsQ0FBQ1gsS0FBSyxDQUFDLENBQUM7RUFBRSxNQUFNbkIsT0FBTyxDQUFDQyxJQUFJLEVBQUU4SixNQUFNLENBQUM3QyxFQUFFLENBQUMsQ0FBQy9GLEtBQUssQ0FBQztJQUFDaUosU0FBUyxFQUFDLENBQUMsT0FBTztFQUFDLENBQUMsQ0FBQztFQUNyRyxNQUFNbkssSUFBSSxDQUFDRSxPQUFPLENBQUMsd0JBQXdCLENBQUMsQ0FBQ2dHLElBQUksQ0FBQyxHQUFHLENBQUM7RUFBRSxNQUFNbEcsSUFBSSxDQUFDRSxPQUFPLENBQUMsd0JBQXdCLENBQUMsQ0FBQ2tLLEtBQUssQ0FBQyxLQUFLLENBQUM7RUFDakgsTUFBTXBLLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGtCQUFrQixDQUFDLENBQUNnQixLQUFLLENBQUMsQ0FBQztFQUM5QyxNQUFNOUIsTUFBTSxDQUFDWSxJQUFJLENBQUNlLFNBQVMsQ0FBQyxRQUFRLEVBQUU7SUFBRUMsSUFBSSxFQUFFLGlCQUFpQjtJQUFFQyxLQUFLLEVBQUU7RUFBSyxDQUFDLENBQUMsQ0FBQyxDQUFDb0osZUFBZSxDQUFDLGNBQWMsRUFBRSxNQUFNLENBQUM7RUFDeEgsTUFBTTlJLE1BQU0sQ0FBQ3ZCLElBQUksRUFBRStJLFFBQVEsQ0FBQzFJLElBQUksQ0FBQztFQUFFLE1BQU13QyxLQUFLLENBQUM3QyxJQUFJLEVBQUUrSSxRQUFRLENBQUM7RUFDOUQsTUFBTS9JLElBQUksQ0FBQ2dKLEtBQUssQ0FBQ3NCLE1BQU0sQ0FBQyxLQUFLLENBQUM7RUFBRSxNQUFNekgsS0FBSyxDQUFDN0MsSUFBSSxFQUFFK0ksUUFBUSxDQUFDO0VBQzNELE1BQU0zQyxJQUFJLEdBQUcyQyxRQUFRLENBQUMzQyxJQUFJLENBQUVELE1BQU07RUFDbEMsSUFBSUMsSUFBSSxDQUFDQyxJQUFJLEtBQUssV0FBVyxFQUFFLE1BQU1DLEtBQUssQ0FBQyxxQ0FBcUMsQ0FBQztFQUNqRixNQUFNMEQsTUFBTSxHQUFHckssS0FBSyxDQUFDUyxNQUFNLENBQUMySSxRQUFRLENBQUMxSSxJQUFJLENBQUMsRUFBRStGLElBQUksQ0FBQztFQUFFaEgsTUFBTSxDQUFDNEssTUFBTSxDQUFDQyxFQUFFLENBQUMsQ0FBQ3pFLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDL0UsTUFBTXpGLE9BQU8sQ0FBQ0MsSUFBSSxFQUFFb0csSUFBSSxDQUFDRyxRQUFRLENBQUMsQ0FBQ3JGLEtBQUssQ0FBQyxDQUFDO0VBQzFDOUIsTUFBTSxDQUFDUyxZQUFZLENBQUNPLE1BQU0sQ0FBQyxNQUFNUSxRQUFRLENBQUNaLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDMkMsT0FBTyxDQUFDb0csUUFBUSxDQUFDM0MsSUFBSSxDQUFFckUsUUFBUSxDQUFDO0VBQ25GM0MsTUFBTSxDQUFDdUcsTUFBTSxDQUFDLENBQUNoRCxPQUFPLENBQUMsRUFBRSxDQUFDO0FBQzVCLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==