# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: playback-edge-cases.spec.ts >> modal Escape preserves continuous combat; local/global very-slow controls stay synchronized
- Location: tests/e2e/playback-edge-cases.spec.ts:7:1

# Error details

```
Error: expect(locator).toHaveValue(expected) failed

Locator:  locator('#battle-speed')
Expected: "very-slow"
Received: ""
Timeout:  5000ms

Call log:
  - Expect "toHaveValue" locator('#battle-speed') with timeout 5000ms
  - waiting for locator('#battle-speed')
    14 × locator resolved to <select id="battle-speed">…</select>
       - unexpected value ""

```

```yaml
- combobox "Battle speed":
  - option "Slow"
  - option "Normal"
  - option "Fast"
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { fixture } from "./battle-fixture";
  3  | import { pinned } from "../core/versioned-match-fixture";
  4  | import { mkdirSync } from "node:fs";
  5  | import { join } from "node:path";
  6  | 
  7  | test("modal Escape preserves continuous combat; local/global very-slow controls stay synchronized", async ({ page }, info) => {
  8  |   const f = fixture("manual"); await page.clock.install({ time: new Date("2026-10-17T12:00:00Z") }); await page.clock.pauseAt(new Date("2026-10-17T12:00:00Z"));
  9  |   await page.goto("/?view=reference-game&control=manual"); await page.getByLabel("Seed", { exact: true }).fill(String(f.seed));
  10 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  11 |   for (let i = 0; i < f.placements; i++) await page.locator(`[data-country="${f.from}"]`).click();
  12 |   await page.locator("#start-combat-button").click(); await page.locator(`[data-country="${f.from}"]`).click(); await page.locator(`[data-country="${f.to}"]`).click({ modifiers: ["Shift"] });
> 13 |   await page.locator("#game-speed").selectOption("very-slow"); await expect(page.locator("#battle-speed")).toHaveValue("very-slow");
     |                                                                                                            ^ Error: expect(locator).toHaveValue(expected) failed
  14 |   await page.locator("#battle-speed").selectOption("normal"); await expect(page.locator("#game-speed")).toHaveValue("normal");
  15 |   await page.locator("#battle-stop-threshold").fill("1"); await page.locator("#battle-stop-threshold").press("Tab"); await page.locator("#fight-on-button").click();
  16 |   const battle = page.getByRole("region", { name: "Battle controls", exact: true }), count = Number(await battle.getAttribute("data-history-count"));
  17 |   await page.locator("#game-log-button").click(); const dialog = page.getByRole("dialog", { name: "Game event log", exact: true }); await expect(dialog).toBeVisible();
  18 |   await page.keyboard.press("Escape"); await expect(dialog).not.toBeVisible(); await expect(battle).toHaveAttribute("data-running", "true");
  19 |   await page.clock.runFor(400); await expect(battle).toHaveAttribute("data-history-count", String(count + 1));
  20 |   await page.locator("#game-pause-button").click(); await page.locator("#battle-speed").selectOption("very-slow"); await expect(page.locator("#game-speed")).toHaveValue("very-slow");
  21 |   await page.locator("#game-log-button").click(); await expect(dialog.locator("details")).not.toHaveAttribute("open", "");
  22 |   expect(await dialog.evaluate(node => getComputedStyle(node).backgroundColor)).not.toBe("rgba(0, 0, 0, 0)");
  23 |   expect(await dialog.evaluate(node => Number(getComputedStyle(node).opacity))).toBe(1);
  24 |   const close = dialog.getByRole("button", { name: "Close game event log", exact: true }); await expect(close).toBeInViewport();
  25 |   const root = process.env["PLAYBACK_EVIDENCE_DIR"]!; mkdirSync(root, { recursive: true }); await page.screenshot({ path: join(root, `production-modal-${info.project.name}.png`) });
  26 | });
  27 | 
  28 | test("default four-seat controls fit and a paused computer is labelled paused", async ({ page }, info) => {
  29 |   await page.clock.install({ time: new Date("2026-10-17T12:00:00Z") }); await page.clock.pauseAt(new Date("2026-10-17T12:00:00Z")); await page.goto("/?view=reference-game");
  30 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  31 |   for (const locator of [page.locator("#game-log-button"), page.locator("#game-pause-button"), page.locator("#game-speed"), ...await page.locator('[data-testid="player-army-total"]').all()]) await expect(locator).toBeInViewport();
  32 |   const f = pinned("watch"); await page.getByLabel("Load game", { exact: true }).setInputFiles({ name: "watch.json", mimeType: "application/json", buffer: Buffer.from(f.text) });
  33 |   await page.locator("#game-pause-button").click(); await expect(page.locator("#reference-computer-status")).toHaveText(/Paused/); await expect(page.locator("#reference-computer-status")).not.toHaveText(/playing/);
  34 |   const root = process.env["PLAYBACK_EVIDENCE_DIR"]!; mkdirSync(root, { recursive: true }); await page.screenshot({ path: join(root, `production-paused-computer-${info.project.name}.png`) });
  35 | });
  36 | 
  37 | test("failed load feedback stays readable without covering capture or playback controls", async ({ page }, info) => {
  38 |   await page.clock.install({ time: new Date("2026-10-17T12:00:00Z") }); await page.clock.pauseAt(new Date("2026-10-17T12:00:00Z"));
  39 |   await page.goto("/?view=reference-game&control=manual");
  40 |   const upload = (text: string) => page.getByLabel("Load game", { exact: true }).setInputFiles({ name: "bad-load.json", mimeType: "application/json", buffer: Buffer.from(text) });
  41 |   await upload(pinned("pending-capture").text); await expect(page.locator("#confirm-capture-button")).toBeVisible();
  42 |   for (const invalid of ["{", pinned("legacy-progress").text]) {
  43 |     await upload(invalid); const error = page.getByRole("alert"); await expect(error).toContainText("Load failed:");
  44 |     expect(await error.evaluate(node => { const r = node.getBoundingClientRect(); return r.width > 200 && r.left >= 0 && r.top >= 0 && r.right <= innerWidth && r.bottom <= innerHeight; })).toBe(true);
  45 |     for (const id of ["game-log-button", "game-pause-button", "game-speed", "reference-save-game", "confirm-capture-button"]) {
  46 |       expect(await page.locator(`#${id}`).evaluate(node => { const r = node.getBoundingClientRect(); return r.left >= 0 && r.top >= 0 && r.right <= innerWidth && r.bottom <= innerHeight; })).toBe(true);
  47 |     }
  48 |   }
  49 |   const root = process.env["PLAYBACK_EVIDENCE_DIR"]!; mkdirSync(root, { recursive: true }); await page.screenshot({ path: join(root, `production-invalid-load-${info.project.name}.png`) });
  50 | });
  51 | 
```