# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: playback-controls.spec.ts >> labelled army totals follow ordinary actions and include eliminated players
- Location: tests/e2e/playback-controls.spec.ts:88:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator: locator('[data-testid="player-army-total"][data-player="seat1"]')
Expected pattern: /Total armies\s*:?\s*22$/i
Received string:  "Total armies: 0"
Timeout: 5000ms

Call log:
  - Expect "toHaveText" locator('[data-testid="player-army-total"][data-player="seat1"]') with timeout 5000ms
  - waiting for locator('[data-testid="player-army-total"][data-player="seat1"]')
    14 × locator resolved to <strong data-player="seat1" data-testid="player-army-total">Total armies: 0</strong>
       - unexpected value "Total armies: 0"

```

```yaml
- strong: "Total armies: 0"
```

# Test source

```ts
  1   | import { expect, test } from "@playwright/test";
  2   | import type { Page } from "@playwright/test";
  3   | import { mkdirSync } from "node:fs";
  4   | import { join } from "node:path";
  5   | import { activePlayer, apply, computerAction } from "../../src/core";
  6   | import type { GameState } from "../../src/core";
  7   | import { deserializeVersionedMatch, serializeVersionedMatch, REFERENCE_MATCH_IDENTITY } from "../../src/core/match-save";
  8   | import { pinned } from "../core/versioned-match-fixture";
  9   | import { fixture } from "./battle-fixture";
  10  | 
  11  | const pause = (p: Page) => p.locator("#game-pause-button");
  12  | const speed = (p: Page) => p.locator("#game-speed");
  13  | async function save(p: Page) {
  14  |   await p.getByRole("button", { name: "Save game", exact: true }).click();
  15  |   return p.evaluate(() => (Reflect.get(window, "playbackSaveBlob") as Blob).text());
  16  | }
  17  | async function load(p: Page, text: string) {
  18  |   await p.getByLabel("Load game", { exact: true }).setInputFiles({ name: "playback.json", mimeType: "application/json", buffer: Buffer.from(text) });
  19  |   await expect(p.locator("[data-country]")).toHaveCount(46);
  20  | }
  21  | async function begin(p: Page, manual = false) {
  22  |   await p.clock.install({ time: new Date("2026-10-17T12:00:00Z") });
  23  |   await p.clock.pauseAt(new Date("2026-10-17T12:00:00Z"));
  24  |   await p.goto(`/?view=reference-game${manual ? "&control=manual" : ""}`);
  25  |   // Keep references to callbacks even after clearTimeout: cancellation alone is insufficient.
  26  |   await p.evaluate(() => {
  27  |     // Read the actual exported Blob, avoiding Chromium's repeated-download throttle.
  28  |     const create = URL.createObjectURL.bind(URL);
  29  |     URL.createObjectURL = blob => { Reflect.set(window, "playbackSaveBlob", blob); return create(blob); };
  30  |     const original = window.setTimeout.bind(window), callbacks: (() => void)[] = [];
  31  |     Reflect.set(window, "playbackCallbacks", callbacks);
  32  |     window.setTimeout = ((fn: TimerHandler, ms?: number, ...args: unknown[]) => {
  33  |       if (typeof fn === "function" && ms !== undefined && ms >= 100 && ms <= 5000) callbacks.push(fn as () => void);
  34  |       return original(fn, ms, ...args);
  35  |     }) as typeof window.setTimeout;
  36  |   });
  37  | }
  38  | async function stale(p: Page) {
  39  |   expect(await p.evaluate(() => (Reflect.get(window, "playbackCallbacks") as unknown[]).length)).toBeGreaterThan(0);
  40  |   await p.evaluate(() => { for (const callback of [...Reflect.get(window, "playbackCallbacks") as (() => void)[]]) callback(); });
  41  | }
  42  | async function totals(p: Page, state?: GameState) {
  43  |   const s = state ?? deserializeVersionedMatch(await save(p)).state;
  44  |   await expect(p.locator('[data-testid="player-army-total"]')).toHaveCount(s.players.length);
  45  |   for (const player of s.players) {
  46  |     const total = p.locator(`[data-testid="player-army-total"][data-player="${player.id}"]`);
  47  |     const owned = s.map.provinces.filter(country => s.ownerOf[country.id] === player.id);
  48  |     const expected = owned.reduce((sum, country) => sum + s.armies[country.id]!, 0);
  49  |     const painted = await p.locator(`[data-country][data-owner="${player.id}"]`).evaluateAll(nodes => nodes.reduce((sum, node) => sum + Number((node as HTMLElement).dataset["armies"]), 0));
  50  |     expect(painted).toBe(expected);
> 51  |     await expect(total).toHaveText(new RegExp(`Total armies\\s*:?\\s*${expected}$`, "i"));
      |                         ^ Error: expect(locator).toHaveText(expected) failed
  52  |     await expect(total).toBeVisible();
  53  |     expect(await total.evaluate(node => parseFloat(getComputedStyle(node).fontSize))).toBeGreaterThanOrEqual(16);
  54  |   }
  55  |   return s;
  56  | }
  57  | async function visibleControls(p: Page) {
  58  |   for (const control of [pause(p), speed(p), ...await p.locator('[data-testid="player-army-total"]').all()]) {
  59  |     await expect(control).toBeVisible();
  60  |     expect(await control.evaluate(node => {
  61  |       const r = node.getBoundingClientRect();
  62  |       return r.left >= 0 && r.top >= 0 && r.right <= innerWidth + 1 && r.bottom <= innerHeight + 1;
  63  |     })).toBe(true);
  64  |   }
  65  |   await expect(pause(p)).toBeEnabled(); await expect(speed(p)).toBeEnabled();
  66  |   await speed(p).focus(); await expect(speed(p)).toBeFocused();
  67  |   await speed(p).press("Home"); await speed(p).press("End");
  68  | }
  69  | async function screenshot(p: Page, name: string, project: string) {
  70  |   const root = process.env["PLAYBACK_EVIDENCE_DIR"] ?? "screenshots";
  71  |   mkdirSync(root, { recursive: true });
  72  |   await p.screenshot({ path: join(root, `playback-${name}-${project}.png`) });
  73  | }
  74  | function pendingComputer() {
  75  |   const f = pinned("human-loss");
  76  |   let s = deserializeVersionedMatch(serializeVersionedMatch(f.options, [], REFERENCE_MATCH_IDENTITY)).state;
  77  |   for (const action of f.actions) {
  78  |     const next = apply(s, action); if (!next.ok) throw Error(next.error); s = next.state;
  79  |     if (s.phase === "capture" && activePlayer(s)?.kind === "computer") return serializeVersionedMatch(f.options, s.history, REFERENCE_MATCH_IDENTITY);
  80  |   }
  81  |   throw Error("Pinned replay has no computer capture");
  82  | }
  83  | function nextComputer(s: GameState) {
  84  |   const action = computerAction(s); if (!action) throw Error("Expected automatic action");
  85  |   const next = apply(s, action); if (!next.ok) throw Error(next.error); return next.state;
  86  | }
  87  | 
  88  | test("labelled army totals follow ordinary actions and include eliminated players", async ({ page }, info) => {
  89  |   await begin(page); await page.getByRole("button", { name: "Start game", exact: true }).click();
  90  |   expect((await totals(page)).players).toHaveLength(4); await visibleControls(page); await screenshot(page, "default-four-seats", info.project.name);
  91  |   await load(page, pinned("placement").text);
  92  |   let s = await totals(page); const player = activePlayer(s)!;
  93  |   const own = s.map.provinces.find(country => s.ownerOf[country.id] === player.id)!.id;
  94  |   const before = s.armies[own]!;
  95  |   for (let i = 0; i < 3; i++) { await page.locator(`[data-country="${own}"]`).press("Enter"); s = await totals(page); }
  96  |   expect(s.armies[own]).toBe(before + 3);
  97  |   await visibleControls(page); await screenshot(page, "totals", info.project.name);
  98  |   await load(page, pinned("human-loss").text); s = await totals(page);
  99  |   expect(s.players.some(player => !s.map.provinces.some(country => s.ownerOf[country.id] === player.id))).toBe(true);
  100 |   await screenshot(page, "eliminated", info.project.name);
  101 | });
  102 | 
  103 | test("very slow spaces automatic actions by two seconds and changes no replay outcome", async ({ page }, info) => {
  104 |   await begin(page); await load(page, pendingComputer()); await visibleControls(page);
  105 |   await speed(page).selectOption("very-slow");
  106 |   let text = await save(page), s = deserializeVersionedMatch(text).state;
  107 |   for (let i = 0; i < 4; i++) {
  108 |     await page.clock.runFor(1999); expect(await save(page)).toBe(text);
  109 |     await page.clock.runFor(1); const next = nextComputer(s);
  110 |     text = await save(page); s = await totals(page);
  111 |     expect(text).toBe(serializeVersionedMatch(deserializeVersionedMatch(text).options, next.history, REFERENCE_MATCH_IDENTITY));
  112 |   }
  113 |   await screenshot(page, "very-slow", info.project.name);
  114 | });
  115 | 
  116 | test("Pause freezes computer play, rejects stale callbacks and replacement cancels the old match", async ({ page }, info) => {
  117 |   await begin(page); const pending = pendingComputer(); await load(page, pending);
  118 |   await speed(page).selectOption("normal"); await expect(pause(page)).toBeVisible();
  119 |   await pause(page).focus(); await pause(page).press("Enter"); await expect(pause(page)).toHaveText(/Resume/i);
  120 |   const frozen = await save(page); await stale(page); await page.clock.runFor(10000); expect(await save(page)).toBe(frozen); await totals(page);
  121 |   await screenshot(page, "paused-computer", info.project.name);
  122 |   await pause(page).press("Space"); await page.clock.runFor(350);
  123 |   const resumed = deserializeVersionedMatch(await save(page));
  124 |   expect(resumed.state.history).toEqual(nextComputer(deserializeVersionedMatch(frozen).state).history); await totals(page);
  125 |   await pause(page).click(); await load(page, pinned("placement").text);
  126 |   const replacement = await save(page); await stale(page); await page.clock.runFor(10000); expect(await save(page)).toBe(replacement); await totals(page);
  127 |   await load(page, pending); await page.getByRole("button", { name: "New game", exact: true }).click();
  128 |   await stale(page); await page.clock.runFor(10000);
  129 |   await expect(page.getByRole("heading", { name: "New reference game", exact: true })).toBeVisible();
  130 | });
  131 | 
  132 | test("global pause freezes continuous human battle and gates manual reinforcement and capture", async ({ page }, info) => {
  133 |   await begin(page, true); const f = fixture("manual");
  134 |   await page.getByLabel("Seed", { exact: true }).fill(String(f.seed));
  135 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  136 |   for (let i = 0; i < f.placements; i++) await page.locator(`[data-country="${f.from}"]`).click();
  137 |   await page.locator("#start-combat-button").click();
  138 |   await page.locator(`[data-country="${f.from}"]`).click();
  139 |   await page.locator(`[data-country="${f.to}"]`).click({ modifiers: ["Shift"] });
  140 |   await page.locator("#battle-stop-threshold").fill("1"); await page.locator("#battle-stop-threshold").press("Tab");
  141 |   await page.locator("#fight-on-button").click(); await expect(page.getByRole("region", { name: "Battle controls", exact: true })).toHaveAttribute("data-running", "true");
  142 |   await totals(page); await visibleControls(page); await speed(page).selectOption("normal"); await pause(page).click();
  143 |   const frozen = await save(page);
  144 |   for (const id of ["fight-on-button", "single-exchange-button", "end-turn-button", "start-friendly-move-button"]) await page.locator(`#${id}`).dispatchEvent("click");
  145 |   await page.locator(`[data-country="${f.to}"]`).press("Enter"); await stale(page); await page.clock.runFor(10000);
  146 |   expect(await save(page)).toBe(frozen); await totals(page); await screenshot(page, "paused-battle", info.project.name);
  147 |   await pause(page).click(); await page.clock.runFor(400);
  148 |   const next = apply(deserializeVersionedMatch(frozen).state, { kind: "attack", from: f.from, to: f.to });
  149 |   if (!next.ok) throw Error(next.error);
  150 |   expect(deserializeVersionedMatch(await save(page)).state.history).toEqual(next.state.history); await totals(page);
  151 |   for (const name of ["placement", "pending-capture"]) {
```