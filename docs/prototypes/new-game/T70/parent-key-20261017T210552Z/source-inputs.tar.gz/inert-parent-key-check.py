from pathlib import Path
import datetime,hashlib,json,os,subprocess,tarfile,time
root=Path('/home/diego/projects/malpaco/.cache/t70-work');out=root/'docs/prototypes/new-game/T70'/('parent-key-'+datetime.datetime.now(datetime.UTC).strftime('%Y%m%dT%H%M%SZ'));out.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=sorted([p for d in ['src','tests','data'] for p in (root/d).rglob('*') if p.is_file()]+[root/n for n in ['package.json','package-lock.json','playwright.config.ts']])
inputs={str(p.relative_to(root)):sha(p.read_bytes()) for p in paths}
with tarfile.open(out/'source-inputs.tar.gz','w:gz') as tar:
 for p in paths:tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
 tar.add(__file__,arcname='inert-parent-key-check.py',recursive=False)
env=dict(os.environ,TMPDIR=str(root/'.cache/t70-tmp'),PLAYWRIGHT_HTML_OUTPUT_DIR=str(out/'playwright-report'));env.pop('PLAYBACK_EVIDENCE_DIR',None)
cmd=['npx','playwright','test','tests/e2e/playback-controls.spec.ts','tests/e2e/game-event-log.spec.ts','--workers=2','--output',str(out/'test-results')]
started=time.monotonic()
with (out/'command.log').open('w') as log:code=subprocess.call(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
stable=all(sha((root/n).read_bytes())==v for n,v in inputs.items())
with tarfile.open(out/'outputs.tar.gz','w:gz') as tar:
 for p in sorted(out.rglob('*')):
  if p.is_file() and p.name not in ['source-inputs.tar.gz','outputs.tar.gz']:tar.add(p,arcname=str(p.relative_to(out)),recursive=False)
 for p in sorted((root/'screenshots').glob('*.png')):
  if p.name.startswith(('playback-','game-event-log-')):tar.add(p,arcname='screenshots/'+p.name,recursive=False)
report={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'command':cmd,'exitCode':code,'seconds':round(time.monotonic()-started,3),'inputs':inputs,'inputsUnchanged':stable,'sourceArchiveSha256':sha((out/'source-inputs.tar.gz').read_bytes()),'outputsArchiveSha256':sha((out/'outputs.tar.gz').read_bytes())}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(str(out),flush=True)
raise SystemExit(0 if code==0 and stable else 1)
