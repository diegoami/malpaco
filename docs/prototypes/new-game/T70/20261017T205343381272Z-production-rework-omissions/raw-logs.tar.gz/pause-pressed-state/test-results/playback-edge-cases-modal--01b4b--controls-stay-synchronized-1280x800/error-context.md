# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: playback-edge-cases.spec.ts >> modal Escape preserves continuous combat; local/global very-slow controls stay synchronized
- Location: tests/e2e/playback-edge-cases.spec.ts:7:1

# Error details

```
Error: expect(locator).not.toHaveAttribute() failed

Locator:  locator('#game-pause-button')
Expected: not have attribute
Received: have attribute
Timeout:  5000ms

Call log:
  - Expect "not toHaveAttribute" locator('#game-pause-button') with timeout 5000ms
  - waiting for locator('#game-pause-button')
    14 × locator resolved to <button type="button" aria-pressed="false" id="game-pause-button" aria-label="Pause game">Pause</button>
       - unexpected value "attribute present"

```

```yaml
- button "Pause game": Pause
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { fixture } from "./battle-fixture";
  3  | import { pinned } from "../core/versioned-match-fixture";
  4  | import { mkdirSync } from "node:fs";
  5  | import { join } from "node:path";
  6  | 
  7  | test("modal Escape preserves continuous combat; local/global very-slow controls stay synchronized", async ({ page }, info) => {
  8  |   const f = fixture("manual"); await page.clock.install({ time: new Date("2026-10-17T12:00:00Z") }); await page.clock.pauseAt(new Date("2026-10-17T12:00:00Z"));
  9  |   await page.goto("/?view=reference-game&control=manual"); await page.getByLabel("Seed", { exact: true }).fill(String(f.seed));
  10 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  11 |   for (let i = 0; i < f.placements; i++) await page.locator(`[data-country="${f.from}"]`).click();
  12 |   await page.locator("#start-combat-button").click(); await page.locator(`[data-country="${f.from}"]`).click(); await page.locator(`[data-country="${f.to}"]`).click({ modifiers: ["Shift"] });
  13 |   await page.locator("#game-speed").selectOption("very-slow"); await expect(page.locator("#battle-speed")).toHaveValue("very-slow");
> 14 |   await expect(page.locator("#game-pause-button")).not.toHaveAttribute("aria-pressed");
     |                                                        ^ Error: expect(locator).not.toHaveAttribute() failed
  15 |   await page.locator("#battle-speed").selectOption("normal"); await expect(page.locator("#game-speed")).toHaveValue("normal");
  16 |   await page.locator("#battle-stop-threshold").fill("1"); await page.locator("#battle-stop-threshold").press("Tab"); await page.locator("#fight-on-button").click();
  17 |   const battle = page.getByRole("region", { name: "Battle controls", exact: true }), count = Number(await battle.getAttribute("data-history-count"));
  18 |   await page.locator("#game-log-button").click(); const dialog = page.getByRole("dialog", { name: "Game event log", exact: true }); await expect(dialog).toBeVisible();
  19 |   await page.keyboard.press("Escape"); await expect(dialog).not.toBeVisible(); await expect(battle).toHaveAttribute("data-running", "true");
  20 |   await page.clock.runFor(400); await expect(battle).toHaveAttribute("data-history-count", String(count + 1));
  21 |   await page.locator("#game-pause-button").click(); await page.locator("#battle-speed").selectOption("very-slow"); await expect(page.locator("#game-speed")).toHaveValue("very-slow");
  22 |   await page.locator("#game-log-button").click(); await expect(dialog.locator("details")).not.toHaveAttribute("open", "");
  23 |   expect(await dialog.evaluate(node => getComputedStyle(node).backgroundColor)).not.toBe("rgba(0, 0, 0, 0)");
  24 |   expect(await dialog.evaluate(node => Number(getComputedStyle(node).opacity))).toBe(1);
  25 |   const close = dialog.getByRole("button", { name: "Close game event log", exact: true }); await expect(close).toBeInViewport();
  26 |   const root = process.env["PLAYBACK_EVIDENCE_DIR"] ?? "screenshots"; mkdirSync(root, { recursive: true }); await page.screenshot({ path: join(root, `production-modal-${info.project.name}.png`) });
  27 | });
  28 | 
  29 | test("default four-seat controls fit and a paused computer is labelled paused", async ({ page }, info) => {
  30 |   await page.clock.install({ time: new Date("2026-10-17T12:00:00Z") }); await page.clock.pauseAt(new Date("2026-10-17T12:00:00Z")); await page.goto("/?view=reference-game");
  31 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  32 |   for (const locator of [page.locator("#game-log-button"), page.locator("#game-pause-button"), page.locator("#game-speed"), ...await page.locator('[data-testid="player-army-total"]').all()]) await expect(locator).toBeInViewport();
  33 |   const f = pinned("watch"); await page.getByLabel("Load game", { exact: true }).setInputFiles({ name: "watch.json", mimeType: "application/json", buffer: Buffer.from(f.text) });
  34 |   await page.locator("#game-pause-button").click(); await expect(page.locator("#reference-computer-status")).toHaveText(/Paused/); await expect(page.locator("#reference-computer-status")).not.toHaveText(/playing/);
  35 |   const root = process.env["PLAYBACK_EVIDENCE_DIR"] ?? "screenshots"; mkdirSync(root, { recursive: true }); await page.screenshot({ path: join(root, `production-paused-computer-${info.project.name}.png`) });
  36 | });
  37 | 
  38 | test("failed load feedback stays readable without covering capture or playback controls", async ({ page }, info) => {
  39 |   await page.clock.install({ time: new Date("2026-10-17T12:00:00Z") }); await page.clock.pauseAt(new Date("2026-10-17T12:00:00Z"));
  40 |   await page.goto("/?view=reference-game&control=manual");
  41 |   const upload = (text: string) => page.getByLabel("Load game", { exact: true }).setInputFiles({ name: "bad-load.json", mimeType: "application/json", buffer: Buffer.from(text) });
  42 |   await upload(pinned("pending-capture").text); await expect(page.locator("#confirm-capture-button")).toBeVisible();
  43 |   for (const invalid of ["{", pinned("legacy-progress").text]) {
  44 |     await upload(invalid); const error = page.getByRole("alert"); await expect(error).toContainText("Load failed:");
  45 |     expect(await error.evaluate(node => { const r = node.getBoundingClientRect(); return r.width > 200 && r.left >= 0 && r.top >= 0 && r.right <= innerWidth && r.bottom <= innerHeight; })).toBe(true);
  46 |     for (const id of ["game-log-button", "game-pause-button", "game-speed", "reference-save-game", "confirm-capture-button"]) {
  47 |       expect(await page.locator(`#${id}`).evaluate(node => { const r = node.getBoundingClientRect(); return r.left >= 0 && r.top >= 0 && r.right <= innerWidth && r.bottom <= innerHeight; })).toBe(true);
  48 |     }
  49 |   }
  50 |   const root = process.env["PLAYBACK_EVIDENCE_DIR"] ?? "screenshots"; mkdirSync(root, { recursive: true }); await page.screenshot({ path: join(root, `production-invalid-load-${info.project.name}.png`) });
  51 | });
  52 | 
```