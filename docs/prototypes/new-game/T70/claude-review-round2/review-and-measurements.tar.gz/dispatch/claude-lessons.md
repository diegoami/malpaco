T70 real-task integration result: Claude CLI is viable as an independent reviewer through the same `review.mjs` entry point. This trial returned an actionable blocking finding, not merely a summary: a CI-only unset-environment failure masked by the producer evidence wrapper.

Verified invocation: Claude Code 2.1.292, `--model claude-sonnet-5-5 --effort high`, init and every assistant model checked; exit 0 in 281.681 seconds with no permission denials. Full review: https://github.com/diegoami/malpaco/pull/159#issuecomment-6240767397

Reusable lessons:

1. Exercise the exact normal CI environment at least once. Evidence-directory variables must be optional; setting them in every local validation can conceal a CI failure.
2. Keep machine-readable acknowledgments on standalone lines: `EVIDENCE: docs/prototypes/new-game/T70/`. Put audit limitations on a separate prose line. A parser flag is not a model failure; read the full final and actual findings before deciding.
3. The shared review profile still contains OpenCode scratch guidance. Explicitly keep Claude scratch in its own review worktree; this run created `/tmp/opencode/rev159` despite a later brief override. We archived and hash-verified the exact owned directory before removing it, preserving shared scratch and all worktrees.
4. Use installed project tools or native Node hooks; avoid ad hoc `npx` downloads of missing packages during a review. The reviewer disclosed a `vite-node@6.0.0` download; no project dependencies changed.
5. Verify gzip tar archives in streaming member order. Repeated random lookups in a compressed archive make a correct verifier needlessly slow.

No backend/default change was needed for this UI rework. Initial review correctly remains rework; the follow-up will use Sonnet Medium for the small fix under the owner's standing difficulty policy. Model trial: https://github.com/diegoami/malpaco/issues/3 ; cross-project index: https://github.com/diegoami/isle-wars-archaeology/issues/9
