T70 review (Claude Sonnet Medium)
You review PR #159 at 88013091a73848f9f99be9da565a550b8f026968. You did not write it. The task file follows.
0. Prove HEAD and the complete local PR diff; name findings with actual file/line.
1. Run every Done-when line yourself and account for it. Existing evidence is not proof.
2. New constants are presentation-only and explicitly designed; core rules/RNG/save schemas must not change.
3. Review every changed executable file before spending time on mutations. Keep commands/output bounded; no whole historical evidence sweep.
4. Inspect actual UI at both desktop sizes and screenshots; owner judges final appearance.
5. Prior round already exercised these omissions on unchanged implementation; do not repeat unchanged mutation matrices. Only if the rework changes behavior, exercise likely omissions: missing gamePaused gate in computer callback, missing cancellation of human continuous battle, stale queued callback after pause/load, incorrect total ownership, omitted reinforcement/combat/movement log entries. Use targeted tests once per distinct class, restore from saved bytes in finally. Never reset/restore/stash/prune or delete inherited evidence/worktrees.
6. Final report must state each DW command/result, FILE: exact/path for every changed file inspected (including executable prototype helpers), EVIDENCE: task data prefix only for known generated data, and SCOPE: complete only after full coverage. An incomplete scope is not approval. Full final report is posted by the harness; no publishing, subagents or global settings changes.

# T70 Visible army totals, playback controls and event log

- **Kind**: feature
- **Issue**: #158 · **Branch**: `task/T70-army-totals-and-playback` · **Merge after**: T32, T33.
- **Implementer**: native Sol Medium under the owner's standing model authorization; timer cancellation and replay preservation need care.
- **Reviewer**: independent Claude Sonnet Medium via the T69 CLI backend.
- **Evidence**: owner playtest and explicit request, 2026-10-17. Seed 1994 can leave computer countries on one army. Parent inspection found no unexplained army changes across 309 handoffs; this does not resolve the owner's exact position. Existing `armyTotal` and the header score already calculate totals, but do not make them prominent enough. Existing battle speed/Stop controls do not pause computer play.
- **Owns**: `src/ui/**`, presentation-only parts of `src/styles.css`, `tests/ui/**`, `tests/e2e/playback-controls.spec.ts`, `tests/e2e/game-event-log.spec.ts`, `tests/e2e/playback-edge-cases.spec.ts`, `docs/prototypes/new-game/T70/**`; append `RUN-NOTES.md`.
- **Scope**: Give each player a conspicuous, explicitly labelled total army count updated after every action, including eliminated players. Keep speed and Pause/Resume visible and keyboard usable throughout computer turns and human combat. Add a very slow setting with at least two seconds between automatic actions. Pause stops both automatic schedulers and gates manual match-changing input; resume continues the same match. Saving and replacement remain usable; replacement/new game cancels old callbacks. Add a popup full game event log, available while paused: initial deal, every ordinary action, turn/phase changes, reinforcements, combat casualties, captures, transfers, elimination and victory. Army changes identify player, region, reason and exact before/after counts; transfers are distinguished from losses. Reconstruct the complete log on load, append without duplicates and reset for a new match. Presentation controls/log add no game actions or RNG draws. Keep existing routes, save formats and core rules unchanged; pause is session state.
- **Done when**:
  1. `npx playwright test tests/e2e/playback-controls.spec.ts` — at both desktop sizes, all displayed totals equal the sum of owned map armies, change with play, and remain readable; Pause freezes history and armies, Resume continues, very slow delays actions, stale callbacks cannot play through pause or replacement. Continuous human fighting also pauses; paused manual actions are gated. Screenshots show the controls and totals.
  2. `npm test && npm run build` — existing rules, replay and presentation checks pass.
  3. `npx playwright test tests/e2e/computer-turn-flow.spec.ts tests/e2e/battle-controls.spec.ts` — existing turn and battle flows remain usable.
  4. `npx playwright test tests/e2e/game-event-log.spec.ts` — popup open/close is keyboard usable and changes no match data; full ordered history and army deltas agree with independent ordinary-action replay, distinguish casualties from transfers, survive save/load without duplicates, include initial deal and game result, and reset on new game.
- **Hazards**: Do not confuse battle-specific Stop with global Pause; cancel both schedulers and invalidate queued callbacks. Do not change speed defaults or core policy to explain the unconfirmed report. Main preflights acceptance on baseline and disposable mock before implementation. Appearance remains the owner's judgment.

## Blocking means
Any one is enough for rework:
1. A Done-when fails or cannot be run as written.
2. Pausing can execute another automatic/manual match action; stale callbacks change a replaced match; resume changes action/RNG replay; ordinary speed defaults change.
3. Displayed totals or log army deltas disagree with actual state, losses are confused with transfers, saved games lose their full log history, or new games retain old events.
4. Any unrelated gameplay/core/save change, missing required event categories, inaccessible controls at the two desktop sizes, uncited rule constants or an acceptance test surviving omission of the behavior it claims to protect.
Not blocking: wording/style and unchanged-code defects; file these as follow-ups. Rate likelihood practically (rule22). This task is a presentation feature, not a rewrite of computer policy, save protocols or board generation.

## Report every blocking finding in this one review

This review is your only pass before the author fixes. Do not stop at the first blocking
finding: finish reading the whole diff and the task file, check every Done-when line and
every item under "Blocking means", and report all blocking findings together.

- Before you write the verdict, make one last pass over the full diff for anything you have
  not yet rated, and say "Final pass done" as the last line before the verdict.
- Number the findings R1, R2, … in order of severity. A finding you held back because an
  earlier one was already blocking is a review defect: if two problems share a cause, list
  both and say so.
- Do not rely on a later round. The author fixes everything you list, and the next review
  checks those fixes and new code only, not anything you saw but did not report.
- If you ran out of time or context before covering the whole diff, say which files or
  sections you did not cover. Do not approve in that case.

Prior preparation failures are preserved honestly: initial repeated-download throttling was fixed in the test export observer; initial sparse input snapshots are labelled. No claim that the owner's exact army disappearance was fixed. Verify current code, with full raw evidence retained.

Efficiency/interpretation: batch DW1/DW3/DW4 browser specs in one invocation and account for each explicitly. Also include playback-edge-cases, versioned-match and finished-copy once, because the changed shared header/Panel have concrete compatibility risks. Reuse the existing typechecked build; do not re-run whole suites for every mutation. For omission controls, remove the behavior as a whole rather than demanding each redundant defensive guard independently fail; a surviving redundant guard is not itself a behavior bypass. Prefer a few likely omission classes and full code coverage over a large mutation matrix.

Out of your depth: stop and hand back, with an ESCALATE block, when any of these happens:
two hypotheses for the same question have failed; you would rely on bytes, code or behaviour
you cannot explain; you are about to write a claim you cannot back with evidence; or you have
made three attempts at one step without progress. The ESCALATE block gives what you tried,
the evidence so far, and the exact question you could not answer. Never guess a format or a cause.

## Follow-up scope and exact CI environment

This is a follow-up after the complete first-pass review below. Check all named fixes and all new code; do not introduce old unreported findings in unchanged code. Initial full scope was complete, independently reran all DW lines and found R1 plus two nonblocking notes. Parent independently audited all source/capture archive hashes. Historical generated run data is provenance, not executable code; do not recursively read old snapshots as current code.

R1 requires all six original edge cases to pass with PLAYBACK_EVIDENCE_DIR genuinely unset. Run the combined browser invocation ONCE (54 original cases plus the new queued-close regression) with `env -u PLAYBACK_EVIDENCE_DIR`; leave other existing evidence env vars pointed inside your review worktree. Default screenshots go to screenshots/ inside that worktree. Include all DW browser specs, playback-edge-cases, versioned-match and finished-copy; account for each DW separately. Run npm test and build once. Verify new production-checks ci-like mode unsets this var and retains the resulting files. Verify the aria-pressed removal and explicit net regional count wording with the new focused assertion.

All scratch and output MUST stay inside your review worktree or the granted evidence directory. This supersedes any obsolete OpenCode /tmp guidance in the shared profile. Do not create /tmp/opencode directories. Use existing installed dependencies; do not invoke missing tools that download packages. No global configuration/cache changes.

Machine-readable final lines must be standalone. Use exactly:
EVIDENCE: docs/prototypes/new-game/T70/
Put explanatory limitations on a separate line. FILE lines name inspected current executable/docs paths; generated historical archives are covered by EVIDENCE, not a claim you audited every tar member. The parent already did the archive audit. State SCOPE: complete when required current code and follow-up scope are actually covered.

## Full first review

T70 review (Claude Sonnet High)
rework

**Where I worked:** my worktree at HEAD `ed379764094e835137a957f255794cf5e1541fc0`. PR base is `c858fd404497a6fc051e19a7073932b9105ed007`. `git diff c858fd4 HEAD` shows 75 files, 19629 insertions and 16 deletions.
- The diff touches nothing under `src/core`, `tests/core` or `data`.
- Every changed file is in the task's Owns list.
- I set `PLAYBACK_EVIDENCE_DIR`, `COMPUTER_FLOW_EVIDENCE_DIR`, `BATTLE_EVIDENCE_DIR` and `VERSIONED_MATCH_EVIDENCE_DIR` to folders under `/tmp/opencode/rev159` for the DW runs.
- I added an untracked `node_modules` symlink in the worktree so the commands could run.
- I ran `npx vite-node` once to dump the log text for a pinned domination save. It downloaded `vite-node@6.0.0` into the npx cache outside the worktree.
- I mutated source files in place and restored the saved bytes in a `finally`. `git status` afterwards shows only `?? node_modules`.

DW1: ran `npx playwright test tests/e2e/playback-controls.spec.ts` (batched with the other specs below, `--workers=2`) → 8 of 8 cases passed at 1280x800 and 1920x1080.
DW2: ran `npm test && npm run build` → 6 harness tests and 622 Vitest tests passed, and the build exited 0.
DW3: ran `npx playwright test tests/e2e/computer-turn-flow.spec.ts tests/e2e/battle-controls.spec.ts` (same batch) → all cases passed.
DW4: ran `npx playwright test tests/e2e/game-event-log.spec.ts` (same batch) → 6 of 6 cases passed.

The one batched invocation was DW1, DW3 and DW4 plus `playback-edge-cases`, `versioned-match` and `finished-copy`. It ran 54 cases and all passed. It ran with `PLAYBACK_EVIDENCE_DIR` set, which R1 shows hides a failure.

**R1 (blocking). `playback-edge-cases.spec.ts` fails in the normal CI run.**
- `tests/e2e/playback-edge-cases.spec.ts:25`, `:34` and `:49` use `process.env["PLAYBACK_EVIDENCE_DIR"]!` and pass it straight to `mkdirSync`.
- CI runs plain `npx playwright test --workers=2` (workflow line 35), so the variable is unset.
- I ran `env -u PLAYBACK_EVIDENCE_DIR npx playwright test tests/e2e/playback-edge-cases.spec.ts --project=1280x800`. All 3 cases failed with `TypeError: The "path" argument must be of type string or an instance of Buffer or URL. Received undefined`. The same failures occur in the 1920x1080 project.
- The commit "Allow T70 timer and modal regression cases in the normal CI test directory" moved this spec into the regular suite. The producer's `production-checks.py` always sets the variable, so the failure was never visible.
- The other new specs use `?? "screenshots"`. The edge spec should do the same.

**Checks that found no defect:**
- Pause gating works. `accepts()` gates every manual method on `playbackPaused`, `dispatchComputer` is gated, and `ComputerTurnLoop.update` cancels when paused. `clickProvince` and `renderMap` are gated and the panel buttons are disabled.
- `setPlaybackPaused` cancels the human timer through `generation` and `cancel()`. The scheduled callback has no pause check of its own, so the cancel is the only guard. Resume reschedules only when `current.running`.
- `replaceGame` resets the pause. Load and new game remount a fresh `ReferenceBattleGame`, and `dispose` cancels the old controller, loop and dialog.
- Omission controls I ran all failed as they should:
  - Removing `this.cancel()` from `setPlaybackPaused` made `global pause freezes continuous human battle` fail.
  - Removing both computer pause guards (the one in `update()` and the one in `dispatchComputer`) made `Pause freezes computer play` fail.
  - Removing the elimination note, the endTurn unplaced-income note and the friendlyMove note made two of the three `game-event-log` cases fail (`move-completed`, `domination`). I did not see which single mutation each failure came from.
- The source also holds up on these points:
  - Army totals come from `armyTotal` for every player, eliminated ones included.
  - The log is rebuilt from `state.history` on mount and append-only, so there are no duplicates.
  - A new match builds a fresh `GameEventLog`.
  - Speed defaults are unchanged (`normal`, `COMPUTER_STEP_TIME` 350, `SPEED_SCALE` slow/normal/fast).
  - The new constants (2000 ms, ×6, 16px) carry `[designed]` comments.
  - The legacy panel layout is preserved through the `prominentArmyTotals` opt-in.
- I viewed these screenshots at both sizes: `playback-paused-computer-1280x800`, `playback-paused-battle-1920x1080` and `production-modal-1280x800`. Pause/Resume, Game speed, the Game event log button and the labelled totals are visible and readable. The modal is opaque and has a visible Close button. Appearance is the owner's call.

**Non-blocking follow-ups:**
- `src/ui/referenceBattleGame.ts:149-151` puts `aria-pressed` on a button whose label already flips between "Pause game" and "Resume game". Screen readers will announce both.
- `src/ui/gameEventLog.ts`, `regionChanges`: on a capture, the captured country's line reads "Combat and capture: 1 → 1 (+0)" and nets the casualty against the transfer. The separate note line explains it correctly, but the region line alone is ambiguous.

SCOPE: complete
FILE: RUN-NOTES.md
FILE: docs/prototypes/new-game/T70/.gitignore
FILE: docs/prototypes/new-game/T70/event-log-mock.ts
FILE: docs/prototypes/new-game/T70/mock-preflight.py
FILE: docs/prototypes/new-game/T70/production-checks.py
FILE: src/styles.css
FILE: src/ui/battleController.ts
FILE: src/ui/battleView.ts
FILE: src/ui/computerTurnLoop.ts
FILE: src/ui/gameEventLog.ts
FILE: src/ui/panel.ts
FILE: src/ui/referenceBattleGame.ts
FILE: tests/e2e/game-event-log.spec.ts
FILE: tests/e2e/playback-controls.spec.ts
FILE: tests/e2e/playback-edge-cases.spec.ts
FILE: tests/ui/game-event-log.test.ts
FILE: tests/ui/playback-controls.test.ts
EVIDENCE: docs/prototypes/new-game/T70/ (I read the README in full and the head of `production-evidence.json`. The run-directory archives, `report.json` files and `raw-outputs.tar.gz` were not audited, and my own runs did not depend on them.)

Final pass done
rework

Additional rework validation exposed a queued native dialog close-event focus race in the preexisting new log. The custom `close` handler unconditionally focused the opener, potentially stealing focus after the user had already focused a country and pressed Enter. Check removal of that redundant focus handler, native dialog focus restoration, and the new deterministic delayed-close regression. Preserve the failed full-run evidence as well as final successful receipts. This is new code/finding, not a request to reopen unrelated unchanged code.


---
OUTPUT RULES (from tools/harness/review.mjs; they override anything above that conflicts):
- Do not post to GitHub, commit, push, label or merge anything. The script posts your review.
  Edit nothing, but for a mutation made in place in your worktree and never committed.
  Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
  restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
  a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
  copy inside your worktree (`<file>.saved`, deleted afterwards) or in your own folder under
  `/tmp/opencode/`. Outside your worktree, write only under `/tmp/opencode/` (a
  `mktemp -d /tmp/opencode/mlp-review-XXXXXX` folder is the tidiest, removed afterwards; the reviewer
  agent file allows nothing else). Every other path outside your worktree is forbidden.
- Your final message is the review and nothing else. Line 1 is exactly: T70 review (Claude Sonnet Medium)
  Line 2 is the verdict, alone on its line: approve, approve after named fixes, rework, or user
  decision. Then any where-I-worked lines (worktree, HEAD, diff, the commands you ran), then the
  findings (R1, R2, ... with file and line, blocking or not), then the verdict again as the very
  last line. Nothing comes after it.
- A finding you proved that lets a forbidden action or a wrong result past what the task protects
  is blocking, and blocks an approve: never "follow-up hardening" or "outside the threat model"
  unless the task's text says so (L47).
- Report every blocking finding in this one review, not one per round: read the whole diff, then
  make a final pass and write "Final pass done" as the line before the closing verdict. Name any
  part you did not cover, and do not approve then (L49).
- The task has 4 Done-when lines. Right after the verdict line, account for each, one
  line per Done-when line, DW1 to DW4: "DW<k>: ran <command> → <result>", or
  "DW<k>: not run — <reason>". An approve with one missing, or one not run, is not applied. A review that does not end with its verdict, or that has a
  finding after it, is posted flagged and acted on by no one until the main session reads it.
- Your worktree is /home/diego/projects/malpaco/.cache/t70-claude-review/159-review-36e36519 at 88013091a73848f9f99be9da565a550b8f026968, and it is already your working directory. Run git
  there without -C, and never type that path: a mistyped path ends the run. This rule is about
  your own worktree only (L61): a Done-when line may send git at a pinned repository outside it
  (git -C <path> show <pin>:<file>); run that exactly as written — OpenCode does not path-check
  git -C — and read a granted outside path only with the L59 recipe.

CLAUDE BACKEND CONTRACT: The exact PR base is c858fd404497a6fc051e19a7073932b9105ed007, head 88013091a73848f9f99be9da565a550b8f026968. Do not use origin/main for a merged PR. Complete local diff: /home/diego/projects/malpaco/.cache/review-evidence/pr159-a6129b54af08/full.diff; bounded parts: /home/diego/projects/malpaco/.cache/review-evidence/pr159-a6129b54af08/diff-parts; full changed-file inventory: /home/diego/projects/malpaco/.cache/review-evidence/pr159-a6129b54af08/inventory.json. Read all executable changes. For generated evidence you may audit a group explicitly. Never claim a file you did not inspect. Before Final pass done, emit SCOPE: complete only if you covered all changes; otherwise SCOPE: incomplete plus UNCOVERED: paths/reasons. Emit FILE: <exact path> for each changed file inspected; EVIDENCE: <docs/prototypes/.../ prefix> may account for generated evidence only, never executable scripts. These are coverage claims, not independent proof. Every Done-when must be run; include exact DW lines. A missing scope acknowledgment prevents approval. No subagents or GitHub writes. Native Claude permission denials mirror OpenCode publishing restrictions; the trusted hook protects credential paths for Read/Grep/Glob. Bash is granted for tests and in-tree mutations. These are mistake safeguards, not an OS sandbox. Preserve scratch/evidence; do not clean up. Ignore obsolete OpenCode-only path restrictions above: your scratch is your retained worktree. No blanket permission bypass.

The read-only contract overrides the tripwire instruction to push: never push.
Out of your depth: stop and hand back, with an ESCALATE block, when any of these happens:
two hypotheses for the same question have failed; you would rely on bytes, code or behaviour
you cannot explain; you are about to write a claim you cannot back with evidence; or you have
made three attempts at one step without progress. Push your branch first. The ESCALATE block
gives what you tried, the evidence so far, and the exact question you could not answer. Never
guess a format or a cause.
