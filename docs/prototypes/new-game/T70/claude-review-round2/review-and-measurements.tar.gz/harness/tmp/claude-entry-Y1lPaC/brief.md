T69 review (Claude)
You review PR #1 at 08ac4089b2d1cfd54b11acbb1a2ed5315765a98d.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
