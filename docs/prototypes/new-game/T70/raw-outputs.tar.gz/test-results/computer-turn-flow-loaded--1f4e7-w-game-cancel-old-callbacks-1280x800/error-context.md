# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: computer-turn-flow.spec.ts >> loaded computer capture resolves without a click; replacement and new game cancel old callbacks
- Location: tests/e2e/computer-turn-flow.spec.ts:27:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   Object {
+     "fits": false,
+     "font": 13,
+     "id": "confirm-capture-button",
+   },
+ ]
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 1 human / 2 computer seats · Computer play · Seed 1994
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]:
          - strong [ref=e13]: "Total armies: 34"
          - generic [ref=e14]: 14 provinces
      - generic [ref=e18]:
        - generic [ref=e19]: Seat 2 · Computer
        - generic [ref=e20]:
          - strong [ref=e21]: "Total armies: 35"
          - generic [ref=e22]: 16 provinces
      - generic [ref=e26]:
        - generic [ref=e27]: Seat 3 · Computer
        - generic [ref=e28]:
          - strong [ref=e29]: "Total armies: 32"
          - generic [ref=e30]: 16 provinces
    - generic [ref=e31]:
      - button "Game event log" [ref=e32] [cursor=pointer]
      - button "Pause" [ref=e33] [cursor=pointer]
      - generic [ref=e34]: Game speed
      - combobox "Game speed" [ref=e35]:
        - option "Very slow (2 s)"
        - option "slow"
        - option "normal" [selected]
        - option "fast"
    - contentinfo [ref=e36]:
      - button "New game" [ref=e37] [cursor=pointer]
    - generic [ref=e38]:
      - button "Save game" [ref=e39] [cursor=pointer]
      - generic [ref=e40]:
        - generic [ref=e41]: Load game
        - button "Load game" [ref=e42]
  - main [ref=e43]:
    - img "Nine Isles reference map" [ref=e45]:
      - button "River gate, Seat 3, 3 armies, Seat 3" [ref=e71] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: "3"
      - button "New port, Seat 1, 3 armies, Seat 1" [ref=e73] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: "3"
      - button "North rest, Seat 2, 2 armies, Seat 2" [ref=e75] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: "2"
      - button "River keep, Seat 2, 1 armies, Seat 2" [ref=e77] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: "1"
      - button "North town, Seat 2, 1 armies, Seat 2" [ref=e79] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: "1"
      - button "Dark ford, Seat 1, 3 armies, Seat 1" [ref=e81] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: "3"
      - button "Iron point, Seat 3, 2 armies, Seat 3" [ref=e83] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: "2"
      - button "South rest, Seat 3, 2 armies, Seat 3" [ref=e85] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: "2"
      - button "High shore, Seat 2, 2 armies, Seat 2" [ref=e87] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: "2"
      - button "Wind town, Seat 3, 3 armies, Seat 3" [ref=e89] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: "3"
      - button "New glen, Seat 1, 3 armies, Seat 1" [ref=e91] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: "3"
      - button "Old rock, Seat 3, 1 armies, Seat 3" [ref=e93] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: "1"
      - button "Blue peak, Seat 2, 1 armies, Seat 2" [ref=e95] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: "1"
      - button "West haven, Seat 3, 1 armies, Seat 3" [ref=e97] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: "1"
      - button "Stone watch, Seat 2, 8 armies, Seat 2" [ref=e99] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: "8"
      - button "Upper ridge, Seat 1, 4 armies, Seat 1" [ref=e101] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: "4"
      - button "Marsh keep, Seat 2, 3 armies, Seat 2" [ref=e103] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: "3"
      - button "New fell, Seat 2, 1 armies, Seat 2" [ref=e105] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: "1"
      - button "Moon point, Seat 3, 1 armies, Seat 3" [ref=e107] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: "1"
      - button "South fell, Seat 2, 1 armies, Seat 2" [ref=e109] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: "1"
      - button "High ridge, Seat 2, 2 armies, Seat 2" [pressed] [ref=e111] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: "2"
      - button "Bay ford, Seat 2, 2 armies, Seat 2" [ref=e113] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: "2"
      - button "Low moor, Seat 1, 3 armies, Seat 1" [ref=e115] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: "3"
      - button "Lower field, Seat 3, 2 armies, Seat 3" [ref=e117] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: "2"
      - button "Wind gate, Seat 3, 3 armies, Seat 3" [ref=e119] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: "3"
      - button "Silver shore, Seat 1, 1 armies, Seat 1" [ref=e121] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: "1"
      - button "Low peak, Seat 1, 2 armies, Seat 1" [ref=e123] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: "2"
      - button "Wind port, Seat 1, 3 armies, Seat 1" [ref=e125] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: "3"
      - button "Gold point, Seat 3, 1 armies, Seat 3" [ref=e127] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: "1"
        - generic [ref=e129]: ★
      - button "Rock moor, Seat 2, 2 armies, Seat 2" [ref=e130] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: "2"
      - button "Marsh rest, Seat 3, 2 armies, Seat 3" [ref=e132] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: "2"
      - button "Wind dale, Seat 1, 3 armies, Seat 1" [ref=e134] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: "3"
      - button "Silver ford, Seat 1, 2 armies, Seat 1" [ref=e136] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: "2"
      - button "Iron field, Seat 1, 1 armies, Seat 1" [ref=e138] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: "1"
      - button "North wood, Seat 2, 2 armies, Seat 2" [ref=e140] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: "2"
      - button "Fort town, Seat 3, 1 armies, Seat 3" [ref=e142] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: "1"
        - generic [ref=e144]: ★
      - button "Red field, Seat 2, 3 armies, Seat 2" [ref=e145] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: "3"
        - generic [ref=e147]: ★
      - button "South ridge, Seat 2, 2 armies, Seat 2" [ref=e148] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: "2"
      - button "Rock bay, Seat 3, 3 armies, Seat 3" [ref=e150] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: "3"
      - button "North ford, Seat 1, 1 armies, Seat 1" [ref=e152] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: "1"
      - button "Port ridge, Seat 3, 1 armies, Seat 3" [ref=e154] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: "1"
      - button "New rock, Seat 2, 2 armies, Seat 2" [ref=e156] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: "2"
      - button "South reach, Seat 3, 3 armies, Seat 3" [ref=e158] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: "3"
      - button "Silver point, Seat 3, 3 armies, Seat 3" [ref=e160] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: "3"
      - button "East ford, Seat 1, 3 armies, Seat 1" [ref=e162] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: "3"
      - button "Gold town, Seat 1, 2 armies, Seat 1" [ref=e164] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: "2"
      - generic [ref=e196]: North Isle +3
      - generic [ref=e197]: East Isle +3
      - generic [ref=e198]: West Isle +3
      - generic [ref=e199]: South Isle +3
      - generic [ref=e200]: Central Isle +5
      - generic [ref=e201]: Harbor Isle +5
      - generic [ref=e202]: Palm Isle +6
      - generic [ref=e203]: Cliff Isle +5
      - generic [ref=e204]: Great Isle +9
    - complementary [ref=e205]:
      - generic [ref=e209]:
        - generic [ref=e210]: Seat 2's turn
        - generic [ref=e211]: Computer · Normal · Round 1 · Capture move-in
      - generic [ref=e212]:
        - button "End turn" [disabled] [ref=e214]
        - region "Battle controls" [ref=e215]:
          - heading "Battle" [level=2] [ref=e216]
          - generic [ref=e217]:
            - generic [ref=e218]:
              - generic [ref=e219]: From
              - strong [ref=e220]: High ridge
              - generic "Source armies" [ref=e221]: "2"
            - generic [ref=e222]:
              - generic [ref=e223]: Target
              - strong [ref=e224]: New fell
              - generic "Target armies" [ref=e225]: "1"
          - generic [ref=e226]:
            - generic [ref=e227]:
              - text: Stop at armies
              - spinbutton "Stop at armies" [disabled] [ref=e228]: "2"
            - generic [ref=e229]:
              - text: Battle speed
              - combobox "Battle speed" [ref=e230]:
                - option "Slow"
                - option "Normal" [selected]
                - option "Fast"
          - paragraph [ref=e231]: This battle stops at 1 army, or on capture.
          - generic [ref=e232]:
            - button "Fight on" [disabled] [ref=e233]
            - button "Stop" [disabled] [ref=e234]
            - button "Single exchange" [disabled] [ref=e235]
          - generic [ref=e236]:
            - strong [ref=e237]: Ready for your choice
            - paragraph [ref=e238]: Confirm the army transfer below.
          - paragraph [ref=e239]:
            - text: Won 0 · Lost 0 · Ties
            - strong [ref=e240]: "0"
          - region "Capture move-in" [ref=e241]:
            - heading "Move armies into the capture" [level=3] [ref=e242]
            - paragraph [ref=e243]: Choose 1–2 total armies. Leave at least one behind.
            - generic [ref=e244]:
              - text: Armies to move
              - spinbutton "Armies to move" [disabled] [ref=e245]: "2"
            - generic [ref=e246]:
              - button "Minimum" [disabled] [ref=e247]
              - button "Move one fewer army" [disabled] [ref=e248]: −
              - button "Move one more army" [disabled] [ref=e249]: +
              - button "Maximum" [disabled] [ref=e250]
            - button "Confirm move-in" [disabled] [ref=e251]
        - status [ref=e252]: Seat 2 is playing…
      - generic [ref=e253]:
        - heading "Battle log" [level=3] [ref=e254]
        - list "Battle log" [ref=e255]:
          - listitem [ref=e256]: "T1 Seat 2: High ridge → New fell, took New fell"
          - listitem [ref=e257]: T1 Seat 1 ends the turn
```

# Test source

```ts
  1  | import { expect, test } from "@playwright/test";
  2  | import type { Page } from "@playwright/test";
  3  | import { mkdirSync, mkdtempSync, readFileSync } from "node:fs";
  4  | import { join } from "node:path";
  5  | import { activePlayer, apply } from "../../src/core";
  6  | import type { GameState } from "../../src/core";
  7  | import { deserializeVersionedMatch, serializeVersionedMatch, REFERENCE_MATCH_IDENTITY } from "../../src/core/match-save";
  8  | import { pinned } from "../core/versioned-match-fixture";
  9  | async function save(page:Page){const p=page.waitForEvent("download");await page.getByRole("button",{name:"Save game",exact:true}).click();return readFileSync((await (await p).path())!,"utf8");}
  10 | async function load(page:Page,text:string){await page.getByLabel("Load game",{exact:true}).setInputFiles({name:"resume.json",mimeType:"application/json",buffer:Buffer.from(text)});await expect(page.locator("[data-country]")).toHaveCount(46);}
  11 | async function begin(page:Page){await page.clock.install();await page.clock.pauseAt(new Date());await page.goto("/?view=reference-game");}
> 12 | async function capture(page:Page,name:string,project:string){const dir=process.env["COMPUTER_FLOW_EVIDENCE_DIR"]??"screenshots";mkdirSync(dir,{recursive:true});expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);const boxes=await page.locator("#reference-computer-status,#confirm-capture-button,#reference-save-game").evaluateAll(nodes=>nodes.filter(n=>n.getClientRects().length).map(n=>{const r=n.getBoundingClientRect();return {id:n.id,font:parseFloat(getComputedStyle(n).fontSize),fits:r.left>=0&&r.top>=0&&r.right<=innerWidth+1&&r.bottom<=innerHeight+1};}));expect(boxes.filter(b=>!b.fits||b.font<12)).toEqual([]);await page.screenshot({path:join(mkdtempSync(join(dir,"flow-")),`${name}-${project}.png`)});}
     |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ^ Error: expect(received).toEqual(expected) // deep equality
  13 | function computerCapture(){const f=pinned("human-loss");let s=deserializeVersionedMatch(serializeVersionedMatch(f.options,[],REFERENCE_MATCH_IDENTITY)).state;for(const a of f.actions){const r=apply(s,a);if(!r.ok)throw Error(r.error);s=r.state;if(s.phase==="capture"&&activePlayer(s)!.kind==="computer")return serializeVersionedMatch(f.options,s.history,REFERENCE_MATCH_IDENTITY);}throw Error("No computer capture");}
  14 | async function runToHuman(page:Page){for(let i=0;i<400;i++){if(await page.locator("#reference-computer-status").isHidden())return;await page.clock.runFor(525);}throw Error("Computer did not hand back control");}
  15 | 
  16 | test("untouched setup starts one human and three Normal computers and consecutive turns return",async({page},info)=>{
  17 |  await begin(page);await expect(page.locator("#reference-seats")).toHaveValue("4");for(let i=1;i<=4;i++)await expect(page.getByLabel(`Seat ${i} control`)).toHaveValue(i===1?"human":"computer");
  18 |  await page.getByRole("button",{name:"Start game",exact:true}).click();let text=await save(page),loaded=deserializeVersionedMatch(text),s=loaded.state;
  19 |  expect(loaded.options.computerStrengths).toEqual(["Normal","Normal","Normal"]);expect(loaded.options.seats.map(p=>p.kind)).toEqual(["human","computer","computer","computer"]);
  20 |  await runToHuman(page);s=deserializeVersionedMatch(await save(page)).state;expect(activePlayer(s)!.kind).toBe("human");const priorHandoffs=s.history.filter(a=>a.kind==="endTurn"||a.kind==="friendlyMove").length;
  21 |  const own=s.map.provinces.find(p=>s.ownerOf[p.id]===activePlayer(s)!.id)!.id;
  22 |  for(let i=0;i<s.reinforcementPool;i++)await page.locator(`[data-country="${own}"]`).press("Enter");await page.locator("#start-combat-button").click();await page.locator("#end-turn-button").click();
  23 |  await expect(page.locator("#reference-computer-status")).toBeVisible();await expect(page.locator("#end-turn-button")).toBeDisabled();await capture(page,"computer-turn",info.project.name);
  24 |  const during=await save(page),computerState=deserializeVersionedMatch(during).state,computerCountry=computerState.map.provinces.find(p=>computerState.ownerOf[p.id]===activePlayer(computerState)!.id)!.id;await page.locator(`[data-country="${computerCountry}"]`).press("Enter");await page.keyboard.press("Escape");expect(await save(page)).toBe(during);
  25 |  await runToHuman(page);s=deserializeVersionedMatch(await save(page)).state;expect(activePlayer(s)!.kind).toBe("human");expect(s.currentPlayer).toBe(0);expect(s.history.filter(a=>a.kind==="endTurn"||a.kind==="friendlyMove")).toHaveLength(priorHandoffs+4);await capture(page,"human-return",info.project.name);
  26 | });
  27 | test("loaded computer capture resolves without a click; replacement and new game cancel old callbacks",async({page},info)=>{
  28 |  await begin(page);await page.evaluate(()=>{const original=window.setTimeout.bind(window);const callbacks:(()=>void)[]=[],canceled:number[]=[];Reflect.set(window,"oldComputerCallbacks",callbacks);Reflect.set(window,"canceledComputerTimers",canceled);const clear=window.clearTimeout.bind(window);window.clearTimeout=((id?:number)=>{if(id!==undefined)canceled.push(id);clear(id);}) as typeof window.clearTimeout;window.setTimeout=((fn:TimerHandler,delay?:number,...args:unknown[])=>{const id=original(fn,delay,...args);if(typeof fn==="function"&&[175,350,525].includes(delay??0)){callbacks.push(fn as ()=>void);Reflect.set(window,"lastComputerTimer",id);}return id;}) as typeof window.setTimeout;});
  29 |  const pending=computerCapture();await load(page,pending);await expect(page.locator("#confirm-capture-button")).toBeDisabled();await capture(page,"pending-computer",info.project.name);
  30 |  const before=deserializeVersionedMatch(pending).state.history.length;await page.clock.runFor(350);let s=deserializeVersionedMatch(await save(page)).state;expect(s.history[before]?.kind).toBe("captureMove");await runToHuman(page);
  31 |  await load(page,pending);const queued=await page.evaluate(()=>Reflect.get(window,"lastComputerTimer") as number);const restored=pinned("placement").text;await load(page,restored);const fresh=await save(page);expect(await page.evaluate(() => Reflect.get(window,"canceledComputerTimers") as number[])).toContain(queued);
  32 |  expect(await page.evaluate(()=>(Reflect.get(window,"oldComputerCallbacks") as unknown[]).length)).toBeGreaterThan(0);
  33 |  await page.evaluate(()=>{for(const cb of Reflect.get(window,"oldComputerCallbacks") as (()=>void)[])cb();});await page.clock.runFor(2000);expect(await save(page)).toBe(fresh);
  34 |  await load(page,pending);const queuedNew=await page.evaluate(()=>Reflect.get(window,"lastComputerTimer") as number);await page.getByRole("button",{name:"New game",exact:true}).click();expect(await page.evaluate(()=>Reflect.get(window,"canceledComputerTimers") as number[])).toContain(queuedNew);await page.evaluate(()=>{for(const cb of Reflect.get(window,"oldComputerCallbacks") as (()=>void)[])cb();});await page.clock.runFor(2000);await expect(page.getByRole("heading",{name:"New reference game",exact:true})).toBeVisible();
  35 | });
  36 | test("loss waits for Watch or Stop; finished game schedules no play; manual route stays manual",async({page},info)=>{
  37 |  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));await begin(page);await load(page,pinned("human-loss").text);const loss=await save(page);await page.clock.runFor(10000);expect(await save(page)).toBe(loss);
  38 |  await page.locator("#watch-computers-button").click();await expect(page.locator("#reference-computer-status")).toBeVisible();await page.clock.runFor(1050);expect(deserializeVersionedMatch(await save(page)).state.history.length).toBeGreaterThan(deserializeVersionedMatch(loss).state.history.length+1);
  39 |  await load(page,loss);await page.locator("#stop-game-button").click();const stopped=await save(page);await page.clock.runFor(10000);expect(await save(page)).toBe(stopped);await capture(page,"stopped",info.project.name);
  40 |  await page.goto("/?view=reference-game&control=manual");await expect(page.locator("#reference-seats")).toHaveValue("2");await load(page,computerCapture());const manual=await save(page);await page.clock.runFor(10000);expect(await save(page)).toBe(manual);await expect(page.locator("#confirm-capture-button")).toBeEnabled();expect(errors).toEqual([]);
  41 | });
  42 | 
```