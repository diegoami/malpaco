T70 CI-correction review (Claude Sonnet Medium)
Review PR #159 at 630cb17d46f2efbc1d6c952c81b815c845f55d59. You did not write it. This is the second scoped rework of the current task.

Read the entire delta since the previously approved 8801309, including parent acceptance changes, the panel identity fix, validation runner and README. The complete initial review at ed37976 and follow-up at 8801309 cover unchanged files; do not reopen old unreported issues in those files.

# T70 Visible army totals, playback controls and event log

- **Kind**: feature
- **Issue**: #158 · **Branch**: `task/T70-army-totals-and-playback` · **Merge after**: T32, T33.
- **Implementer**: native Sol Medium under the owner's standing model authorization; timer cancellation and replay preservation need care.
- **Reviewer**: independent Claude Sonnet High via the T69 CLI backend.
- **Evidence**: owner playtest and explicit request, 2026-10-17. Seed 1994 can leave computer countries on one army. Parent inspection found no unexplained army changes across 309 handoffs; this does not resolve the owner's exact position. Existing `armyTotal` and the header score already calculate totals, but do not make them prominent enough. Existing battle speed/Stop controls do not pause computer play.
- **Owns**: `src/ui/**`, presentation-only parts of `src/styles.css`, `tests/ui/**`, `tests/e2e/playback-controls.spec.ts`, `tests/e2e/game-event-log.spec.ts`, `tests/e2e/playback-edge-cases.spec.ts`, `docs/prototypes/new-game/T70/**`; append `RUN-NOTES.md`.
- **Scope**: Give each player a conspicuous, explicitly labelled total army count updated after every action, including eliminated players. Keep speed and Pause/Resume visible and keyboard usable throughout computer turns and human combat. Add a very slow setting with at least two seconds between automatic actions. Pause stops both automatic schedulers and gates manual match-changing input; resume continues the same match. Saving and replacement remain usable; replacement/new game cancels old callbacks. Add a popup full game event log, available while paused: initial deal, every ordinary action, turn/phase changes, reinforcements, combat casualties, captures, transfers, elimination and victory. Army changes identify player, region, reason and exact before/after counts; transfers are distinguished from losses. Reconstruct the complete log on load, append without duplicates and reset for a new match. Presentation controls/log add no game actions or RNG draws. Keep existing routes, save formats and core rules unchanged; pause is session state.
- **Done when**:
  1. `npx playwright test tests/e2e/playback-controls.spec.ts` — at both desktop sizes, all displayed totals equal the sum of owned map armies, change with play, and remain readable; Pause freezes history and armies, Resume continues, very slow delays actions, stale callbacks cannot play through pause or replacement. Continuous human fighting also pauses; paused manual actions are gated. Screenshots show the controls and totals.
  2. `npm test && npm run build` — existing rules, replay and presentation checks pass.
  3. `npx playwright test tests/e2e/computer-turn-flow.spec.ts tests/e2e/battle-controls.spec.ts` — existing turn and battle flows remain usable.
  4. `npx playwright test tests/e2e/game-event-log.spec.ts` — popup open/close is keyboard usable and changes no match data; full ordered history and army deltas agree with independent ordinary-action replay, distinguish casualties from transfers, survive save/load without duplicates, include initial deal and game result, and reset on new game.
- **Hazards**: Do not confuse battle-specific Stop with global Pause; cancel both schedulers and invalidate queued callbacks. Do not change speed defaults or core policy to explain the unconfirmed report. Main preflights acceptance on baseline and disposable mock before implementation. Appearance remains the owner's judgment.

Parent acceptance clarification (2026-10-17, full CI39069554707): retain one `data-player` identity per score row; total assertions locate the child count through that row. Parent helpers must await completion of asynchronous valid file loads by observing the replaced input disconnect, rather than treating the unchanged 46-country count as load completion. All state, delta, history, pause and screenshot assertions remain unchanged. These corrections strengthen synchronization and preserve existing map-readability/row-identity contracts; they do not relax a Done-when. Original frozen bytes remain in the retained preflight/source archives.


```text
<T<nn>> review (<model>)
You review PR #<n> at <sha>. You did not write it. The task file follows.
0. Prove the tree: HEAD is <sha> and the diff against origin/main is the PR's; findings name its files.
1. Re-run every Done-when line yourself, and account for each (L32). The PR's evidence is no proof.
2. [evidence-driven] Every constant traces to a fixture, report or investigation; a [designed] one says what was searched.
3. [seeded] No wall clock, unseeded random or order-dependent iteration in rule code.
4. Every changed file and behaviour is one the task asks for (L44); docs it makes wrong are updated.
5. Sweep the diff: tests that pass with the behaviour deleted (mutate, rebuild clean, re-take any
   negative result), branches no input reaches, edge comments without a test, <project classes>.
   Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
   restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
   a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
   copy inside your worktree (`<file>.saved`, deleted afterwards) or in a `mktemp -d` folder under
   `/tmp`, never as a loose file elsewhere.
6. <docs/review-brief.md in full: "Blocking means" for this task, then its one-pass section (L47, L49)>
Prove each finding (run it, or delete the behaviour and name the test that fails) or label it
unverified. Your final message is the review: the header; the verdict (approve | approve after
named fixes | rework | user decision); per Done-when line `DW<k>: ran <command> → <result>` or
`DW<k>: not run — <reason>`; the findings R1..Rn (file:line, blocking or not); the verdict again
last. Never post it: the script posts it and applies the label.
```

A further review, such as `/code-review <pr>` on an architecture task, runs only when the user asks
for it and names the model (CLAUDE.md rule 6.2: one review unless the user asks for more); then
always with the PR number, since a bare invocation from an agent reviews the wrong tree. (L8)


## Blocking means

Any one is enough; a blocking finding means rework, never approve.
1. A Done-when line fails, or cannot be run as written.
2. What this task protects can be got past: <name it: the guard, check, permission, invariant,
   rule value or file this task exists to protect>. A bypass you proved is blocking, even when it
   looks like an edge case. Never "follow-up hardening" or "outside the threat model" unless the
   task says so; if it does, quote the line. (L47)
3. Behaviour the task forbids, or behaviour nobody asked for, inside a file the task requires. (L44)
4. <project-specific items: a constant with no evidence, a test that passes with the behaviour
   deleted, a status written into a document>
Not blocking: wording, style, and defects in code the PR did not change: file those as follow-ups.
When unsure, say how likely the problem is. Rate it blocking only if it is likely and would get
past what the task protects; otherwise it is a follow-up. (L53)

## Report every blocking finding in this one review

This review is your only pass before the author fixes. Do not stop at the first blocking
finding: finish reading the whole diff and the task file, check every Done-when line and
every item under "Blocking means", and report all blocking findings together.

- Before you write the verdict, make one last pass over the full diff for anything you have
  not yet rated, and say "Final pass done" as the last line before the verdict.
- Number the findings R1, R2, … in order of severity. A finding you held back because an
  earlier one was already blocking is a review defect: if two problems share a cause, list
  both and say so.
- Do not rely on a later round. The author fixes everything you list, and the next review
  checks those fixes and new code only, not anything you saw but did not report.
- If you ran out of time or context before covering the whole diff, say which files or
  sections you did not cover. Do not approve in that case.

Specific checks for this pass:

CI 39069554707 at bf57cdf passed 219/222 cases. Both map-readability army-label cases failed because the new total child duplicated its score row's data-player attribute, producing Seat 5 for actual Seat 3. The log test at 1920 also raced an unfinished valid file read: its old country-count wait was already satisfied by the previous board, which was then replaced during verification. The parent retained all 522 output/report/screenshot members and verified their archive hashes; those historical binaries are evidence, not current executable code.

The parent clarified the task on main b402402. The revised acceptance helpers wait for the old input to disconnect and locate each total through its score row. Original state, history, army, pause and screenshot assertions are unchanged. Inspect parent-acceptance-ci-correction.json and parent-load-completion-proof: the latter deliberately delays File.text and proves the old wait returns early while the new wait blocks until actual replacement. Original frozen bytes remain archived. Do not change acceptance specs. Read the short parent-load-completion-proof/inert-proof-driver.mjs source and acknowledge it with a FILE line; do not run its historical fixed output path. Its measured result is in report.json. The driver is not wired into the application or test suite.

Run npm test and npm run build once. Batch DW1, DW3 and DW4 with playback-edge-cases, versioned-match, finished-copy and map-readability in ONE browser invocation, with PLAYBACK_EVIDENCE_DIR genuinely unset. Account for every DW separately. The producer's pinned Playwright 1.63.0, two-CPU run covers the full 222-case CI suite; check its current source and result without repeating that full suite if successful and unchanged. Reintroduce the redundant child data-player once, show the existing readability test fails, and restore saved bytes in finally. Do not repeat old mutation matrices.

Keep all scratch/output inside your review worktree or granted evidence directory, even if the shared profile mentions obsolete /tmp/opencode guidance. Use installed tools; no missing-package npx downloads, global settings/cache changes, subagents or publishing. The actual model must be claude-sonnet-5-5 at Medium; init and every assistant model will be verified.

Use standalone FILE lines for inspected current files. State earlier unchanged-file coverage honestly in prose; do not claim those files were reread. The parent can resolve the whole-PR parser flag using byte hashes. Emit this EXACT standalone line:
EVIDENCE: docs/prototypes/new-game/T70/
Put audit limitations on a separate prose line. SCOPE: complete requires complete follow-up coverage. Include each DW command/result, findings, Final pass done, then verdict.

Sonnet tripwire: stop with an ESCALATE block if two hypotheses for one question fail, you cannot explain needed bytes/code, a claim lacks evidence, or three attempts make no progress. State what was tried and the exact bounded question.

Full previous approving follow-up:

T70 review (Claude Sonnet Medium)
approve

Where I worked: my review worktree at HEAD `88013091a73848f9f99be9da565a550b8f026968`, confirmed with `git rev-parse`. PR base is `c858fd404497a6fc051e19a7073932b9105ed007`. I read the follow-up delta `ed37976..HEAD` in full. Code in that delta: `src/ui/gameEventLog.ts`, `src/ui/referenceBattleGame.ts`, `tests/e2e/playback-edge-cases.spec.ts`, `tests/ui/game-event-log.test.ts`, `docs/prototypes/new-game/T70/production-checks.py`, `RUN-NOTES.md`. The rest of the delta is generated evidence. I did not re-read the first-pass code, which had no findings besides R1 and the two notes.
- The PR diff touches nothing under `src/core`, `tests/core` or `data`. Core, RNG and save schemas are unchanged.
- No new constants were added in the follow-up.
- Every mutation I made was restored. `git status` is clean.

DW1: ran `env -u PLAYBACK_EVIDENCE_DIR npx playwright test tests/e2e/playback-controls.spec.ts … --workers=2` in one combined invocation with the other specs → the 8 `playback-controls` cases passed at both sizes. The whole invocation ran 56 cases and all passed.
DW2: ran `npm test && npm run build` → 623 Vitest tests passed and the build exited 0. I did not see the 6 harness tests in the tail I kept, but the Vitest summary showed 44 files passed.
DW3: ran `computer-turn-flow.spec.ts` and `battle-controls.spec.ts` in the same invocation → all cases passed.
DW4: ran `game-event-log.spec.ts` in the same invocation → all 6 cases passed.

The same invocation also covered `playback-edge-cases` (now 4 cases per project, including the new queued-close regression), `versioned-match` and `finished-copy`.

**Follow-up checks**
- **R1 fixed.** All three `PLAYBACK_EVIDENCE_DIR` lookups in `playback-edge-cases.spec.ts` now fall back to `"screenshots"`. Run with the variable genuinely unset, all four edge cases pass in both projects, and the `production-*` PNGs land in `screenshots/`.
- **Focus race fixed.**
  - `gameEventLog.ts` no longer has the `close` handler that focused the opener, so native dialog focus restoration applies.
  - The new test sends a delayed `close` after focus has moved to a country and then presses Enter.
  - I re-added the handler and ran that test: it failed in both projects. I then restored the file.
- **Non-blocking notes addressed.**
  - `aria-pressed` is removed, and the edge spec asserts it is absent.
  - The capture line now reads "Net after combat and capture". The new unit test checks that label and that the casualty and transfer notes stay separate.
- **`production-checks.py`.** It compiles. The `ci-like` and `edge-baseline` modes pop `PLAYBACK_EVIDENCE_DIR`, snapshot the default `screenshots/` folder before the run, and copy any new or changed PNGs into the run directory. Static read only; I did not run the script, because it creates new evidence runs.
- **Evidence kept.** `rework-round1-evidence.json` and the Claude round-1 archive directory are present. `RUN-NOTES.md` records the first intermittent 53/54 failure and the final receipts. I did not audit the archive contents.

No blocking findings. No new non-blocking findings.

SCOPE: complete
FILE: RUN-NOTES.md
FILE: docs/prototypes/new-game/T70/production-checks.py
FILE: src/ui/gameEventLog.ts
FILE: src/ui/referenceBattleGame.ts
FILE: tests/e2e/playback-edge-cases.spec.ts
FILE: tests/ui/game-event-log.test.ts
EVIDENCE: docs/prototypes/new-game/T70/
Limitation: generated archives were not audited by me; the parent already audited them. The first-pass files are covered by the first review, not re-read here.

Final pass done
approve