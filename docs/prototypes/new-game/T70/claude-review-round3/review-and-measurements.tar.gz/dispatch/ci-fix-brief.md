T70 CI correction, Luna High, continue existing worktree .cache/t70-work at992d72a. Owner says finish CURRENT work only; no new tasks. Native parent read your full last final and full independent approving follow-up.

Root cause1 proven by CI: `panel.ts` adds data-player to both .score-row and its total child, breaking existing map-readability.spec.ts global identity order (Seat5 for actualSeat3). Preserve one data-player per score row; remove ONLY the redundant child's data-player. Existing map-readability tests and parent revised total selector prove behavior without editing legacy tests. No visual layout change.

Root cause2 is PARENT acceptance synchronization, not demonstrated runtime loss: helpers awaited a count46 already satisfied by the old board, then valid file.text completion could replace the modal during verify. Parent clarified task onmainb402402 and integrated. Parent updated both frozen specs to wait for old input.isConnected false and locate total through its identity row. These are NEW frozen bytes: playback46feb0fd44d3e64c99de67a7ab40a908772ee749f5bef704c8152881a3fe5762; logdc30a76c6118924ab9780e2b7b3598b51670def96f6fc5e6aaf38084e834b684. Never edit these tests/task. Originalbytes retained and index parent-acceptance-ci-correction.json. All original state/history/casualty/pause assertions remain unchanged.

Do the one-line panel fix and add exact full-CI validation support to production-checks.py if useful. Exercise updated acceptance and map-readability, then run FULL222 Playwright suite with PLAYBACK_EVIDENCE_DIR unset in the pinned1.63.0 image at2CPUs if feasible (same exact CI environment). Existing Docker setup worked forT34, inspect retained timeout-target helper if needed. If environment fails, retain failure and report; do not silently adjust goldens/assertions. Build runs as webServer step. No need repeat all omission matrix or full unit suite for this DOM attribute-only fix; reviewer/CI rerunDWs. Preserve complete outputs/source hashes/captures as usual, preserve all previous failedCI/evidence. Parent downloads failedCI artifacts separately; do not archive until main saysready.

Add a deterministic focused acceptance test for load-helper completion if practical via delayedFile.text (existing versioned-match pattern); don't modify runtime file-loader semantics or unchanged legacy tests to mask parent synchronization. This can be parent test/proof if needed; ask main via message if unsure. All source stays withinOwns. Use ownsystemdunit+onewatch perlongjob. Do not start CI or review/GHcomments/merge, no cleanup beyondownscratch. Update index/README/RUNNOTES; [skip ci] commits, push, full final. NormalCI run only after newreview approval, and only correctedhead.

CI39069554707 retained complete log .cache/t70-dispatch/ci-failed-39069554707/complete-log.txt inROOT main; full summary219pass/3fail. Failures bothmapreadability atline19 and log1920 atline77/verifyline32. Main willarchivefullfailedrun afterdownload. Review pass1+followup alreadyapproved functionality but this newfix/testchange requires scopedindependentreview.

# T70 Visible army totals, playback controls and event log

- **Kind**: feature
- **Issue**: #158 · **Branch**: `task/T70-army-totals-and-playback` · **Merge after**: T32, T33.
- **Implementer**: native Sol Medium under the owner's standing model authorization; timer cancellation and replay preservation need care.
- **Reviewer**: independent Claude Sonnet High via the T69 CLI backend.
- **Evidence**: owner playtest and explicit request, 2026-10-17. Seed 1994 can leave computer countries on one army. Parent inspection found no unexplained army changes across 309 handoffs; this does not resolve the owner's exact position. Existing `armyTotal` and the header score already calculate totals, but do not make them prominent enough. Existing battle speed/Stop controls do not pause computer play.
- **Owns**: `src/ui/**`, presentation-only parts of `src/styles.css`, `tests/ui/**`, `tests/e2e/playback-controls.spec.ts`, `tests/e2e/game-event-log.spec.ts`, `tests/e2e/playback-edge-cases.spec.ts`, `docs/prototypes/new-game/T70/**`; append `RUN-NOTES.md`.
- **Scope**: Give each player a conspicuous, explicitly labelled total army count updated after every action, including eliminated players. Keep speed and Pause/Resume visible and keyboard usable throughout computer turns and human combat. Add a very slow setting with at least two seconds between automatic actions. Pause stops both automatic schedulers and gates manual match-changing input; resume continues the same match. Saving and replacement remain usable; replacement/new game cancels old callbacks. Add a popup full game event log, available while paused: initial deal, every ordinary action, turn/phase changes, reinforcements, combat casualties, captures, transfers, elimination and victory. Army changes identify player, region, reason and exact before/after counts; transfers are distinguished from losses. Reconstruct the complete log on load, append without duplicates and reset for a new match. Presentation controls/log add no game actions or RNG draws. Keep existing routes, save formats and core rules unchanged; pause is session state.
- **Done when**:
  1. `npx playwright test tests/e2e/playback-controls.spec.ts` — at both desktop sizes, all displayed totals equal the sum of owned map armies, change with play, and remain readable; Pause freezes history and armies, Resume continues, very slow delays actions, stale callbacks cannot play through pause or replacement. Continuous human fighting also pauses; paused manual actions are gated. Screenshots show the controls and totals.
  2. `npm test && npm run build` — existing rules, replay and presentation checks pass.
  3. `npx playwright test tests/e2e/computer-turn-flow.spec.ts tests/e2e/battle-controls.spec.ts` — existing turn and battle flows remain usable.
  4. `npx playwright test tests/e2e/game-event-log.spec.ts` — popup open/close is keyboard usable and changes no match data; full ordered history and army deltas agree with independent ordinary-action replay, distinguish casualties from transfers, survive save/load without duplicates, include initial deal and game result, and reset on new game.
- **Hazards**: Do not confuse battle-specific Stop with global Pause; cancel both schedulers and invalidate queued callbacks. Do not change speed defaults or core policy to explain the unconfirmed report. Main preflights acceptance on baseline and disposable mock before implementation. Appearance remains the owner's judgment.

Parent acceptance clarification (2026-10-17, full CI39069554707): retain one `data-player` identity per score row; total assertions locate the child count through that row. Parent helpers must await completion of asynchronous valid file loads by observing the replaced input disconnect, rather than treating the unchanged 46-country count as load completion. All state, delta, history, pause and screenshot assertions remain unchanged. These corrections strengthen synchronization and preserve existing map-readability/row-identity contracts; they do not relax a Done-when. Original frozen bytes remain in the retained preflight/source archives.


The brief is the task file pasted in full, then this block, then on a rework round the review's URL.
The `implementer` agent file repeats the run mechanics; this block is the contract, for the main
session implementing directly as much as for the subagent. A line that needs the user's machine outside the
worktree, or a cloud session, is the main session's (L26).

```text
You implement <T<nn>>. The task file above is the contract.
- Build only what the task asks for, even inside a file it requires; say why for each changed file. (L44)
- A Done-when you cannot meet: stop and report. Never weaken an assertion, skip a test or edit the task file.
- **Constraint-feasibility probe** (when the task names structural constraints and a target success
  rate): before any algorithmic change, run a small smoke test that confirms the constraint
  set alone is feasible at the target rate (often a wide-seed sweep of the existing generator
  body, plus the new constraints, with no algorithmic rewrite). If the probe shows the target
  is unreachable, STOP and report. Do not weaken a constraint to make the algorithm pass
  (rule 5); the user prefers a design amendment (preferred) over a quieter relaxation, and
  the probe surfaces the conflict one round earlier than a full implementation.
- Every new test fails before your change and passes after it; say how you checked.
- Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
  restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
  a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
  copy inside your worktree (`<file>.saved`, deleted afterwards) or in a `mktemp -d` folder under
  `/tmp`, never as a loose file elsewhere.
- If you measure: every output a finding or the PR may cite goes under a tracked path the task owns,
  pushed per batch and every 30 min, never deleted or overwritten; originals out, hashes recorded. (L40)
- A comment that asserts behaviour at an edge comes with the test that visits that edge.
- A defect you find outside the task: report it. A one-file mechanical fix that blocks you may
  ride this PR, declared under Scope in the PR body.
- Update any document your change makes wrong, in this PR. Never write status into a document.
- PR body: Closes #<issue>; Scope (files and why); a fenced block with each Done-when command and
  the tail of its output; Docs changed.
```


Full last review:
T70 review (Claude Sonnet Medium)
approve

Where I worked: my review worktree at HEAD `88013091a73848f9f99be9da565a550b8f026968`, confirmed with `git rev-parse`. PR base is `c858fd404497a6fc051e19a7073932b9105ed007`. I read the follow-up delta `ed37976..HEAD` in full. Code in that delta: `src/ui/gameEventLog.ts`, `src/ui/referenceBattleGame.ts`, `tests/e2e/playback-edge-cases.spec.ts`, `tests/ui/game-event-log.test.ts`, `docs/prototypes/new-game/T70/production-checks.py`, `RUN-NOTES.md`. The rest of the delta is generated evidence. I did not re-read the first-pass code, which had no findings besides R1 and the two notes.
- The PR diff touches nothing under `src/core`, `tests/core` or `data`. Core, RNG and save schemas are unchanged.
- No new constants were added in the follow-up.
- Every mutation I made was restored. `git status` is clean.

DW1: ran `env -u PLAYBACK_EVIDENCE_DIR npx playwright test tests/e2e/playback-controls.spec.ts … --workers=2` in one combined invocation with the other specs → the 8 `playback-controls` cases passed at both sizes. The whole invocation ran 56 cases and all passed.
DW2: ran `npm test && npm run build` → 623 Vitest tests passed and the build exited 0. I did not see the 6 harness tests in the tail I kept, but the Vitest summary showed 44 files passed.
DW3: ran `computer-turn-flow.spec.ts` and `battle-controls.spec.ts` in the same invocation → all cases passed.
DW4: ran `game-event-log.spec.ts` in the same invocation → all 6 cases passed.

The same invocation also covered `playback-edge-cases` (now 4 cases per project, including the new queued-close regression), `versioned-match` and `finished-copy`.

**Follow-up checks**
- **R1 fixed.** All three `PLAYBACK_EVIDENCE_DIR` lookups in `playback-edge-cases.spec.ts` now fall back to `"screenshots"`. Run with the variable genuinely unset, all four edge cases pass in both projects, and the `production-*` PNGs land in `screenshots/`.
- **Focus race fixed.**
  - `gameEventLog.ts` no longer has the `close` handler that focused the opener, so native dialog focus restoration applies.
  - The new test sends a delayed `close` after focus has moved to a country and then presses Enter.
  - I re-added the handler and ran that test: it failed in both projects. I then restored the file.
- **Non-blocking notes addressed.**
  - `aria-pressed` is removed, and the edge spec asserts it is absent.
  - The capture line now reads "Net after combat and capture". The new unit test checks that label and that the casualty and transfer notes stay separate.
- **`production-checks.py`.** It compiles. The `ci-like` and `edge-baseline` modes pop `PLAYBACK_EVIDENCE_DIR`, snapshot the default `screenshots/` folder before the run, and copy any new or changed PNGs into the run directory. Static read only; I did not run the script, because it creates new evidence runs.
- **Evidence kept.** `rework-round1-evidence.json` and the Claude round-1 archive directory are present. `RUN-NOTES.md` records the first intermittent 53/54 failure and the final receipts. I did not audit the archive contents.

No blocking findings. No new non-blocking findings.

SCOPE: complete
FILE: RUN-NOTES.md
FILE: docs/prototypes/new-game/T70/production-checks.py
FILE: src/ui/gameEventLog.ts
FILE: src/ui/referenceBattleGame.ts
FILE: tests/e2e/playback-edge-cases.spec.ts
FILE: tests/ui/game-event-log.test.ts
EVIDENCE: docs/prototypes/new-game/T70/
Limitation: generated archives were not audited by me; the parent already audited them. The first-pass files are covered by the first review, not re-read here.

Final pass done
approve