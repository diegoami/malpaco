T69 review (Claude)
You review PR #1 at 16b55ab437b5accdbf70f7838dba7dde42c23e3e.
# T69 fixture
- **Done when**:
  1. git diff --check BASE HEAD passes.
- **Hazards**: none.
