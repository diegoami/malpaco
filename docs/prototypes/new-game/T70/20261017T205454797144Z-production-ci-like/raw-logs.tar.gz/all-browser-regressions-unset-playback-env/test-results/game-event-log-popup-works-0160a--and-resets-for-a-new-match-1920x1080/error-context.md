# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: game-event-log.spec.ts >> popup works by keyboard while paused, appends exactly once and resets for a new match
- Location: tests/e2e/game-event-log.spec.ts:68:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Save game', exact: true })
    - locator resolved to <button type="button" id="reference-save-game">Save game</button>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <dialog open="" class="game-event-log" aria-labelledby="game-event-log-title">…</dialog> from <div class="game-playback">…</div> subtree intercepts pointer events
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <dialog open="" class="game-event-log" aria-labelledby="game-event-log-title">…</dialog> from <div class="game-playback">…</div> subtree intercepts pointer events
    - retrying click action
      - waiting 100ms
    56 × waiting for element to be visible, enabled and stable
       - element is visible, enabled and stable
       - scrolling into view if needed
       - done scrolling
       - <dialog open="" class="game-event-log" aria-labelledby="game-event-log-title">…</dialog> from <div class="game-playback">…</div> subtree intercepts pointer events
     - retrying click action
       - waiting 500ms

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 2 human seats · Seed 1994
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]:
          - strong [ref=e13]: "Total armies: 46"
          - generic [ref=e14]: 23 provinces
      - generic [ref=e18]:
        - generic [ref=e19]: Seat 2
        - generic [ref=e20]:
          - strong [ref=e21]: "Total armies: 49"
          - generic [ref=e22]: 23 provinces
    - generic [ref=e23]:
      - button "Game event log" [ref=e24] [cursor=pointer]
      - dialog [ref=e25]:
        - banner [ref=e26]:
          - heading "Game event log" [level=2] [ref=e27]
          - button "Close game event log" [active] [ref=e28] [cursor=pointer]
        - list "All game events" [ref=e29]:
          - listitem [ref=e30]:
            - group [ref=e31]:
              - generic "Initial deal · Round 1 · 46 countries" [ref=e32] [cursor=pointer]
            - paragraph [ref=e33]: "Seat 2 unplaced reinforcement income: 7. These armies enter the map only when placed."
          - listitem [ref=e34]:
            - heading "Action 1 · Round 1 · Seat 2 · Reinforcement placement · Reinforcement → Reinforcement" [level=3] [ref=e35]
            - paragraph [ref=e36]: "New port · Seat 2 · Reinforcement placement: 1 → 2 (+1)"
            - paragraph [ref=e37]: "Unplaced armies: 7 → 6. 1 placed on New port."
          - listitem [ref=e38]:
            - heading "Action 2 · Round 1 · Seat 2 · Reinforcement placement · Reinforcement → Reinforcement" [level=3] [ref=e39]
            - paragraph [ref=e40]: "New port · Seat 2 · Reinforcement placement: 2 → 3 (+1)"
            - paragraph [ref=e41]: "Unplaced armies: 6 → 5. 1 placed on New port."
          - listitem [ref=e42]:
            - heading "Action 3 · Round 1 · Seat 2 · Reinforcement placement · Reinforcement → Reinforcement" [level=3] [ref=e43]
            - paragraph [ref=e44]: "New port · Seat 2 · Reinforcement placement: 3 → 4 (+1)"
            - paragraph [ref=e45]: "Unplaced armies: 5 → 4. 1 placed on New port."
      - button "Pause game" [ref=e46] [cursor=pointer]: Pause
      - generic [ref=e47]: Game speed
      - combobox "Game speed" [ref=e48]:
        - option "Very slow (2 s)"
        - option "Slow"
        - option "Normal" [selected]
        - option "Fast"
    - contentinfo [ref=e49]:
      - button "New game" [ref=e50] [cursor=pointer]
    - generic [ref=e51]:
      - button "Save game" [ref=e52] [cursor=pointer]
      - generic [ref=e53]:
        - generic [ref=e54]: Load game
        - button "Load game" [ref=e55]
  - main [ref=e56]:
    - img "Nine Isles reference map" [ref=e58]:
      - button "River gate, Seat 1, 3 armies, Seat 1" [ref=e84] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: "3"
      - button "New port, Seat 2, 4 armies, Seat 2" [ref=e86] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: "4"
      - button "North rest, Seat 1, 1 armies, Seat 1" [ref=e88] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: "1"
      - button "River keep, Seat 2, 2 armies, Seat 2" [ref=e90] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: "2"
      - button "North town, Seat 1, 2 armies, Seat 1" [ref=e92] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: "2"
      - button "Dark ford, Seat 2, 1 armies, Seat 2" [ref=e94] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: "1"
      - button "Iron point, Seat 1, 3 armies, Seat 1" [ref=e96] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: "3"
      - button "South rest, Seat 2, 2 armies, Seat 2" [ref=e98] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: "2"
      - button "High shore, Seat 1, 1 armies, Seat 1" [ref=e100] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: "1"
      - button "Wind town, Seat 1, 2 armies, Seat 1" [ref=e102] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: "2"
      - button "New glen, Seat 2, 1 armies, Seat 2" [ref=e104] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: "1"
      - button "Old rock, Seat 1, 1 armies, Seat 1" [ref=e106] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: "1"
      - button "Blue peak, Seat 1, 3 armies, Seat 1" [ref=e108] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: "3"
      - button "West haven, Seat 1, 2 armies, Seat 1" [ref=e110] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: "2"
      - button "Stone watch, Seat 1, 3 armies, Seat 1" [ref=e112] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: "3"
      - button "Upper ridge, Seat 2, 2 armies, Seat 2" [ref=e114] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: "2"
      - button "Marsh keep, Seat 2, 3 armies, Seat 2" [ref=e116] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: "3"
      - button "New fell, Seat 2, 3 armies, Seat 2" [ref=e118] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: "3"
      - button "Moon point, Seat 1, 2 armies, Seat 1" [ref=e120] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: "2"
      - button "South fell, Seat 2, 2 armies, Seat 2" [ref=e122] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: "2"
      - button "High ridge, Seat 1, 2 armies, Seat 1" [ref=e124] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: "2"
      - button "Bay ford, Seat 1, 2 armies, Seat 1" [ref=e126] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: "2"
      - button "Low moor, Seat 2, 2 armies, Seat 2" [ref=e128] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: "2"
      - button "Lower field, Seat 2, 2 armies, Seat 2" [ref=e130] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: "2"
      - button "Wind gate, Seat 1, 2 armies, Seat 1" [ref=e132] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: "2"
      - button "Silver shore, Seat 2, 1 armies, Seat 2" [ref=e134] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: "1"
      - button "Low peak, Seat 1, 2 armies, Seat 1" [ref=e136] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: "2"
      - button "Wind port, Seat 2, 3 armies, Seat 2" [ref=e138] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: "3"
      - button "Gold point, Seat 1, 3 armies, Seat 1" [ref=e140] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: "3"
        - generic [ref=e142]: ★
      - button "Rock moor, Seat 2, 3 armies, Seat 2" [ref=e143] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: "3"
      - button "Marsh rest, Seat 1, 2 armies, Seat 1" [ref=e145] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: "2"
      - button "Wind dale, Seat 2, 2 armies, Seat 2" [ref=e147] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: "2"
      - button "Silver ford, Seat 2, 3 armies, Seat 2" [ref=e149] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: "3"
      - button "Iron field, Seat 2, 1 armies, Seat 2" [ref=e151] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: "1"
      - button "North wood, Seat 2, 2 armies, Seat 2" [ref=e153] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: "2"
      - button "Fort town, Seat 1, 1 armies, Seat 1" [ref=e155] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: "1"
        - generic [ref=e157]: ★
      - button "Red field, Seat 1, 2 armies, Seat 1" [ref=e158] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: "2"
        - generic [ref=e160]: ★
      - button "South ridge, Seat 2, 2 armies, Seat 2" [ref=e161] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: "2"
      - button "Rock bay, Seat 1, 1 armies, Seat 1" [ref=e163] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: "1"
      - button "North ford, Seat 2, 2 armies, Seat 2" [ref=e165] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: "2"
      - button "Port ridge, Seat 1, 3 armies, Seat 1" [ref=e167] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: "3"
      - button "New rock, Seat 2, 2 armies, Seat 2" [ref=e169] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: "2"
      - button "South reach, Seat 1, 1 armies, Seat 1" [ref=e171] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: "1"
      - button "Silver point, Seat 1, 2 armies, Seat 1" [ref=e173] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: "2"
      - button "East ford, Seat 2, 2 armies, Seat 2" [ref=e175] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: "2"
      - button "Gold town, Seat 2, 2 armies, Seat 2" [ref=e177] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: "2"
      - generic [ref=e209]: North Isle +3
      - generic [ref=e210]: East Isle +3
      - generic [ref=e211]: West Isle +3
      - generic [ref=e212]: South Isle +3
      - generic [ref=e213]: Central Isle +5
      - generic [ref=e214]: Harbor Isle +5
      - generic [ref=e215]: Palm Isle +6
      - generic [ref=e216]: Cliff Isle +5
      - generic [ref=e217]: Great Isle +9
    - complementary [ref=e218]:
      - generic [ref=e222]:
        - generic [ref=e223]: Seat 2's turn
        - generic [ref=e224]: Round 1 · Reinforcement
      - generic [ref=e225]:
        - generic [ref=e226]:
          - generic [ref=e227]:
            - generic [ref=e228]: Province income
            - strong [ref=e229]: "7"
          - generic [ref=e230]:
            - generic [ref=e231]: Island income
            - strong [ref=e232]: "0"
          - generic [ref=e233]:
            - generic [ref=e234]: Armies to place
            - strong [ref=e235]: "4"
        - paragraph [ref=e236]: Place your armies on your countries, then start combat.
        - generic [ref=e237]:
          - button "Start combat" [disabled] [ref=e238]
          - button "End turn" [disabled] [ref=e239]
      - generic [ref=e240]:
        - heading "Battle log" [level=3] [ref=e241]
        - list "Battle log"
```

# Test source

```ts
  1  | import { expect, test } from "@playwright/test";
  2  | import type { Page } from "@playwright/test";
  3  | import { mkdirSync } from "node:fs";
  4  | import { join } from "node:path";
  5  | import { activePlayer, apply } from "../../src/core";
  6  | import { deserializeVersionedMatch, serializeVersionedMatch, REFERENCE_MATCH_IDENTITY } from "../../src/core/match-save";
  7  | import { pinned } from "../core/versioned-match-fixture";
  8  | const dialog = (p: Page) => p.getByRole("dialog", { name: "Game event log", exact: true });
  9  | async function save(p: Page) {
> 10 |   await p.getByRole("button", { name: "Save game", exact: true }).click();
     |                                                                   ^ Error: locator.click: Test timeout of 30000ms exceeded.
  11 |   return p.evaluate(() => (Reflect.get(window, "eventLogSave") as Blob).text());
  12 | }
  13 | async function load(p: Page, text: string) {
  14 |   await p.getByLabel("Load game", { exact: true }).setInputFiles({ name: "event-log.json", mimeType: "application/json", buffer: Buffer.from(text) });
  15 |   await expect(p.locator("[data-country]")).toHaveCount(46);
  16 | }
  17 | async function begin(p: Page) {
  18 |   await p.clock.install({ time: new Date("2026-10-17T12:00:00Z") }); await p.clock.pauseAt(new Date("2026-10-17T12:00:00Z"));
  19 |   await p.goto("/?view=reference-game&control=manual");
  20 |   await p.evaluate(() => { const create = URL.createObjectURL.bind(URL); URL.createObjectURL = blob => { Reflect.set(window, "eventLogSave", blob); return create(blob); }; });
  21 | }
  22 | async function open(p: Page) {
  23 |   const button = p.locator("#game-log-button"); await expect(button).toBeVisible(); await button.focus(); await button.press("Enter"); await expect(dialog(p)).toBeVisible();
  24 | }
  25 | // Independent core replay is the oracle; no UI projection function is imported.
  26 | async function verify(p: Page, text: string) {
  27 |   const loaded = deserializeVersionedMatch(text);
  28 |   let before = deserializeVersionedMatch(serializeVersionedMatch(loaded.options, [], REFERENCE_MATCH_IDENTITY)).state;
  29 |   const rows = dialog(p).locator("[data-event-index]"); await expect(rows).toHaveCount(loaded.state.history.length + 1);
  30 |   const actual = await rows.evaluateAll(nodes => nodes.map(node => ({ index: node.getAttribute("data-event-index"), text: node.textContent!, regions: [...node.querySelectorAll("[data-region]")].map(cell => ({ id: cell.getAttribute("data-region"), text: cell.textContent! })) })));
  31 |   expect(actual.map(row => Number(row.index))).toEqual(Array.from({ length: actual.length }, (_, i) => i));
  32 |   expect(actual[0]!.text).toMatch(/initial deal/i);
  33 |   for (const country of before.map.provinces) {
  34 |     const cell = actual[0]!.regions.find(region => region.id === country.id)!; expect(cell).toBeDefined();
  35 |     expect(cell.text).toContain(country.name); expect(cell.text).toContain(`0 → ${before.armies[country.id]}`);
  36 |     expect(cell.text).toContain(before.players.find(player => player.id === before.ownerOf[country.id])!.name);
  37 |   }
  38 |   for (const [i, action] of loaded.state.history.entries()) {
  39 |     const result = apply(before, action); if (!result.ok) throw Error(result.error);
  40 |     const after = result.state, row = actual[i + 1]!;
  41 |     expect(row.text).toContain(`Round ${before.turnNumber}`); expect(row.text).toContain(activePlayer(before)!.name);
  42 |     for (const country of before.map.provinces) {
  43 |       const a = before.armies[country.id]!, b = after.armies[country.id]!;
  44 |       if (a === b && before.ownerOf[country.id] === after.ownerOf[country.id]) continue;
  45 |       const cell = row.regions.find(region => region.id === country.id); expect(cell, `${i + 1}: ${country.name}`).toBeDefined();
  46 |       expect(cell!.text).toContain(country.name); expect(cell!.text).toContain(`${a} → ${b}`);
  47 |       expect(cell!.text).toContain(`(${b - a >= 0 ? "+" : ""}${b - a})`);
  48 |       expect(cell!.text).toContain(before.players.find(player => player.id === before.ownerOf[country.id])!.name);
  49 |     }
  50 |     if (action.kind === "reinforce") expect(row.text).toMatch(/reinforcement placement/i);
  51 |     if (action.kind === "captureMove") expect(row.text).toMatch(/capture.*transfer/i);
  52 |     if (action.kind === "friendlyMove") expect(row.text).toMatch(/friendly.*transfer/i);
  53 |     if (result.outcome) {
  54 |       for (const [player, region, losses] of [[result.outcome.attacker, result.outcome.from, result.outcome.attackerLosses], [result.outcome.defender, result.outcome.to, result.outcome.defenderLosses]] as const) {
  55 |         const who = before.players.find(candidate => candidate.id === player)!.name;
  56 |         const where = before.map.provinces.find(country => country.id === region)!.name;
  57 |         expect(row.text).toContain(`${who} ${where}: ${losses} combat casualties`);
  58 |       }
  59 |       if (result.outcome.captured) expect(row.text).toContain(`${result.outcome.moved} capture transfer`);
  60 |     }
  61 |     if ((action.kind === "endTurn" || action.kind === "friendlyMove") && after.reinforcementPool > 0) expect(row.text).toMatch(new RegExp(`unplaced reinforcement income.*${after.reinforcementPool}`, "i"));
  62 |     for (const event of after.log.slice(before.log.length)) if (event.event === "eliminated" || event.event === "victory") expect(row.text).toContain(event.event);
  63 |     before = after;
  64 |   }
  65 |   return actual.map(row => row.text);
  66 | }
  67 | 
  68 | test("popup works by keyboard while paused, appends exactly once and resets for a new match", async ({ page }, info) => {
  69 |   await begin(page); await page.getByRole("button", { name: "Start game", exact: true }).click();
  70 |   let text = await save(page); const state = deserializeVersionedMatch(text).state;
  71 |   const own = state.map.provinces.find(country => state.ownerOf[country.id] === activePlayer(state)!.id)!.id;
  72 |   for (let i = 0; i < 3; i++) await page.locator(`[data-country="${own}"]`).press("Enter");
  73 |   await expect(page.locator("#game-pause-button")).toBeVisible(); await page.locator("#game-pause-button").click(); text = await save(page); await open(page); const rows = await verify(page, text);
  74 |   const root = process.env["PLAYBACK_EVIDENCE_DIR"] ?? "screenshots"; mkdirSync(root, { recursive: true }); await page.screenshot({ path: join(root, `game-event-log-${info.project.name}.png`) });
  75 |   await page.keyboard.press("Escape"); await expect(dialog(page)).not.toBeVisible(); expect(await save(page)).toBe(text);
  76 |   await open(page); expect(await verify(page, text)).toEqual(rows); await dialog(page).getByRole("button", { name: "Close game event log", exact: true }).press("Enter");
  77 |   await load(page, text); await open(page); expect(await verify(page, text)).toEqual(rows); await page.keyboard.press("Escape");
  78 |   await page.locator(`[data-country="${own}"]`).press("Enter"); text = await save(page); await open(page); expect((await verify(page, text)).length).toBe(rows.length + 1); await page.keyboard.press("Escape");
  79 |   await page.getByRole("button", { name: "New game", exact: true }).click(); await page.getByRole("button", { name: "Start game", exact: true }).click();
  80 |   text = await save(page); await open(page); expect(await verify(page, text)).toHaveLength(1);
  81 | });
  82 | for (const name of ["move-completed", "domination"]) test(`complete ${name} replay includes ordered army accounting beyond seven entries`, async ({ page }) => {
  83 |   await begin(page); const text = pinned(name).text; await load(page, text); const saved = await save(page); await open(page);
  84 |   const rows = await verify(page, saved); expect(rows.length).toBeGreaterThan(7);
  85 |   if (name === "domination") expect(rows.join(" ")).toMatch(/victory|game result/i);
  86 |   await page.keyboard.press("Escape"); expect(await save(page)).toBe(saved);
  87 |   await load(page, saved); await open(page); expect(await verify(page, saved)).toEqual(rows);
  88 | });
  89 | 
```