T37 review (Kimi K3)
You review PR #166 at 6516876af95e149874af71cc920156104b4f2811. You did not write it. The task file follows.
0. Prove the tree: HEAD is 6516876af95e149874af71cc920156104b4f2811 and the diff against origin/main is the PR's; findings name its files.
1. Re-run every Done-when line yourself, and account for each (L32). The PR's evidence is no proof.
2. [evidence-driven] Every constant traces to a fixture, report or investigation; a [designed] one says what was searched.
3. [seeded] No wall clock, unseeded random or order-dependent iteration in rule code.
4. Every changed file and behaviour is one the task asks for (L44); docs it makes wrong are updated.
5. Sweep the diff: tests that pass with the behaviour deleted (mutate, rebuild clean, re-take any
   negative result), branches no input reaches, edge comments without a test, card inventory, pending choice gates, seeded replay and backward compatibility.
   Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
   restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
   a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
   copy inside your worktree (`<file>.saved`, deleted afterwards) or in a `mktemp -d` folder under
   `/tmp`, never as a loose file elsewhere.
6. Read the Blocking means and one-pass sections below.
Prove each finding (run it, or delete the behaviour and name the test that fails) or label it
unverified. Your final message is the review: the header; the verdict (approve | approve after
named fixes | rework | user decision); per Done-when line `DW<k>: ran <command> → <result>` or
`DW<k>: not run — <reason>`; the findings R1..Rn (file:line, blocking or not); the verdict again
last. Never post it: the script posts it and applies the label.

# T37 Card deck, hands and earning a card

- **Kind**: feature
- **Issue**: #82 · **Branch**: `task/T37-card-deck-hands-and-earning-a-card` · **Merge after**: T36.
- **Difficulty**: Medium; estimate, not a model assignment.
- **Implementer**: owner-selected under rule 6; use an isolated worktree and record the choice before dispatch.
- **Reviewer**: owner-selected OpenCode model of another family under rule 6; record the choice before review.
- **Evidence**: [pinned variety design](https://github.com/diegoami/isle-wars-archaeology/blob/ae298e37c2f5177039e55767607f9345b6cb0e7a/design/variety.md), owner roadmap accepted 2026-10-15, and upstream task evidence. T23 resolves source anchors; new constants need citations or explicit [designed] provenance.
- **Owns**: src/core/**; tests/core/**; src/ui/gameEventLog.ts (mechanical action label only); docs/prototypes/new-game/T37/**; docs/spike.md; append-only RUN-NOTES.md.
- **Scope**: Add the approved 40-card composition, seeded shuffle after the deal/centres, hidden hands, public counts, draw/discard piles and reshuffle. Award one card after any capturing turn, before victory; require a chosen discard before drawing into a full five-card hand. Discard eliminated hands. Implement Squall draw handling here because it is inseparable from drawing; no trade or raid effects yet. Declare the blocking one-file mechanical `discardCard` action label in `gameEventLog.ts` under rule 12; no UI flow or layout changes.
- **Done when**:
  1. `npx vitest run tests/core/card-deck.test.ts` — exact eight-kind multiplicities, empty opening hands, draw order, capture reward, full-hand pre-discard, Squall and elimination conserve all 40 cards.
  2. `npx vitest run tests/core/card-deck-replay.test.ts` — reshuffle, pending discard, decisive-turn reward and RNG continuation replay exactly; disabling the pre-discard or duplicating a card fails acceptance.
  3. `npm test` and `npm run build` pass; affected pinned browser suites pass without weakening existing assertions. Retain measured outputs, screenshots where applicable, commands and hashes in the owned evidence path; report negative-before/positive-after checks and exact restoration.
- **Hazards**: No card is awarded per captured country. A player must choose the discard before seeing the drawn card; do not leak hidden kinds through public events. Main session preflights acceptance before dispatch; unresolved design conflicts stop implementation, never weaken a Done-when.


## Blocking means

Any one is enough; a blocking finding means rework, never approve.
1. A Done-when line fails, or cannot be run as written.
2. What this task protects can be got past: 40-card conservation, approved multiplicities, chosen discard before draw/RNG/victory/handoff, one earned reward per capturing turn, Squall/elimination disposal, private hand projection, exact schema/action-only replay. A bypass you proved is blocking, even when it
   looks like an edge case. Never "follow-up hardening" or "outside the threat model" unless the
   task says so; if it does, quote the line. (L47)
3. Behaviour the task forbids, or behaviour nobody asked for, inside a file the task requires. (L44)
4. A rule constant without approved/designed provenance, unseeded randomness, a removed behavior surviving its claimed acceptance, or copied original content.
Not blocking: wording, style, and defects in code the PR did not change: file those as follow-ups.
When unsure, say how likely the problem is. Rate it blocking only if it is likely and would get
past what the task protects; otherwise it is a follow-up. (L53)

## Report every blocking finding in this one review

This review is your only pass before the author fixes. Do not stop at the first blocking
finding: finish reading the whole diff and the task file, check every Done-when line and
every item under "Blocking means", and report all blocking findings together.

- Before you write the verdict, make one last pass over the full diff for anything you have
  not yet rated, and say "Final pass done" as the last line before the verdict.
- Number the findings R1, R2, … in order of severity. A finding you held back because an
  earlier one was already blocking is a review defect: if two problems share a cause, list
  both and say so.
- Do not rely on a later round. The author fixes everything you list, and the next review
  checks those fixes and new code only, not anything you saw but did not report.
- If you ran out of time or context before covering the whole diff, say which files or
  sections you did not cover. Do not approve in that case.

Practical run details:
- Owner chose native Sol Medium implementer and Kimi K3 reviewer. Exact live id kimi-code-plan-global/k3, variant low (live variants low/high/max). Do not delegate or substitute a model. This is the one independent review. Session family explicitly OpenAI for this native Sol implementer.
- Dependencies already copied into a private real node_modules; no npm install or external symlink needed. Retain scratch, command outputs and source snapshots. Use saved-byte finally restoration for mutations. Never git checkout, restore, reset or clean.
- DW1 run npx vitest run tests/core/card-deck.test.ts; DW2 run npx vitest run tests/core/card-deck-replay.test.ts. For DW3 run npm test and npm run build, then exact affected browser command below. No CI or wide map-generation sweep: card opt-in does not change generator/default victory rules.
- Browser command (relative paths; source root is current directory): docker run --rm --init --ipc=host --user 1000:1000 -v "$PWD:/work" -w /work -e HOME=/tmp mcr.microsoft.com/playwright:v1.63.0-noble npx playwright test tests/e2e/versioned-match.spec.ts tests/e2e/reference-complete-game.spec.ts tests/e2e/game-event-log.spec.ts tests/e2e/geographic-review-guards.spec.ts --workers=2
- No source adoption/algorithm default/card UI/policy change is authorized. Current game remains victoryRules until T40; T41 owns computer cards policy. Full trusted local save is omniscient but public cardView/log must not disclose enemy hidden kinds. Reject unsupported identity tuples, malformed discard shapes and unrelated actions while pending. Test actual captures, elimination, friendlyMove once and real production codec, not standalone fake adapters.
- Sweep actual executable change: git diff origin/main...HEAD -- src tests docs/spike.md RUN-NOTES.md. Full changed-file list: git diff --name-only origin/main...HEAD. Inspect src/core/cards.ts/types.ts/state.ts/setup.ts/rules.ts/index.ts/match-save.ts, src/ui/gameEventLog.ts and three tests/core/card-deck*.ts. docs/spike.md is changed API/staging documentation.
- Historical source copies under docs/prototypes/new-game/T37 are evidence, never imported by production/tests except the four options/actions-only fixtures. You may audit historical snapshots as explicitly named groups using manifests/hashes; do inspect executable evidence drivers, their input/receipt integrity, and ensure acceptance is not being weakened. Read parent-acceptance/PRE-DISPATCH.md, FROZEN-ACCEPTANCE.json, integrated-mock/REPORT.md, implementation/README.md and validation receipt, then targeted raw outputs/hashes. Full archives/scratch/original failures stay retained; no need rerun disposable exploration searches or treat historical mock copies as deployed features. Existing giant RUN-NOTES is append-only; tail the new T37 section, do not dump the whole historical file.
- Parent preflight baseline20fail; actual mock20pass; omission guard7fail, duplicate10fail; exact restoration recorded. Formal production13+7/665Vitest+8harness/build/28browser passes are convenience, rerun yourself. Mutation evidence source token-equivalence excludes only comments/whitespace, inspect that claim critically.
- Your outputs and session export are retained by an invocation-only launcher copy for known issue125; canonical harness source/model/family/permission-denial/approval guards are unchanged. No GitHub writes or cleanup. Final must give all findings in full, every DW accounted, Final pass done, closing verdict.



---
OUTPUT RULES (from tools/harness/review.mjs; they override anything above that conflicts):
- Do not post to GitHub, commit, push, label or merge anything. The script posts your review.
  Edit nothing, but for a mutation made in place in your worktree and never committed.
  Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
  restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
  a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
  copy inside your worktree (`<file>.saved`, deleted afterwards) or in your own folder under
  `/tmp/opencode/`. Outside your worktree, write only under `/tmp/opencode/` (a
  `mktemp -d /tmp/opencode/mlp-review-XXXXXX` folder is the tidiest, removed afterwards; the reviewer
  agent file allows nothing else). Every other path outside your worktree is forbidden.
- Your final message is the review and nothing else. Line 1 is exactly: T37 review (Kimi K3)
  Line 2 is the verdict, alone on its line: approve, approve after named fixes, rework, or user
  decision. Then any where-I-worked lines (worktree, HEAD, diff, the commands you ran), then the
  findings (R1, R2, ... with file and line, blocking or not), then the verdict again as the very
  last line. Nothing comes after it.
- A finding you proved that lets a forbidden action or a wrong result past what the task protects
  is blocking, and blocks an approve: never "follow-up hardening" or "outside the threat model"
  unless the task's text says so (L47).
- Report every blocking finding in this one review, not one per round: read the whole diff, then
  make a final pass and write "Final pass done" as the line before the closing verdict. Name any
  part you did not cover, and do not approve then (L49).
- The task has 3 Done-when lines. Right after the verdict line, account for each, one
  line per Done-when line, DW1 to DW3: "DW<k>: ran <command> → <result>", or
  "DW<k>: not run — <reason>". An approve with one missing, or one not run, is not applied. A review that does not end with its verdict, or that has a
  finding after it, is posted flagged and acted on by no one until the main session reads it.
- Your worktree is /home/diego/projects/malpaco/.cache/review-worktrees/166-review-a6433f09 at 6516876af95e149874af71cc920156104b4f2811, and it is already your working directory. Run git
  there without -C, and never type that path: a mistyped path ends the run. This rule is about
  your own worktree only (L61): a Done-when line may send git at a pinned repository outside it
  (git -C <path> show <pin>:<file>); run that exactly as written — OpenCode does not path-check
  git -C — and read a granted outside path only with the L59 recipe.
