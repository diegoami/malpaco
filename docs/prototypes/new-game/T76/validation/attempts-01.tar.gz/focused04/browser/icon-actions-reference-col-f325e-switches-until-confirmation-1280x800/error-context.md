# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: icon-actions.spec.ts >> reference: collapsed friendly draft survives Escape and surface switches until confirmation
- Location: tests/e2e/icon-actions.spec.ts:51:2

# Error details

```
Error: start-friendly-move-button physically reachable

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- main [ref=e3]:
  - img "Nine Isles reference map" [ref=e5]:
    - button "River gate, Seat 3, 2 armies, Seat 3" [ref=e31] [cursor=pointer]:
      - generic:
        - generic: River
        - generic: gate
        - generic: "2"
    - button "New port, Seat 1, 4 armies, Seat 1" [ref=e33] [cursor=pointer]:
      - generic:
        - generic: New
        - generic: port
        - generic: "4"
    - button "North rest, Seat 2, 1 armies, Seat 2" [ref=e35] [cursor=pointer]:
      - generic:
        - generic: North
        - generic: rest
        - generic: "1"
    - button "River keep, Seat 2, 1 armies, Seat 2" [ref=e37] [cursor=pointer]:
      - generic:
        - generic: River
        - generic: keep
        - generic: "1"
    - button "North town, Seat 2, 1 armies, Seat 2" [ref=e39] [cursor=pointer]:
      - generic:
        - generic: North
        - generic: town
        - generic: "1"
    - button "Dark ford, Seat 3, 1 armies, Seat 3" [ref=e41] [cursor=pointer]:
      - generic:
        - generic: Dark
        - generic: ford
        - generic: "1"
    - button "Iron point, Seat 3, 1 armies, Seat 3" [ref=e43] [cursor=pointer]:
      - generic:
        - generic: Iron
        - generic: point
        - generic: "1"
    - button "South rest, Seat 3, 3 armies, Seat 3" [ref=e45] [cursor=pointer]:
      - generic:
        - generic: South
        - generic: rest
        - generic: "3"
    - button "High shore, Seat 1, 2 armies, Seat 1" [ref=e47] [cursor=pointer]:
      - generic:
        - generic: High
        - generic: shore
        - generic: "2"
    - button "Wind town, Seat 2, 1 armies, Seat 2" [ref=e49] [cursor=pointer]:
      - generic:
        - generic: Wind
        - generic: town
        - generic: "1"
    - button "New glen, Seat 2, 1 armies, Seat 2" [ref=e51] [cursor=pointer]:
      - generic:
        - generic: New
        - generic: glen
        - generic: "1"
    - button "Old rock, Seat 3, 2 armies, Seat 3" [ref=e53] [cursor=pointer]:
      - generic:
        - generic: Old
        - generic: rock
        - generic: "2"
    - button "Blue peak, Seat 2, 1 armies, Seat 2" [ref=e55] [cursor=pointer]:
      - generic:
        - generic: Blue
        - generic: peak
        - generic: "1"
    - button "West haven, Seat 2, 1 armies, Seat 2" [ref=e57] [cursor=pointer]:
      - generic:
        - generic: West
        - generic: haven
        - generic: "1"
    - button "Stone watch, Seat 2, 1 armies, Seat 2" [ref=e59] [cursor=pointer]:
      - generic:
        - generic: Stone
        - generic: watch
        - generic: "1"
    - button "Upper ridge, Seat 2, 1 armies, Seat 2" [ref=e61] [cursor=pointer]:
      - generic:
        - generic: Upper
        - generic: ridge
        - generic: "1"
    - button "Marsh keep, Seat 1, 3 armies, Seat 1" [ref=e63] [cursor=pointer]:
      - generic:
        - generic: Marsh
        - generic: keep
        - generic: "3"
    - button "New fell, Seat 4, 1 armies, Seat 4" [ref=e65] [cursor=pointer]:
      - generic:
        - generic: New
        - generic: fell
        - generic: "1"
    - button "Moon point, Seat 2, 1 armies, Seat 2" [ref=e67] [cursor=pointer]:
      - generic:
        - generic: Moon
        - generic: point
        - generic: "1"
    - button "South fell, Seat 1, 3 armies, Seat 1" [ref=e69] [cursor=pointer]:
      - generic:
        - generic: South
        - generic: fell
        - generic: "3"
    - button "High ridge, Seat 2, 1 armies, Seat 2" [ref=e71] [cursor=pointer]:
      - generic:
        - generic: High
        - generic: ridge
        - generic: "1"
    - button "Bay ford, Seat 2, 2 armies, Seat 2" [ref=e73] [cursor=pointer]:
      - generic:
        - generic: Bay
        - generic: ford
        - generic: "2"
    - button "Low moor, Seat 1, 2 armies, Seat 1" [ref=e75] [cursor=pointer]:
      - generic:
        - generic: Low
        - generic: moor
        - generic: "2"
    - button "Lower field, Seat 4, 1 armies, Seat 4" [ref=e77] [cursor=pointer]:
      - generic:
        - generic: Lower
        - generic: field
        - generic: "1"
    - button "Wind gate, Seat 2, 1 armies, Seat 2" [ref=e79] [cursor=pointer]:
      - generic:
        - generic: Wind
        - generic: gate
        - generic: "1"
    - button "Silver shore, Seat 4, 1 armies, Seat 4" [ref=e81] [cursor=pointer]:
      - generic:
        - generic: Silver
        - generic: shore
        - generic: "1"
    - button "Low peak, Seat 4, 1 armies, Seat 4" [ref=e83] [cursor=pointer]:
      - generic:
        - generic: Low
        - generic: peak
        - generic: "1"
    - button "Wind port, Seat 4, 1 armies, Seat 4" [ref=e85] [cursor=pointer]:
      - generic:
        - generic: Wind
        - generic: port
        - generic: "1"
    - button "Gold point, Seat 3, 2 armies, Seat 3" [ref=e87] [cursor=pointer]:
      - generic:
        - generic: Gold
        - generic: point
        - generic: "2"
      - generic [ref=e89]: ★
    - button "Rock moor, Seat 1, 2 armies, Seat 1" [ref=e90] [cursor=pointer]:
      - generic:
        - generic: Rock
        - generic: moor
        - generic: "2"
    - button "Marsh rest, Seat 3, 2 armies, Seat 3" [ref=e92] [cursor=pointer]:
      - generic:
        - generic: Marsh
        - generic: rest
        - generic: "2"
    - button "Wind dale, Seat 4, 1 armies, Seat 4" [ref=e94] [cursor=pointer]:
      - generic:
        - generic: Wind
        - generic: dale
        - generic: "1"
    - button "Silver ford, Seat 4, 2 armies, Seat 4" [ref=e96] [cursor=pointer]:
      - generic:
        - generic: Silver
        - generic: ford
        - generic: "2"
    - button "Iron field, Seat 4, 1 armies, Seat 4" [ref=e98] [cursor=pointer]:
      - generic:
        - generic: Iron
        - generic: field
        - generic: "1"
    - button "North wood, Seat 4, 1 armies, Seat 4" [ref=e100] [cursor=pointer]:
      - generic:
        - generic: North
        - generic: wood
        - generic: "1"
    - button "Fort town, Seat 3, 2 armies, Seat 3" [ref=e102] [cursor=pointer]:
      - generic:
        - generic: Fort
        - generic: town
        - generic: "2"
      - generic [ref=e104]: ★
    - button "Red field, Seat 2, 1 armies, Seat 2" [ref=e105] [cursor=pointer]:
      - generic:
        - generic: Red
        - generic: field
        - generic: "1"
      - generic [ref=e107]: ★
    - button "South ridge, Seat 1, 2 armies, Seat 1" [ref=e108] [cursor=pointer]:
      - generic:
        - generic: South
        - generic: ridge
        - generic: "2"
    - button "Rock bay, Seat 4, 1 armies, Seat 4" [ref=e110] [cursor=pointer]:
      - generic:
        - generic: Rock
        - generic: bay
        - generic: "1"
    - button "North ford, Seat 4, 1 armies, Seat 4" [ref=e112] [cursor=pointer]:
      - generic:
        - generic: North
        - generic: ford
        - generic: "1"
    - button "Port ridge, Seat 3, 3 armies, Seat 3" [ref=e114] [cursor=pointer]:
      - generic:
        - generic: Port
        - generic: ridge
        - generic: "3"
    - button "New rock, Seat 1, 1 armies, Seat 1" [ref=e116] [cursor=pointer]:
      - generic:
        - generic: New
        - generic: rock
        - generic: "1"
    - button "South reach, Seat 3, 3 armies, Seat 3" [ref=e118] [cursor=pointer]:
      - generic:
        - generic: South
        - generic: reach
        - generic: "3"
    - button "Silver point, Seat 3, 1 armies, Seat 3" [ref=e120] [cursor=pointer]:
      - generic:
        - generic: Silver
        - generic: point
        - generic: "1"
    - button "East ford, Seat 4, 1 armies, Seat 4" [ref=e122] [cursor=pointer]:
      - generic:
        - generic: East
        - generic: ford
        - generic: "1"
    - button "Gold town, Seat 4, 1 armies, Seat 4" [ref=e124] [cursor=pointer]:
      - generic:
        - generic: Gold
        - generic: town
        - generic: "1"
    - generic [ref=e156]: North Isle +3
    - generic [ref=e157]: East Isle +3
    - generic [ref=e158]: West Isle +3
    - generic [ref=e159]: South Isle +3
    - generic [ref=e160]: Central Isle +5
    - generic [ref=e161]: Harbor Isle +5
    - generic [ref=e162]: Palm Isle +6
    - generic [ref=e163]: Cliff Isle +5
    - generic [ref=e164]: Great Isle +9
  - toolbar "Game actions" [ref=e165]:
    - button "Show top panel" [ref=e166] [cursor=pointer]:
      - generic [aria-hidden] [ref=e167]: ▤
    - button "Show side panel" [ref=e168] [cursor=pointer]:
      - generic [aria-hidden] [ref=e169]: ◧
    - button "Game actions" [ref=e170] [cursor=pointer]:
      - generic [aria-hidden] [ref=e171]: ⚔
    - button "Cards" [ref=e172] [cursor=pointer]:
      - generic [aria-hidden] [ref=e173]: ▱
    - button "Game details and history" [ref=e174] [cursor=pointer]:
      - generic [aria-hidden] [ref=e175]: ≡
    - button "Game settings and files" [ref=e176] [cursor=pointer]:
      - generic [aria-hidden] [ref=e177]: ⚙
    - button "Pause game" [ref=e178] [cursor=pointer]: Ⅱ Pause
    - button "≡ Game event log" [ref=e179] [cursor=pointer]
    - generic [ref=e180]:
      - button "End turn" [ref=e181] [cursor=pointer]: ↦End turn
      - button "Move armies" [ref=e182] [cursor=pointer]: ⇄Move armies
    - generic: ⚔ ■ ⚀
    - generic "Seat 2 · Attack" [ref=e183]
  - dialog [ref=e184]:
    - generic [ref=e185]:
      - heading "Game actions" [level=2] [ref=e186]
      - button "Close game panel" [active] [ref=e187] [cursor=pointer]:
        - generic [aria-hidden] [ref=e188]: ×
    - region "Battle controls" [ref=e191]:
      - generic [ref=e192]:
        - generic [ref=e193]:
          - generic [ref=e194]: From
          - strong [ref=e195]: Choose your country
          - generic "Source armies" [ref=e196]: —
        - generic [ref=e197]:
          - generic [ref=e198]: Target
          - strong [ref=e199]: Choose an enemy neighbour
          - generic "Target armies" [ref=e200]: —
      - generic [ref=e201]:
        - generic [ref=e202]:
          - text: Stop at armies
          - spinbutton "Stop at armies" [ref=e203]: "2"
        - generic [ref=e204]:
          - text: Battle speed
          - combobox "Battle speed" [ref=e205]:
            - option "Very slow"
            - option "Slow"
            - option "Normal" [selected]
            - option "Fast"
      - generic [ref=e206]:
        - strong [ref=e207]: Ready for your choice
        - paragraph [ref=e208]: Choose your country, then click an enemy to attack. Shift-click or Shift-Enter selects only.
      - paragraph [ref=e209]:
        - text: Won 0 · Lost 0 · Ties
        - strong [ref=e210]: "0"
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test';
  2  | import type {Page,TestInfo} from '@playwright/test';
  3  | import {readFileSync} from 'node:fs';
  4  | import {apply,deserializeVersionedMatch} from '../../src/core';
  5  | import type {Action,GameState} from '../../src/core';
  6  | const fixtureRoot='docs/prototypes/new-game/';
  7  | const input=(name:string)=>readFileSync(fixtureRoot+name,'utf8');
  8  | const discoveries=JSON.parse(input('issue180/preflight/discovery.json'));
  9  | const country=(p:Page,id:string)=>p.locator(`[data-country="${id}"]`);
  10 | async function begin(p:Page){
  11 |  await p.clock.install({time:new Date('2026-10-19T12:00:00Z')});await p.clock.pauseAt(new Date('2026-10-19T12:00:00Z'));
  12 |  await p.goto('/');await p.evaluate(()=>{const create=URL.createObjectURL.bind(URL);URL.createObjectURL=blob=>{Reflect.set(window,'iconSave',blob);return create(blob);};});
  13 | }
  14 | async function open(p:Page,surface:string){
  15 |  const d=p.locator('#game-focus-drawer');if(await d.isVisible()&&await d.getAttribute('data-surface')===surface)return;
  16 |  await p.locator('#open-game-'+surface).click();await expect(d).toBeVisible();await expect(d).toHaveAttribute('data-surface',surface);
  17 | }
  18 | async function close(p:Page){if(await p.locator('#game-focus-drawer').isVisible())await p.locator('#close-game-drawer').click();}
  19 | async function load(p:Page,text:string){
  20 |  if(await p.locator('#battle-action-rail').count())await open(p,'settings');
  21 |  const old=await p.getByLabel('Load game',{exact:true}).elementHandle();await p.getByLabel('Load game',{exact:true}).setInputFiles({name:'icons.json',mimeType:'application/json',buffer:Buffer.from(text)});
  22 |  await expect.poll(()=>old!.evaluate(e=>e.isConnected)).toBe(false);await expect(p.locator('[data-country]')).toHaveCount(46);
  23 | }
  24 | async function save(p:Page){await open(p,'settings');await p.getByRole('button',{name:'Save game',exact:true}).click();const text=await p.evaluate(()=>(Reflect.get(window,'iconSave') as Blob).text());await close(p);return text;}
  25 | async function exact(p:Page,state:GameState){expect(deserializeVersionedMatch(await save(p)).state).toEqual(state);}
  26 | function next(state:GameState,action:Action){const r=apply(state,action);if(!r.ok)throw Error(r.error);return r.state;}
  27 | async function collapse(p:Page){
  28 |  for(const id of ['toggle-topbar','toggle-sidebar'])if(await p.locator('#'+id).getAttribute('aria-expanded')==='true')await p.locator('#'+id).click();
  29 |  await expect(p.locator('.topbar')).toBeHidden();await expect(p.locator('.panel')).toBeHidden();
  30 | }
> 31 | async function hit(p:Page,id:string){const e=p.locator('#'+id);await expect(e).toBeVisible();await expect(e).toBeEnabled();expect(await e.evaluate(n=>{const r=n.getBoundingClientRect(),h=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return r.x>=0&&r.y>=0&&r.right<=innerWidth&&r.bottom<=innerHeight&&!!h&&(n===h||n.contains(h));}),id+' physically reachable').toBe(true);await e.click();}
     |                                                                                                                                                                                                                                                                                                                                                                                  ^ Error: start-friendly-move-button physically reachable
  32 | async function shot(p:Page,info:TestInfo,name:string){await p.screenshot({path:info.outputPath(name+'.png')});}
  33 | function row(host:string,kind:string){return discoveries.find((r:any)=>r.source===(host==='reference'?'T39-legal-pending-raid.json':'geographic-raid-pending-one-human.json')&&r.kind===kind);}
  34 | for(const host of ['reference','geographic']){
  35 |  test(`${host}: collapsed battle commands, pause and details preserve exact actions and selection`,async({page},info)=>{
  36 |   await begin(page);const f=row(host,'attack-running'),text=input('issue180/preflight/fixtures/'+f.fixture),before=deserializeVersionedMatch(text);await load(page,text);await collapse(page);
  37 |   await country(page,f.action.from).click();await country(page,f.action.to).click({modifiers:['Shift']});await open(page,'actions');
  38 |   const source=await page.locator('#battle-source-name').textContent(),target=await page.locator('#battle-target-name').textContent();await page.locator('#battle-stop-threshold').fill('1');await page.locator('#battle-stop-threshold').press('Tab');
  39 |   await page.keyboard.press('Escape');await expect(page.locator('#open-game-actions')).toBeFocused();await open(page,'actions');await expect(page.locator('#battle-source-name')).toHaveText(source!);await expect(page.locator('#battle-target-name')).toHaveText(target!);await expect(page.locator('#battle-stop-threshold')).toHaveValue('1');
  40 |   await hit(page,'game-pause-button');await expect(page.locator('#single-exchange-button')).toBeDisabled();await page.locator('#single-exchange-button').evaluate(e=>(e as HTMLButtonElement).click());await exact(page,before.state);await hit(page,'game-pause-button');
  41 |   await open(page,'actions');await hit(page,'fight-on-button');await page.locator('#stop-battle-button').focus();await page.keyboard.press('Enter');const after=next(before.state,f.action);await exact(page,after);
  42 |   await open(page,'actions');await hit(page,'single-exchange-button');await exact(page,next(after,f.action));
  43 |   await open(page,'details');const history=page.getByRole('list',{name:'Battle log',exact:true});await expect(history.locator('li')).toHaveCount(next(after,f.action).log.filter(e=>e.event!=='game_started').length);await history.evaluate(e=>{e.scrollTop=42;});const reading=await history.evaluate(e=>e.scrollTop);await close(page);await open(page,'settings');await page.locator('#game-speed').selectOption('very-slow');await close(page);await open(page,'details');expect(await history.evaluate(e=>e.scrollTop)).toBe(reading);await shot(page,info,host+'-details');
  44 |   await close(page);await hit(page,'game-log-button');await expect(page.getByRole('dialog',{name:'Game event log',exact:true})).toBeVisible();await page.keyboard.press('Escape');await expect(page.locator('#game-log-button')).toBeFocused();await exact(page,next(after,f.action));
  45 |  });
  46 |  test(`${host}: collapsed capture retains quantity across surfaces, toggles and pause`,async({page},info)=>{
  47 |   await begin(page);const f=row(host,'capture'),text=input('issue180/preflight/fixtures/'+f.fixture),before=deserializeVersionedMatch(text);await load(page,text);await collapse(page);await hit(page,'open-required-action');
  48 |   const amount=before.state.pendingCapture!.max;await page.locator('#capture-amount').fill(String(amount));await close(page);await open(page,'cards');await close(page);await open(page,'actions');await expect(page.locator('#capture-amount')).toHaveValue(String(amount));
  49 |   await hit(page,'toggle-sidebar');await hit(page,'toggle-sidebar');await open(page,'actions');await expect(page.locator('#capture-amount')).toHaveValue(String(amount));await hit(page,'game-pause-button');await expect(page.locator('#confirm-capture-button')).toBeDisabled();await hit(page,'game-pause-button');await expect(page.locator('#capture-amount')).toHaveValue(String(amount));await shot(page,info,host+'-capture');await hit(page,'confirm-capture-button');await exact(page,next(before.state,{kind:'captureMove',amount}));
  50 |  });
  51 |  test(`${host}: collapsed friendly draft survives Escape and surface switches until confirmation`,async({page},info)=>{
  52 |   await begin(page);const envelope=JSON.parse(input(`T71/fixtures/${host}-friendly-movement.json`));envelope.options.seats=envelope.options.seats.map(()=>({kind:'human'}));envelope.options.computerStrengths=[];const text=JSON.stringify(envelope),before=deserializeVersionedMatch(text),discovery=JSON.parse(input('T71/fixtures/fixture-discovery.json')).results.find((r:any)=>r.host===host),action=discovery.found['friendly-movement'].action;
  53 |   await load(page,text);await collapse(page);await open(page,'actions');await hit(page,'start-friendly-move-button');await close(page);await country(page,action.from).click();await country(page,action.to).click();await open(page,'actions');await page.locator('#friendly-move-amount').fill('1');await page.keyboard.press('Escape');await expect(page.locator('#open-game-actions')).toBeFocused();await open(page,'settings');await close(page);await open(page,'actions');await expect(page.locator('#friendly-move-amount')).toHaveValue('1');await shot(page,info,host+'-friendly');await hit(page,'confirm-friendly-move-button');await exact(page,next(before.state,{...action,amount:1}));
  54 |  });
  55 |  test(`${host}: collapsed card trade and nonmodal Raid use ordinary core actions`,async({page},info)=>{
  56 |   await begin(page);const trade=host==='reference'?'T38-legal-Surge-before.json':'geographic-income-before-one-human.json',before=deserializeVersionedMatch(input('T40/fixtures/'+trade));await load(page,input('T40/fixtures/'+trade));await collapse(page);await hit(page,'open-required-action');await page.getByRole('button',{name:/^Surge:/}).click();await exact(page,next(before.state,{kind:'tradeCards',handIndices:[0,1,4]}));
  57 |   const raid=host==='reference'?'T39-legal-pending-raid.json':'geographic-raid-pending-one-human.json',pending=deserializeVersionedMatch(input('T40/fixtures/'+raid));await load(page,input('T40/fixtures/'+raid));await expect(page.locator('#toggle-sidebar')).toHaveAttribute('aria-expanded','false');await expect(page.locator('#toggle-topbar')).toHaveAttribute('aria-expanded','false');await open(page,'cards');await expect(page.locator('#game-focus-drawer')).toHaveAttribute('aria-modal','false');await close(page);await country(page,'province_41').click();await open(page,'cards');await expect(page.getByRole('button',{name:'Confirm raid',exact:true})).toBeEnabled();await hit(page,'game-pause-button');await expect(page.getByRole('button',{name:'Confirm raid',exact:true})).toBeDisabled();await hit(page,'game-pause-button');await shot(page,info,host+'-raid');await page.getByRole('button',{name:'Confirm raid',exact:true}).click();await exact(page,next(pending.state,{kind:'raidTarget',province:'province_41'}));
  58 |  });
  59 | }
  60 | test('collapsed full-hand discard, reward, skip and replacement retain reachable choices and clean surfaces',async({page},info)=>{
  61 |  await begin(page);const text=input('T40/fixtures/T37-reshuffle-before-match.json'),before=deserializeVersionedMatch(text),hand=before.state.cards!.hands[before.state.players.find(p=>p.kind==='human')!.id]!;await load(page,text);await collapse(page);await hit(page,'open-required-action');await expect(page.getByRole('button',{name:/^Discard .*\(card /})).toHaveCount(5);await page.getByRole('button',{name:`Discard ${hand[2]} (card 3)`,exact:true}).click();const after=next(before.state,{kind:'discardCard',handIndex:2});await exact(page,after);await hit(page,'open-required-action');await shot(page,info,'discard-reward');await page.getByRole('button',{name:'Continue',exact:true}).click();await exact(page,after);
  62 |  const replacement=input('T40/fixtures/T38-legal-Surge-before.json'),fresh=deserializeVersionedMatch(replacement);await load(page,replacement);await expect(page.locator('#game-focus-drawer')).toBeHidden();await expect(page.locator('#toggle-sidebar')).toHaveAttribute('aria-expanded','false');await hit(page,'open-required-action');await page.getByRole('button',{name:'Skip cards',exact:true}).click();await exact(page,next(fresh.state,{kind:'skipCards'}));
  63 |  await open(page,'settings');await page.getByRole('button',{name:'New game',exact:true}).click();await expect(page.getByRole('button',{name:'Start game',exact:true})).toBeVisible();await expect(page.locator('#game-focus-drawer')).toHaveCount(0);
  64 | });
  65 | 
```