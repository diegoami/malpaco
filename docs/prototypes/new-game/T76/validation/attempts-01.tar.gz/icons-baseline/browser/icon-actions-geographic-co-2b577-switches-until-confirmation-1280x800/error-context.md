# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: icon-actions.spec.ts >> geographic: collapsed friendly draft survives Escape and surface switches until confirmation
- Location: tests/e2e/icon-actions.spec.ts:51:2

# Error details

```
Test timeout of 5000ms exceeded.
```

```
Error: locator.getAttribute: Test timeout of 5000ms exceeded.
Call log:
  - waiting for locator('#toggle-topbar')

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Generated islands · 4 human seats · Seed 1994
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]:
          - strong [ref=e13]: "Total armies: 24"
          - generic [ref=e14]: 9 provinces
      - generic [ref=e18]:
        - generic [ref=e19]: Seat 2
        - generic [ref=e20]:
          - strong [ref=e21]: "Total armies: 17"
          - generic [ref=e22]: 14 provinces
      - generic [ref=e26]:
        - generic [ref=e27]: Seat 3
        - generic [ref=e28]:
          - strong [ref=e29]: "Total armies: 12"
          - generic [ref=e30]: 11 provinces
      - generic [ref=e34]:
        - generic [ref=e35]: Seat 4
        - generic [ref=e36]:
          - strong [ref=e37]: "Total armies: 14"
          - generic [ref=e38]: 12 provinces
    - generic [ref=e39]:
      - button "Game event log" [ref=e40] [cursor=pointer]
      - button "Pause game" [ref=e41] [cursor=pointer]: Pause
      - generic [ref=e42]: Game speed
      - combobox "Game speed" [ref=e43]:
        - option "Very slow (2 s)"
        - option "Slow"
        - option "Normal" [selected]
        - option "Fast"
      - generic [ref=e44]: Panel detail
      - combobox "Panel detail" [ref=e45]:
        - option "Compact" [selected]
        - option "Detailed"
    - contentinfo [ref=e46]:
      - button "New game" [ref=e47] [cursor=pointer]
    - generic [ref=e48]:
      - button "Save game" [ref=e49] [cursor=pointer]
      - generic [ref=e50]:
        - generic [ref=e51]: Load game
        - button "Load game" [ref=e52]
  - main [ref=e53]:
    - group "Generated island map" [ref=e55]:
      - button "Country 1, Seat 2, 1 armies, Seat 2" [ref=e81] [cursor=pointer]:
        - generic: "1"
      - button "Country 2, Seat 1, 6 armies, Seat 1" [ref=e83] [cursor=pointer]:
        - generic: "6"
      - button "Country 3, Seat 2, 1 armies, Seat 2" [ref=e85] [cursor=pointer]:
        - generic: "1"
      - button "Country 4, Seat 2, 1 armies, Seat 2" [ref=e87] [cursor=pointer]:
        - generic: "1"
      - button "Country 5, Seat 2, 1 armies, Seat 2" [ref=e89] [cursor=pointer]:
        - generic: "1"
      - button "Country 6, Seat 3, 1 armies, Seat 3" [ref=e91] [cursor=pointer]:
        - generic: "1"
      - button "Country 7, Seat 2, 3 armies, Seat 2" [ref=e93] [cursor=pointer]:
        - generic: "3"
      - button "Country 8, Seat 2, 1 armies, Seat 2" [ref=e95] [cursor=pointer]:
        - generic: "1"
      - button "Country 9, Seat 1, 3 armies, Seat 1" [ref=e97] [cursor=pointer]:
        - generic: "3"
      - button "Country 10, Seat 4, 1 armies, Seat 4" [ref=e99] [cursor=pointer]:
        - generic: "1"
      - button "Country 11, Seat 4, 2 armies, Seat 4" [ref=e101] [cursor=pointer]:
        - generic: "2"
      - button "Country 12, Seat 1, 2 armies, Seat 1" [ref=e103] [cursor=pointer]:
        - generic: "2"
      - button "Country 13, Seat 1, 2 armies, Seat 1" [ref=e105] [cursor=pointer]:
        - generic: "2"
      - button "Country 14, Seat 3, 1 armies, Seat 3" [ref=e107] [cursor=pointer]:
        - generic: "1"
      - button "Country 15, Seat 4, 1 armies, Seat 4" [ref=e109] [cursor=pointer]:
        - generic: "1"
      - button "Country 16, Seat 1, 3 armies, Seat 1" [ref=e111] [cursor=pointer]:
        - generic: "3"
      - button "Country 17, Seat 2, 1 armies, Seat 2" [ref=e113] [cursor=pointer]:
        - generic: "1"
      - button "Country 18, Seat 3, 1 armies, Seat 3" [ref=e115] [cursor=pointer]:
        - generic: "1"
      - button "Country 19, Seat 1, 2 armies, Seat 1" [ref=e117] [cursor=pointer]:
        - generic: "2"
      - button "Country 20, Seat 2, 1 armies, Seat 2" [ref=e119] [cursor=pointer]:
        - generic: "1"
      - button "Country 21, Seat 4, 1 armies, Seat 4" [ref=e121] [cursor=pointer]:
        - generic: "1"
      - button "Country 22, Seat 4, 1 armies, Seat 4" [ref=e123] [cursor=pointer]:
        - generic: "1"
      - button "Country 23, Seat 3, 1 armies, Seat 3" [ref=e125] [cursor=pointer]:
        - generic:
          - generic: "1"
          - generic: ★
      - button "Country 24, Seat 3, 1 armies, Seat 3" [ref=e127] [cursor=pointer]:
        - generic: "1"
      - button "Country 25, Seat 3, 1 armies, Seat 3" [ref=e129] [cursor=pointer]:
        - generic: "1"
      - button "Country 26, Seat 4, 1 armies, Seat 4" [ref=e131] [cursor=pointer]:
        - generic: "1"
      - button "Country 27, Seat 3, 1 armies, Seat 3" [ref=e133] [cursor=pointer]:
        - generic: "1"
      - button "Country 28, Seat 1, 1 armies, Seat 1" [ref=e135] [cursor=pointer]:
        - generic: "1"
      - button "Country 29, Seat 1, 3 armies, Seat 1" [ref=e137] [cursor=pointer]:
        - generic: "3"
      - button "Country 30, Seat 3, 1 armies, Seat 3" [ref=e139] [cursor=pointer]:
        - generic: "1"
      - button "Country 31, Seat 2, 1 armies, Seat 2" [ref=e141] [cursor=pointer]:
        - generic: "1"
      - button "Country 32, Seat 2, 1 armies, Seat 2" [ref=e143] [cursor=pointer]:
        - generic: "1"
      - button "Country 33, Seat 3, 1 armies, Seat 3" [ref=e145] [cursor=pointer]:
        - generic: "1"
      - button "Country 34, Seat 3, 2 armies, Seat 3" [ref=e147] [cursor=pointer]:
        - generic:
          - generic: "2"
          - generic: ★
      - button "Country 35, Seat 2, 1 armies, Seat 2" [ref=e149] [cursor=pointer]:
        - generic:
          - generic: "1"
          - generic: ★
      - button "Country 36, Seat 2, 2 armies, Seat 2" [ref=e151] [cursor=pointer]:
        - generic: "2"
      - button "Country 37, Seat 4, 2 armies, Seat 4" [ref=e153] [cursor=pointer]:
        - generic: "2"
      - button "Country 38, Seat 1, 2 armies, Seat 1" [ref=e155] [cursor=pointer]:
        - generic: "2"
      - button "Country 39, Seat 4, 1 armies, Seat 4" [ref=e157] [cursor=pointer]:
        - generic: "1"
      - button "Country 40, Seat 4, 1 armies, Seat 4" [ref=e159] [cursor=pointer]:
        - generic: "1"
      - button "Country 41, Seat 2, 1 armies, Seat 2" [ref=e161] [cursor=pointer]:
        - generic: "1"
      - button "Country 42, Seat 4, 1 armies, Seat 4" [ref=e163] [cursor=pointer]:
        - generic: "1"
      - button "Country 43, Seat 2, 1 armies, Seat 2" [ref=e165] [cursor=pointer]:
        - generic: "1"
      - button "Country 44, Seat 3, 1 armies, Seat 3" [ref=e167] [cursor=pointer]:
        - generic: "1"
      - button "Country 45, Seat 4, 1 armies, Seat 4" [ref=e169] [cursor=pointer]:
        - generic: "1"
      - button "Country 46, Seat 4, 1 armies, Seat 4" [ref=e171] [cursor=pointer]:
        - generic: "1"
    - complementary [ref=e173]:
      - generic [ref=e177]:
        - generic [ref=e178]: Seat 2's turn
        - generic [ref=e179]: Round 1 · Attack
      - generic [ref=e180]:
        - generic [ref=e181]:
          - button "End turn" [ref=e182] [cursor=pointer]
          - button "Move armies" [ref=e183] [cursor=pointer]
        - region "Battle controls" [ref=e184]:
          - generic [ref=e185]:
            - generic [ref=e186]:
              - generic [ref=e187]: From
              - strong [ref=e188]: Choose your country
              - generic "Source armies" [ref=e189]: —
            - generic [ref=e190]:
              - generic [ref=e191]: Target
              - strong [ref=e192]: Choose an enemy neighbour
              - generic "Target armies" [ref=e193]: —
          - generic [ref=e194]:
            - generic [ref=e195]:
              - text: Stop at armies
              - spinbutton "Stop at armies" [ref=e196]: "2"
            - generic [ref=e197]:
              - text: Battle speed
              - combobox "Battle speed" [ref=e198]:
                - option "Very slow"
                - option "Slow"
                - option "Normal" [selected]
                - option "Fast"
          - generic [ref=e199]:
            - button "Fight on" [disabled] [ref=e200]
            - button "Stop" [disabled] [ref=e201]
            - button "Single exchange" [disabled] [ref=e202]
          - generic [ref=e203]:
            - strong [ref=e204]: Ready for your choice
            - paragraph [ref=e205]: Choose your country, then click an enemy to attack. Shift-click or Shift-Enter selects only.
          - paragraph [ref=e206]:
            - text: Won 0 · Lost 0 · Ties
            - strong [ref=e207]: "0"
      - generic [ref=e208]:
        - heading "Battle log" [level=3] [ref=e209]
        - list "Battle log" [ref=e210]:
          - listitem [ref=e211]: "T1 Seat 3: Country 27 → Country 24, took Country 24"
          - listitem [ref=e212]: "T1 Seat 3: Country 24 → Country 25, -1 / -0"
          - listitem [ref=e213]: "T1 Seat 3: Country 24 → Country 25, -1 / -0"
          - listitem [ref=e214]: "T1 Seat 3: Country 24 → Country 25, took Country 25"
          - listitem [ref=e215]: "T1 Seat 3: Country 3 → Country 40, -1 / -0"
          - listitem [ref=e216]: "T1 Seat 3: Country 25 → Country 28, -1 / -0"
          - listitem [ref=e217]: "T1 Seat 3: Country 45 → Country 14, took Country 14"
          - listitem [ref=e218]: "T1 Seat 3: Country 30 → Country 33, took Country 33"
          - listitem [ref=e219]: "T1 Seat 3: Country 21 → Country 18, took Country 18"
          - listitem [ref=e220]: "T1 Seat 3: Country 6 → Country 5, took Country 5"
          - listitem [ref=e221]: "T1 Seat 3: Country 3 → Country 40, -1 / -0"
          - listitem [ref=e222]: T1 Seat 3 ends the turn
          - listitem [ref=e223]: "T1 Seat 4: Country 22 → Country 21, -1 / -0"
          - listitem [ref=e224]: "T1 Seat 4: Country 22 → Country 21, -1 / -0"
          - listitem [ref=e225]: "T1 Seat 4: Country 22 → Country 21, took Country 21"
          - listitem [ref=e226]: "T1 Seat 4: Country 21 → Country 18, -1 / -0"
          - listitem [ref=e227]: "T1 Seat 4: Country 15 → Country 25, -1 / -0"
          - listitem [ref=e228]: "T1 Seat 4: Country 10 → Country 17, -1 / -0"
          - listitem [ref=e229]: "T1 Seat 4: Country 46 → Country 45, took Country 45"
          - listitem [ref=e230]: "T1 Seat 4: Country 21 → Country 18, -1 / -0"
          - listitem [ref=e231]: "T1 Seat 4: Country 42 → Country 37, -0 / -1"
          - listitem [ref=e232]: "T1 Seat 4: Country 42 → Country 37, took Country 37"
          - listitem [ref=e233]: "T1 Seat 4: Country 39 → Country 44, -0 / -1"
          - listitem [ref=e234]: "T1 Seat 4: Country 39 → Country 44, -1 / -0"
          - listitem [ref=e235]: "T1 Seat 4: Country 43 → Country 44, -1 / -0"
          - listitem [ref=e236]: "T1 Seat 4: Country 39 → Country 44, -1 / -0"
          - listitem [ref=e237]: T1 Seat 4 ends the turn
          - listitem [ref=e238]: T1 Seat 1 ends the turn
          - listitem [ref=e239]: "T1 Seat 2: Country 8 → Country 43, -1 / -0"
          - listitem [ref=e240]: "T1 Seat 2: Country 8 → Country 43, -1 / -0"
          - listitem [ref=e241]: "T1 Seat 2: Country 8 → Country 43, -1 / -0"
          - listitem [ref=e242]: "T1 Seat 2: Country 8 → Country 43, took Country 43"
          - listitem [ref=e243]: "T1 Seat 2: Country 35 → Country 36, took Country 36"
          - listitem [ref=e244]: "T1 Seat 2: Country 43 → Country 44, -1 / -0"
          - listitem [ref=e245]: "T1 Seat 2: Country 20 → Country 10, -1 / -0"
          - listitem [ref=e246]: "T1 Seat 2: Country 4 → Country 5, took Country 5"
          - listitem [ref=e247]: "T1 Seat 2: Country 1 → Country 3, took Country 3"
          - listitem [ref=e248]: "T1 Seat 2: Country 32 → Country 31, -0 / -1"
          - listitem [ref=e249]: "T1 Seat 2: Country 32 → Country 31, -1 / -0"
          - listitem [ref=e250]: "T1 Seat 2: Country 32 → Country 31, took Country 31"
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test';
  2  | import type {Page,TestInfo} from '@playwright/test';
  3  | import {readFileSync} from 'node:fs';
  4  | import {apply,deserializeVersionedMatch} from '../../src/core';
  5  | import type {Action,GameState} from '../../src/core';
  6  | const fixtureRoot='docs/prototypes/new-game/';
  7  | const input=(name:string)=>readFileSync(fixtureRoot+name,'utf8');
  8  | const discoveries=JSON.parse(input('issue180/preflight/discovery.json'));
  9  | const country=(p:Page,id:string)=>p.locator(`[data-country="${id}"]`);
  10 | async function begin(p:Page){
  11 |  await p.clock.install({time:new Date('2026-10-19T12:00:00Z')});await p.clock.pauseAt(new Date('2026-10-19T12:00:00Z'));
  12 |  await p.goto('/');await p.evaluate(()=>{const create=URL.createObjectURL.bind(URL);URL.createObjectURL=blob=>{Reflect.set(window,'iconSave',blob);return create(blob);};});
  13 | }
  14 | async function open(p:Page,surface:string){
  15 |  const d=p.locator('#game-focus-drawer');if(await d.isVisible()&&await d.getAttribute('data-surface')===surface)return;
  16 |  await p.locator('#open-game-'+surface).click();await expect(d).toBeVisible();await expect(d).toHaveAttribute('data-surface',surface);
  17 | }
  18 | async function close(p:Page){if(await p.locator('#game-focus-drawer').isVisible())await p.locator('#close-game-drawer').click();}
  19 | async function load(p:Page,text:string){
  20 |  if(await p.locator('#battle-action-rail').count())await open(p,'settings');
  21 |  const old=await p.getByLabel('Load game',{exact:true}).elementHandle();await p.getByLabel('Load game',{exact:true}).setInputFiles({name:'icons.json',mimeType:'application/json',buffer:Buffer.from(text)});
  22 |  await expect.poll(()=>old!.evaluate(e=>e.isConnected)).toBe(false);await expect(p.locator('[data-country]')).toHaveCount(46);
  23 | }
  24 | async function save(p:Page){await open(p,'settings');await p.getByRole('button',{name:'Save game',exact:true}).click();const text=await p.evaluate(()=>(Reflect.get(window,'iconSave') as Blob).text());await close(p);return text;}
  25 | async function exact(p:Page,state:GameState){expect(deserializeVersionedMatch(await save(p)).state).toEqual(state);}
  26 | function next(state:GameState,action:Action){const r=apply(state,action);if(!r.ok)throw Error(r.error);return r.state;}
  27 | async function collapse(p:Page){
> 28 |  for(const id of ['toggle-topbar','toggle-sidebar'])if(await p.locator('#'+id).getAttribute('aria-expanded')==='true')await p.locator('#'+id).click();
     |                                                                                ^ Error: locator.getAttribute: Test timeout of 5000ms exceeded.
  29 |  await expect(p.locator('.topbar')).toBeHidden();await expect(p.locator('.panel')).toBeHidden();
  30 | }
  31 | async function hit(p:Page,id:string){const e=p.locator('#'+id);await expect(e).toBeVisible();await expect(e).toBeEnabled();expect(await e.evaluate(n=>{const r=n.getBoundingClientRect(),h=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return r.x>=0&&r.y>=0&&r.right<=innerWidth&&r.bottom<=innerHeight&&!!h&&(n===h||n.contains(h));}),id+' physically reachable').toBe(true);await e.click();}
  32 | async function shot(p:Page,info:TestInfo,name:string){await p.screenshot({path:info.outputPath(name+'.png')});}
  33 | function row(host:string,kind:string){return discoveries.find((r:any)=>r.source===(host==='reference'?'T39-legal-pending-raid.json':'geographic-raid-pending-one-human.json')&&r.kind===kind);}
  34 | for(const host of ['reference','geographic']){
  35 |  test(`${host}: collapsed battle commands, pause and details preserve exact actions and selection`,async({page},info)=>{
  36 |   await begin(page);const f=row(host,'attack-running'),text=input('issue180/preflight/fixtures/'+f.fixture),before=deserializeVersionedMatch(text);await load(page,text);await collapse(page);
  37 |   await country(page,f.action.from).click();await country(page,f.action.to).click({modifiers:['Shift']});await open(page,'actions');
  38 |   const source=await page.locator('#battle-source-name').textContent(),target=await page.locator('#battle-target-name').textContent();await page.locator('#battle-stop-threshold').fill('1');await page.locator('#battle-stop-threshold').press('Tab');
  39 |   await page.keyboard.press('Escape');await expect(page.locator('#open-game-actions')).toBeFocused();await open(page,'actions');await expect(page.locator('#battle-source-name')).toHaveText(source!);await expect(page.locator('#battle-target-name')).toHaveText(target!);await expect(page.locator('#battle-stop-threshold')).toHaveValue('1');
  40 |   await hit(page,'game-pause-button');await expect(page.locator('#single-exchange-button')).toBeDisabled();await page.locator('#single-exchange-button').evaluate(e=>(e as HTMLButtonElement).click());await exact(page,before.state);await hit(page,'game-pause-button');
  41 |   await open(page,'actions');await hit(page,'fight-on-button');await page.locator('#stop-battle-button').focus();await page.keyboard.press('Enter');const after=next(before.state,f.action);await exact(page,after);
  42 |   await open(page,'actions');await hit(page,'single-exchange-button');await exact(page,next(after,f.action));
  43 |   await open(page,'details');const history=page.getByRole('list',{name:'Battle log',exact:true});await expect(history.locator('li')).toHaveCount(next(after,f.action).log.filter(e=>e.event!=='game_started').length);await history.evaluate(e=>{e.scrollTop=42;});const reading=await history.evaluate(e=>e.scrollTop);await close(page);await open(page,'settings');await page.locator('#game-speed').selectOption('very-slow');await close(page);await open(page,'details');expect(await history.evaluate(e=>e.scrollTop)).toBe(reading);await shot(page,info,host+'-details');
  44 |   await close(page);await hit(page,'game-log-button');await expect(page.getByRole('dialog',{name:'Game event log',exact:true})).toBeVisible();await page.keyboard.press('Escape');await expect(page.locator('#game-log-button')).toBeFocused();await exact(page,next(after,f.action));
  45 |  });
  46 |  test(`${host}: collapsed capture retains quantity across surfaces, toggles and pause`,async({page},info)=>{
  47 |   await begin(page);const f=row(host,'capture'),text=input('issue180/preflight/fixtures/'+f.fixture),before=deserializeVersionedMatch(text);await load(page,text);await collapse(page);await hit(page,'open-required-action');
  48 |   const amount=before.state.pendingCapture!.max;await page.locator('#capture-amount').fill(String(amount));await close(page);await open(page,'cards');await close(page);await open(page,'actions');await expect(page.locator('#capture-amount')).toHaveValue(String(amount));
  49 |   await hit(page,'toggle-sidebar');await hit(page,'toggle-sidebar');await open(page,'actions');await expect(page.locator('#capture-amount')).toHaveValue(String(amount));await hit(page,'game-pause-button');await expect(page.locator('#confirm-capture-button')).toBeDisabled();await hit(page,'game-pause-button');await expect(page.locator('#capture-amount')).toHaveValue(String(amount));await shot(page,info,host+'-capture');await hit(page,'confirm-capture-button');await exact(page,next(before.state,{kind:'captureMove',amount}));
  50 |  });
  51 |  test(`${host}: collapsed friendly draft survives Escape and surface switches until confirmation`,async({page},info)=>{
  52 |   await begin(page);const envelope=JSON.parse(input(`T71/fixtures/${host}-friendly-movement.json`));envelope.options.seats=envelope.options.seats.map(()=>({kind:'human'}));envelope.options.computerStrengths=[];const text=JSON.stringify(envelope),before=deserializeVersionedMatch(text),discovery=JSON.parse(input('T71/fixtures/fixture-discovery.json')).results.find((r:any)=>r.host===host),action=discovery.found['friendly-movement'].action;
  53 |   await load(page,text);await collapse(page);await open(page,'actions');await hit(page,'start-friendly-move-button');await close(page);await country(page,action.from).click();await country(page,action.to).click();await open(page,'actions');await page.locator('#friendly-move-amount').fill('1');await page.keyboard.press('Escape');await expect(page.locator('#open-game-actions')).toBeFocused();await open(page,'settings');await close(page);await open(page,'actions');await expect(page.locator('#friendly-move-amount')).toHaveValue('1');await shot(page,info,host+'-friendly');await hit(page,'confirm-friendly-move-button');await exact(page,next(before.state,{...action,amount:1}));
  54 |  });
  55 |  test(`${host}: collapsed card trade and nonmodal Raid use ordinary core actions`,async({page},info)=>{
  56 |   await begin(page);const trade=host==='reference'?'T38-legal-Surge-before.json':'geographic-income-before-one-human.json',before=deserializeVersionedMatch(input('T40/fixtures/'+trade));await load(page,input('T40/fixtures/'+trade));await collapse(page);await hit(page,'open-required-action');await page.getByRole('button',{name:/^Surge:/}).click();await exact(page,next(before.state,{kind:'tradeCards',handIndices:[0,1,4]}));
  57 |   const raid=host==='reference'?'T39-legal-pending-raid.json':'geographic-raid-pending-one-human.json',pending=deserializeVersionedMatch(input('T40/fixtures/'+raid));await load(page,input('T40/fixtures/'+raid));await expect(page.locator('#toggle-sidebar')).toHaveAttribute('aria-expanded','false');await expect(page.locator('#toggle-topbar')).toHaveAttribute('aria-expanded','false');await open(page,'cards');await expect(page.locator('#game-focus-drawer')).toHaveAttribute('aria-modal','false');await close(page);await country(page,'province_41').click();await open(page,'cards');await expect(page.getByRole('button',{name:'Confirm raid',exact:true})).toBeEnabled();await hit(page,'game-pause-button');await expect(page.getByRole('button',{name:'Confirm raid',exact:true})).toBeDisabled();await hit(page,'game-pause-button');await shot(page,info,host+'-raid');await page.getByRole('button',{name:'Confirm raid',exact:true}).click();await exact(page,next(pending.state,{kind:'raidTarget',province:'province_41'}));
  58 |  });
  59 | }
  60 | test('collapsed full-hand discard, reward, skip and replacement retain reachable choices and clean surfaces',async({page},info)=>{
  61 |  await begin(page);const text=input('T40/fixtures/T37-reshuffle-before-match.json'),before=deserializeVersionedMatch(text),hand=before.state.cards!.hands[before.state.players.find(p=>p.kind==='human')!.id]!;await load(page,text);await collapse(page);await hit(page,'open-required-action');await expect(page.getByRole('button',{name:/^Discard .*\(card /})).toHaveCount(5);await page.getByRole('button',{name:`Discard ${hand[2]} (card 3)`,exact:true}).click();const after=next(before.state,{kind:'discardCard',handIndex:2});await exact(page,after);await hit(page,'open-required-action');await shot(page,info,'discard-reward');await page.getByRole('button',{name:'Continue',exact:true}).click();await exact(page,after);
  62 |  const replacement=input('T40/fixtures/T38-legal-Surge-before.json'),fresh=deserializeVersionedMatch(replacement);await load(page,replacement);await expect(page.locator('#game-focus-drawer')).toBeHidden();await expect(page.locator('#toggle-sidebar')).toHaveAttribute('aria-expanded','false');await hit(page,'open-required-action');await page.getByRole('button',{name:'Skip cards',exact:true}).click();await exact(page,next(fresh.state,{kind:'skipCards'}));
  63 |  await open(page,'settings');await page.getByRole('button',{name:'New game',exact:true}).click();await expect(page.getByRole('button',{name:'Start game',exact:true})).toBeVisible();await expect(page.locator('#game-focus-drawer')).toHaveCount(0);
  64 | });
  65 | 
```