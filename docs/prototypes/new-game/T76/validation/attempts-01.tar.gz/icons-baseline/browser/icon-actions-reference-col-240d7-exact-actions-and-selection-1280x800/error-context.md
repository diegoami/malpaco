# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: icon-actions.spec.ts >> reference: collapsed battle commands, pause and details preserve exact actions and selection
- Location: tests/e2e/icon-actions.spec.ts:35:2

# Error details

```
Test timeout of 5000ms exceeded.
```

```
Error: locator.getAttribute: Test timeout of 5000ms exceeded.
Call log:
  - waiting for locator('#toggle-topbar')

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 1 human / 3 computer seats · Computer play · Seed 1
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1 · Computer
        - generic [ref=e12]:
          - strong [ref=e13]: "Total armies: 36"
          - generic [ref=e14]: 15 provinces
      - generic [ref=e18]:
        - generic [ref=e19]: Seat 2 · Computer
        - generic [ref=e20]:
          - strong [ref=e21]: "Total armies: 9"
          - generic [ref=e22]: 6 provinces
      - generic [ref=e26]:
        - generic [ref=e27]: Seat 3 · Computer
        - generic [ref=e28]:
          - strong [ref=e29]: "Total armies: 33"
          - generic [ref=e30]: 11 provinces
      - generic [ref=e34]:
        - generic [ref=e35]: Seat 4
        - generic [ref=e36]:
          - strong [ref=e37]: "Total armies: 31"
          - generic [ref=e38]: 14 provinces
    - generic [ref=e39]:
      - button "Game event log" [ref=e40] [cursor=pointer]
      - button "Pause game" [ref=e41] [cursor=pointer]: Pause
      - generic [ref=e42]: Game speed
      - combobox "Game speed" [ref=e43]:
        - option "Very slow (2 s)"
        - option "Slow"
        - option "Normal" [selected]
        - option "Fast"
      - generic [ref=e44]: Panel detail
      - combobox "Panel detail" [ref=e45]:
        - option "Compact" [selected]
        - option "Detailed"
    - contentinfo [ref=e46]:
      - button "New game" [ref=e47] [cursor=pointer]
    - generic [ref=e48]:
      - button "Save game" [ref=e49] [cursor=pointer]
      - generic [ref=e50]:
        - generic [ref=e51]: Load game
        - button "Load game" [ref=e52]
  - main [ref=e53]:
    - img "Nine Isles reference map" [ref=e55]:
      - button "River gate, Seat 1, 5 armies, Seat 1" [ref=e81] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: "5"
      - button "New port, Seat 1, 1 armies, Seat 1" [ref=e83] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: "1"
      - button "North rest, Seat 1, 1 armies, Seat 1" [ref=e85] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: "1"
      - button "River keep, Seat 1, 1 armies, Seat 1" [ref=e87] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: "1"
      - button "North town, Seat 1, 1 armies, Seat 1" [ref=e89] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: "1"
      - button "Dark ford, Seat 1, 8 armies, Seat 1" [ref=e91] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: "8"
        - generic [ref=e93]: ★
      - button "Iron point, Seat 3, 1 armies, Seat 3" [ref=e94] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: "1"
      - button "South rest, Seat 3, 13 armies, Seat 3" [ref=e96] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: "13"
      - button "High shore, Seat 3, 9 armies, Seat 3" [ref=e98] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: "9"
      - button "Wind town, Seat 3, 2 armies, Seat 3" [ref=e100] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: "2"
      - button "New glen, Seat 3, 1 armies, Seat 3" [ref=e102] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: "1"
      - button "Old rock, Seat 4, 1 armies, Seat 4" [ref=e104] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: "1"
      - button "Blue peak, Seat 1, 1 armies, Seat 1" [ref=e106] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: "1"
      - button "West haven, Seat 1, 1 armies, Seat 1" [ref=e108] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: "1"
      - button "Stone watch, Seat 3, 1 armies, Seat 3" [ref=e110] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: "1"
      - button "Upper ridge, Seat 1, 2 armies, Seat 1" [ref=e112] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: "2"
      - button "Marsh keep, Seat 1, 1 armies, Seat 1" [ref=e114] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: "1"
      - button "New fell, Seat 4, 1 armies, Seat 4" [ref=e116] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: "1"
        - generic [ref=e118]: ★
      - button "Moon point, Seat 3, 1 armies, Seat 3" [ref=e119] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: "1"
      - button "South fell, Seat 4, 8 armies, Seat 4" [ref=e121] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: "8"
      - button "High ridge, Seat 3, 1 armies, Seat 3" [ref=e123] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: "1"
      - button "Bay ford, Seat 2, 2 armies, Seat 2" [ref=e125] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: "2"
      - button "Low moor, Seat 4, 1 armies, Seat 4" [ref=e127] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: "1"
      - button "Lower field, Seat 3, 1 armies, Seat 3" [ref=e129] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: "1"
      - button "Wind gate, Seat 2, 3 armies, Seat 2" [ref=e131] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: "3"
      - button "Silver shore, Seat 4, 4 armies, Seat 4" [ref=e133] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: "4"
      - button "Low peak, Seat 4, 1 armies, Seat 4" [ref=e135] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: "1"
      - button "Wind port, Seat 2, 1 armies, Seat 2" [ref=e137] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: "1"
      - button "Gold point, Seat 2, 1 armies, Seat 2" [ref=e139] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: "1"
      - button "Rock moor, Seat 1, 8 armies, Seat 1" [ref=e141] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: "8"
      - button "Marsh rest, Seat 1, 2 armies, Seat 1" [ref=e143] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: "2"
      - button "Wind dale, Seat 1, 2 armies, Seat 1" [ref=e145] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: "2"
      - button "Silver ford, Seat 1, 1 armies, Seat 1" [ref=e147] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: "1"
      - button "Iron field, Seat 1, 1 armies, Seat 1" [ref=e149] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: "1"
      - button "North wood, Seat 2, 1 armies, Seat 2" [ref=e151] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: "1"
      - button "Fort town, Seat 3, 1 armies, Seat 3" [ref=e153] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: "1"
      - button "Red field, Seat 2, 1 armies, Seat 2" [ref=e155] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: "1"
      - button "South ridge, Seat 4, 1 armies, Seat 4" [ref=e157] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: "1"
      - button "Rock bay, Seat 4, 2 armies, Seat 4" [ref=e159] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: "2"
      - button "North ford, Seat 4, 1 armies, Seat 4" [ref=e161] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: "1"
      - button "Port ridge, Seat 3, 2 armies, Seat 3" [ref=e163] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: "2"
      - button "New rock, Seat 4, 1 armies, Seat 4" [ref=e165] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: "1"
      - button "South reach, Seat 4, 2 armies, Seat 4" [ref=e167] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: "2"
        - generic [ref=e169]: ★
      - button "Silver point, Seat 4, 1 armies, Seat 4" [ref=e170] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: "1"
      - button "East ford, Seat 4, 6 armies, Seat 4" [ref=e172] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: "6"
      - button "Gold town, Seat 4, 1 armies, Seat 4" [ref=e174] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: "1"
      - generic [ref=e206]: North Isle +3
      - generic [ref=e207]: East Isle +3
      - generic [ref=e208]: West Isle +3
      - generic [ref=e209]: South Isle +3
      - generic [ref=e210]: Central Isle +5
      - generic [ref=e211]: Harbor Isle +5
      - generic [ref=e212]: Palm Isle +6
      - generic [ref=e213]: Cliff Isle +5
      - generic [ref=e214]: Great Isle +9
    - complementary [ref=e215]:
      - generic [ref=e219]:
        - generic [ref=e220]: Seat 4's turn
        - generic [ref=e221]: Round 8 · Attack
      - generic [ref=e222]:
        - generic [ref=e223]:
          - button "End turn" [ref=e224] [cursor=pointer]
          - button "Move armies" [ref=e225] [cursor=pointer]
        - region "Battle controls" [ref=e226]:
          - generic [ref=e227]:
            - generic [ref=e228]:
              - generic [ref=e229]: From
              - strong [ref=e230]: Choose your country
              - generic "Source armies" [ref=e231]: —
            - generic [ref=e232]:
              - generic [ref=e233]: Target
              - strong [ref=e234]: Choose an enemy neighbour
              - generic "Target armies" [ref=e235]: —
          - generic [ref=e236]:
            - generic [ref=e237]:
              - text: Stop at armies
              - spinbutton "Stop at armies" [ref=e238]: "2"
            - generic [ref=e239]:
              - text: Battle speed
              - combobox "Battle speed" [ref=e240]:
                - option "Very slow"
                - option "Slow"
                - option "Normal" [selected]
                - option "Fast"
          - generic [ref=e241]:
            - button "Fight on" [disabled] [ref=e242]
            - button "Stop" [disabled] [ref=e243]
            - button "Single exchange" [disabled] [ref=e244]
          - generic [ref=e245]:
            - strong [ref=e246]: Ready for your choice
            - paragraph [ref=e247]: Choose your country, then click an enemy to attack. Shift-click or Shift-Enter selects only.
          - paragraph [ref=e248]:
            - text: Won 0 · Lost 0 · Ties
            - strong [ref=e249]: "0"
        - region "Cards" [ref=e250]:
          - paragraph [ref=e251]: "Draw: 15 · Discard: 7 · Top: Surge. seat1: 4 · seat2: 4 · seat3: 5 · seat4: 5"
          - 'button "View your hand: 5 of 5" [ref=e252] [cursor=pointer]'
      - generic [ref=e253]:
        - heading "Battle log" [level=3] [ref=e254]
        - list "Battle log" [ref=e255]:
          - listitem [ref=e256]: "T1 Seat 4: Silver shore → Low moor, -1 / -0"
          - listitem [ref=e257]: "T1 Seat 4: Silver shore → Low moor, took Low moor"
          - listitem [ref=e258]: T1 Seat 4 ends the turn
          - listitem [ref=e259]: "T1 Seat 1: Upper ridge → Blue peak, -0 / -1"
          - listitem [ref=e260]: "T1 Seat 1: Upper ridge → Blue peak, -0 / -1"
          - listitem [ref=e261]: "T1 Seat 1: Upper ridge → Blue peak, took Blue peak"
          - listitem [ref=e262]: T1 Seat 1 ends the turn
          - listitem [ref=e263]: "T1 Seat 2: River keep → North town, -1 / -0"
          - listitem [ref=e264]: "T1 Seat 2: River keep → North town, -1 / -0"
          - listitem [ref=e265]: "T1 Seat 2: River keep → North town, -1 / -0"
          - listitem [ref=e266]: "T1 Seat 2: River keep → North rest, -1 / -0"
          - listitem [ref=e267]: "T1 Seat 2: Bay ford → New glen, -1 / -0"
          - listitem [ref=e268]: T1 Seat 2 ends the turn
          - listitem [ref=e269]: "T1 Seat 3: South rest → Iron point, -1 / -0"
          - listitem [ref=e270]: "T1 Seat 3: South rest → Iron point, took Iron point"
          - listitem [ref=e271]: T1 Seat 3 ends the turn
          - listitem [ref=e272]: "T2 Seat 4: Silver shore → Low peak, -1 / -0"
          - listitem [ref=e273]: "T2 Seat 4: Silver shore → Low peak, -1 / -0"
          - listitem [ref=e274]: "T2 Seat 4: Silver shore → Low peak, -1 / -0"
          - listitem [ref=e275]: "T2 Seat 4: Silver shore → Low peak, took Low peak"
          - listitem [ref=e276]: T2 Seat 4 ends the turn
          - listitem [ref=e277]: "T2 Seat 1: Upper ridge → West haven, -1 / -0"
          - listitem [ref=e278]: "T2 Seat 1: Upper ridge → West haven, -0 / -1"
          - listitem [ref=e279]: "T2 Seat 1: Upper ridge → West haven, -1 / -0"
          - listitem [ref=e280]: "T2 Seat 1: Upper ridge → West haven, -1 / -0"
          - listitem [ref=e281]: "T2 Seat 1: Upper ridge → West haven, -1 / -0"
          - listitem [ref=e282]: "T2 Seat 1: Upper ridge → West haven, -1 / -0"
          - listitem [ref=e283]: "T2 Seat 1: Upper ridge → West haven, -1 / -0"
          - listitem [ref=e284]: "T2 Seat 1: Upper ridge → West haven, took West haven"
          - listitem [ref=e285]: T2 Seat 1 ends the turn
          - listitem [ref=e286]: "T2 Seat 2: Wind gate → Wind port, -0 / -1"
          - listitem [ref=e287]: "T2 Seat 2: Wind gate → Wind port, took Wind port"
          - listitem [ref=e288]: T2 Seat 2 ends the turn
          - listitem [ref=e289]: "T2 Seat 3: South rest → Stone watch, -1 / -0"
          - listitem [ref=e290]: "T2 Seat 3: South rest → Stone watch, -1 / -0"
          - listitem [ref=e291]: "T2 Seat 3: South rest → Stone watch, -1 / -0"
          - listitem [ref=e292]: "T2 Seat 3: South rest → Stone watch, -1 / -0"
          - listitem [ref=e293]: "T2 Seat 3: South rest → Stone watch, took Stone watch"
          - listitem [ref=e294]: T2 Seat 3 ends the turn
          - listitem [ref=e295]: "T3 Seat 4: Red field → Wind gate, -1 / -0"
          - listitem [ref=e296]: "T3 Seat 4: Red field → Stone watch, -1 / -0"
          - listitem [ref=e297]: "T3 Seat 4: Red field → Stone watch, -1 / -0"
          - listitem [ref=e298]: "T3 Seat 4: Red field → Stone watch, took Stone watch"
          - listitem [ref=e299]: T3 Seat 4 ends the turn
          - listitem [ref=e300]: "T3 Seat 1: Rock moor → Silver ford, -0 / -1"
          - listitem [ref=e301]: "T3 Seat 1: Rock moor → Silver ford, -0 / -1"
          - listitem [ref=e302]: "T3 Seat 1: Rock moor → Silver ford, took Silver ford"
          - listitem [ref=e303]: T3 Seat 1 ends the turn
          - listitem [ref=e304]: "T3 Seat 2: Wind gate → Red field, -0 / -1"
          - listitem [ref=e305]: "T3 Seat 2: Wind gate → Red field, -0 / -1"
          - listitem [ref=e306]: "T3 Seat 2: Wind gate → Red field, -1 / -0"
          - listitem [ref=e307]: "T3 Seat 2: Wind gate → Red field, -1 / -0"
          - listitem [ref=e308]: "T3 Seat 2: Wind gate → Red field, took Red field"
          - listitem [ref=e309]: T3 Seat 2 ends the turn
          - listitem [ref=e310]: "T3 Seat 3: South rest → Stone watch, -1 / -0"
          - listitem [ref=e311]: "T3 Seat 3: South rest → Stone watch, took Stone watch"
          - listitem [ref=e312]: T3 Seat 3 ends the turn
          - listitem [ref=e313]: "T4 Seat 4: East ford → North ford, -1 / -0"
          - listitem [ref=e314]: "T4 Seat 4: East ford → North ford, -1 / -0"
          - listitem [ref=e315]: "T4 Seat 4: East ford → Silver point, took Silver point"
          - listitem [ref=e316]: T4 Seat 4 ends the turn
          - listitem [ref=e317]: "T4 Seat 1: Rock moor → Iron field, -1 / -0"
          - listitem [ref=e318]: "T4 Seat 1: Rock moor → Iron field, -0 / -1"
          - listitem [ref=e319]: "T4 Seat 1: Rock moor → Iron field, took Iron field"
          - listitem [ref=e320]: T4 Seat 1 ends the turn
          - listitem [ref=e321]: "T4 Seat 2: River keep → North town, -0 / -1"
          - listitem [ref=e322]: "T4 Seat 2: River keep → North town, -1 / -0"
          - listitem [ref=e323]: "T4 Seat 2: River keep → North town, -1 / -0"
          - listitem [ref=e324]: "T4 Seat 2: River keep → North town, -1 / -0"
          - listitem [ref=e325]: T4 Seat 2 ends the turn
          - listitem [ref=e326]: "T4 Seat 3: South rest → Fort town, -0 / -1"
          - listitem [ref=e327]: "T4 Seat 3: South rest → Fort town, -1 / -0"
          - listitem [ref=e328]: "T4 Seat 3: South rest → Fort town, took Fort town"
          - listitem [ref=e329]: T4 Seat 3 ends the turn
          - listitem [ref=e330]: "T5 Seat 4: East ford → North ford, -0 / -1"
          - listitem [ref=e331]: "T5 Seat 4: East ford → North ford, -0 / -1"
          - listitem [ref=e332]: "T5 Seat 4: East ford → North ford, -1 / -0"
          - listitem [ref=e333]: "T5 Seat 4: East ford → North ford, took North ford"
          - listitem [ref=e334]: T5 Seat 4 ends the turn
          - listitem [ref=e335]: "T5 Seat 1: River gate → New port, -0 / -1"
          - listitem [ref=e336]: "T5 Seat 1: River gate → New port, took New port"
          - listitem [ref=e337]: T5 Seat 1 ends the turn
          - listitem [ref=e338]: "T5 Seat 2: River keep → North town, took North town"
          - listitem [ref=e339]: T5 Seat 2 ends the turn
          - listitem [ref=e340]: "T5 Seat 3: High shore → Lower field, -1 / -0"
          - listitem [ref=e341]: "T5 Seat 3: High shore → Lower field, -1 / -0"
          - listitem [ref=e342]: "T5 Seat 3: High shore → Lower field, -1 / -0"
          - listitem [ref=e343]: "T5 Seat 3: High shore → Lower field, -1 / -0"
          - listitem [ref=e344]: "T5 Seat 3: High shore → Lower field, -1 / -0"
          - listitem [ref=e345]: "T5 Seat 3: High shore → Lower field, -1 / -0"
          - listitem [ref=e346]: "T5 Seat 3: New fell → Moon point, took Moon point"
          - listitem [ref=e347]: T5 Seat 3 ends the turn
          - listitem [ref=e348]: "T6 Seat 4: East ford → Gold town, -0 / -1"
          - listitem [ref=e349]: "T6 Seat 4: East ford → Gold town, -1 / -0"
          - listitem [ref=e350]: "T6 Seat 4: East ford → Gold town, took Gold town"
          - listitem [ref=e351]: T6 Seat 4 ends the turn
          - listitem [ref=e352]: "T6 Seat 1: Dark ford → River keep, -0 / -1"
          - listitem [ref=e353]: "T6 Seat 1: Dark ford → River keep, -1 / -0"
          - listitem [ref=e354]: "T6 Seat 1: Dark ford → River keep, -1 / -0"
          - listitem [ref=e355]: "T6 Seat 1: Dark ford → River keep, -1 / -0"
          - listitem [ref=e356]: "T6 Seat 1: Dark ford → River keep, -0 / -1"
          - listitem [ref=e357]: "T6 Seat 1: Dark ford → River keep, -0 / -1"
          - listitem [ref=e358]: "T6 Seat 1: Dark ford → River keep, -1 / -0"
          - listitem [ref=e359]: "T6 Seat 1: Dark ford → River keep, took River keep"
          - listitem [ref=e360]: T6 Seat 1 ends the turn
          - listitem [ref=e361]: "T6 Seat 2: Bay ford → Moon point, -1 / -0"
          - listitem [ref=e362]: "T6 Seat 2: Bay ford → Moon point, -1 / -0"
          - listitem [ref=e363]: T6 Seat 2 ends the turn
          - listitem [ref=e364]: "T6 Seat 3: High shore → Lower field, -1 / -0"
          - listitem [ref=e365]: "T6 Seat 3: High shore → Lower field, -1 / -0"
          - listitem [ref=e366]: "T6 Seat 3: High shore → Lower field, -1 / -0"
          - listitem [ref=e367]: "T6 Seat 3: High shore → Lower field, -0 / -1"
          - listitem [ref=e368]: "T6 Seat 3: High shore → Lower field, took Lower field"
          - listitem [ref=e369]: T6 Seat 3 ends the turn
          - listitem [ref=e370]: "T7 Seat 4: South fell → New fell, -0 / -1"
          - listitem [ref=e371]: "T7 Seat 4: South fell → New fell, took New fell"
          - listitem [ref=e372]: T7 Seat 4 ends the turn
          - listitem [ref=e373]: "T7 Seat 1: Dark ford → North town, -1 / -0"
          - listitem [ref=e374]: "T7 Seat 1: Dark ford → North town, -1 / -0"
          - listitem [ref=e375]: "T7 Seat 1: Dark ford → North town, took North town"
          - listitem [ref=e376]: T7 Seat 1 ends the turn
          - listitem [ref=e377]: "T7 Seat 2: Wind gate → Lower field, -1 / -0"
          - listitem [ref=e378]: "T7 Seat 2: Wind gate → Lower field, -1 / -0"
          - listitem [ref=e379]: "T7 Seat 2: Wind gate → Lower field, -1 / -0"
          - listitem [ref=e380]: "T7 Seat 2: Wind gate → Lower field, took Lower field"
          - listitem [ref=e381]: T7 Seat 2 ends the turn
          - listitem [ref=e382]: "T7 Seat 3: High shore → Lower field, -1 / -0"
          - listitem [ref=e383]: "T7 Seat 3: High shore → Lower field, took Lower field"
          - listitem [ref=e384]: T7 Seat 3 ends the turn
          - listitem [ref=e385]: "T8 Seat 4: South fell → High ridge, -1 / -0"
          - listitem [ref=e386]: "T8 Seat 4: South fell → High ridge, -0 / -1"
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test';
  2  | import type {Page,TestInfo} from '@playwright/test';
  3  | import {readFileSync} from 'node:fs';
  4  | import {apply,deserializeVersionedMatch} from '../../src/core';
  5  | import type {Action,GameState} from '../../src/core';
  6  | const fixtureRoot='docs/prototypes/new-game/';
  7  | const input=(name:string)=>readFileSync(fixtureRoot+name,'utf8');
  8  | const discoveries=JSON.parse(input('issue180/preflight/discovery.json'));
  9  | const country=(p:Page,id:string)=>p.locator(`[data-country="${id}"]`);
  10 | async function begin(p:Page){
  11 |  await p.clock.install({time:new Date('2026-10-19T12:00:00Z')});await p.clock.pauseAt(new Date('2026-10-19T12:00:00Z'));
  12 |  await p.goto('/');await p.evaluate(()=>{const create=URL.createObjectURL.bind(URL);URL.createObjectURL=blob=>{Reflect.set(window,'iconSave',blob);return create(blob);};});
  13 | }
  14 | async function open(p:Page,surface:string){
  15 |  const d=p.locator('#game-focus-drawer');if(await d.isVisible()&&await d.getAttribute('data-surface')===surface)return;
  16 |  await p.locator('#open-game-'+surface).click();await expect(d).toBeVisible();await expect(d).toHaveAttribute('data-surface',surface);
  17 | }
  18 | async function close(p:Page){if(await p.locator('#game-focus-drawer').isVisible())await p.locator('#close-game-drawer').click();}
  19 | async function load(p:Page,text:string){
  20 |  if(await p.locator('#battle-action-rail').count())await open(p,'settings');
  21 |  const old=await p.getByLabel('Load game',{exact:true}).elementHandle();await p.getByLabel('Load game',{exact:true}).setInputFiles({name:'icons.json',mimeType:'application/json',buffer:Buffer.from(text)});
  22 |  await expect.poll(()=>old!.evaluate(e=>e.isConnected)).toBe(false);await expect(p.locator('[data-country]')).toHaveCount(46);
  23 | }
  24 | async function save(p:Page){await open(p,'settings');await p.getByRole('button',{name:'Save game',exact:true}).click();const text=await p.evaluate(()=>(Reflect.get(window,'iconSave') as Blob).text());await close(p);return text;}
  25 | async function exact(p:Page,state:GameState){expect(deserializeVersionedMatch(await save(p)).state).toEqual(state);}
  26 | function next(state:GameState,action:Action){const r=apply(state,action);if(!r.ok)throw Error(r.error);return r.state;}
  27 | async function collapse(p:Page){
> 28 |  for(const id of ['toggle-topbar','toggle-sidebar'])if(await p.locator('#'+id).getAttribute('aria-expanded')==='true')await p.locator('#'+id).click();
     |                                                                                ^ Error: locator.getAttribute: Test timeout of 5000ms exceeded.
  29 |  await expect(p.locator('.topbar')).toBeHidden();await expect(p.locator('.panel')).toBeHidden();
  30 | }
  31 | async function hit(p:Page,id:string){const e=p.locator('#'+id);await expect(e).toBeVisible();await expect(e).toBeEnabled();expect(await e.evaluate(n=>{const r=n.getBoundingClientRect(),h=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return r.x>=0&&r.y>=0&&r.right<=innerWidth&&r.bottom<=innerHeight&&!!h&&(n===h||n.contains(h));}),id+' physically reachable').toBe(true);await e.click();}
  32 | async function shot(p:Page,info:TestInfo,name:string){await p.screenshot({path:info.outputPath(name+'.png')});}
  33 | function row(host:string,kind:string){return discoveries.find((r:any)=>r.source===(host==='reference'?'T39-legal-pending-raid.json':'geographic-raid-pending-one-human.json')&&r.kind===kind);}
  34 | for(const host of ['reference','geographic']){
  35 |  test(`${host}: collapsed battle commands, pause and details preserve exact actions and selection`,async({page},info)=>{
  36 |   await begin(page);const f=row(host,'attack-running'),text=input('issue180/preflight/fixtures/'+f.fixture),before=deserializeVersionedMatch(text);await load(page,text);await collapse(page);
  37 |   await country(page,f.action.from).click();await country(page,f.action.to).click({modifiers:['Shift']});await open(page,'actions');
  38 |   const source=await page.locator('#battle-source-name').textContent(),target=await page.locator('#battle-target-name').textContent();await page.locator('#battle-stop-threshold').fill('1');await page.locator('#battle-stop-threshold').press('Tab');
  39 |   await page.keyboard.press('Escape');await expect(page.locator('#open-game-actions')).toBeFocused();await open(page,'actions');await expect(page.locator('#battle-source-name')).toHaveText(source!);await expect(page.locator('#battle-target-name')).toHaveText(target!);await expect(page.locator('#battle-stop-threshold')).toHaveValue('1');
  40 |   await hit(page,'game-pause-button');await expect(page.locator('#single-exchange-button')).toBeDisabled();await page.locator('#single-exchange-button').evaluate(e=>(e as HTMLButtonElement).click());await exact(page,before.state);await hit(page,'game-pause-button');
  41 |   await open(page,'actions');await hit(page,'fight-on-button');await page.locator('#stop-battle-button').focus();await page.keyboard.press('Enter');const after=next(before.state,f.action);await exact(page,after);
  42 |   await open(page,'actions');await hit(page,'single-exchange-button');await exact(page,next(after,f.action));
  43 |   await open(page,'details');const history=page.getByRole('list',{name:'Battle log',exact:true});await expect(history.locator('li')).toHaveCount(next(after,f.action).log.filter(e=>e.event!=='game_started').length);await history.evaluate(e=>{e.scrollTop=42;});const reading=await history.evaluate(e=>e.scrollTop);await close(page);await open(page,'settings');await page.locator('#game-speed').selectOption('very-slow');await close(page);await open(page,'details');expect(await history.evaluate(e=>e.scrollTop)).toBe(reading);await shot(page,info,host+'-details');
  44 |   await close(page);await hit(page,'game-log-button');await expect(page.getByRole('dialog',{name:'Game event log',exact:true})).toBeVisible();await page.keyboard.press('Escape');await expect(page.locator('#game-log-button')).toBeFocused();await exact(page,next(after,f.action));
  45 |  });
  46 |  test(`${host}: collapsed capture retains quantity across surfaces, toggles and pause`,async({page},info)=>{
  47 |   await begin(page);const f=row(host,'capture'),text=input('issue180/preflight/fixtures/'+f.fixture),before=deserializeVersionedMatch(text);await load(page,text);await collapse(page);await hit(page,'open-required-action');
  48 |   const amount=before.state.pendingCapture!.max;await page.locator('#capture-amount').fill(String(amount));await close(page);await open(page,'cards');await close(page);await open(page,'actions');await expect(page.locator('#capture-amount')).toHaveValue(String(amount));
  49 |   await hit(page,'toggle-sidebar');await hit(page,'toggle-sidebar');await open(page,'actions');await expect(page.locator('#capture-amount')).toHaveValue(String(amount));await hit(page,'game-pause-button');await expect(page.locator('#confirm-capture-button')).toBeDisabled();await hit(page,'game-pause-button');await expect(page.locator('#capture-amount')).toHaveValue(String(amount));await shot(page,info,host+'-capture');await hit(page,'confirm-capture-button');await exact(page,next(before.state,{kind:'captureMove',amount}));
  50 |  });
  51 |  test(`${host}: collapsed friendly draft survives Escape and surface switches until confirmation`,async({page},info)=>{
  52 |   await begin(page);const envelope=JSON.parse(input(`T71/fixtures/${host}-friendly-movement.json`));envelope.options.seats=envelope.options.seats.map(()=>({kind:'human'}));envelope.options.computerStrengths=[];const text=JSON.stringify(envelope),before=deserializeVersionedMatch(text),discovery=JSON.parse(input('T71/fixtures/fixture-discovery.json')).results.find((r:any)=>r.host===host),action=discovery.found['friendly-movement'].action;
  53 |   await load(page,text);await collapse(page);await open(page,'actions');await hit(page,'start-friendly-move-button');await close(page);await country(page,action.from).click();await country(page,action.to).click();await open(page,'actions');await page.locator('#friendly-move-amount').fill('1');await page.keyboard.press('Escape');await expect(page.locator('#open-game-actions')).toBeFocused();await open(page,'settings');await close(page);await open(page,'actions');await expect(page.locator('#friendly-move-amount')).toHaveValue('1');await shot(page,info,host+'-friendly');await hit(page,'confirm-friendly-move-button');await exact(page,next(before.state,{...action,amount:1}));
  54 |  });
  55 |  test(`${host}: collapsed card trade and nonmodal Raid use ordinary core actions`,async({page},info)=>{
  56 |   await begin(page);const trade=host==='reference'?'T38-legal-Surge-before.json':'geographic-income-before-one-human.json',before=deserializeVersionedMatch(input('T40/fixtures/'+trade));await load(page,input('T40/fixtures/'+trade));await collapse(page);await hit(page,'open-required-action');await page.getByRole('button',{name:/^Surge:/}).click();await exact(page,next(before.state,{kind:'tradeCards',handIndices:[0,1,4]}));
  57 |   const raid=host==='reference'?'T39-legal-pending-raid.json':'geographic-raid-pending-one-human.json',pending=deserializeVersionedMatch(input('T40/fixtures/'+raid));await load(page,input('T40/fixtures/'+raid));await expect(page.locator('#toggle-sidebar')).toHaveAttribute('aria-expanded','false');await expect(page.locator('#toggle-topbar')).toHaveAttribute('aria-expanded','false');await open(page,'cards');await expect(page.locator('#game-focus-drawer')).toHaveAttribute('aria-modal','false');await close(page);await country(page,'province_41').click();await open(page,'cards');await expect(page.getByRole('button',{name:'Confirm raid',exact:true})).toBeEnabled();await hit(page,'game-pause-button');await expect(page.getByRole('button',{name:'Confirm raid',exact:true})).toBeDisabled();await hit(page,'game-pause-button');await shot(page,info,host+'-raid');await page.getByRole('button',{name:'Confirm raid',exact:true}).click();await exact(page,next(pending.state,{kind:'raidTarget',province:'province_41'}));
  58 |  });
  59 | }
  60 | test('collapsed full-hand discard, reward, skip and replacement retain reachable choices and clean surfaces',async({page},info)=>{
  61 |  await begin(page);const text=input('T40/fixtures/T37-reshuffle-before-match.json'),before=deserializeVersionedMatch(text),hand=before.state.cards!.hands[before.state.players.find(p=>p.kind==='human')!.id]!;await load(page,text);await collapse(page);await hit(page,'open-required-action');await expect(page.getByRole('button',{name:/^Discard .*\(card /})).toHaveCount(5);await page.getByRole('button',{name:`Discard ${hand[2]} (card 3)`,exact:true}).click();const after=next(before.state,{kind:'discardCard',handIndex:2});await exact(page,after);await hit(page,'open-required-action');await shot(page,info,'discard-reward');await page.getByRole('button',{name:'Continue',exact:true}).click();await exact(page,after);
  62 |  const replacement=input('T40/fixtures/T38-legal-Surge-before.json'),fresh=deserializeVersionedMatch(replacement);await load(page,replacement);await expect(page.locator('#game-focus-drawer')).toBeHidden();await expect(page.locator('#toggle-sidebar')).toHaveAttribute('aria-expanded','false');await hit(page,'open-required-action');await page.getByRole('button',{name:'Skip cards',exact:true}).click();await exact(page,next(fresh.state,{kind:'skipCards'}));
  63 |  await open(page,'settings');await page.getByRole('button',{name:'New game',exact:true}).click();await expect(page.getByRole('button',{name:'Start game',exact:true})).toBeVisible();await expect(page.locator('#game-focus-drawer')).toHaveCount(0);
  64 | });
  65 | 
```