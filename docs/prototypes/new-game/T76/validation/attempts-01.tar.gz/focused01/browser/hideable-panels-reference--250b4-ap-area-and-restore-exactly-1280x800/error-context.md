# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: hideable-panels.spec.ts >> reference: independently hidden panels reclaim map area and restore exactly
- Location: tests/e2e/hideable-panels.spec.ts:24:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator:  locator('#open-game-cards')
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - Expect "toBeVisible" locator('#open-game-cards') with timeout 5000ms
  - waiting for locator('#open-game-cards')
    14 × locator resolved to <button type="button" title="Cards" class="game-icon" aria-label="Cards" id="open-game-cards" aria-controls="game-focus-drawer">…</button>
       - unexpected value "hidden"

```

```yaml
- main:
  - img "Nine Isles reference map":
    - button "River gate, Seat 3, 2 armies, Seat 3": River gate 2
    - button "New port, Seat 1, 2 armies, Seat 1": New port 2
    - button "North rest, Seat 2, 1 armies, Seat 2": North rest 1
    - button "River keep, Seat 2, 1 armies, Seat 2": River keep 1
    - button "North town, Seat 2, 1 armies, Seat 2": North town 1
    - button "Dark ford, Seat 3, 1 armies, Seat 3": Dark ford 1
    - button "Iron point, Seat 3, 1 armies, Seat 3": Iron point 1
    - button "South rest, Seat 3, 3 armies, Seat 3": South rest 3
    - button "High shore, Seat 1, 2 armies, Seat 1": High shore 2
    - button "Wind town, Seat 2, 3 armies, Seat 2": Wind town 3
    - button "New glen, Seat 4, 2 armies, Seat 4": New glen 2
    - button "Old rock, Seat 3, 2 armies, Seat 3": Old rock 2
    - button "Blue peak, Seat 2, 3 armies, Seat 2": Blue peak 3
    - button "West haven, Seat 2, 1 armies, Seat 2": West haven 1
    - button "Stone watch, Seat 2, 3 armies, Seat 2": Stone watch 3
    - button "Upper ridge, Seat 4, 2 armies, Seat 4": Upper ridge 2
    - button "Marsh keep, Seat 1, 3 armies, Seat 1": Marsh keep 3
    - button "New fell, Seat 4, 2 armies, Seat 4": New fell 2
    - button "Moon point, Seat 2, 2 armies, Seat 2": Moon point 2
    - button "South fell, Seat 1, 3 armies, Seat 1": South fell 3
    - button "High ridge, Seat 2, 2 armies, Seat 2": High ridge 2
    - button "Bay ford, Seat 2, 3 armies, Seat 2": Bay ford 3
    - button "Low moor, Seat 1, 2 armies, Seat 1": Low moor 2
    - button "Lower field, Seat 1, 1 armies, Seat 1": Lower field 1
    - button "Wind gate, Seat 3, 1 armies, Seat 3": Wind gate 1
    - button "Silver shore, Seat 4, 1 armies, Seat 4": Silver shore 1
    - button "Low peak, Seat 4, 1 armies, Seat 4": Low peak 1
    - button "Wind port, Seat 4, 3 armies, Seat 4": Wind port 3
    - button "Gold point, Seat 3, 2 armies, Seat 3": Gold point 2 ★
    - button "Rock moor, Seat 1, 2 armies, Seat 1": Rock moor 2
    - button "Marsh rest, Seat 3, 2 armies, Seat 3": Marsh rest 2
    - button "Wind dale, Seat 4, 1 armies, Seat 4": Wind dale 1
    - button "Silver ford, Seat 4, 2 armies, Seat 4": Silver ford 2
    - button "Iron field, Seat 4, 2 armies, Seat 4": Iron field 2
    - button "North wood, Seat 1, 1 armies, Seat 1": North wood 1
    - button "Fort town, Seat 3, 2 armies, Seat 3": Fort town 2 ★
    - button "Red field, Seat 2, 3 armies, Seat 2": Red field 3 ★
    - button "South ridge, Seat 1, 2 armies, Seat 1": South ridge 2
    - button "Rock bay, Seat 2, 1 armies, Seat 2": Rock bay 1
    - button "North ford, Seat 4, 3 armies, Seat 4": North ford 3
    - button "Port ridge, Seat 3, 3 armies, Seat 3": Port ridge 3
    - button "New rock, Seat 1, 1 armies, Seat 1": New rock 1
    - button "South reach, Seat 3, 3 armies, Seat 3": South reach 3
    - button "Silver point, Seat 3, 2 armies, Seat 3": Silver point 2
    - button "East ford, Seat 1, 3 armies, Seat 1": East ford 3
    - button "Gold town, Seat 4, 3 armies, Seat 4": Gold town 3
    - text: North Isle +3 East Isle +3 West Isle +3 South Isle +3 Central Isle +5 Harbor Isle +5 Palm Isle +6 Cliff Isle +5 Great Isle +9
  - toolbar "Game actions":
    - button "Show top panel"
    - button "Show side panel"
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | import type {Page,TestInfo} from '@playwright/test';
  3  | import {readFileSync} from 'node:fs';
  4  | 
  5  | async function begin(page:Page,host:string,kind:'layout'|'cards') {
  6  |   await page.clock.install({time:new Date('2026-10-19T12:00:00Z')});
  7  |   await page.clock.pauseAt(new Date('2026-10-19T12:00:00Z'));
  8  |   const errors:string[]=[];page.on('pageerror',e=>errors.push(String(e)));
  9  |   await page.goto(host==='reference'?'/?view=reference-game':'/',{waitUntil:'domcontentloaded'});
  10 |   await page.evaluate(()=>{const create=URL.createObjectURL.bind(URL);URL.createObjectURL=blob=>{Reflect.set(window,'t76Save',blob);return create(blob);};});
  11 |   const path=kind==='layout'?`docs/prototypes/new-game/T71/fixtures/${host}-reinforcement.json`:
  12 |     `docs/prototypes/new-game/T40/fixtures/${host==='reference'?'T38-legal-Surge-before.json':'geographic-income-before-one-human.json'}`;
  13 |   const old=await page.getByLabel('Load game',{exact:true}).elementHandle();
  14 |   await page.getByLabel('Load game',{exact:true}).setInputFiles({name:'panels.json',mimeType:'application/json',buffer:Buffer.from(readFileSync(path))});
  15 |   await expect.poll(()=>old!.evaluate(e=>e.isConnected)).toBe(false);
  16 |   await expect(page.locator('.battle-reference [data-country]')).toHaveCount(46);
  17 |   return errors;
  18 | }
  19 | async function save(page:Page){await page.getByRole('button',{name:'Save game',exact:true}).click();return page.evaluate(()=>(Reflect.get(window,'t76Save') as Blob).text());}
  20 | async function box(page:Page){return page.locator('.battle-reference .board').evaluate(e=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height};});}
> 21 | async function fits(page:Page,selector:string){const e=page.locator(selector);await expect(e).toBeVisible();expect(await e.evaluate(n=>{const r=n.getBoundingClientRect(),hit=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return r.width>0&&r.height>0&&r.x>=0&&r.y>=0&&r.right<=innerWidth&&r.bottom<=innerHeight&&!!hit&&(n===hit||n.contains(hit));})).toBe(true);}
     |                                                                                               ^ Error: expect(locator).toBeVisible() failed
  22 | async function evidence(page:Page,info:TestInfo,label:string){await page.screenshot({path:info.outputPath(label+'.png')});await info.attach(label,{body:JSON.stringify({board:await box(page),scroll:await page.evaluate(()=>({width:document.documentElement.scrollWidth,height:document.documentElement.scrollHeight,innerWidth,innerHeight}))}),contentType:'application/json'});}
  23 | for(const host of ['reference','geographic']){
  24 |   test(`${host}: independently hidden panels reclaim map area and restore exactly`,async({page},info)=>{
  25 |     const errors=await begin(page,host,'layout');const before=await save(page),original=await box(page);
  26 |     const top=page.locator('#toggle-topbar'),side=page.locator('#toggle-sidebar');
  27 |     await expect(top).toHaveAttribute('aria-expanded','true',{timeout:1000});
  28 |     await expect(side).toHaveAttribute('aria-expanded','true',{timeout:1000});
  29 |     await evidence(page,info,'expanded');
  30 |     await top.click();await expect(top).toHaveAttribute('aria-expanded','false');await expect(page.locator('.battle-reference .topbar')).toBeHidden();
  31 |     const topHidden=await box(page);expect(topHidden.height).toBeGreaterThan(original.height+24);expect(topHidden.width).toBe(original.width);
  32 |     await side.click();await expect(side).toHaveAttribute('aria-expanded','false');
  33 |     const both=await box(page);expect(both.width).toBeGreaterThan(original.width+200);expect(both.height).toBe(topHidden.height);
  34 |     const rail=page.locator('#battle-action-rail');await expect(rail).toHaveAttribute('role','toolbar');expect((await rail.boundingBox())!.width).toBeLessThanOrEqual(72);
  35 |     for(const id of ['toggle-topbar','toggle-sidebar','open-game-cards','open-game-details','open-game-settings']){await fits(page,'#'+id);const control=page.locator('#'+id);await expect(control).toHaveAccessibleName(/\S/);await expect(control).toHaveAttribute('title',/\S/);}
  36 |     expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight)).toBe(true);
  37 |     await evidence(page,info,'both-hidden');
  38 |     await top.focus();await top.press('Enter');await expect(top).toHaveAttribute('aria-expanded','true');
  39 |     const sideOnly=await box(page);expect(sideOnly.width).toBe(both.width);expect(sideOnly.height).toBe(original.height);
  40 |     await side.focus();await side.press('Space');await expect(side).toHaveAttribute('aria-expanded','true');expect(await box(page)).toEqual(original);
  41 |     expect(await save(page)).toBe(before);expect(errors).toEqual([]);
  42 |   });
  43 |   test(`${host}: icon cards surface closes with Escape and returns focus without game actions`,async({page},info)=>{
  44 |     const errors=await begin(page,host,'cards');const before=await save(page);
  45 |     const top=page.locator('#toggle-topbar'),side=page.locator('#toggle-sidebar');
  46 |     await expect(side).toBeVisible({timeout:1000});await side.click();await top.click();
  47 |     const cards=page.locator('#open-game-cards');await fits(page,'#open-game-cards');await cards.click();
  48 |     const drawer=page.locator('#game-focus-drawer');await expect(drawer).toBeVisible();await expect(drawer).toHaveAttribute('role','dialog');
  49 |     await expect(drawer.locator('.card-interactions')).toBeVisible();await fits(page,'#close-game-drawer');await evidence(page,info,'cards-drawer');
  50 |     await page.keyboard.press('Escape');await expect(drawer).toBeHidden();await expect(cards).toBeFocused();
  51 |     await cards.press('Enter');await expect(drawer).toBeVisible();await page.locator('#close-game-drawer').click();await expect(cards).toBeFocused();
  52 |     await top.click();await side.click();expect(await save(page)).toBe(before);expect(errors).toEqual([]);
  53 |   });
  54 | }
  55 | 
```