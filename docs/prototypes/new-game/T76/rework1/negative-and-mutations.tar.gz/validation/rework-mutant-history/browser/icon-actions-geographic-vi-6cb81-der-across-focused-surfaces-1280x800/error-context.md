# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: icon-actions.spec.ts >> geographic: visible sidebar keeps an older history reader across focused surfaces
- Location: tests/e2e/icon-actions.spec.ts:36:2

# Error details

```
Error: moving visible history must keep the latest reading position

expect(received).toBeLessThan(expected)

Expected: < 0.5
Received:   3493
```

# Page snapshot

```yaml
- main [ref=e3]:
  - group "Generated island map" [ref=e5]:
    - button "Country 1, Seat 3, 1 armies, Seat 3" [ref=e31] [cursor=pointer]:
      - generic: "1"
    - button "Country 2, Seat 3, 1 armies, Seat 3" [ref=e33] [cursor=pointer]:
      - generic: "1"
    - button "Country 3, Seat 3, 35 armies, Seat 3" [ref=e35] [cursor=pointer]:
      - generic: "35"
    - button "Country 4, Seat 3, 1 armies, Seat 3" [ref=e37] [cursor=pointer]:
      - generic: "1"
    - button "Country 5, Seat 4, 1 armies, Seat 4" [ref=e39] [cursor=pointer]:
      - generic: "1"
    - button "Country 6, Seat 3, 2 armies, Seat 3" [ref=e41] [cursor=pointer]:
      - generic: "2"
    - button "Country 7, Seat 2, 3 armies, Seat 2" [ref=e43] [cursor=pointer]:
      - generic: "3"
    - button "Country 8, Seat 2, 1 armies, Seat 2" [ref=e45] [cursor=pointer]:
      - generic: "1"
    - button "Country 9, Seat 2, 1 armies, Seat 2" [ref=e47] [cursor=pointer]:
      - generic: "1"
    - button "Country 10, Seat 1, 8 armies, Seat 1" [ref=e49] [cursor=pointer]:
      - generic: "8"
    - button "Country 11, Seat 1, 12 armies, Seat 1" [ref=e51] [cursor=pointer]:
      - generic: "12"
    - button "Country 12, Seat 1, 15 armies, Seat 1" [ref=e53] [cursor=pointer]:
      - generic: "15"
    - button "Country 13, Seat 1, 2 armies, Seat 1" [ref=e55] [cursor=pointer]:
      - generic: "2"
    - button "Country 14, Seat 1, 45 armies, Seat 1" [ref=e57] [cursor=pointer]:
      - generic: "45"
    - button "Country 15, Seat 1, 1 armies, Seat 1" [ref=e59] [cursor=pointer]:
      - generic: "1"
    - button "Country 16, Seat 1, 4 armies, Seat 1" [ref=e61] [cursor=pointer]:
      - generic: "4"
    - button "Country 17, Seat 1, 1 armies, Seat 1" [ref=e63] [cursor=pointer]:
      - generic: "1"
    - button "Country 18, Seat 2, 1 armies, Seat 2" [ref=e65] [cursor=pointer]:
      - generic: "1"
    - button "Country 19, Seat 1, 1 armies, Seat 1" [ref=e67] [cursor=pointer]:
      - generic: "1"
    - button "Country 20, Seat 1, 1 armies, Seat 1" [ref=e69] [cursor=pointer]:
      - generic: "1"
    - button "Country 21, Seat 3, 2 armies, Seat 3" [ref=e71] [cursor=pointer]:
      - generic: "2"
    - button "Country 22, Seat 1, 1 armies, Seat 1" [ref=e73] [cursor=pointer]:
      - generic: "1"
    - button "Country 23, Seat 3, 1 armies, Seat 3" [ref=e75] [cursor=pointer]:
      - generic:
        - generic: "1"
        - generic: ★
    - button "Country 24, Seat 1, 1 armies, Seat 1" [ref=e77] [cursor=pointer]:
      - generic: "1"
    - button "Country 25, Seat 1, 1 armies, Seat 1" [ref=e79] [cursor=pointer]:
      - generic: "1"
    - button "Country 26, Seat 4, 1 armies, Seat 4" [ref=e81] [cursor=pointer]:
      - generic: "1"
    - button "Country 27, Seat 3, 3 armies, Seat 3" [ref=e83] [cursor=pointer]:
      - generic: "3"
    - button "Country 28, Seat 1, 1 armies, Seat 1" [ref=e85] [cursor=pointer]:
      - generic: "1"
    - button "Country 29, Seat 1, 10 armies, Seat 1" [ref=e87] [cursor=pointer]:
      - generic: "10"
    - button "Country 30, Seat 3, 2 armies, Seat 3" [ref=e89] [cursor=pointer]:
      - generic: "2"
    - button "Country 31, Seat 2, 1 armies, Seat 2" [ref=e91] [cursor=pointer]:
      - generic: "1"
    - button "Country 32, Seat 2, 38 armies, Seat 2" [ref=e93] [cursor=pointer]:
      - generic: "38"
    - button "Country 33, Seat 1, 1 armies, Seat 1" [ref=e95] [cursor=pointer]:
      - generic: "1"
    - button "Country 34, Seat 3, 2 armies, Seat 3" [ref=e97] [cursor=pointer]:
      - generic:
        - generic: "2"
        - generic: ★
    - button "Country 35, Seat 2, 3 armies, Seat 2" [ref=e99] [cursor=pointer]:
      - generic:
        - generic: "3"
        - generic: ★
    - button "Country 36, Seat 2, 1 armies, Seat 2" [ref=e101] [cursor=pointer]:
      - generic: "1"
    - button "Country 37, Seat 4, 1 armies, Seat 4" [ref=e103] [cursor=pointer]:
      - generic: "1"
    - button "Country 38, Seat 4, 1 armies, Seat 4" [ref=e105] [cursor=pointer]:
      - generic: "1"
    - button "Country 39, Seat 4, 15 armies, Seat 4" [ref=e107] [cursor=pointer]:
      - generic: "15"
    - button "Country 40, Seat 4, 1 armies, Seat 4" [ref=e109] [cursor=pointer]:
      - generic: "1"
    - button "Country 41, Seat 2, 1 armies, Seat 2" [ref=e111] [cursor=pointer]:
      - generic: "1"
    - button "Country 42, Seat 4, 4 armies, Seat 4" [ref=e113] [cursor=pointer]:
      - generic: "4"
    - button "Country 43, Seat 4, 4 armies, Seat 4" [ref=e115] [cursor=pointer]:
      - generic: "4"
    - button "Country 44, Seat 1, 1 armies, Seat 1" [ref=e117] [cursor=pointer]:
      - generic: "1"
    - button "Country 45, Seat 1, 1 armies, Seat 1" [ref=e119] [cursor=pointer]:
      - generic: "1"
    - button "Country 46, Seat 4, 2 armies, Seat 4" [ref=e121] [cursor=pointer]:
      - generic: "2"
  - complementary [ref=e123]:
    - generic [ref=e127]:
      - generic [ref=e128]: Seat 4's turn
      - generic [ref=e129]: Round 13 · Attack
    - generic [ref=e130]:
      - generic [ref=e131]:
        - button "End turn" [ref=e132] [cursor=pointer]
        - button "Move armies" [ref=e133] [cursor=pointer]
      - region "Battle controls" [ref=e134]:
        - generic [ref=e135]:
          - generic [ref=e136]:
            - generic [ref=e137]: From
            - strong [ref=e138]: Choose your country
            - generic "Source armies" [ref=e139]: —
          - generic [ref=e140]:
            - generic [ref=e141]: Target
            - strong [ref=e142]: Choose an enemy neighbour
            - generic "Target armies" [ref=e143]: —
        - generic [ref=e144]:
          - generic [ref=e145]:
            - text: Stop at armies
            - spinbutton "Stop at armies" [ref=e146]: "2"
          - generic [ref=e147]:
            - text: Battle speed
            - combobox "Battle speed" [ref=e148]:
              - option "Very slow"
              - option "Slow"
              - option "Normal" [selected]
              - option "Fast"
        - generic [ref=e149]:
          - button "Fight on" [disabled] [ref=e150]
          - button "Stop" [disabled] [ref=e151]
          - button "Single exchange" [disabled] [ref=e152]
        - generic [ref=e153]:
          - strong [ref=e154]: Ready for your choice
          - paragraph [ref=e155]: Choose your country, then click an enemy to attack. Shift-click or Shift-Enter selects only.
        - paragraph [ref=e156]:
          - text: Won 0 · Lost 0 · Ties
          - strong [ref=e157]: "0"
      - region "Cards" [ref=e158]:
        - paragraph [ref=e159]: "Draw: 19 · Discard: 5 · Top: Surge. seat1: 5 · seat2: 1 · seat3: 5 · seat4: 5"
        - 'button "View your hand: 5 of 5" [ref=e160] [cursor=pointer]'
  - toolbar "Game actions" [ref=e161]:
    - button "Show top panel" [ref=e162] [cursor=pointer]
    - button "Hide side panel" [expanded] [ref=e165] [cursor=pointer]
    - button "Game actions" [ref=e168] [cursor=pointer]
    - button "Cards" [ref=e171] [cursor=pointer]
    - button "Game details and history" [ref=e174] [cursor=pointer]
    - button "Game settings and files" [ref=e177] [cursor=pointer]
    - button "Pause game" [ref=e180] [cursor=pointer]: Pause
    - button "Game event log" [ref=e183] [cursor=pointer]
    - generic "Seat 4 · Attack" [ref=e186]: Seat 4 Attack
  - dialog [ref=e187]:
    - generic [ref=e188]:
      - heading "Game details" [level=2] [ref=e189]
      - button "Close game panel" [active] [ref=e190] [cursor=pointer]
    - generic [ref=e193]:
      - generic [ref=e194]:
        - generic [ref=e198]:
          - generic [ref=e199]: Seat 1 · Computer
          - generic [ref=e200]:
            - strong [ref=e201]: "Total armies: 107"
            - generic [ref=e202]: 18 provinces
        - generic [ref=e206]:
          - generic [ref=e207]: Seat 2 · Computer
          - generic [ref=e208]:
            - strong [ref=e209]: "Total armies: 50"
            - generic [ref=e210]: 9 provinces
        - generic [ref=e214]:
          - generic [ref=e215]: Seat 3 · Computer
          - generic [ref=e216]:
            - strong [ref=e217]: "Total armies: 50"
            - generic [ref=e218]: 10 provinces
        - generic [ref=e222]:
          - generic [ref=e223]: Seat 4
          - generic [ref=e224]:
            - strong [ref=e225]: "Total armies: 30"
            - generic [ref=e226]: 9 provinces
      - generic [ref=e227]:
        - heading "Battle log" [level=3] [ref=e228]
        - list "Battle log" [ref=e229]:
          - listitem [ref=e230]: "T1 Seat 3: Country 3 → Country 2, -0 / -1"
          - listitem [ref=e231]: "T1 Seat 3: Country 3 → Country 2, -0 / -1"
          - listitem [ref=e232]: "T1 Seat 3: Country 3 → Country 2, took Country 2"
          - listitem [ref=e233]: T1 Seat 3 ends the turn
          - listitem [ref=e234]: "T1 Seat 4: Country 22 → Country 19, -1 / -0"
          - listitem [ref=e235]: "T1 Seat 4: Country 22 → Country 19, -0 / -1"
          - listitem [ref=e236]: "T1 Seat 4: Country 22 → Country 19, -1 / -0"
          - listitem [ref=e237]: "T1 Seat 4: Country 22 → Country 19, -1 / -0"
          - listitem [ref=e238]: "T1 Seat 4: Country 22 → Country 19, -1 / -0"
          - listitem [ref=e239]: T1 Seat 4 ends the turn
          - listitem [ref=e240]: "T1 Seat 1: Country 9 → Country 8, -0 / -1"
          - listitem [ref=e241]: "T1 Seat 1: Country 9 → Country 8, -1 / -0"
          - listitem [ref=e242]: "T1 Seat 1: Country 9 → Country 8, -0 / -1"
          - listitem [ref=e243]: "T1 Seat 1: Country 9 → Country 8, took Country 8"
          - listitem [ref=e244]: T1 Seat 1 ends the turn
          - listitem [ref=e245]: "T1 Seat 2: Country 7 → Country 9, -0 / -1"
          - listitem [ref=e246]: "T1 Seat 2: Country 7 → Country 9, -0 / -1"
          - listitem [ref=e247]: "T1 Seat 2: Country 7 → Country 9, -0 / -1"
          - listitem [ref=e248]: "T1 Seat 2: Country 7 → Country 9, -1 / -0"
          - listitem [ref=e249]: "T1 Seat 2: Country 7 → Country 9, -1 / -0"
          - listitem [ref=e250]: "T1 Seat 2: Country 7 → Country 9, took Country 9"
          - listitem [ref=e251]: T1 Seat 2 ends the turn
          - listitem [ref=e252]: "T2 Seat 3: Country 3 → Country 1, -1 / -0"
          - listitem [ref=e253]: "T2 Seat 3: Country 3 → Country 1, -1 / -0"
          - listitem [ref=e254]: "T2 Seat 3: Country 3 → Country 1, -1 / -0"
          - listitem [ref=e255]: "T2 Seat 3: Country 3 → Country 1, -1 / -0"
          - listitem [ref=e256]: "T2 Seat 3: Country 3 → Country 1, -0 / -1"
          - listitem [ref=e257]: "T2 Seat 3: Country 3 → Country 1, -1 / -0"
          - listitem [ref=e258]: "T2 Seat 3: Country 3 → Country 1, took Country 1"
          - listitem [ref=e259]: T2 Seat 3 ends the turn
          - listitem [ref=e260]: "T2 Seat 4: Country 39 → Country 44, -1 / -0"
          - listitem [ref=e261]: "T2 Seat 4: Country 39 → Country 44, -0 / -1"
          - listitem [ref=e262]: "T2 Seat 4: Country 39 → Country 44, took Country 44"
          - listitem [ref=e263]: T2 Seat 4 ends the turn
          - listitem [ref=e264]: "T2 Seat 1: Country 16 → Country 15, -1 / -0"
          - listitem [ref=e265]: "T2 Seat 1: Country 16 → Country 15, -0 / -1"
          - listitem [ref=e266]: "T2 Seat 1: Country 16 → Country 15, took Country 15"
          - listitem [ref=e267]: T2 Seat 1 ends the turn
          - listitem [ref=e268]: "T2 Seat 2: Country 7 → Country 8, -1 / -0"
          - listitem [ref=e269]: "T2 Seat 2: Country 7 → Country 8, took Country 8"
          - listitem [ref=e270]: T2 Seat 2 ends the turn
          - listitem [ref=e271]: "T3 Seat 3: Country 3 → Country 4, -0 / -1"
          - listitem [ref=e272]: "T3 Seat 3: Country 3 → Country 4, took Country 4"
          - listitem [ref=e273]: T3 Seat 3 ends the turn
          - listitem [ref=e274]: "T3 Seat 4: Country 39 → Country 38, -1 / -0"
          - listitem [ref=e275]: "T3 Seat 4: Country 39 → Country 38, -0 / -1"
          - listitem [ref=e276]: "T3 Seat 4: Country 39 → Country 38, took Country 38"
          - listitem [ref=e277]: T3 Seat 4 ends the turn
          - listitem [ref=e278]: "T3 Seat 1: Country 16 → Country 17, -1 / -0"
          - listitem [ref=e279]: "T3 Seat 1: Country 16 → Country 17, -1 / -0"
          - listitem [ref=e280]: "T3 Seat 1: Country 16 → Country 17, took Country 17"
          - listitem [ref=e281]: T3 Seat 1 ends the turn
          - listitem [ref=e282]: "T3 Seat 2: Country 32 → Country 36, -1 / -0"
          - listitem [ref=e283]: "T3 Seat 2: Country 32 → Country 36, took Country 36"
          - listitem [ref=e284]: T3 Seat 2 ends the turn
          - listitem [ref=e285]: "T4 Seat 3: Country 3 → Country 40, -1 / -0"
          - listitem [ref=e286]: "T4 Seat 3: Country 3 → Country 40, took Country 40"
          - listitem [ref=e287]: T4 Seat 3 ends the turn
          - listitem [ref=e288]: "T4 Seat 4: Country 39 → Country 40, -1 / -0"
          - listitem [ref=e289]: "T4 Seat 4: Country 39 → Country 40, -1 / -0"
          - listitem [ref=e290]: "T4 Seat 4: Country 39 → Country 40, took Country 40"
          - listitem [ref=e291]: T4 Seat 4 ends the turn
          - listitem [ref=e292]: "T4 Seat 1: Country 29 → Country 25, took Country 25"
          - listitem [ref=e293]: T4 Seat 1 ends the turn
          - listitem [ref=e294]: "T4 Seat 2: Country 32 → Country 31, -1 / -0"
          - listitem [ref=e295]: "T4 Seat 2: Country 32 → Country 31, -0 / -1"
          - listitem [ref=e296]: "T4 Seat 2: Country 32 → Country 31, took Country 31"
          - listitem [ref=e297]: T4 Seat 2 ends the turn
          - listitem [ref=e298]: "T5 Seat 3: Country 3 → Country 40, took Country 40"
          - listitem [ref=e299]: T5 Seat 3 ends the turn
          - listitem [ref=e300]: "T5 Seat 4: Country 39 → Country 40, took Country 40"
          - listitem [ref=e301]: T5 Seat 4 ends the turn
          - listitem [ref=e302]: "T5 Seat 1: Country 12 → Country 10, -0 / -1"
          - listitem [ref=e303]: "T5 Seat 1: Country 12 → Country 10, -1 / -0"
          - listitem [ref=e304]: "T5 Seat 1: Country 12 → Country 10, took Country 10"
          - listitem [ref=e305]: T5 Seat 1 ends the turn
          - listitem [ref=e306]: "T5 Seat 2: Country 32 → Country 1, -1 / -0"
          - listitem [ref=e307]: "T5 Seat 2: Country 32 → Country 1, -1 / -0"
          - listitem [ref=e308]: "T5 Seat 2: Country 32 → Country 1, -1 / -0"
          - listitem [ref=e309]: "T5 Seat 2: Country 32 → Country 1, took Country 1"
          - listitem [ref=e310]: T5 Seat 2 ends the turn
          - listitem [ref=e311]: "T6 Seat 3: Country 3 → Country 1, took Country 1"
          - listitem [ref=e312]: T6 Seat 3 ends the turn
          - listitem [ref=e313]: "T6 Seat 4: Country 42 → Country 37, -1 / -0"
          - listitem [ref=e314]: "T6 Seat 4: Country 42 → Country 37, -1 / -0"
          - listitem [ref=e315]: "T6 Seat 4: Country 42 → Country 37, -1 / -0"
          - listitem [ref=e316]: T6 Seat 4 ends the turn
          - listitem [ref=e317]: "T6 Seat 1: Country 12 → Country 11, -0 / -1"
          - listitem [ref=e318]: "T6 Seat 1: Country 12 → Country 11, -1 / -0"
          - listitem [ref=e319]: "T6 Seat 1: Country 12 → Country 11, -1 / -0"
          - listitem [ref=e320]: "T6 Seat 1: Country 12 → Country 11, took Country 11"
          - listitem [ref=e321]: T6 Seat 1 ends the turn
          - listitem [ref=e322]: "T6 Seat 2: Country 32 → Country 1, took Country 1"
          - listitem [ref=e323]: T6 Seat 2 ends the turn
          - listitem [ref=e324]: "T7 Seat 3: Country 3 → Country 1, -1 / -0"
          - listitem [ref=e325]: "T7 Seat 3: Country 3 → Country 1, took Country 1"
          - listitem [ref=e326]: T7 Seat 3 ends the turn
          - listitem [ref=e327]: "T7 Seat 4: Country 42 → Country 37, -0 / -1"
          - listitem [ref=e328]: "T7 Seat 4: Country 42 → Country 37, -1 / -0"
          - listitem [ref=e329]: "T7 Seat 4: Country 42 → Country 37, took Country 37"
          - listitem [ref=e330]: T7 Seat 4 ends the turn
          - listitem [ref=e331]: "T7 Seat 1: Country 10 → Country 20, -0 / -1"
          - listitem [ref=e332]: "T7 Seat 1: Country 10 → Country 20, -1 / -0"
          - listitem [ref=e333]: "T7 Seat 1: Country 10 → Country 20, -1 / -0"
          - listitem [ref=e334]: "T7 Seat 1: Country 10 → Country 20, -1 / -0"
          - listitem [ref=e335]: "T7 Seat 1: Country 10 → Country 20, -1 / -0"
          - listitem [ref=e336]: "T7 Seat 1: Country 10 → Country 20, took Country 20"
          - listitem [ref=e337]: T7 Seat 1 ends the turn
          - listitem [ref=e338]: "T7 Seat 2: Country 32 → Country 1, -1 / -0"
          - listitem [ref=e339]: "T7 Seat 2: Country 32 → Country 1, -1 / -0"
          - listitem [ref=e340]: "T7 Seat 2: Country 32 → Country 1, -1 / -0"
          - listitem [ref=e341]: "T7 Seat 2: Country 32 → Country 1, -1 / -0"
          - listitem [ref=e342]: "T7 Seat 2: Country 32 → Country 1, took Country 1"
          - listitem [ref=e343]: T7 Seat 2 ends the turn
          - listitem [ref=e344]: "T8 Seat 3: Country 3 → Country 1, -1 / -0"
          - listitem [ref=e345]: "T8 Seat 3: Country 3 → Country 1, took Country 1"
          - listitem [ref=e346]: T8 Seat 3 ends the turn
          - listitem [ref=e347]: "T8 Seat 4: Country 22 → Country 19, -1 / -0"
          - listitem [ref=e348]: "T8 Seat 4: Country 22 → Country 19, -1 / -0"
          - listitem [ref=e349]: "T8 Seat 4: Country 22 → Country 19, -1 / -0"
          - listitem [ref=e350]: T8 Seat 4 ends the turn
          - listitem [ref=e351]: "T8 Seat 1: Country 11 → Country 22, -1 / -0"
          - listitem [ref=e352]: "T8 Seat 1: Country 11 → Country 22, -0 / -1"
          - listitem [ref=e353]: "T8 Seat 1: Country 11 → Country 22, took Country 22"
          - listitem [ref=e354]: T8 Seat 1 ends the turn
          - listitem [ref=e355]: "T8 Seat 2: Country 32 → Country 1, took Country 1"
          - listitem [ref=e356]: T8 Seat 2 ends the turn
          - listitem [ref=e357]: "T9 Seat 3: Country 3 → Country 1, took Country 1"
          - listitem [ref=e358]: T9 Seat 3 ends the turn
          - listitem [ref=e359]: "T9 Seat 4: Country 43 → Country 8, took Country 8"
          - listitem [ref=e360]: T9 Seat 4 ends the turn
          - listitem [ref=e361]: "T9 Seat 1: Country 14 → Country 45, -1 / -0"
          - listitem [ref=e362]: "T9 Seat 1: Country 14 → Country 45, -1 / -0"
          - listitem [ref=e363]: "T9 Seat 1: Country 14 → Country 45, -0 / -1"
          - listitem [ref=e364]: "T9 Seat 1: Country 14 → Country 45, took Country 45"
          - listitem [ref=e365]: T9 Seat 1 ends the turn
          - listitem [ref=e366]: "T9 Seat 2: Country 7 → Country 8, took Country 8"
          - listitem [ref=e367]: T9 Seat 2 ends the turn
          - listitem [ref=e368]: "T10 Seat 3: Country 3 → Country 40, took Country 40"
          - listitem [ref=e369]: T10 Seat 3 ends the turn
          - listitem [ref=e370]: "T10 Seat 4: Country 39 → Country 40, took Country 40"
          - listitem [ref=e371]: T10 Seat 4 ends the turn
          - listitem [ref=e372]: "T10 Seat 1: Country 14 → Country 44, took Country 44"
          - listitem [ref=e373]: T10 Seat 1 ends the turn
          - listitem [ref=e374]: "T10 Seat 2: Country 32 → Country 1, took Country 1"
          - listitem [ref=e375]: T10 Seat 2 ends the turn
          - listitem [ref=e376]: "T11 Seat 3: Country 3 → Country 1, took Country 1"
          - listitem [ref=e377]: T11 Seat 3 ends the turn
          - listitem [ref=e378]: "T11 Seat 4: Country 39 → Country 44, took Country 44"
          - listitem [ref=e379]: T11 Seat 4 ends the turn
          - listitem [ref=e380]: "T11 Seat 1: Country 14 → Country 44, -1 / -0"
          - listitem [ref=e381]: "T11 Seat 1: Country 14 → Country 44, took Country 44"
          - listitem [ref=e382]: T11 Seat 1 ends the turn
          - listitem [ref=e383]: "T11 Seat 2: Country 32 → Country 1, -1 / -0"
          - listitem [ref=e384]: "T11 Seat 2: Country 32 → Country 1, took Country 1"
          - listitem [ref=e385]: T11 Seat 2 ends the turn
          - listitem [ref=e386]: "T12 Seat 3: Country 3 → Country 1, -1 / -0"
          - listitem [ref=e387]: "T12 Seat 3: Country 3 → Country 1, took Country 1"
          - listitem [ref=e388]: T12 Seat 3 ends the turn
          - listitem [ref=e389]: "T12 Seat 4: Country 39 → Country 44, took Country 44"
          - listitem [ref=e390]: T12 Seat 4 ends the turn
          - listitem [ref=e391]: "T12 Seat 1: Country 14 → Country 44, -1 / -0"
          - listitem [ref=e392]: "T12 Seat 1: Country 14 → Country 44, took Country 44"
          - listitem [ref=e393]: T12 Seat 1 ends the turn
          - listitem [ref=e394]: "T12 Seat 2: Country 32 → Country 1, -1 / -0"
          - listitem [ref=e395]: "T12 Seat 2: Country 32 → Country 1, -1 / -0"
          - listitem [ref=e396]: "T12 Seat 2: Country 32 → Country 1, took Country 1"
          - listitem [ref=e397]: T12 Seat 2 ends the turn
          - listitem [ref=e398]: "T13 Seat 3: Country 3 → Country 1, took Country 1"
          - listitem [ref=e399]: T13 Seat 3 ends the turn
          - listitem [ref=e400]: "T13 Seat 4: Country 39 → Country 44, -1 / -0"
```

# Test source

```ts
  1   | import {expect,test} from '@playwright/test';
  2   | import type {Page,TestInfo} from '@playwright/test';
  3   | import {readFileSync} from 'node:fs';
  4   | import {apply,deserializeVersionedMatch,friendlySources,friendlyTargets} from '../../src/core';
  5   | import type {Action,GameState} from '../../src/core';
  6   | const fixtureRoot='docs/prototypes/new-game/';
  7   | const input=(name:string)=>readFileSync(fixtureRoot+name,'utf8');
  8   | const discoveries=JSON.parse(input('issue180/preflight/discovery.json'));
  9   | const country=(p:Page,id:string)=>p.locator(`[data-country="${id}"]`);
  10  | async function begin(p:Page){
  11  |  await p.clock.install({time:new Date('2026-10-19T12:00:00Z')});await p.clock.pauseAt(new Date('2026-10-19T12:00:00Z'));
  12  |  await p.goto('/');await p.evaluate(()=>{const create=URL.createObjectURL.bind(URL);URL.createObjectURL=blob=>{Reflect.set(window,'iconSave',blob);return create(blob);};});
  13  | }
  14  | async function open(p:Page,surface:string){
  15  |  const d=p.locator('#game-focus-drawer');if(await d.isVisible()&&await d.getAttribute('data-surface')===surface)return;
  16  |  await p.locator('#open-game-'+surface).click();await expect(d).toBeVisible();await expect(d).toHaveAttribute('data-surface',surface);
  17  | }
  18  | async function close(p:Page){if(await p.locator('#game-focus-drawer').isVisible())await p.locator('#close-game-drawer').click();}
  19  | async function load(p:Page,text:string){
  20  |  if(await p.locator('#battle-action-rail').count())await open(p,'settings');
  21  |  const old=await p.getByLabel('Load game',{exact:true}).elementHandle();await p.getByLabel('Load game',{exact:true}).setInputFiles({name:'icons.json',mimeType:'application/json',buffer:Buffer.from(text)});
  22  |  await expect.poll(()=>old!.evaluate(e=>e.isConnected)).toBe(false);await expect(p.locator('[data-country]')).toHaveCount(46);
  23  | }
  24  | async function save(p:Page){await open(p,'settings');await p.getByRole('button',{name:'Save game',exact:true}).click();const text=await p.evaluate(()=>(Reflect.get(window,'iconSave') as Blob).text());await close(p);return text;}
  25  | async function exact(p:Page,state:GameState){expect(deserializeVersionedMatch(await save(p)).state).toEqual(state);}
  26  | function next(state:GameState,action:Action){const r=apply(state,action);if(!r.ok)throw Error(r.error);return r.state;}
  27  | async function collapse(p:Page){
  28  |  for(const id of ['toggle-topbar','toggle-sidebar'])if(await p.locator('#'+id).getAttribute('aria-expanded')==='true')await p.locator('#'+id).click();
  29  |  await expect(p.locator('.topbar')).toBeHidden();await expect(p.locator('.panel')).toBeHidden();
  30  | }
  31  | async function hit(p:Page,id:string){const e=p.locator('#'+id);await expect(e).toBeVisible();await expect(e).toBeEnabled();expect(await e.evaluate(n=>{const r=n.getBoundingClientRect(),h=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return r.x>=0&&r.y>=0&&r.right<=innerWidth&&r.bottom<=innerHeight&&!!h&&(n===h||n.contains(h));}),id+' physically reachable').toBe(true);await e.click();}
  32  | async function railFits(p:Page){const rail=p.locator('#battle-action-rail');expect(await rail.evaluate(e=>e.scrollHeight<=e.clientHeight+1),'rail needs no scrolling').toBe(true);for(const b of await rail.locator('button:visible').all()){expect(await b.evaluate(n=>{const r=n.getBoundingClientRect(),a=n.closest('#battle-action-rail')!.getBoundingClientRect(),h=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return r.top>=a.top&&r.bottom<=a.bottom&&r.left>=a.left&&r.right<=a.right&&!!h&&(n===h||n.contains(h));}),'every visible rail button physically reachable').toBe(true);}}
  33  | async function shot(p:Page,info:TestInfo,name:string){await p.screenshot({path:info.outputPath(name+'.png')});}
  34  | function row(host:string,kind:string){return discoveries.find((r:any)=>r.source===(host==='reference'?'T39-legal-pending-raid.json':'geographic-raid-pending-one-human.json')&&r.kind===kind);}
  35  | for(const host of ['reference','geographic']){
  36  |  test(`${host}: visible sidebar keeps an older history reader across focused surfaces`,async({page},info)=>{
  37  |   await begin(page);
  38  |   const f=row(host,'attack-running'),text=input('issue180/preflight/fixtures/'+f.fixture),before=deserializeVersionedMatch(text);
  39  |   await load(page,text);await hit(page,'toggle-topbar');
  40  |   const history=page.getByRole('list',{name:'Battle log',exact:true});
  41  |   await expect(page.locator('.panel')).toBeVisible();
  42  |   const rows=await history.locator('li').allTextContents();
  43  |   expect(rows.length).toBe(before.state.log.filter(e=>e.event!=='game_started').length);
  44  |   expect(await history.evaluate(e=>e.scrollHeight-e.clientHeight)).toBeGreaterThan(180);
  45  |   for(const requested of [80,120]){
  46  |    await history.evaluate((e,top)=>{e.scrollTop=top;},requested);
  47  |    const reading=await history.evaluate(e=>e.scrollTop);
  48  |    expect(Math.abs(reading-requested),'native zoom may quantize scroll offsets by less than half a CSS pixel').toBeLessThan(0.5);
  49  |    await open(page,'details');
> 50  |    expect(Math.abs(await history.evaluate(e=>e.scrollTop)-reading),'moving visible history must keep the latest reading position').toBeLessThan(0.5);
      |                                                                                                                                    ^ Error: moving visible history must keep the latest reading position
  51  |    await page.keyboard.press('Escape');await expect(page.locator('#open-game-details')).toBeFocused();
  52  |    await expect(page.locator('.panel > .log-card')).toBeVisible();
  53  |    expect(Math.abs(await history.evaluate(e=>e.scrollTop)-reading),'returning history to the sidebar must keep the reading position').toBeLessThan(0.5);
  54  |    await open(page,'settings');await close(page);
  55  |    expect(Math.abs(await history.evaluate(e=>e.scrollTop)-reading),'other focused surfaces must not reset the visible history').toBeLessThan(0.5);
  56  |   }
  57  |   expect(await history.locator('li').allTextContents()).toEqual(rows);
  58  |   await exact(page,before.state);expect(Math.abs(await history.evaluate(e=>e.scrollTop)-120)).toBeLessThan(0.5);
  59  |   await shot(page,info,host+'-visible-sidebar-history');
  60  |  });
  61  |  test(`${host}: sidebar-only rail places armies and starts combat directly without scrolling`,async({page},info)=>{
  62  |   await begin(page);const envelope=JSON.parse(input(`T71/fixtures/${host}-reinforcement.json`));envelope.options.seats=envelope.options.seats.map(()=>({kind:'human'}));envelope.options.computerStrengths=[];const text=JSON.stringify(envelope),before=deserializeVersionedMatch(text);await load(page,text);await hit(page,'toggle-sidebar');await railFits(page);await page.locator('#toggle-sidebar').focus();await page.keyboard.press('ArrowDown');await expect(page.locator('#open-game-actions')).toBeFocused();await page.keyboard.press('Home');await expect(page.locator('#toggle-topbar')).toBeFocused();await page.keyboard.press('End');await expect(page.locator('#battle-action-rail button:visible').last()).toBeFocused();let state=before.state;const owned=state.map.provinces.find(p=>state.ownerOf[p.id]===state.players[state.currentPlayer]!.id)!.id;while(state.reinforcementPool){await country(page,owned).click();state=next(state,{kind:'reinforce',province:owned,amount:1});}await expect(page.locator('#battle-action-rail #start-combat-button')).toBeVisible();await railFits(page);await hit(page,'game-pause-button');await expect(page.locator('#start-combat-button')).toBeDisabled();await exact(page,state);await hit(page,'game-pause-button');await hit(page,'start-combat-button');state=next(state,{kind:'endReinforcement'});await exact(page,state);await shot(page,info,host+'-sidebar-only-rail');
  63  |  });
  64  |  test(`${host}: collapsed battle commands, pause and details preserve exact actions and selection`,async({page},info)=>{
  65  |   await begin(page);const f=row(host,'attack-running'),text=input('issue180/preflight/fixtures/'+f.fixture),before=deserializeVersionedMatch(text);await load(page,text);await collapse(page);
  66  |   await country(page,f.action.from).click();await country(page,f.action.to).click({modifiers:['Shift']});await open(page,'actions');
  67  |   const source=await page.locator('#battle-source-name').textContent(),target=await page.locator('#battle-target-name').textContent();await page.locator('#battle-stop-threshold').fill('1');await page.locator('#battle-stop-threshold').press('Tab');
  68  |   await page.keyboard.press('Escape');await expect(page.locator('#open-game-actions')).toBeFocused();await open(page,'actions');await expect(page.locator('#battle-source-name')).toHaveText(source!);await expect(page.locator('#battle-target-name')).toHaveText(target!);await expect(page.locator('#battle-stop-threshold')).toHaveValue('1');
  69  |   await hit(page,'game-pause-button');await expect(page.locator('#single-exchange-button')).toBeDisabled();await page.locator('#single-exchange-button').evaluate(e=>(e as HTMLButtonElement).click());await exact(page,before.state);await hit(page,'game-pause-button');
  70  |   await open(page,'actions');await close(page);await hit(page,'toggle-topbar');await expect(page.locator('#battle-action-rail #fight-on-button')).toBeVisible();await railFits(page);await shot(page,info,host+'-sidebar-only-battle-rail');await hit(page,'fight-on-button');await page.locator('#stop-battle-button').focus();await page.keyboard.press('Enter');const after=next(before.state,f.action);await exact(page,after);
  71  |   await open(page,'actions');await hit(page,'single-exchange-button');await exact(page,next(after,f.action));
  72  |   await open(page,'details');const history=page.getByRole('list',{name:'Battle log',exact:true});await expect(history.locator('li')).toHaveCount(next(after,f.action).log.filter(e=>e.event!=='game_started').length);await history.evaluate(e=>{e.scrollTop=42;});const reading=await history.evaluate(e=>e.scrollTop);await close(page);await open(page,'settings');await page.locator('#game-speed').selectOption('very-slow');await close(page);await open(page,'details');expect(await history.evaluate(e=>e.scrollTop)).toBe(reading);await shot(page,info,host+'-details');
  73  |   await close(page);await hit(page,'game-log-button');await expect(page.getByRole('dialog',{name:'Game event log',exact:true})).toBeVisible();await page.keyboard.press('Escape');await expect(page.locator('#game-log-button')).toBeFocused();await exact(page,next(after,f.action));
  74  |  });
  75  |  test(`${host}: collapsed capture retains quantity across surfaces, toggles and pause`,async({page},info)=>{
  76  |   await begin(page);const f=row(host,'capture'),text=input('issue180/preflight/fixtures/'+f.fixture),before=deserializeVersionedMatch(text);await load(page,text);await collapse(page);await hit(page,'open-required-action');
  77  |   const pending=before.state.pendingCapture!,amount=pending.min===pending.defaultAmount?pending.max:pending.min;expect(pending.max).toBeGreaterThan(pending.min);expect(amount).not.toBe(pending.defaultAmount);await page.locator('#capture-amount').fill(String(amount));await close(page);await open(page,'cards');await close(page);await open(page,'actions');await expect(page.locator('#capture-amount')).toHaveValue(String(amount));
  78  |   await hit(page,'toggle-sidebar');await hit(page,'toggle-sidebar');await open(page,'actions');await expect(page.locator('#capture-amount')).toHaveValue(String(amount));await hit(page,'game-pause-button');await expect(page.locator('#confirm-capture-button')).toBeDisabled();await hit(page,'game-pause-button');await expect(page.locator('#capture-amount')).toHaveValue(String(amount));await shot(page,info,host+'-capture');await hit(page,'confirm-capture-button');await exact(page,next(before.state,{kind:'captureMove',amount}));
  79  |  });
  80  |  test(`${host}: collapsed friendly non-default draft survives a redraw with input focus`,async({page},info)=>{
  81  |   await begin(page);
  82  |   const envelope=JSON.parse(input(`T71/fixtures/${host}-reinforcement.json`));
  83  |   envelope.options.seats=envelope.options.seats.map(()=>({kind:'human'}));envelope.options.computerStrengths=[];
  84  |   let prepared=deserializeVersionedMatch(JSON.stringify(envelope)).state;
  85  |   const owner=prepared.players[prepared.currentPlayer]!.id;
  86  |   const staging=prepared.map.provinces.filter(p=>prepared.ownerOf[p.id]===owner&&[...p.borders,...p.seaLanes].some(id=>prepared.ownerOf[id]===owner)).sort((a,b)=>prepared.armies[b.id]!-prepared.armies[a.id]!)[0];
  87  |   expect(staging,'reinforcement fixture must contain an owned adjacent pair').toBeDefined();
  88  |   expect(prepared.reinforcementPool).toBeGreaterThan(0);
  89  |   while(prepared.reinforcementPool){const action:Action={kind:'reinforce',province:staging!.id,amount:1};prepared=next(prepared,action);envelope.actions.push(action);}
  90  |   const start:Action={kind:'endReinforcement'};prepared=next(prepared,start);envelope.actions.push(start);
  91  |   const text=JSON.stringify(envelope),before=deserializeVersionedMatch(text);expect(before.state).toEqual(prepared);
  92  |   const sources=friendlySources(before.state).filter(id=>before.state.armies[id]!>=3);
  93  |   expect(sources.length,'fixture needs a legal source with at least two movable armies').toBeGreaterThan(0);
  94  |   const from=sources[0]!,to=friendlyTargets(before.state,from)[0]!,maximum=before.state.armies[from]!-1,amount=maximum-1;
  95  |   expect(maximum).toBeGreaterThanOrEqual(2);expect(amount).toBeGreaterThanOrEqual(1);expect(amount).toBeLessThan(maximum);
  96  |   await load(page,text);await collapse(page);await open(page,'actions');await hit(page,'start-friendly-move-button');await close(page);
  97  |   await country(page,from).click();await country(page,to).click();await open(page,'actions');
  98  |   const quantity=page.locator('#friendly-move-amount');await expect(quantity).toHaveAttribute('max',String(maximum));await expect(quantity).toHaveValue(String(maximum));
  99  |   await quantity.fill(String(amount));await page.keyboard.press('Escape');await expect(page.locator('#open-game-actions')).toBeFocused();
  100 |   await open(page,'settings');await close(page);await hit(page,'toggle-topbar');await open(page,'actions');
  101 |   await expect(quantity).toHaveValue(String(amount));await quantity.focus();await expect(quantity).toBeFocused();
  102 |   const retired=await quantity.elementHandle();
  103 |   await page.locator('#game-speed').selectOption('slow');
  104 |   expect(await retired!.evaluate(e=>e.isConnected),'speed change must actually replace the friendly controls').toBe(false);
  105 |   await expect(quantity).toHaveValue(String(amount));await expect(quantity).toBeFocused();
  106 |   await shot(page,info,host+'-friendly-redraw');await hit(page,'confirm-friendly-move-button');
  107 |   await exact(page,next(before.state,{kind:'friendlyMove',from,to,amount}));
  108 |  });
  109 |  test(`${host}: collapsed card trade and nonmodal Raid use ordinary core actions`,async({page},info)=>{
  110 |   await begin(page);const trade=host==='reference'?'T38-legal-Surge-before.json':'geographic-income-before-one-human.json',before=deserializeVersionedMatch(input('T40/fixtures/'+trade));await load(page,input('T40/fixtures/'+trade));await collapse(page);await hit(page,'open-required-action');await page.getByRole('button',{name:/^Surge:/}).click();await exact(page,next(before.state,{kind:'tradeCards',handIndices:[0,1,4]}));
  111 |   const raid=host==='reference'?'T39-legal-pending-raid.json':'geographic-raid-pending-one-human.json',pending=deserializeVersionedMatch(input('T40/fixtures/'+raid));await load(page,input('T40/fixtures/'+raid));await expect(page.locator('#toggle-sidebar')).toHaveAttribute('aria-expanded','false');await expect(page.locator('#toggle-topbar')).toHaveAttribute('aria-expanded','false');await open(page,'cards');await expect(page.locator('#game-focus-drawer')).toHaveAttribute('aria-modal','false');await close(page);await country(page,'province_41').click();await open(page,'cards');await expect(page.getByRole('button',{name:'Confirm raid',exact:true})).toBeEnabled();await hit(page,'game-pause-button');await expect(page.getByRole('button',{name:'Confirm raid',exact:true})).toBeDisabled();await hit(page,'game-pause-button');await shot(page,info,host+'-raid');await page.getByRole('button',{name:'Confirm raid',exact:true}).click();await exact(page,next(pending.state,{kind:'raidTarget',province:'province_41'}));
  112 |  });
  113 | }
  114 | test('collapsed full-hand discard, reward, skip and replacement retain reachable choices and clean surfaces',async({page},info)=>{
  115 |  await begin(page);const text=input('T40/fixtures/T37-reshuffle-before-match.json'),before=deserializeVersionedMatch(text),hand=before.state.cards!.hands[before.state.players.find(p=>p.kind==='human')!.id]!;await load(page,text);await collapse(page);await hit(page,'open-required-action');await expect(page.getByRole('button',{name:/^Discard .*\(card /})).toHaveCount(5);await page.getByRole('button',{name:`Discard ${hand[2]} (card 3)`,exact:true}).click();const after=next(before.state,{kind:'discardCard',handIndex:2});await exact(page,after);await hit(page,'open-required-action');await shot(page,info,'discard-reward');await page.getByRole('button',{name:'Continue',exact:true}).click();await page.keyboard.press('Escape');await expect(page.locator('#toggle-sidebar')).toBeFocused();await exact(page,after);
  116 |  const replacement=input('T40/fixtures/T38-legal-Surge-before.json'),fresh=deserializeVersionedMatch(replacement);await load(page,replacement);await expect(page.locator('#game-focus-drawer')).toBeHidden();await expect(page.locator('#toggle-sidebar')).toHaveAttribute('aria-expanded','false');await hit(page,'open-required-action');await page.getByRole('button',{name:'Skip cards',exact:true}).click();await exact(page,next(fresh.state,{kind:'skipCards'}));
  117 |  await open(page,'settings');await page.getByRole('button',{name:'New game',exact:true}).click();await expect(page.getByRole('button',{name:'Start game',exact:true})).toBeVisible();await expect(page.locator('#game-focus-drawer')).toHaveCount(0);
  118 | });
  119 | 
  120 | test('collapsed human-loss and finished choices keep core results reachable',async({page},info)=>{
  121 |  await begin(page);const text=input('T40/fixtures/T40-human-loss-450.json'),before=deserializeVersionedMatch(text);expect(before.state.phase).toBe('human-loss');await load(page,text);await collapse(page);await hit(page,'open-required-action');await hit(page,'watch-computers-button');await exact(page,next(before.state,{kind:'watchComputers'}));await load(page,text);await hit(page,'open-required-action');await hit(page,'stop-game-button');await exact(page,next(before.state,{kind:'stopGame'}));await hit(page,'open-required-action');await shot(page,info,'finished-result');await close(page);await open(page,'settings');await page.getByRole('button',{name:'New game',exact:true}).click();await expect(page.getByRole('button',{name:'Start game',exact:true})).toBeVisible();await page.getByRole('button',{name:'Start game',exact:true}).click();await expect(page.locator('#toggle-sidebar')).toHaveAttribute('aria-expanded','false');await expect(page.locator('#toggle-topbar')).toHaveAttribute('aria-expanded','false');
  122 | });
  123 | 
```