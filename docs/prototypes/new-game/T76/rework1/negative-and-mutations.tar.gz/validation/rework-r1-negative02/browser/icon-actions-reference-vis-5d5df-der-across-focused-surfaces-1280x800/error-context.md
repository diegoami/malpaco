# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: icon-actions.spec.ts >> reference: visible sidebar keeps an older history reader across focused surfaces
- Location: tests/e2e/icon-actions.spec.ts:36:2

# Error details

```
Error: moving visible history must keep the latest reading position

expect(received).toBe(expected) // Object.is equality

Expected: 80
Received: 2686
```

# Page snapshot

```yaml
- main [ref=e3]:
  - img "Nine Isles reference map" [ref=e5]:
    - button "River gate, Seat 1, 5 armies, Seat 1" [ref=e31] [cursor=pointer]:
      - generic:
        - generic: River
        - generic: gate
        - generic: "5"
    - button "New port, Seat 1, 1 armies, Seat 1" [ref=e33] [cursor=pointer]:
      - generic:
        - generic: New
        - generic: port
        - generic: "1"
    - button "North rest, Seat 1, 1 armies, Seat 1" [ref=e35] [cursor=pointer]:
      - generic:
        - generic: North
        - generic: rest
        - generic: "1"
    - button "River keep, Seat 1, 1 armies, Seat 1" [ref=e37] [cursor=pointer]:
      - generic:
        - generic: River
        - generic: keep
        - generic: "1"
    - button "North town, Seat 1, 1 armies, Seat 1" [ref=e39] [cursor=pointer]:
      - generic:
        - generic: North
        - generic: town
        - generic: "1"
    - button "Dark ford, Seat 1, 8 armies, Seat 1" [ref=e41] [cursor=pointer]:
      - generic:
        - generic: Dark
        - generic: ford
        - generic: "8"
      - generic [ref=e43]: ★
    - button "Iron point, Seat 3, 1 armies, Seat 3" [ref=e44] [cursor=pointer]:
      - generic:
        - generic: Iron
        - generic: point
        - generic: "1"
    - button "South rest, Seat 3, 13 armies, Seat 3" [ref=e46] [cursor=pointer]:
      - generic:
        - generic: South
        - generic: rest
        - generic: "13"
    - button "High shore, Seat 3, 9 armies, Seat 3" [ref=e48] [cursor=pointer]:
      - generic:
        - generic: High
        - generic: shore
        - generic: "9"
    - button "Wind town, Seat 3, 2 armies, Seat 3" [ref=e50] [cursor=pointer]:
      - generic:
        - generic: Wind
        - generic: town
        - generic: "2"
    - button "New glen, Seat 3, 1 armies, Seat 3" [ref=e52] [cursor=pointer]:
      - generic:
        - generic: New
        - generic: glen
        - generic: "1"
    - button "Old rock, Seat 4, 1 armies, Seat 4" [ref=e54] [cursor=pointer]:
      - generic:
        - generic: Old
        - generic: rock
        - generic: "1"
    - button "Blue peak, Seat 1, 1 armies, Seat 1" [ref=e56] [cursor=pointer]:
      - generic:
        - generic: Blue
        - generic: peak
        - generic: "1"
    - button "West haven, Seat 1, 1 armies, Seat 1" [ref=e58] [cursor=pointer]:
      - generic:
        - generic: West
        - generic: haven
        - generic: "1"
    - button "Stone watch, Seat 3, 1 armies, Seat 3" [ref=e60] [cursor=pointer]:
      - generic:
        - generic: Stone
        - generic: watch
        - generic: "1"
    - button "Upper ridge, Seat 1, 2 armies, Seat 1" [ref=e62] [cursor=pointer]:
      - generic:
        - generic: Upper
        - generic: ridge
        - generic: "2"
    - button "Marsh keep, Seat 1, 1 armies, Seat 1" [ref=e64] [cursor=pointer]:
      - generic:
        - generic: Marsh
        - generic: keep
        - generic: "1"
    - button "New fell, Seat 4, 1 armies, Seat 4" [ref=e66] [cursor=pointer]:
      - generic:
        - generic: New
        - generic: fell
        - generic: "1"
      - generic [ref=e68]: ★
    - button "Moon point, Seat 3, 1 armies, Seat 3" [ref=e69] [cursor=pointer]:
      - generic:
        - generic: Moon
        - generic: point
        - generic: "1"
    - button "South fell, Seat 4, 8 armies, Seat 4" [ref=e71] [cursor=pointer]:
      - generic:
        - generic: South
        - generic: fell
        - generic: "8"
    - button "High ridge, Seat 3, 1 armies, Seat 3" [ref=e73] [cursor=pointer]:
      - generic:
        - generic: High
        - generic: ridge
        - generic: "1"
    - button "Bay ford, Seat 2, 2 armies, Seat 2" [ref=e75] [cursor=pointer]:
      - generic:
        - generic: Bay
        - generic: ford
        - generic: "2"
    - button "Low moor, Seat 4, 1 armies, Seat 4" [ref=e77] [cursor=pointer]:
      - generic:
        - generic: Low
        - generic: moor
        - generic: "1"
    - button "Lower field, Seat 3, 1 armies, Seat 3" [ref=e79] [cursor=pointer]:
      - generic:
        - generic: Lower
        - generic: field
        - generic: "1"
    - button "Wind gate, Seat 2, 3 armies, Seat 2" [ref=e81] [cursor=pointer]:
      - generic:
        - generic: Wind
        - generic: gate
        - generic: "3"
    - button "Silver shore, Seat 4, 4 armies, Seat 4" [ref=e83] [cursor=pointer]:
      - generic:
        - generic: Silver
        - generic: shore
        - generic: "4"
    - button "Low peak, Seat 4, 1 armies, Seat 4" [ref=e85] [cursor=pointer]:
      - generic:
        - generic: Low
        - generic: peak
        - generic: "1"
    - button "Wind port, Seat 2, 1 armies, Seat 2" [ref=e87] [cursor=pointer]:
      - generic:
        - generic: Wind
        - generic: port
        - generic: "1"
    - button "Gold point, Seat 2, 1 armies, Seat 2" [ref=e89] [cursor=pointer]:
      - generic:
        - generic: Gold
        - generic: point
        - generic: "1"
    - button "Rock moor, Seat 1, 8 armies, Seat 1" [ref=e91] [cursor=pointer]:
      - generic:
        - generic: Rock
        - generic: moor
        - generic: "8"
    - button "Marsh rest, Seat 1, 2 armies, Seat 1" [ref=e93] [cursor=pointer]:
      - generic:
        - generic: Marsh
        - generic: rest
        - generic: "2"
    - button "Wind dale, Seat 1, 2 armies, Seat 1" [ref=e95] [cursor=pointer]:
      - generic:
        - generic: Wind
        - generic: dale
        - generic: "2"
    - button "Silver ford, Seat 1, 1 armies, Seat 1" [ref=e97] [cursor=pointer]:
      - generic:
        - generic: Silver
        - generic: ford
        - generic: "1"
    - button "Iron field, Seat 1, 1 armies, Seat 1" [ref=e99] [cursor=pointer]:
      - generic:
        - generic: Iron
        - generic: field
        - generic: "1"
    - button "North wood, Seat 2, 1 armies, Seat 2" [ref=e101] [cursor=pointer]:
      - generic:
        - generic: North
        - generic: wood
        - generic: "1"
    - button "Fort town, Seat 3, 1 armies, Seat 3" [ref=e103] [cursor=pointer]:
      - generic:
        - generic: Fort
        - generic: town
        - generic: "1"
    - button "Red field, Seat 2, 1 armies, Seat 2" [ref=e105] [cursor=pointer]:
      - generic:
        - generic: Red
        - generic: field
        - generic: "1"
    - button "South ridge, Seat 4, 1 armies, Seat 4" [ref=e107] [cursor=pointer]:
      - generic:
        - generic: South
        - generic: ridge
        - generic: "1"
    - button "Rock bay, Seat 4, 2 armies, Seat 4" [ref=e109] [cursor=pointer]:
      - generic:
        - generic: Rock
        - generic: bay
        - generic: "2"
    - button "North ford, Seat 4, 1 armies, Seat 4" [ref=e111] [cursor=pointer]:
      - generic:
        - generic: North
        - generic: ford
        - generic: "1"
    - button "Port ridge, Seat 3, 2 armies, Seat 3" [ref=e113] [cursor=pointer]:
      - generic:
        - generic: Port
        - generic: ridge
        - generic: "2"
    - button "New rock, Seat 4, 1 armies, Seat 4" [ref=e115] [cursor=pointer]:
      - generic:
        - generic: New
        - generic: rock
        - generic: "1"
    - button "South reach, Seat 4, 2 armies, Seat 4" [ref=e117] [cursor=pointer]:
      - generic:
        - generic: South
        - generic: reach
        - generic: "2"
      - generic [ref=e119]: ★
    - button "Silver point, Seat 4, 1 armies, Seat 4" [ref=e120] [cursor=pointer]:
      - generic:
        - generic: Silver
        - generic: point
        - generic: "1"
    - button "East ford, Seat 4, 6 armies, Seat 4" [ref=e122] [cursor=pointer]:
      - generic:
        - generic: East
        - generic: ford
        - generic: "6"
    - button "Gold town, Seat 4, 1 armies, Seat 4" [ref=e124] [cursor=pointer]:
      - generic:
        - generic: Gold
        - generic: town
        - generic: "1"
    - generic [ref=e156]: North Isle +3
    - generic [ref=e157]: East Isle +3
    - generic [ref=e158]: West Isle +3
    - generic [ref=e159]: South Isle +3
    - generic [ref=e160]: Central Isle +5
    - generic [ref=e161]: Harbor Isle +5
    - generic [ref=e162]: Palm Isle +6
    - generic [ref=e163]: Cliff Isle +5
    - generic [ref=e164]: Great Isle +9
  - complementary [ref=e165]:
    - generic [ref=e169]:
      - generic [ref=e170]: Seat 4's turn
      - generic [ref=e171]: Round 8 · Attack
    - generic [ref=e172]:
      - generic [ref=e173]:
        - button "End turn" [ref=e174] [cursor=pointer]
        - button "Move armies" [ref=e175] [cursor=pointer]
      - region "Battle controls" [ref=e176]:
        - generic [ref=e177]:
          - generic [ref=e178]:
            - generic [ref=e179]: From
            - strong [ref=e180]: Choose your country
            - generic "Source armies" [ref=e181]: —
          - generic [ref=e182]:
            - generic [ref=e183]: Target
            - strong [ref=e184]: Choose an enemy neighbour
            - generic "Target armies" [ref=e185]: —
        - generic [ref=e186]:
          - generic [ref=e187]:
            - text: Stop at armies
            - spinbutton "Stop at armies" [ref=e188]: "2"
          - generic [ref=e189]:
            - text: Battle speed
            - combobox "Battle speed" [ref=e190]:
              - option "Very slow"
              - option "Slow"
              - option "Normal" [selected]
              - option "Fast"
        - generic [ref=e191]:
          - button "Fight on" [disabled] [ref=e192]
          - button "Stop" [disabled] [ref=e193]
          - button "Single exchange" [disabled] [ref=e194]
        - generic [ref=e195]:
          - strong [ref=e196]: Ready for your choice
          - paragraph [ref=e197]: Choose your country, then click an enemy to attack. Shift-click or Shift-Enter selects only.
        - paragraph [ref=e198]:
          - text: Won 0 · Lost 0 · Ties
          - strong [ref=e199]: "0"
      - region "Cards" [ref=e200]:
        - paragraph [ref=e201]: "Draw: 15 · Discard: 7 · Top: Surge. seat1: 4 · seat2: 4 · seat3: 5 · seat4: 5"
        - 'button "View your hand: 5 of 5" [ref=e202] [cursor=pointer]'
  - toolbar "Game actions" [ref=e203]:
    - button "Show top panel" [ref=e204] [cursor=pointer]
    - button "Hide side panel" [expanded] [ref=e207] [cursor=pointer]
    - button "Game actions" [ref=e210] [cursor=pointer]
    - button "Cards" [ref=e213] [cursor=pointer]
    - button "Game details and history" [ref=e216] [cursor=pointer]
    - button "Game settings and files" [ref=e219] [cursor=pointer]
    - button "Pause game" [ref=e222] [cursor=pointer]: Pause
    - button "Game event log" [ref=e225] [cursor=pointer]
    - generic "Seat 4 · Attack" [ref=e228]: Seat 4 Attack
  - dialog [ref=e229]:
    - generic [ref=e230]:
      - heading "Game details" [level=2] [ref=e231]
      - button "Close game panel" [active] [ref=e232] [cursor=pointer]
    - generic [ref=e235]:
      - generic [ref=e236]:
        - generic [ref=e240]:
          - generic [ref=e241]: Seat 1 · Computer
          - generic [ref=e242]:
            - strong [ref=e243]: "Total armies: 36"
            - generic [ref=e244]: 15 provinces
        - generic [ref=e248]:
          - generic [ref=e249]: Seat 2 · Computer
          - generic [ref=e250]:
            - strong [ref=e251]: "Total armies: 9"
            - generic [ref=e252]: 6 provinces
        - generic [ref=e256]:
          - generic [ref=e257]: Seat 3 · Computer
          - generic [ref=e258]:
            - strong [ref=e259]: "Total armies: 33"
            - generic [ref=e260]: 11 provinces
        - generic [ref=e264]:
          - generic [ref=e265]: Seat 4
          - generic [ref=e266]:
            - strong [ref=e267]: "Total armies: 31"
            - generic [ref=e268]: 14 provinces
      - generic [ref=e269]:
        - heading "Battle log" [level=3] [ref=e270]
        - list "Battle log" [ref=e271]:
          - listitem [ref=e272]: "T1 Seat 4: Silver shore → Low moor, -1 / -0"
          - listitem [ref=e273]: "T1 Seat 4: Silver shore → Low moor, took Low moor"
          - listitem [ref=e274]: T1 Seat 4 ends the turn
          - listitem [ref=e275]: "T1 Seat 1: Upper ridge → Blue peak, -0 / -1"
          - listitem [ref=e276]: "T1 Seat 1: Upper ridge → Blue peak, -0 / -1"
          - listitem [ref=e277]: "T1 Seat 1: Upper ridge → Blue peak, took Blue peak"
          - listitem [ref=e278]: T1 Seat 1 ends the turn
          - listitem [ref=e279]: "T1 Seat 2: River keep → North town, -1 / -0"
          - listitem [ref=e280]: "T1 Seat 2: River keep → North town, -1 / -0"
          - listitem [ref=e281]: "T1 Seat 2: River keep → North town, -1 / -0"
          - listitem [ref=e282]: "T1 Seat 2: River keep → North rest, -1 / -0"
          - listitem [ref=e283]: "T1 Seat 2: Bay ford → New glen, -1 / -0"
          - listitem [ref=e284]: T1 Seat 2 ends the turn
          - listitem [ref=e285]: "T1 Seat 3: South rest → Iron point, -1 / -0"
          - listitem [ref=e286]: "T1 Seat 3: South rest → Iron point, took Iron point"
          - listitem [ref=e287]: T1 Seat 3 ends the turn
          - listitem [ref=e288]: "T2 Seat 4: Silver shore → Low peak, -1 / -0"
          - listitem [ref=e289]: "T2 Seat 4: Silver shore → Low peak, -1 / -0"
          - listitem [ref=e290]: "T2 Seat 4: Silver shore → Low peak, -1 / -0"
          - listitem [ref=e291]: "T2 Seat 4: Silver shore → Low peak, took Low peak"
          - listitem [ref=e292]: T2 Seat 4 ends the turn
          - listitem [ref=e293]: "T2 Seat 1: Upper ridge → West haven, -1 / -0"
          - listitem [ref=e294]: "T2 Seat 1: Upper ridge → West haven, -0 / -1"
          - listitem [ref=e295]: "T2 Seat 1: Upper ridge → West haven, -1 / -0"
          - listitem [ref=e296]: "T2 Seat 1: Upper ridge → West haven, -1 / -0"
          - listitem [ref=e297]: "T2 Seat 1: Upper ridge → West haven, -1 / -0"
          - listitem [ref=e298]: "T2 Seat 1: Upper ridge → West haven, -1 / -0"
          - listitem [ref=e299]: "T2 Seat 1: Upper ridge → West haven, -1 / -0"
          - listitem [ref=e300]: "T2 Seat 1: Upper ridge → West haven, took West haven"
          - listitem [ref=e301]: T2 Seat 1 ends the turn
          - listitem [ref=e302]: "T2 Seat 2: Wind gate → Wind port, -0 / -1"
          - listitem [ref=e303]: "T2 Seat 2: Wind gate → Wind port, took Wind port"
          - listitem [ref=e304]: T2 Seat 2 ends the turn
          - listitem [ref=e305]: "T2 Seat 3: South rest → Stone watch, -1 / -0"
          - listitem [ref=e306]: "T2 Seat 3: South rest → Stone watch, -1 / -0"
          - listitem [ref=e307]: "T2 Seat 3: South rest → Stone watch, -1 / -0"
          - listitem [ref=e308]: "T2 Seat 3: South rest → Stone watch, -1 / -0"
          - listitem [ref=e309]: "T2 Seat 3: South rest → Stone watch, took Stone watch"
          - listitem [ref=e310]: T2 Seat 3 ends the turn
          - listitem [ref=e311]: "T3 Seat 4: Red field → Wind gate, -1 / -0"
          - listitem [ref=e312]: "T3 Seat 4: Red field → Stone watch, -1 / -0"
          - listitem [ref=e313]: "T3 Seat 4: Red field → Stone watch, -1 / -0"
          - listitem [ref=e314]: "T3 Seat 4: Red field → Stone watch, took Stone watch"
          - listitem [ref=e315]: T3 Seat 4 ends the turn
          - listitem [ref=e316]: "T3 Seat 1: Rock moor → Silver ford, -0 / -1"
          - listitem [ref=e317]: "T3 Seat 1: Rock moor → Silver ford, -0 / -1"
          - listitem [ref=e318]: "T3 Seat 1: Rock moor → Silver ford, took Silver ford"
          - listitem [ref=e319]: T3 Seat 1 ends the turn
          - listitem [ref=e320]: "T3 Seat 2: Wind gate → Red field, -0 / -1"
          - listitem [ref=e321]: "T3 Seat 2: Wind gate → Red field, -0 / -1"
          - listitem [ref=e322]: "T3 Seat 2: Wind gate → Red field, -1 / -0"
          - listitem [ref=e323]: "T3 Seat 2: Wind gate → Red field, -1 / -0"
          - listitem [ref=e324]: "T3 Seat 2: Wind gate → Red field, took Red field"
          - listitem [ref=e325]: T3 Seat 2 ends the turn
          - listitem [ref=e326]: "T3 Seat 3: South rest → Stone watch, -1 / -0"
          - listitem [ref=e327]: "T3 Seat 3: South rest → Stone watch, took Stone watch"
          - listitem [ref=e328]: T3 Seat 3 ends the turn
          - listitem [ref=e329]: "T4 Seat 4: East ford → North ford, -1 / -0"
          - listitem [ref=e330]: "T4 Seat 4: East ford → North ford, -1 / -0"
          - listitem [ref=e331]: "T4 Seat 4: East ford → Silver point, took Silver point"
          - listitem [ref=e332]: T4 Seat 4 ends the turn
          - listitem [ref=e333]: "T4 Seat 1: Rock moor → Iron field, -1 / -0"
          - listitem [ref=e334]: "T4 Seat 1: Rock moor → Iron field, -0 / -1"
          - listitem [ref=e335]: "T4 Seat 1: Rock moor → Iron field, took Iron field"
          - listitem [ref=e336]: T4 Seat 1 ends the turn
          - listitem [ref=e337]: "T4 Seat 2: River keep → North town, -0 / -1"
          - listitem [ref=e338]: "T4 Seat 2: River keep → North town, -1 / -0"
          - listitem [ref=e339]: "T4 Seat 2: River keep → North town, -1 / -0"
          - listitem [ref=e340]: "T4 Seat 2: River keep → North town, -1 / -0"
          - listitem [ref=e341]: T4 Seat 2 ends the turn
          - listitem [ref=e342]: "T4 Seat 3: South rest → Fort town, -0 / -1"
          - listitem [ref=e343]: "T4 Seat 3: South rest → Fort town, -1 / -0"
          - listitem [ref=e344]: "T4 Seat 3: South rest → Fort town, took Fort town"
          - listitem [ref=e345]: T4 Seat 3 ends the turn
          - listitem [ref=e346]: "T5 Seat 4: East ford → North ford, -0 / -1"
          - listitem [ref=e347]: "T5 Seat 4: East ford → North ford, -0 / -1"
          - listitem [ref=e348]: "T5 Seat 4: East ford → North ford, -1 / -0"
          - listitem [ref=e349]: "T5 Seat 4: East ford → North ford, took North ford"
          - listitem [ref=e350]: T5 Seat 4 ends the turn
          - listitem [ref=e351]: "T5 Seat 1: River gate → New port, -0 / -1"
          - listitem [ref=e352]: "T5 Seat 1: River gate → New port, took New port"
          - listitem [ref=e353]: T5 Seat 1 ends the turn
          - listitem [ref=e354]: "T5 Seat 2: River keep → North town, took North town"
          - listitem [ref=e355]: T5 Seat 2 ends the turn
          - listitem [ref=e356]: "T5 Seat 3: High shore → Lower field, -1 / -0"
          - listitem [ref=e357]: "T5 Seat 3: High shore → Lower field, -1 / -0"
          - listitem [ref=e358]: "T5 Seat 3: High shore → Lower field, -1 / -0"
          - listitem [ref=e359]: "T5 Seat 3: High shore → Lower field, -1 / -0"
          - listitem [ref=e360]: "T5 Seat 3: High shore → Lower field, -1 / -0"
          - listitem [ref=e361]: "T5 Seat 3: High shore → Lower field, -1 / -0"
          - listitem [ref=e362]: "T5 Seat 3: New fell → Moon point, took Moon point"
          - listitem [ref=e363]: T5 Seat 3 ends the turn
          - listitem [ref=e364]: "T6 Seat 4: East ford → Gold town, -0 / -1"
          - listitem [ref=e365]: "T6 Seat 4: East ford → Gold town, -1 / -0"
          - listitem [ref=e366]: "T6 Seat 4: East ford → Gold town, took Gold town"
          - listitem [ref=e367]: T6 Seat 4 ends the turn
          - listitem [ref=e368]: "T6 Seat 1: Dark ford → River keep, -0 / -1"
          - listitem [ref=e369]: "T6 Seat 1: Dark ford → River keep, -1 / -0"
          - listitem [ref=e370]: "T6 Seat 1: Dark ford → River keep, -1 / -0"
          - listitem [ref=e371]: "T6 Seat 1: Dark ford → River keep, -1 / -0"
          - listitem [ref=e372]: "T6 Seat 1: Dark ford → River keep, -0 / -1"
          - listitem [ref=e373]: "T6 Seat 1: Dark ford → River keep, -0 / -1"
          - listitem [ref=e374]: "T6 Seat 1: Dark ford → River keep, -1 / -0"
          - listitem [ref=e375]: "T6 Seat 1: Dark ford → River keep, took River keep"
          - listitem [ref=e376]: T6 Seat 1 ends the turn
          - listitem [ref=e377]: "T6 Seat 2: Bay ford → Moon point, -1 / -0"
          - listitem [ref=e378]: "T6 Seat 2: Bay ford → Moon point, -1 / -0"
          - listitem [ref=e379]: T6 Seat 2 ends the turn
          - listitem [ref=e380]: "T6 Seat 3: High shore → Lower field, -1 / -0"
          - listitem [ref=e381]: "T6 Seat 3: High shore → Lower field, -1 / -0"
          - listitem [ref=e382]: "T6 Seat 3: High shore → Lower field, -1 / -0"
          - listitem [ref=e383]: "T6 Seat 3: High shore → Lower field, -0 / -1"
          - listitem [ref=e384]: "T6 Seat 3: High shore → Lower field, took Lower field"
          - listitem [ref=e385]: T6 Seat 3 ends the turn
          - listitem [ref=e386]: "T7 Seat 4: South fell → New fell, -0 / -1"
          - listitem [ref=e387]: "T7 Seat 4: South fell → New fell, took New fell"
          - listitem [ref=e388]: T7 Seat 4 ends the turn
          - listitem [ref=e389]: "T7 Seat 1: Dark ford → North town, -1 / -0"
          - listitem [ref=e390]: "T7 Seat 1: Dark ford → North town, -1 / -0"
          - listitem [ref=e391]: "T7 Seat 1: Dark ford → North town, took North town"
          - listitem [ref=e392]: T7 Seat 1 ends the turn
          - listitem [ref=e393]: "T7 Seat 2: Wind gate → Lower field, -1 / -0"
          - listitem [ref=e394]: "T7 Seat 2: Wind gate → Lower field, -1 / -0"
          - listitem [ref=e395]: "T7 Seat 2: Wind gate → Lower field, -1 / -0"
          - listitem [ref=e396]: "T7 Seat 2: Wind gate → Lower field, took Lower field"
          - listitem [ref=e397]: T7 Seat 2 ends the turn
          - listitem [ref=e398]: "T7 Seat 3: High shore → Lower field, -1 / -0"
          - listitem [ref=e399]: "T7 Seat 3: High shore → Lower field, took Lower field"
          - listitem [ref=e400]: T7 Seat 3 ends the turn
          - listitem [ref=e401]: "T8 Seat 4: South fell → High ridge, -1 / -0"
          - listitem [ref=e402]: "T8 Seat 4: South fell → High ridge, -0 / -1"
```

# Test source

```ts
  1   | import {expect,test} from '@playwright/test';
  2   | import type {Page,TestInfo} from '@playwright/test';
  3   | import {readFileSync} from 'node:fs';
  4   | import {apply,deserializeVersionedMatch,friendlySources,friendlyTargets} from '../../src/core';
  5   | import type {Action,GameState} from '../../src/core';
  6   | const fixtureRoot='docs/prototypes/new-game/';
  7   | const input=(name:string)=>readFileSync(fixtureRoot+name,'utf8');
  8   | const discoveries=JSON.parse(input('issue180/preflight/discovery.json'));
  9   | const country=(p:Page,id:string)=>p.locator(`[data-country="${id}"]`);
  10  | async function begin(p:Page){
  11  |  await p.clock.install({time:new Date('2026-10-19T12:00:00Z')});await p.clock.pauseAt(new Date('2026-10-19T12:00:00Z'));
  12  |  await p.goto('/');await p.evaluate(()=>{const create=URL.createObjectURL.bind(URL);URL.createObjectURL=blob=>{Reflect.set(window,'iconSave',blob);return create(blob);};});
  13  | }
  14  | async function open(p:Page,surface:string){
  15  |  const d=p.locator('#game-focus-drawer');if(await d.isVisible()&&await d.getAttribute('data-surface')===surface)return;
  16  |  await p.locator('#open-game-'+surface).click();await expect(d).toBeVisible();await expect(d).toHaveAttribute('data-surface',surface);
  17  | }
  18  | async function close(p:Page){if(await p.locator('#game-focus-drawer').isVisible())await p.locator('#close-game-drawer').click();}
  19  | async function load(p:Page,text:string){
  20  |  if(await p.locator('#battle-action-rail').count())await open(p,'settings');
  21  |  const old=await p.getByLabel('Load game',{exact:true}).elementHandle();await p.getByLabel('Load game',{exact:true}).setInputFiles({name:'icons.json',mimeType:'application/json',buffer:Buffer.from(text)});
  22  |  await expect.poll(()=>old!.evaluate(e=>e.isConnected)).toBe(false);await expect(p.locator('[data-country]')).toHaveCount(46);
  23  | }
  24  | async function save(p:Page){await open(p,'settings');await p.getByRole('button',{name:'Save game',exact:true}).click();const text=await p.evaluate(()=>(Reflect.get(window,'iconSave') as Blob).text());await close(p);return text;}
  25  | async function exact(p:Page,state:GameState){expect(deserializeVersionedMatch(await save(p)).state).toEqual(state);}
  26  | function next(state:GameState,action:Action){const r=apply(state,action);if(!r.ok)throw Error(r.error);return r.state;}
  27  | async function collapse(p:Page){
  28  |  for(const id of ['toggle-topbar','toggle-sidebar'])if(await p.locator('#'+id).getAttribute('aria-expanded')==='true')await p.locator('#'+id).click();
  29  |  await expect(p.locator('.topbar')).toBeHidden();await expect(p.locator('.panel')).toBeHidden();
  30  | }
  31  | async function hit(p:Page,id:string){const e=p.locator('#'+id);await expect(e).toBeVisible();await expect(e).toBeEnabled();expect(await e.evaluate(n=>{const r=n.getBoundingClientRect(),h=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return r.x>=0&&r.y>=0&&r.right<=innerWidth&&r.bottom<=innerHeight&&!!h&&(n===h||n.contains(h));}),id+' physically reachable').toBe(true);await e.click();}
  32  | async function railFits(p:Page){const rail=p.locator('#battle-action-rail');expect(await rail.evaluate(e=>e.scrollHeight<=e.clientHeight+1),'rail needs no scrolling').toBe(true);for(const b of await rail.locator('button:visible').all()){expect(await b.evaluate(n=>{const r=n.getBoundingClientRect(),a=n.closest('#battle-action-rail')!.getBoundingClientRect(),h=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return r.top>=a.top&&r.bottom<=a.bottom&&r.left>=a.left&&r.right<=a.right&&!!h&&(n===h||n.contains(h));}),'every visible rail button physically reachable').toBe(true);}}
  33  | async function shot(p:Page,info:TestInfo,name:string){await p.screenshot({path:info.outputPath(name+'.png')});}
  34  | function row(host:string,kind:string){return discoveries.find((r:any)=>r.source===(host==='reference'?'T39-legal-pending-raid.json':'geographic-raid-pending-one-human.json')&&r.kind===kind);}
  35  | for(const host of ['reference','geographic']){
  36  |  test(`${host}: visible sidebar keeps an older history reader across focused surfaces`,async({page},info)=>{
  37  |   await begin(page);
  38  |   const f=row(host,'attack-running'),text=input('issue180/preflight/fixtures/'+f.fixture),before=deserializeVersionedMatch(text);
  39  |   await load(page,text);await hit(page,'toggle-topbar');
  40  |   const history=page.getByRole('list',{name:'Battle log',exact:true});
  41  |   await expect(page.locator('.panel')).toBeVisible();
  42  |   const rows=await history.locator('li').allTextContents();
  43  |   expect(rows.length).toBe(before.state.log.filter(e=>e.event!=='game_started').length);
  44  |   expect(await history.evaluate(e=>e.scrollHeight-e.clientHeight)).toBeGreaterThan(180);
  45  |   for(const reading of [80,120]){
  46  |    await history.evaluate((e,top)=>{e.scrollTop=top;},reading);
  47  |    expect(await history.evaluate(e=>e.scrollTop)).toBe(reading);
  48  |    await open(page,'details');
> 49  |    expect(await history.evaluate(e=>e.scrollTop),'moving visible history must keep the latest reading position').toBe(reading);
      |                                                                                                                  ^ Error: moving visible history must keep the latest reading position
  50  |    await page.keyboard.press('Escape');await expect(page.locator('#open-game-details')).toBeFocused();
  51  |    await expect(page.locator('.panel > .log-card')).toBeVisible();
  52  |    expect(await history.evaluate(e=>e.scrollTop),'returning history to the sidebar must keep the reading position').toBe(reading);
  53  |    await open(page,'settings');await close(page);
  54  |    expect(await history.evaluate(e=>e.scrollTop),'other focused surfaces must not reset the visible history').toBe(reading);
  55  |   }
  56  |   expect(await history.locator('li').allTextContents()).toEqual(rows);
  57  |   await exact(page,before.state);expect(await history.evaluate(e=>e.scrollTop)).toBe(120);
  58  |   await shot(page,info,host+'-visible-sidebar-history');
  59  |  });
  60  |  test(`${host}: sidebar-only rail places armies and starts combat directly without scrolling`,async({page},info)=>{
  61  |   await begin(page);const envelope=JSON.parse(input(`T71/fixtures/${host}-reinforcement.json`));envelope.options.seats=envelope.options.seats.map(()=>({kind:'human'}));envelope.options.computerStrengths=[];const text=JSON.stringify(envelope),before=deserializeVersionedMatch(text);await load(page,text);await hit(page,'toggle-sidebar');await railFits(page);await page.locator('#toggle-sidebar').focus();await page.keyboard.press('ArrowDown');await expect(page.locator('#open-game-actions')).toBeFocused();await page.keyboard.press('Home');await expect(page.locator('#toggle-topbar')).toBeFocused();await page.keyboard.press('End');await expect(page.locator('#battle-action-rail button:visible').last()).toBeFocused();let state=before.state;const owned=state.map.provinces.find(p=>state.ownerOf[p.id]===state.players[state.currentPlayer]!.id)!.id;while(state.reinforcementPool){await country(page,owned).click();state=next(state,{kind:'reinforce',province:owned,amount:1});}await expect(page.locator('#battle-action-rail #start-combat-button')).toBeVisible();await railFits(page);await hit(page,'game-pause-button');await expect(page.locator('#start-combat-button')).toBeDisabled();await exact(page,state);await hit(page,'game-pause-button');await hit(page,'start-combat-button');state=next(state,{kind:'endReinforcement'});await exact(page,state);await shot(page,info,host+'-sidebar-only-rail');
  62  |  });
  63  |  test(`${host}: collapsed battle commands, pause and details preserve exact actions and selection`,async({page},info)=>{
  64  |   await begin(page);const f=row(host,'attack-running'),text=input('issue180/preflight/fixtures/'+f.fixture),before=deserializeVersionedMatch(text);await load(page,text);await collapse(page);
  65  |   await country(page,f.action.from).click();await country(page,f.action.to).click({modifiers:['Shift']});await open(page,'actions');
  66  |   const source=await page.locator('#battle-source-name').textContent(),target=await page.locator('#battle-target-name').textContent();await page.locator('#battle-stop-threshold').fill('1');await page.locator('#battle-stop-threshold').press('Tab');
  67  |   await page.keyboard.press('Escape');await expect(page.locator('#open-game-actions')).toBeFocused();await open(page,'actions');await expect(page.locator('#battle-source-name')).toHaveText(source!);await expect(page.locator('#battle-target-name')).toHaveText(target!);await expect(page.locator('#battle-stop-threshold')).toHaveValue('1');
  68  |   await hit(page,'game-pause-button');await expect(page.locator('#single-exchange-button')).toBeDisabled();await page.locator('#single-exchange-button').evaluate(e=>(e as HTMLButtonElement).click());await exact(page,before.state);await hit(page,'game-pause-button');
  69  |   await open(page,'actions');await close(page);await hit(page,'toggle-topbar');await expect(page.locator('#battle-action-rail #fight-on-button')).toBeVisible();await railFits(page);await shot(page,info,host+'-sidebar-only-battle-rail');await hit(page,'fight-on-button');await page.locator('#stop-battle-button').focus();await page.keyboard.press('Enter');const after=next(before.state,f.action);await exact(page,after);
  70  |   await open(page,'actions');await hit(page,'single-exchange-button');await exact(page,next(after,f.action));
  71  |   await open(page,'details');const history=page.getByRole('list',{name:'Battle log',exact:true});await expect(history.locator('li')).toHaveCount(next(after,f.action).log.filter(e=>e.event!=='game_started').length);await history.evaluate(e=>{e.scrollTop=42;});const reading=await history.evaluate(e=>e.scrollTop);await close(page);await open(page,'settings');await page.locator('#game-speed').selectOption('very-slow');await close(page);await open(page,'details');expect(await history.evaluate(e=>e.scrollTop)).toBe(reading);await shot(page,info,host+'-details');
  72  |   await close(page);await hit(page,'game-log-button');await expect(page.getByRole('dialog',{name:'Game event log',exact:true})).toBeVisible();await page.keyboard.press('Escape');await expect(page.locator('#game-log-button')).toBeFocused();await exact(page,next(after,f.action));
  73  |  });
  74  |  test(`${host}: collapsed capture retains quantity across surfaces, toggles and pause`,async({page},info)=>{
  75  |   await begin(page);const f=row(host,'capture'),text=input('issue180/preflight/fixtures/'+f.fixture),before=deserializeVersionedMatch(text);await load(page,text);await collapse(page);await hit(page,'open-required-action');
  76  |   const pending=before.state.pendingCapture!,amount=pending.min===pending.defaultAmount?pending.max:pending.min;expect(pending.max).toBeGreaterThan(pending.min);expect(amount).not.toBe(pending.defaultAmount);await page.locator('#capture-amount').fill(String(amount));await close(page);await open(page,'cards');await close(page);await open(page,'actions');await expect(page.locator('#capture-amount')).toHaveValue(String(amount));
  77  |   await hit(page,'toggle-sidebar');await hit(page,'toggle-sidebar');await open(page,'actions');await expect(page.locator('#capture-amount')).toHaveValue(String(amount));await hit(page,'game-pause-button');await expect(page.locator('#confirm-capture-button')).toBeDisabled();await hit(page,'game-pause-button');await expect(page.locator('#capture-amount')).toHaveValue(String(amount));await shot(page,info,host+'-capture');await hit(page,'confirm-capture-button');await exact(page,next(before.state,{kind:'captureMove',amount}));
  78  |  });
  79  |  test(`${host}: collapsed friendly non-default draft survives a redraw with input focus`,async({page},info)=>{
  80  |   await begin(page);
  81  |   const envelope=JSON.parse(input(`T71/fixtures/${host}-reinforcement.json`));
  82  |   envelope.options.seats=envelope.options.seats.map(()=>({kind:'human'}));envelope.options.computerStrengths=[];
  83  |   let prepared=deserializeVersionedMatch(JSON.stringify(envelope)).state;
  84  |   const owner=prepared.players[prepared.currentPlayer]!.id;
  85  |   const staging=prepared.map.provinces.filter(p=>prepared.ownerOf[p.id]===owner&&[...p.borders,...p.seaLanes].some(id=>prepared.ownerOf[id]===owner)).sort((a,b)=>prepared.armies[b.id]!-prepared.armies[a.id]!)[0];
  86  |   expect(staging,'reinforcement fixture must contain an owned adjacent pair').toBeDefined();
  87  |   expect(prepared.reinforcementPool).toBeGreaterThan(0);
  88  |   while(prepared.reinforcementPool){const action:Action={kind:'reinforce',province:staging!.id,amount:1};prepared=next(prepared,action);envelope.actions.push(action);}
  89  |   const start:Action={kind:'endReinforcement'};prepared=next(prepared,start);envelope.actions.push(start);
  90  |   const text=JSON.stringify(envelope),before=deserializeVersionedMatch(text);expect(before.state).toEqual(prepared);
  91  |   const sources=friendlySources(before.state).filter(id=>before.state.armies[id]!>=3);
  92  |   expect(sources.length,'fixture needs a legal source with at least two movable armies').toBeGreaterThan(0);
  93  |   const from=sources[0]!,to=friendlyTargets(before.state,from)[0]!,maximum=before.state.armies[from]!-1,amount=maximum-1;
  94  |   expect(maximum).toBeGreaterThanOrEqual(2);expect(amount).toBeGreaterThanOrEqual(1);expect(amount).toBeLessThan(maximum);
  95  |   await load(page,text);await collapse(page);await open(page,'actions');await hit(page,'start-friendly-move-button');await close(page);
  96  |   await country(page,from).click();await country(page,to).click();await open(page,'actions');
  97  |   const quantity=page.locator('#friendly-move-amount');await expect(quantity).toHaveAttribute('max',String(maximum));await expect(quantity).toHaveValue(String(maximum));
  98  |   await quantity.fill(String(amount));await page.keyboard.press('Escape');await expect(page.locator('#open-game-actions')).toBeFocused();
  99  |   await open(page,'settings');await close(page);await hit(page,'toggle-topbar');await open(page,'actions');
  100 |   await expect(quantity).toHaveValue(String(amount));await quantity.focus();await expect(quantity).toBeFocused();
  101 |   const retired=await quantity.elementHandle();
  102 |   await page.locator('#game-speed').selectOption('slow');
  103 |   expect(await retired!.evaluate(e=>e.isConnected),'speed change must actually replace the friendly controls').toBe(false);
  104 |   await expect(quantity).toHaveValue(String(amount));await expect(quantity).toBeFocused();
  105 |   await shot(page,info,host+'-friendly-redraw');await hit(page,'confirm-friendly-move-button');
  106 |   await exact(page,next(before.state,{kind:'friendlyMove',from,to,amount}));
  107 |  });
  108 |  test(`${host}: collapsed card trade and nonmodal Raid use ordinary core actions`,async({page},info)=>{
  109 |   await begin(page);const trade=host==='reference'?'T38-legal-Surge-before.json':'geographic-income-before-one-human.json',before=deserializeVersionedMatch(input('T40/fixtures/'+trade));await load(page,input('T40/fixtures/'+trade));await collapse(page);await hit(page,'open-required-action');await page.getByRole('button',{name:/^Surge:/}).click();await exact(page,next(before.state,{kind:'tradeCards',handIndices:[0,1,4]}));
  110 |   const raid=host==='reference'?'T39-legal-pending-raid.json':'geographic-raid-pending-one-human.json',pending=deserializeVersionedMatch(input('T40/fixtures/'+raid));await load(page,input('T40/fixtures/'+raid));await expect(page.locator('#toggle-sidebar')).toHaveAttribute('aria-expanded','false');await expect(page.locator('#toggle-topbar')).toHaveAttribute('aria-expanded','false');await open(page,'cards');await expect(page.locator('#game-focus-drawer')).toHaveAttribute('aria-modal','false');await close(page);await country(page,'province_41').click();await open(page,'cards');await expect(page.getByRole('button',{name:'Confirm raid',exact:true})).toBeEnabled();await hit(page,'game-pause-button');await expect(page.getByRole('button',{name:'Confirm raid',exact:true})).toBeDisabled();await hit(page,'game-pause-button');await shot(page,info,host+'-raid');await page.getByRole('button',{name:'Confirm raid',exact:true}).click();await exact(page,next(pending.state,{kind:'raidTarget',province:'province_41'}));
  111 |  });
  112 | }
  113 | test('collapsed full-hand discard, reward, skip and replacement retain reachable choices and clean surfaces',async({page},info)=>{
  114 |  await begin(page);const text=input('T40/fixtures/T37-reshuffle-before-match.json'),before=deserializeVersionedMatch(text),hand=before.state.cards!.hands[before.state.players.find(p=>p.kind==='human')!.id]!;await load(page,text);await collapse(page);await hit(page,'open-required-action');await expect(page.getByRole('button',{name:/^Discard .*\(card /})).toHaveCount(5);await page.getByRole('button',{name:`Discard ${hand[2]} (card 3)`,exact:true}).click();const after=next(before.state,{kind:'discardCard',handIndex:2});await exact(page,after);await hit(page,'open-required-action');await shot(page,info,'discard-reward');await page.getByRole('button',{name:'Continue',exact:true}).click();await page.keyboard.press('Escape');await expect(page.locator('#toggle-sidebar')).toBeFocused();await exact(page,after);
  115 |  const replacement=input('T40/fixtures/T38-legal-Surge-before.json'),fresh=deserializeVersionedMatch(replacement);await load(page,replacement);await expect(page.locator('#game-focus-drawer')).toBeHidden();await expect(page.locator('#toggle-sidebar')).toHaveAttribute('aria-expanded','false');await hit(page,'open-required-action');await page.getByRole('button',{name:'Skip cards',exact:true}).click();await exact(page,next(fresh.state,{kind:'skipCards'}));
  116 |  await open(page,'settings');await page.getByRole('button',{name:'New game',exact:true}).click();await expect(page.getByRole('button',{name:'Start game',exact:true})).toBeVisible();await expect(page.locator('#game-focus-drawer')).toHaveCount(0);
  117 | });
  118 | 
  119 | test('collapsed human-loss and finished choices keep core results reachable',async({page},info)=>{
  120 |  await begin(page);const text=input('T40/fixtures/T40-human-loss-450.json'),before=deserializeVersionedMatch(text);expect(before.state.phase).toBe('human-loss');await load(page,text);await collapse(page);await hit(page,'open-required-action');await hit(page,'watch-computers-button');await exact(page,next(before.state,{kind:'watchComputers'}));await load(page,text);await hit(page,'open-required-action');await hit(page,'stop-game-button');await exact(page,next(before.state,{kind:'stopGame'}));await hit(page,'open-required-action');await shot(page,info,'finished-result');await close(page);await open(page,'settings');await page.getByRole('button',{name:'New game',exact:true}).click();await expect(page.getByRole('button',{name:'Start game',exact:true})).toBeVisible();await page.getByRole('button',{name:'Start game',exact:true}).click();await expect(page.locator('#toggle-sidebar')).toHaveAttribute('aria-expanded','false');await expect(page.locator('#toggle-topbar')).toHaveAttribute('aria-expanded','false');
  121 | });
  122 | 
```