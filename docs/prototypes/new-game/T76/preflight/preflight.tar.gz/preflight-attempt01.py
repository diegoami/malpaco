from pathlib import Path
import hashlib,json,os,subprocess,time
w=Path('/home/diego/projects/malpaco/.cache/worktrees/T76-panels');out=w/'docs/prototypes/new-game/T76/preflight';root=Path('/home/diego/projects/malpaco');src=w/'src/ui/referenceBattleGame.ts';saved=src.read_bytes();(out/'referenceBattleGame.ts.original.txt').write_bytes(saved)
records=[]
def run(label):
 d=out/label;d.mkdir();cmd=['docker','run','--rm','--pull=never','--name','malpaco-t76-'+label,'--network','none','--shm-size=1g','--user',f'{os.getuid()}:{os.getgid()}','--mount',f'type=bind,src={w},dst={w}','--workdir',str(w),'--env','PLAYWRIGHT_JSON_OUTPUT_FILE='+str(d/'results.json'),'--env','PLAYWRIGHT_HTML_OUTPUT_DIR='+str(d/'html'),'sha256:eff16c30e6f3f4af0a03fa4b706120d5e9b0891c344a27d64559aff5900a4a27','node_modules/.bin/playwright','test','tests/e2e/hideable-panels.spec.ts','--workers=2','--reporter=list,json','--output',str(d/'browser')]
 start=time.monotonic()
 with (d/'raw.log').open('w') as f:r=subprocess.run(cmd,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
 stats=json.loads((d/'results.json').read_text())['stats'];record=dict(label=label,argv=cmd,exit=r.returncode,seconds=time.monotonic()-start,stats=stats);records.append(record);(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');return record
try:
 b=run('baseline');assert b['exit']!=0 and b['stats']['unexpected']==8 and b['stats']['skipped']==0,b
 mock=(root/'.cache/release-011/mock.txt').read_text();(out/'mock-injection.txt').write_text(mock)
 original=saved.decode();needle='    this.mounted = true;\n    this.render();';assert original.count(needle)==1
 src.write_text(original.replace(needle,needle+'\n'+mock))
 m=run('mock');assert m['exit']==0 and m['stats']['expected']==8,m
finally:
 src.write_bytes(saved);assert src.read_bytes()==saved
 (out/'restoration.json').write_text(json.dumps({'restoredExact':True,'sha256':hashlib.sha256(saved).hexdigest(),'testsSha256':hashlib.sha256((w/'tests/e2e/hideable-panels.spec.ts').read_bytes()).hexdigest()},indent=2)+'\n')
(out/'REPORT.md').write_text('# T76 acceptance preflight\n\nBaseline: eight executed failures because the independent hide/restore controls are absent. Temporary minimal DOM/CSS mock: eight passes at both desktop sizes and both hosts. This validates selector, layout measurement, save-invariance and focused-card-surface checks; it is not the implementation or proof of all future interaction coverage. Mock source was restored byte-for-byte in finally. Raw commands/results/logs and screenshots retained alongside this report. Existing regression suites are release-proven baseline constraints; new collapsed-flow coverage remains implementation work under DW2. No CI/review run.\n')
print(json.dumps(records))
