# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: hideable-panels.spec.ts >> geographic: independently hidden panels reclaim map area and restore exactly
- Location: tests/e2e/hideable-panels.spec.ts:24:3

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator: locator('#toggle-topbar')
Expected: "true"
Timeout: 1000ms
Error: element(s) not found

Call log:
  - Expect "toHaveAttribute" locator('#toggle-topbar') with timeout 1000ms
  - waiting for locator('#toggle-topbar')

```

```yaml
- banner:
  - heading "Malpaco" [level=1]
  - text: Generated islands · 1 human / 3 computer seats · Computer play · Seed 1994 Seat 1
  - strong: "Total armies: 24"
  - text: 12 provinces Seat 2 · Computer
  - strong: "Total armies: 24"
  - text: 12 provinces Seat 3 · Computer
  - strong: "Total armies: 22"
  - text: 11 provinces Seat 4 · Computer
  - strong: "Total armies: 22"
  - text: 11 provinces
  - button "Game event log"
  - button "Pause game": Pause
  - text: Game speed
  - combobox "Game speed":
    - option "Very slow (2 s)"
    - option "Slow"
    - option "Normal" [selected]
    - option "Fast"
  - text: Panel detail
  - combobox "Panel detail":
    - option "Compact" [selected]
    - option "Detailed"
  - contentinfo:
    - button "New game"
  - button "Save game"
  - text: Load game
  - button "Load game"
- main:
  - group "Generated island map":
    - button "Country 1, Seat 2, 2 armies, Seat 2": "2"
    - button "Country 2, Seat 1, 3 armies, Seat 1": "3"
    - button "Country 3, Seat 3, 3 armies, Seat 3": "3"
    - button "Country 4, Seat 2, 2 armies, Seat 2": "2"
    - button "Country 5, Seat 4, 1 armies, Seat 4": "1"
    - button "Country 6, Seat 3, 2 armies, Seat 3": "2"
    - button "Country 7, Seat 2, 3 armies, Seat 2": "3"
    - button "Country 8, Seat 2, 3 armies, Seat 2": "3"
    - button "Country 9, Seat 1, 3 armies, Seat 1": "3"
    - button "Country 10, Seat 4, 2 armies, Seat 4": "2"
    - button "Country 11, Seat 4, 2 armies, Seat 4": "2"
    - button "Country 12, Seat 1, 2 armies, Seat 1": "2"
    - button "Country 13, Seat 1, 2 armies, Seat 1": "2"
    - button "Country 14, Seat 1, 1 armies, Seat 1": "1"
    - button "Country 15, Seat 4, 2 armies, Seat 4": "2"
    - button "Country 16, Seat 1, 3 armies, Seat 1": "3"
    - button "Country 17, Seat 2, 1 armies, Seat 2": "1"
    - button "Country 18, Seat 2, 1 armies, Seat 2": "1"
    - button "Country 19, Seat 1, 2 armies, Seat 1": "2"
    - button "Country 20, Seat 2, 2 armies, Seat 2": "2"
    - button "Country 21, Seat 3, 2 armies, Seat 3": "2"
    - button "Country 22, Seat 4, 3 armies, Seat 4": "3"
    - button "Country 23, Seat 3, 1 armies, Seat 3": 1 ★
    - button "Country 24, Seat 1, 1 armies, Seat 1": "1"
    - button "Country 25, Seat 2, 1 armies, Seat 2": "1"
    - button "Country 26, Seat 4, 1 armies, Seat 4": "1"
    - button "Country 27, Seat 3, 3 armies, Seat 3": "3"
    - button "Country 28, Seat 1, 1 armies, Seat 1": "1"
    - button "Country 29, Seat 1, 3 armies, Seat 1": "3"
    - button "Country 30, Seat 3, 2 armies, Seat 3": "2"
    - button "Country 31, Seat 3, 2 armies, Seat 3": "2"
    - button "Country 32, Seat 2, 3 armies, Seat 2": "3"
    - button "Country 33, Seat 1, 1 armies, Seat 1": "1"
    - button "Country 34, Seat 3, 2 armies, Seat 3": 2 ★
    - button "Country 35, Seat 2, 3 armies, Seat 2": 3 ★
    - button "Country 36, Seat 3, 1 armies, Seat 3": "1"
    - button "Country 37, Seat 2, 2 armies, Seat 2": "2"
    - button "Country 38, Seat 1, 2 armies, Seat 1": "2"
    - button "Country 39, Seat 4, 3 armies, Seat 4": "3"
    - button "Country 40, Seat 4, 1 armies, Seat 4": "1"
    - button "Country 41, Seat 2, 1 armies, Seat 2": "1"
    - button "Country 42, Seat 4, 3 armies, Seat 4": "3"
    - button "Country 43, Seat 4, 2 armies, Seat 4": "2"
    - button "Country 44, Seat 3, 2 armies, Seat 3": "2"
    - button "Country 45, Seat 3, 2 armies, Seat 3": "2"
    - button "Country 46, Seat 4, 2 armies, Seat 4": "2"
  - complementary:
    - text: Seat 3's turn Computer · Normal · Round 1 · Reinforcement Province income
    - strong: "3"
    - text: Island income
    - strong: "0"
    - text: Armies to place
    - strong: "3"
    - status: Seat 3 is playing…
    - heading "Battle log" [level=3]
    - list "Battle log"
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | import type {Page,TestInfo} from '@playwright/test';
  3  | import {readFileSync} from 'node:fs';
  4  | 
  5  | async function begin(page:Page,host:string,kind:'layout'|'cards') {
  6  |   await page.clock.install({time:new Date('2026-10-19T12:00:00Z')});
  7  |   await page.clock.pauseAt(new Date('2026-10-19T12:00:00Z'));
  8  |   const errors:string[]=[];page.on('pageerror',e=>errors.push(String(e)));
  9  |   await page.goto(host==='reference'?'/?view=reference-game':'/',{waitUntil:'domcontentloaded'});
  10 |   await page.evaluate(()=>{const create=URL.createObjectURL.bind(URL);URL.createObjectURL=blob=>{Reflect.set(window,'t76Save',blob);return create(blob);};});
  11 |   const path=kind==='layout'?`docs/prototypes/new-game/T71/fixtures/${host}-reinforcement.json`:
  12 |     `docs/prototypes/new-game/T40/fixtures/${host==='reference'?'T38-legal-Surge-before.json':'geographic-income-before-one-human.json'}`;
  13 |   const old=await page.getByLabel('Load game',{exact:true}).elementHandle();
  14 |   await page.getByLabel('Load game',{exact:true}).setInputFiles({name:'panels.json',mimeType:'application/json',buffer:Buffer.from(readFileSync(path))});
  15 |   await expect.poll(()=>old!.evaluate(e=>e.isConnected)).toBe(false);
  16 |   await expect(page.locator('.battle-reference [data-country]')).toHaveCount(46);
  17 |   return errors;
  18 | }
  19 | async function save(page:Page){await page.getByRole('button',{name:'Save game',exact:true}).click();return page.evaluate(()=>(Reflect.get(window,'t76Save') as Blob).text());}
  20 | async function box(page:Page){return page.locator('.battle-reference .board').evaluate(e=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height};});}
  21 | async function fits(page:Page,selector:string){const e=page.locator(selector);await expect(e).toBeVisible();expect(await e.evaluate(n=>{const r=n.getBoundingClientRect(),hit=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return r.width>0&&r.height>0&&r.x>=0&&r.y>=0&&r.right<=innerWidth&&r.bottom<=innerHeight&&!!hit&&(n===hit||n.contains(hit));})).toBe(true);}
  22 | async function evidence(page:Page,info:TestInfo,label:string){await page.screenshot({path:info.outputPath(label+'.png')});await info.attach(label,{body:JSON.stringify({board:await box(page),scroll:await page.evaluate(()=>({width:document.documentElement.scrollWidth,height:document.documentElement.scrollHeight,innerWidth,innerHeight}))}),contentType:'application/json'});}
  23 | for(const host of ['reference','geographic']){
  24 |   test(`${host}: independently hidden panels reclaim map area and restore exactly`,async({page},info)=>{
  25 |     const errors=await begin(page,host,'layout');const before=await save(page),original=await box(page);
  26 |     const top=page.locator('#toggle-topbar'),side=page.locator('#toggle-sidebar');
> 27 |     await expect(top).toHaveAttribute('aria-expanded','true',{timeout:1000});
     |                       ^ Error: expect(locator).toHaveAttribute(expected) failed
  28 |     await expect(side).toHaveAttribute('aria-expanded','true',{timeout:1000});
  29 |     await evidence(page,info,'expanded');
  30 |     await top.click();await expect(top).toHaveAttribute('aria-expanded','false');await expect(page.locator('.battle-reference .topbar')).toBeHidden();
  31 |     const topHidden=await box(page);expect(topHidden.height).toBeGreaterThan(original.height+24);expect(topHidden.width).toBe(original.width);
  32 |     await side.click();await expect(side).toHaveAttribute('aria-expanded','false');
  33 |     const both=await box(page);expect(both.width).toBeGreaterThan(original.width+200);expect(both.height).toBe(topHidden.height);
  34 |     const rail=page.locator('#battle-action-rail');await expect(rail).toHaveAttribute('role','toolbar');expect((await rail.boundingBox())!.width).toBeLessThanOrEqual(72);
  35 |     for(const id of ['toggle-topbar','toggle-sidebar','open-game-cards','open-game-details','open-game-settings']){await fits(page,'#'+id);const control=page.locator('#'+id);await expect(control).toHaveAccessibleName(/\S/);await expect(control).toHaveAttribute('title',/\S/);}
  36 |     expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight)).toBe(true);
  37 |     await evidence(page,info,'both-hidden');
  38 |     await top.focus();await top.press('Enter');await expect(top).toHaveAttribute('aria-expanded','true');
  39 |     const sideOnly=await box(page);expect(sideOnly.width).toBe(both.width);expect(sideOnly.height).toBe(original.height);
  40 |     await side.focus();await side.press('Space');await expect(side).toHaveAttribute('aria-expanded','true');expect(await box(page)).toEqual(original);
  41 |     expect(await save(page)).toBe(before);expect(errors).toEqual([]);
  42 |   });
  43 |   test(`${host}: icon cards surface closes with Escape and returns focus without game actions`,async({page},info)=>{
  44 |     const errors=await begin(page,host,'cards');const before=await save(page);
  45 |     const top=page.locator('#toggle-topbar'),side=page.locator('#toggle-sidebar');
  46 |     await expect(side).toBeVisible({timeout:1000});await side.click();await top.click();
  47 |     const cards=page.locator('#open-game-cards');await fits(page,'#open-game-cards');await cards.click();
  48 |     const drawer=page.locator('#game-focus-drawer');await expect(drawer).toBeVisible();await expect(drawer).toHaveAttribute('role','dialog');
  49 |     await expect(drawer.locator('.card-interactions')).toBeVisible();await fits(page,'#close-game-drawer');await evidence(page,info,'cards-drawer');
  50 |     await page.keyboard.press('Escape');await expect(drawer).toBeHidden();await expect(cards).toBeFocused();
  51 |     await cards.press('Enter');await expect(drawer).toBeVisible();await page.locator('#close-game-drawer').click();await expect(cards).toBeFocused();
  52 |     await top.click();await side.click();expect(await save(page)).toBe(before);expect(errors).toEqual([]);
  53 |   });
  54 | }
  55 | 
```