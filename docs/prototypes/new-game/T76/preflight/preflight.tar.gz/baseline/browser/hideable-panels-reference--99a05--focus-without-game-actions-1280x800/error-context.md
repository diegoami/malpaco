# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: hideable-panels.spec.ts >> reference: icon cards surface closes with Escape and returns focus without game actions
- Location: tests/e2e/hideable-panels.spec.ts:43:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('#toggle-sidebar')
Expected: visible
Timeout: 1000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('#toggle-sidebar') with timeout 1000ms
  - waiting for locator('#toggle-sidebar')

```

```yaml
- banner:
  - heading "Malpaco" [level=1]
  - text: Nine Isles · 1 human / 3 computer seats · Computer play · Seed 2 Seat 1 · Computer
  - strong: "Total armies: 89"
  - text: 13 provinces Seat 2 · Computer
  - strong: "Total armies: 24"
  - text: 8 provinces Seat 3 · Computer
  - strong: "Total armies: 98"
  - text: 15 provinces Seat 4
  - strong: "Total armies: 58"
  - text: 10 provinces
  - button "Game event log"
  - button "Pause game": Pause
  - text: Game speed
  - combobox "Game speed":
    - option "Very slow (2 s)"
    - option "Slow"
    - option "Normal" [selected]
    - option "Fast"
  - text: Panel detail
  - combobox "Panel detail":
    - option "Compact" [selected]
    - option "Detailed"
  - contentinfo:
    - button "New game"
  - button "Save game"
  - text: Load game
  - button "Load game"
- main:
  - img "Nine Isles reference map":
    - button "River gate, Seat 1, 1 armies, Seat 1": River gate 1
    - button "New port, Seat 1, 70 armies, Seat 1": New port 70
    - button "North rest, Seat 1, 1 armies, Seat 1": North rest 1
    - button "River keep, Seat 4, 1 armies, Seat 4": River keep 1 ★
    - button "North town, Seat 4, 1 armies, Seat 4": North town 1
    - button "Dark ford, Seat 4, 42 armies, Seat 4": Dark ford 42
    - button "Iron point, Seat 3, 1 armies, Seat 3": Iron point 1
    - button "South rest, Seat 1, 2 armies, Seat 1": South rest 2
    - button "High shore, Seat 3, 2 armies, Seat 3": High shore 2
    - button "Wind town, Seat 3, 77 armies, Seat 3": Wind town 77
    - button "New glen, Seat 3, 1 armies, Seat 3": New glen 1
    - button "Old rock, Seat 3, 1 armies, Seat 3": Old rock 1
    - button "Blue peak, Seat 1, 2 armies, Seat 1": Blue peak 2
    - button "West haven, Seat 3, 2 armies, Seat 3": West haven 2
    - button "Stone watch, Seat 1, 1 armies, Seat 1": Stone watch 1
    - button "Upper ridge, Seat 1, 1 armies, Seat 1": Upper ridge 1 ★
    - button "Marsh keep, Seat 4, 1 armies, Seat 4": Marsh keep 1
    - button "New fell, Seat 2, 1 armies, Seat 2": New fell 1
    - button "Moon point, Seat 2, 1 armies, Seat 2": Moon point 1 ★
    - button "South fell, Seat 3, 1 armies, Seat 3": South fell 1
    - button "High ridge, Seat 2, 11 armies, Seat 2": High ridge 11
    - button "Bay ford, Seat 3, 2 armies, Seat 3": Bay ford 2
    - button "Low moor, Seat 3, 2 armies, Seat 3": Low moor 2
    - button "Lower field, Seat 1, 1 armies, Seat 1": Lower field 1
    - button "Wind gate, Seat 4, 3 armies, Seat 4": Wind gate 3
    - button "Silver shore, Seat 4, 2 armies, Seat 4": Silver shore 2
    - button "Low peak, Seat 2, 3 armies, Seat 2": Low peak 3
    - button "Wind port, Seat 2, 1 armies, Seat 2": Wind port 1
    - button "Gold point, Seat 4, 3 armies, Seat 4": Gold point 3
    - button "Rock moor, Seat 3, 2 armies, Seat 3": Rock moor 2
    - button "Marsh rest, Seat 3, 1 armies, Seat 3": Marsh rest 1
    - button "Wind dale, Seat 3, 1 armies, Seat 3": Wind dale 1
    - button "Silver ford, Seat 4, 1 armies, Seat 4": Silver ford 1
    - button "Iron field, Seat 1, 2 armies, Seat 1": Iron field 2
    - button "North wood, Seat 3, 2 armies, Seat 3": North wood 2
    - button "Fort town, Seat 2, 2 armies, Seat 2": Fort town 2
    - button "Red field, Seat 1, 3 armies, Seat 1": Red field 3
    - button "South ridge, Seat 3, 2 armies, Seat 3": South ridge 2
    - button "Rock bay, Seat 4, 1 armies, Seat 4": Rock bay 1
    - button "North ford, Seat 1, 2 armies, Seat 1": North ford 2
    - button "Port ridge, Seat 3, 1 armies, Seat 3": Port ridge 1
    - button "New rock, Seat 2, 2 armies, Seat 2": New rock 2
    - button "South reach, Seat 2, 3 armies, Seat 2": South reach 3
    - button "Silver point, Seat 1, 1 armies, Seat 1": Silver point 1
    - button "East ford, Seat 4, 3 armies, Seat 4": East ford 3
    - button "Gold town, Seat 1, 2 armies, Seat 1": Gold town 2
    - text: North Isle +3 East Isle +3 West Isle +3 South Isle +3 Central Isle +5 Harbor Isle +5 Palm Isle +6 Cliff Isle +5 Great Isle +9
  - complementary:
    - text: Seat 4's turn Round 12 · Cards
    - region "Cards":
      - paragraph: "Draw: 8 · Discard: 13 · Top: Anchor. seat1: 4 · seat2: 5 · seat3: 5 · seat4: 5"
      - strong: "Your hand: 5 of 5"
      - strong: Wild
      - text: Replaces up to two missing set cards
      - strong: Surge
      - text: Three double turn income
      - strong: Compass
      - text: Three add 8 armies
      - strong: Compass
      - text: Three add 8 armies
      - strong: Wild
      - text: Replaces up to two missing set cards
      - paragraph: Choose at most one set, or skip.
      - 'button "Surge: Wild + Surge + Wild — Double pool: 6 → 12"'
      - 'button "Compass: Wild + Compass + Compass — Add 8 armies"'
      - 'button "Compass: Wild + Compass + Wild — Add 8 armies"'
      - 'button "Compass: Wild + Compass + Wild — Add 8 armies"'
      - 'button "Compass: Compass + Compass + Wild — Add 8 armies"'
      - button "Skip cards"
    - heading "Battle log" [level=3]
    - list "Battle log":
      - listitem: "T1 Seat 2: High ridge → New fell, took New fell"
      - listitem: T1 Seat 2 ends the turn
      - listitem: "T1 Seat 3: Wind town → New glen, -0 / -1"
      - listitem: "T1 Seat 3: Wind town → New glen, -1 / -0"
      - listitem: "T1 Seat 3: Wind town → New glen, took New glen"
      - listitem: T1 Seat 3 ends the turn
      - listitem: "T1 Seat 4: Dark ford → River keep, -0 / -1"
      - listitem: "T1 Seat 4: Dark ford → River keep, took River keep"
      - listitem: T1 Seat 4 ends the turn
      - listitem: "T1 Seat 1: New port → River gate, -0 / -1"
      - listitem: "T1 Seat 1: New port → River gate, took River gate"
      - listitem: T1 Seat 1 ends the turn
      - listitem: "T2 Seat 2: High ridge → Moon point, -1 / -0"
      - listitem: "T2 Seat 2: High ridge → Moon point, -0 / -1"
      - listitem: "T2 Seat 2: High ridge → Moon point, took Moon point"
      - listitem: T2 Seat 2 ends the turn
      - listitem: "T2 Seat 3: Wind town → Old rock, -1 / -0"
      - listitem: "T2 Seat 3: Wind town → Old rock, -1 / -0"
      - listitem: "T2 Seat 3: Wind town → Old rock, took Old rock"
      - listitem: T2 Seat 3 ends the turn
      - listitem: "T2 Seat 4: Dark ford → North town, took North town"
      - listitem: T2 Seat 4 ends the turn
      - listitem: "T2 Seat 1: New port → North rest, -1 / -0"
      - listitem: "T2 Seat 1: New port → North rest, -0 / -1"
      - listitem: "T2 Seat 1: New port → North rest, took North rest"
      - listitem: T2 Seat 1 ends the turn
      - listitem: "T3 Seat 2: High ridge → South fell, -0 / -1"
      - listitem: "T3 Seat 2: High ridge → South fell, took South fell"
      - listitem: T3 Seat 2 ends the turn
      - listitem: "T3 Seat 3: Wind town → Port ridge, -1 / -0"
      - listitem: "T3 Seat 3: Wind town → Port ridge, -0 / -1"
      - listitem: "T3 Seat 3: Wind town → Port ridge, took Port ridge"
      - listitem: T3 Seat 3 ends the turn
      - listitem: "T3 Seat 4: Dark ford → New fell, -1 / -0"
      - listitem: "T3 Seat 4: Dark ford → New fell, took New fell"
      - listitem: T3 Seat 4 ends the turn
      - listitem: "T3 Seat 1: Blue peak → Upper ridge, took Upper ridge"
      - listitem: T3 Seat 1 ends the turn
      - listitem: "T4 Seat 2: High ridge → New fell, -1 / -0"
      - listitem: "T4 Seat 2: High ridge → New fell, took New fell"
      - listitem: T4 Seat 2 ends the turn
      - listitem: "T4 Seat 3: Wind town → South fell, -1 / -0"
      - listitem: "T4 Seat 3: Wind town → South fell, took South fell"
      - listitem: T4 Seat 3 ends the turn
      - listitem: "T4 Seat 4: Dark ford → New fell, -1 / -0"
      - listitem: "T4 Seat 4: Dark ford → New fell, took New fell"
      - listitem: T4 Seat 4 ends the turn
      - listitem: "T4 Seat 1: Iron field → Marsh rest, took Marsh rest"
      - listitem: T4 Seat 1 ends the turn
      - listitem: "T5 Seat 2: High ridge → New fell, -1 / -0"
      - listitem: "T5 Seat 2: High ridge → New fell, -1 / -0"
      - listitem: "T5 Seat 2: High ridge → New fell, -1 / -0"
      - listitem: "T5 Seat 2: High ridge → New fell, took New fell"
      - listitem: T5 Seat 2 ends the turn
      - listitem: "T5 Seat 3: Bay ford → Moon point, -1 / -0"
      - listitem: "T5 Seat 3: North wood → Marsh rest, took Marsh rest"
      - listitem: T5 Seat 3 ends the turn
      - listitem: "T5 Seat 4: Dark ford → New fell, took New fell"
      - listitem: T5 Seat 4 ends the turn
      - listitem: T5 Seat 1 ends the turn
      - listitem: "T6 Seat 2: High ridge → New fell, -1 / -0"
      - listitem: "T6 Seat 2: High ridge → New fell, took New fell"
      - listitem: T6 Seat 2 ends the turn
      - listitem: T6 Seat 3 ends the turn
      - listitem: "T6 Seat 4: Dark ford → New fell, -1 / -0"
      - listitem: "T6 Seat 4: Dark ford → New fell, -1 / -0"
      - listitem: "T6 Seat 4: Dark ford → New fell, -1 / -0"
      - listitem: "T6 Seat 4: Dark ford → New fell, -1 / -0"
      - listitem: "T6 Seat 4: Dark ford → New fell, -1 / -0"
      - listitem: "T6 Seat 4: Dark ford → New fell, took New fell"
      - listitem: T6 Seat 4 ends the turn
      - listitem: T6 Seat 1 ends the turn
      - listitem: "T7 Seat 2: High ridge → New fell, took New fell"
      - listitem: T7 Seat 2 ends the turn
      - listitem: T7 Seat 3 ends the turn
      - listitem: "T7 Seat 4: Dark ford → New fell, took New fell"
      - listitem: T7 Seat 4 ends the turn
      - listitem: T7 Seat 1 ends the turn
      - listitem: "T8 Seat 2: High ridge → New fell, -1 / -0"
      - listitem: "T8 Seat 2: High ridge → New fell, took New fell"
      - listitem: T8 Seat 2 ends the turn
      - listitem: T8 Seat 3 ends the turn
      - listitem: "T8 Seat 4: Dark ford → New fell, -1 / -0"
      - listitem: "T8 Seat 4: Dark ford → New fell, took New fell"
      - listitem: T8 Seat 4 ends the turn
      - listitem: T8 Seat 1 ends the turn
      - listitem: "T9 Seat 2: High ridge → New fell, took New fell"
      - listitem: T9 Seat 2 ends the turn
      - listitem: T9 Seat 3 ends the turn
      - listitem: "T9 Seat 4: Dark ford → New fell, took New fell"
      - listitem: T9 Seat 4 ends the turn
      - listitem: T9 Seat 1 ends the turn
      - listitem: "T10 Seat 2: High ridge → New fell, took New fell"
      - listitem: T10 Seat 2 ends the turn
      - listitem: T10 Seat 3 ends the turn
      - listitem: "T10 Seat 4: Dark ford → New fell, -1 / -0"
      - listitem: "T10 Seat 4: Dark ford → New fell, -1 / -0"
      - listitem: "T10 Seat 4: Dark ford → New fell, took New fell"
      - listitem: T10 Seat 4 ends the turn
      - listitem: T10 Seat 1 ends the turn
      - listitem: "T11 Seat 2: High ridge → New fell, took New fell"
      - listitem: T11 Seat 2 ends the turn
      - listitem: T11 Seat 3 ends the turn
      - listitem: "T11 Seat 4: Dark ford → New fell, -1 / -0"
      - listitem: "T11 Seat 4: Dark ford → New fell, took New fell"
      - listitem: T11 Seat 4 ends the turn
      - listitem: T11 Seat 1 ends the turn
      - listitem: "T12 Seat 2: High ridge → New fell, -1 / -0"
      - listitem: "T12 Seat 2: High ridge → New fell, took New fell"
      - listitem: T12 Seat 2 ends the turn
      - listitem: T12 Seat 3 ends the turn
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | import type {Page,TestInfo} from '@playwright/test';
  3  | import {readFileSync} from 'node:fs';
  4  | 
  5  | async function begin(page:Page,host:string,kind:'layout'|'cards') {
  6  |   await page.clock.install({time:new Date('2026-10-19T12:00:00Z')});
  7  |   await page.clock.pauseAt(new Date('2026-10-19T12:00:00Z'));
  8  |   const errors:string[]=[];page.on('pageerror',e=>errors.push(String(e)));
  9  |   await page.goto(host==='reference'?'/?view=reference-game':'/',{waitUntil:'domcontentloaded'});
  10 |   await page.evaluate(()=>{const create=URL.createObjectURL.bind(URL);URL.createObjectURL=blob=>{Reflect.set(window,'t76Save',blob);return create(blob);};});
  11 |   const path=kind==='layout'?`docs/prototypes/new-game/T71/fixtures/${host}-reinforcement.json`:
  12 |     `docs/prototypes/new-game/T40/fixtures/${host==='reference'?'T38-legal-Surge-before.json':'geographic-income-before-one-human.json'}`;
  13 |   const old=await page.getByLabel('Load game',{exact:true}).elementHandle();
  14 |   await page.getByLabel('Load game',{exact:true}).setInputFiles({name:'panels.json',mimeType:'application/json',buffer:Buffer.from(readFileSync(path))});
  15 |   await expect.poll(()=>old!.evaluate(e=>e.isConnected)).toBe(false);
  16 |   await expect(page.locator('.battle-reference [data-country]')).toHaveCount(46);
  17 |   return errors;
  18 | }
  19 | async function save(page:Page){await page.getByRole('button',{name:'Save game',exact:true}).click();return page.evaluate(()=>(Reflect.get(window,'t76Save') as Blob).text());}
  20 | async function box(page:Page){return page.locator('.battle-reference .board').evaluate(e=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height};});}
  21 | async function fits(page:Page,selector:string){const e=page.locator(selector);await expect(e).toBeVisible();expect(await e.evaluate(n=>{const r=n.getBoundingClientRect(),hit=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return r.width>0&&r.height>0&&r.x>=0&&r.y>=0&&r.right<=innerWidth&&r.bottom<=innerHeight&&!!hit&&(n===hit||n.contains(hit));})).toBe(true);}
  22 | async function evidence(page:Page,info:TestInfo,label:string){await page.screenshot({path:info.outputPath(label+'.png')});await info.attach(label,{body:JSON.stringify({board:await box(page),scroll:await page.evaluate(()=>({width:document.documentElement.scrollWidth,height:document.documentElement.scrollHeight,innerWidth,innerHeight}))}),contentType:'application/json'});}
  23 | for(const host of ['reference','geographic']){
  24 |   test(`${host}: independently hidden panels reclaim map area and restore exactly`,async({page},info)=>{
  25 |     const errors=await begin(page,host,'layout');const before=await save(page),original=await box(page);
  26 |     const top=page.locator('#toggle-topbar'),side=page.locator('#toggle-sidebar');
  27 |     await expect(top).toHaveAttribute('aria-expanded','true',{timeout:1000});
  28 |     await expect(side).toHaveAttribute('aria-expanded','true',{timeout:1000});
  29 |     await evidence(page,info,'expanded');
  30 |     await top.click();await expect(top).toHaveAttribute('aria-expanded','false');await expect(page.locator('.battle-reference .topbar')).toBeHidden();
  31 |     const topHidden=await box(page);expect(topHidden.height).toBeGreaterThan(original.height+24);expect(topHidden.width).toBe(original.width);
  32 |     await side.click();await expect(side).toHaveAttribute('aria-expanded','false');
  33 |     const both=await box(page);expect(both.width).toBeGreaterThan(original.width+200);expect(both.height).toBe(topHidden.height);
  34 |     const rail=page.locator('#battle-action-rail');await expect(rail).toHaveAttribute('role','toolbar');expect((await rail.boundingBox())!.width).toBeLessThanOrEqual(72);
  35 |     for(const id of ['toggle-topbar','toggle-sidebar','open-game-cards','open-game-details','open-game-settings']){await fits(page,'#'+id);const control=page.locator('#'+id);await expect(control).toHaveAccessibleName(/\S/);await expect(control).toHaveAttribute('title',/\S/);}
  36 |     expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight)).toBe(true);
  37 |     await evidence(page,info,'both-hidden');
  38 |     await top.focus();await top.press('Enter');await expect(top).toHaveAttribute('aria-expanded','true');
  39 |     const sideOnly=await box(page);expect(sideOnly.width).toBe(both.width);expect(sideOnly.height).toBe(original.height);
  40 |     await side.focus();await side.press('Space');await expect(side).toHaveAttribute('aria-expanded','true');expect(await box(page)).toEqual(original);
  41 |     expect(await save(page)).toBe(before);expect(errors).toEqual([]);
  42 |   });
  43 |   test(`${host}: icon cards surface closes with Escape and returns focus without game actions`,async({page},info)=>{
  44 |     const errors=await begin(page,host,'cards');const before=await save(page);
  45 |     const top=page.locator('#toggle-topbar'),side=page.locator('#toggle-sidebar');
> 46 |     await expect(side).toBeVisible({timeout:1000});await side.click();await top.click();
     |                        ^ Error: expect(locator).toBeVisible() failed
  47 |     const cards=page.locator('#open-game-cards');await fits(page,'#open-game-cards');await cards.click();
  48 |     const drawer=page.locator('#game-focus-drawer');await expect(drawer).toBeVisible();await expect(drawer).toHaveAttribute('role','dialog');
  49 |     await expect(drawer.locator('.card-interactions')).toBeVisible();await fits(page,'#close-game-drawer');await evidence(page,info,'cards-drawer');
  50 |     await page.keyboard.press('Escape');await expect(drawer).toBeHidden();await expect(cards).toBeFocused();
  51 |     await cards.press('Enter');await expect(drawer).toBeVisible();await page.locator('#close-game-drawer').click();await expect(cards).toBeFocused();
  52 |     await top.click();await side.click();expect(await save(page)).toBe(before);expect(errors).toEqual([]);
  53 |   });
  54 | }
  55 | 
```