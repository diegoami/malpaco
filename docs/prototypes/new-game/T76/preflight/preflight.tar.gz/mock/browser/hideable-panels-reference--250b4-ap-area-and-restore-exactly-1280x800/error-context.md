# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: hideable-panels.spec.ts >> reference: independently hidden panels reclaim map area and restore exactly
- Location: tests/e2e/hideable-panels.spec.ts:24:3

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 623.828125
Received:   24
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - main:
    - generic [ref=e3]:
      - img "Nine Isles reference map":
        - button "River gate, Seat 3, 2 armies, Seat 3" [ref=e29] [cursor=pointer]:
          - generic:
            - generic: River
            - generic: gate
            - generic: "2"
        - button "New port, Seat 1, 2 armies, Seat 1" [ref=e31] [cursor=pointer]:
          - generic:
            - generic: New
            - generic: port
            - generic: "2"
        - button "North rest, Seat 2, 1 armies, Seat 2" [ref=e33] [cursor=pointer]:
          - generic:
            - generic: North
            - generic: rest
            - generic: "1"
        - button "River keep, Seat 2, 1 armies, Seat 2" [ref=e35] [cursor=pointer]:
          - generic:
            - generic: River
            - generic: keep
            - generic: "1"
        - button "North town, Seat 2, 1 armies, Seat 2" [ref=e37] [cursor=pointer]:
          - generic:
            - generic: North
            - generic: town
            - generic: "1"
        - button "Dark ford, Seat 3, 1 armies, Seat 3" [ref=e39] [cursor=pointer]:
          - generic:
            - generic: Dark
            - generic: ford
            - generic: "1"
        - button "Iron point, Seat 3, 1 armies, Seat 3" [ref=e41] [cursor=pointer]:
          - generic:
            - generic: Iron
            - generic: point
            - generic: "1"
        - button "South rest, Seat 3, 3 armies, Seat 3" [ref=e43] [cursor=pointer]:
          - generic:
            - generic: South
            - generic: rest
            - generic: "3"
        - button "High shore, Seat 1, 2 armies, Seat 1" [ref=e45] [cursor=pointer]:
          - generic:
            - generic: High
            - generic: shore
            - generic: "2"
        - button "Wind town, Seat 2, 3 armies, Seat 2" [ref=e47] [cursor=pointer]:
          - generic:
            - generic: Wind
            - generic: town
            - generic: "3"
        - button "New glen, Seat 4, 2 armies, Seat 4" [ref=e49] [cursor=pointer]:
          - generic:
            - generic: New
            - generic: glen
            - generic: "2"
        - button "Old rock, Seat 3, 2 armies, Seat 3" [ref=e51] [cursor=pointer]:
          - generic:
            - generic: Old
            - generic: rock
            - generic: "2"
        - button "Blue peak, Seat 2, 3 armies, Seat 2" [ref=e53] [cursor=pointer]:
          - generic:
            - generic: Blue
            - generic: peak
            - generic: "3"
        - button "West haven, Seat 2, 1 armies, Seat 2" [ref=e55] [cursor=pointer]:
          - generic:
            - generic: West
            - generic: haven
            - generic: "1"
        - button "Stone watch, Seat 2, 3 armies, Seat 2" [ref=e57] [cursor=pointer]:
          - generic:
            - generic: Stone
            - generic: watch
            - generic: "3"
        - button "Upper ridge, Seat 4, 2 armies, Seat 4" [ref=e59] [cursor=pointer]:
          - generic:
            - generic: Upper
            - generic: ridge
            - generic: "2"
        - button "Marsh keep, Seat 1, 3 armies, Seat 1" [ref=e61] [cursor=pointer]:
          - generic:
            - generic: Marsh
            - generic: keep
            - generic: "3"
        - button "New fell, Seat 4, 2 armies, Seat 4" [ref=e63] [cursor=pointer]:
          - generic:
            - generic: New
            - generic: fell
            - generic: "2"
        - button "Moon point, Seat 2, 2 armies, Seat 2" [ref=e65] [cursor=pointer]:
          - generic:
            - generic: Moon
            - generic: point
            - generic: "2"
        - button "South fell, Seat 1, 3 armies, Seat 1" [ref=e67] [cursor=pointer]:
          - generic:
            - generic: South
            - generic: fell
            - generic: "3"
        - button "High ridge, Seat 2, 2 armies, Seat 2" [ref=e69] [cursor=pointer]:
          - generic:
            - generic: High
            - generic: ridge
            - generic: "2"
        - button "Bay ford, Seat 2, 3 armies, Seat 2" [ref=e71] [cursor=pointer]:
          - generic:
            - generic: Bay
            - generic: ford
            - generic: "3"
        - button "Low moor, Seat 1, 2 armies, Seat 1" [ref=e73] [cursor=pointer]:
          - generic:
            - generic: Low
            - generic: moor
            - generic: "2"
        - button "Lower field, Seat 1, 1 armies, Seat 1" [ref=e75] [cursor=pointer]:
          - generic:
            - generic: Lower
            - generic: field
            - generic: "1"
        - button "Wind gate, Seat 3, 1 armies, Seat 3" [ref=e77] [cursor=pointer]:
          - generic:
            - generic: Wind
            - generic: gate
            - generic: "1"
        - button "Silver shore, Seat 4, 1 armies, Seat 4" [ref=e79] [cursor=pointer]:
          - generic:
            - generic: Silver
            - generic: shore
            - generic: "1"
        - button "Low peak, Seat 4, 1 armies, Seat 4" [ref=e81] [cursor=pointer]:
          - generic:
            - generic: Low
            - generic: peak
            - generic: "1"
        - button "Wind port, Seat 4, 3 armies, Seat 4" [ref=e83] [cursor=pointer]:
          - generic:
            - generic: Wind
            - generic: port
            - generic: "3"
        - button "Gold point, Seat 3, 2 armies, Seat 3" [ref=e85] [cursor=pointer]:
          - generic:
            - generic: Gold
            - generic: point
            - generic: "2"
          - generic [ref=e87]: ★
        - button "Rock moor, Seat 1, 2 armies, Seat 1" [ref=e88] [cursor=pointer]:
          - generic:
            - generic: Rock
            - generic: moor
            - generic: "2"
        - button "Marsh rest, Seat 3, 2 armies, Seat 3" [ref=e90] [cursor=pointer]:
          - generic:
            - generic: Marsh
            - generic: rest
            - generic: "2"
        - button "Wind dale, Seat 4, 1 armies, Seat 4" [ref=e92] [cursor=pointer]:
          - generic:
            - generic: Wind
            - generic: dale
            - generic: "1"
        - button "Silver ford, Seat 4, 2 armies, Seat 4" [ref=e94] [cursor=pointer]:
          - generic:
            - generic: Silver
            - generic: ford
            - generic: "2"
        - button "Iron field, Seat 4, 2 armies, Seat 4" [ref=e96] [cursor=pointer]:
          - generic:
            - generic: Iron
            - generic: field
            - generic: "2"
        - button "North wood, Seat 1, 1 armies, Seat 1" [ref=e98] [cursor=pointer]:
          - generic:
            - generic: North
            - generic: wood
            - generic: "1"
        - button "Fort town, Seat 3, 2 armies, Seat 3" [ref=e100] [cursor=pointer]:
          - generic:
            - generic: Fort
            - generic: town
            - generic: "2"
          - generic [ref=e102]: ★
        - button "Red field, Seat 2, 3 armies, Seat 2" [ref=e103] [cursor=pointer]:
          - generic:
            - generic: Red
            - generic: field
            - generic: "3"
          - generic [ref=e105]: ★
        - button "South ridge, Seat 1, 2 armies, Seat 1" [ref=e106] [cursor=pointer]:
          - generic:
            - generic: South
            - generic: ridge
            - generic: "2"
        - button "Rock bay, Seat 2, 1 armies, Seat 2" [ref=e108] [cursor=pointer]:
          - generic:
            - generic: Rock
            - generic: bay
            - generic: "1"
        - button "North ford, Seat 4, 3 armies, Seat 4" [ref=e110] [cursor=pointer]:
          - generic:
            - generic: North
            - generic: ford
            - generic: "3"
        - button "Port ridge, Seat 3, 3 armies, Seat 3" [ref=e112] [cursor=pointer]:
          - generic:
            - generic: Port
            - generic: ridge
            - generic: "3"
        - button "New rock, Seat 1, 1 armies, Seat 1" [ref=e114] [cursor=pointer]:
          - generic:
            - generic: New
            - generic: rock
            - generic: "1"
        - button "South reach, Seat 3, 3 armies, Seat 3" [ref=e116] [cursor=pointer]:
          - generic:
            - generic: South
            - generic: reach
            - generic: "3"
        - button "Silver point, Seat 3, 2 armies, Seat 3" [ref=e118] [cursor=pointer]:
          - generic:
            - generic: Silver
            - generic: point
            - generic: "2"
        - button "East ford, Seat 1, 3 armies, Seat 1" [ref=e120] [cursor=pointer]:
          - generic:
            - generic: East
            - generic: ford
            - generic: "3"
        - button "Gold town, Seat 4, 3 armies, Seat 4" [ref=e122] [cursor=pointer]:
          - generic:
            - generic: Gold
            - generic: town
            - generic: "3"
        - generic [ref=e154]: North Isle +3
        - generic [ref=e155]: East Isle +3
        - generic [ref=e156]: West Isle +3
        - generic [ref=e157]: South Isle +3
        - generic [ref=e158]: Central Isle +5
        - generic [ref=e159]: Harbor Isle +5
        - generic [ref=e160]: Palm Isle +6
        - generic [ref=e161]: Cliff Isle +5
        - generic [ref=e162]: Great Isle +9
    - complementary [ref=e163]:
      - generic [ref=e167]:
        - generic [ref=e168]: Seat 4's turn
        - generic [ref=e169]: Computer · Normal · Round 1 · Reinforcement
      - generic [ref=e170]:
        - generic [ref=e171]:
          - generic [ref=e172]:
            - generic [ref=e173]: Province income
            - strong [ref=e174]: "3"
          - generic [ref=e175]:
            - generic [ref=e176]: Island income
            - strong [ref=e177]: "0"
          - generic [ref=e178]:
            - generic [ref=e179]: Armies to place
            - strong [ref=e180]: "3"
        - status [ref=e181]: Seat 4 is playing…
      - generic [ref=e182]:
        - heading "Battle log" [level=3] [ref=e183]
        - list "Battle log"
  - button "Top bar" [active] [ref=e184] [cursor=pointer]: ◇
  - button "Side panel" [expanded] [ref=e185] [cursor=pointer]: ◇
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | import type {Page,TestInfo} from '@playwright/test';
  3  | import {readFileSync} from 'node:fs';
  4  | 
  5  | async function begin(page:Page,host:string,kind:'layout'|'cards') {
  6  |   await page.clock.install({time:new Date('2026-10-19T12:00:00Z')});
  7  |   await page.clock.pauseAt(new Date('2026-10-19T12:00:00Z'));
  8  |   const errors:string[]=[];page.on('pageerror',e=>errors.push(String(e)));
  9  |   await page.goto(host==='reference'?'/?view=reference-game':'/',{waitUntil:'domcontentloaded'});
  10 |   await page.evaluate(()=>{const create=URL.createObjectURL.bind(URL);URL.createObjectURL=blob=>{Reflect.set(window,'t76Save',blob);return create(blob);};});
  11 |   const path=kind==='layout'?`docs/prototypes/new-game/T71/fixtures/${host}-reinforcement.json`:
  12 |     `docs/prototypes/new-game/T40/fixtures/${host==='reference'?'T38-legal-Surge-before.json':'geographic-income-before-one-human.json'}`;
  13 |   const old=await page.getByLabel('Load game',{exact:true}).elementHandle();
  14 |   await page.getByLabel('Load game',{exact:true}).setInputFiles({name:'panels.json',mimeType:'application/json',buffer:Buffer.from(readFileSync(path))});
  15 |   await expect.poll(()=>old!.evaluate(e=>e.isConnected)).toBe(false);
  16 |   await expect(page.locator('.battle-reference [data-country]')).toHaveCount(46);
  17 |   return errors;
  18 | }
  19 | async function save(page:Page){await page.getByRole('button',{name:'Save game',exact:true}).click();return page.evaluate(()=>(Reflect.get(window,'t76Save') as Blob).text());}
  20 | async function box(page:Page){return page.locator('.battle-reference .board').evaluate(e=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height};});}
  21 | async function fits(page:Page,selector:string){const e=page.locator(selector);await expect(e).toBeVisible();expect(await e.evaluate(n=>{const r=n.getBoundingClientRect(),hit=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return r.width>0&&r.height>0&&r.x>=0&&r.y>=0&&r.right<=innerWidth&&r.bottom<=innerHeight&&!!hit&&(n===hit||n.contains(hit));})).toBe(true);}
  22 | async function evidence(page:Page,info:TestInfo,label:string){await page.screenshot({path:info.outputPath(label+'.png')});await info.attach(label,{body:JSON.stringify({board:await box(page),scroll:await page.evaluate(()=>({width:document.documentElement.scrollWidth,height:document.documentElement.scrollHeight,innerWidth,innerHeight}))}),contentType:'application/json'});}
  23 | for(const host of ['reference','geographic']){
  24 |   test(`${host}: independently hidden panels reclaim map area and restore exactly`,async({page},info)=>{
  25 |     const errors=await begin(page,host,'layout');const before=await save(page),original=await box(page);
  26 |     const top=page.locator('#toggle-topbar'),side=page.locator('#toggle-sidebar');
  27 |     await expect(top).toHaveAttribute('aria-expanded','true',{timeout:1000});
  28 |     await expect(side).toHaveAttribute('aria-expanded','true',{timeout:1000});
  29 |     await evidence(page,info,'expanded');
  30 |     await top.click();await expect(top).toHaveAttribute('aria-expanded','false');await expect(page.locator('.battle-reference .topbar')).toBeHidden();
> 31 |     const topHidden=await box(page);expect(topHidden.height).toBeGreaterThan(original.height+24);expect(topHidden.width).toBe(original.width);
     |                                                              ^ Error: expect(received).toBeGreaterThan(expected)
  32 |     await side.click();await expect(side).toHaveAttribute('aria-expanded','false');
  33 |     const both=await box(page);expect(both.width).toBeGreaterThan(original.width+200);expect(both.height).toBe(topHidden.height);
  34 |     const rail=page.locator('#battle-action-rail');await expect(rail).toHaveAttribute('role','toolbar');expect((await rail.boundingBox())!.width).toBeLessThanOrEqual(72);
  35 |     for(const id of ['toggle-topbar','toggle-sidebar','open-game-cards','open-game-details','open-game-settings']){await fits(page,'#'+id);const control=page.locator('#'+id);await expect(control).toHaveAccessibleName(/\S/);await expect(control).toHaveAttribute('title',/\S/);}
  36 |     expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight)).toBe(true);
  37 |     await evidence(page,info,'both-hidden');
  38 |     await top.focus();await top.press('Enter');await expect(top).toHaveAttribute('aria-expanded','true');
  39 |     const sideOnly=await box(page);expect(sideOnly.width).toBe(both.width);expect(sideOnly.height).toBe(original.height);
  40 |     await side.focus();await side.press('Space');await expect(side).toHaveAttribute('aria-expanded','true');expect(await box(page)).toEqual(original);
  41 |     expect(await save(page)).toBe(before);expect(errors).toEqual([]);
  42 |   });
  43 |   test(`${host}: icon cards surface closes with Escape and returns focus without game actions`,async({page},info)=>{
  44 |     const errors=await begin(page,host,'cards');const before=await save(page);
  45 |     const top=page.locator('#toggle-topbar'),side=page.locator('#toggle-sidebar');
  46 |     await expect(side).toBeVisible({timeout:1000});await side.click();await top.click();
  47 |     const cards=page.locator('#open-game-cards');await fits(page,'#open-game-cards');await cards.click();
  48 |     const drawer=page.locator('#game-focus-drawer');await expect(drawer).toBeVisible();await expect(drawer).toHaveAttribute('role','dialog');
  49 |     await expect(drawer.locator('.card-interactions')).toBeVisible();await fits(page,'#close-game-drawer');await evidence(page,info,'cards-drawer');
  50 |     await page.keyboard.press('Escape');await expect(drawer).toBeHidden();await expect(cards).toBeFocused();
  51 |     await cards.press('Enter');await expect(drawer).toBeVisible();await page.locator('#close-game-drawer').click();await expect(cards).toBeFocused();
  52 |     await top.click();await side.click();expect(await save(page)).toBe(before);expect(errors).toEqual([]);
  53 |   });
  54 | }
  55 | 
```