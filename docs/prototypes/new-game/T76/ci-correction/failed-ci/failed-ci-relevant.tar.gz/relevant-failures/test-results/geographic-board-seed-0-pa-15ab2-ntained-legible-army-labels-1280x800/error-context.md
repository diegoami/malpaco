# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: geographic-board.spec.ts >> seed 0 paints actual geography and contained legible army labels
- Location: tests/e2e/geographic-board.spec.ts:81:35

# Error details

```
Error: province_6 40px actual input square

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Generated islands · 2 human seats · Seed 0
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]:
          - strong [ref=e13]: "Total armies: 46"
          - generic [ref=e14]: 23 provinces
      - generic [ref=e18]:
        - generic [ref=e19]: Seat 2
        - generic [ref=e20]:
          - strong [ref=e21]: "Total armies: 46"
          - generic [ref=e22]: 23 provinces
    - region "Game settings" [ref=e23]:
      - generic [ref=e24]:
        - button "Game event log" [ref=e25] [cursor=pointer]
        - button "Pause game" [ref=e26] [cursor=pointer]: Pause
        - generic [ref=e27]: Game speed
        - combobox "Game speed" [ref=e28]:
          - option "Very slow (2 s)"
          - option "Slow"
          - option "Normal" [selected]
          - option "Fast"
        - generic [ref=e29]: Panel detail
        - combobox "Panel detail" [ref=e30]:
          - option "Compact" [selected]
          - option "Detailed"
      - button "New game" [ref=e32] [cursor=pointer]
      - generic [ref=e33]:
        - button "Save game" [ref=e34] [cursor=pointer]
        - generic [ref=e35]:
          - generic [ref=e36]: Load game
          - button "Load game" [ref=e37]
  - main [ref=e38]:
    - group "Generated island map" [ref=e40]:
      - button "Country 1, Seat 1, 1 armies, Seat 1" [ref=e66] [cursor=pointer]:
        - generic: "1"
      - button "Country 2, Seat 2, 2 armies, Seat 2" [ref=e68] [cursor=pointer]:
        - generic: "2"
      - button "Country 3, Seat 2, 2 armies, Seat 2" [ref=e70] [cursor=pointer]:
        - generic: "2"
      - button "Country 4, Seat 2, 1 armies, Seat 2" [ref=e72] [cursor=pointer]:
        - generic: "1"
      - button "Country 5, Seat 1, 2 armies, Seat 1" [ref=e74] [cursor=pointer]:
        - generic: "2"
      - button "Country 6, Seat 2, 1 armies, Seat 2" [ref=e76] [cursor=pointer]:
        - generic: "1"
      - button "Country 7, Seat 1, 3 armies, Seat 1" [ref=e78] [cursor=pointer]:
        - generic: "3"
      - button "Country 8, Seat 2, 2 armies, Seat 2" [ref=e80] [cursor=pointer]:
        - generic: "2"
      - button "Country 9, Seat 2, 3 armies, Seat 2" [ref=e82] [cursor=pointer]:
        - generic: "3"
      - button "Country 10, Seat 2, 1 armies, Seat 2" [ref=e84] [cursor=pointer]:
        - generic: "1"
      - button "Country 11, Seat 1, 2 armies, Seat 1" [ref=e86] [cursor=pointer]:
        - generic: "2"
      - button "Country 12, Seat 2, 1 armies, Seat 2" [ref=e88] [cursor=pointer]:
        - generic: "1"
      - button "Country 13, Seat 2, 1 armies, Seat 2" [ref=e90] [cursor=pointer]:
        - generic: "1"
      - button "Country 14, Seat 1, 1 armies, Seat 1" [ref=e92] [cursor=pointer]:
        - generic:
          - generic: "1"
          - generic: ★
      - button "Country 15, Seat 2, 2 armies, Seat 2" [ref=e94] [cursor=pointer]:
        - generic: "2"
      - button "Country 16, Seat 1, 3 armies, Seat 1" [ref=e96] [cursor=pointer]:
        - generic: "3"
      - button "Country 17, Seat 1, 1 armies, Seat 1" [ref=e98] [cursor=pointer]:
        - generic: "1"
      - button "Country 18, Seat 1, 2 armies, Seat 1" [ref=e100] [cursor=pointer]:
        - generic: "2"
      - button "Country 19, Seat 2, 2 armies, Seat 2" [ref=e102] [cursor=pointer]:
        - generic: "2"
      - button "Country 20, Seat 1, 3 armies, Seat 1" [ref=e104] [cursor=pointer]:
        - generic: "3"
      - button "Country 21, Seat 1, 2 armies, Seat 1" [ref=e106] [cursor=pointer]:
        - generic: "2"
      - button "Country 22, Seat 2, 3 armies, Seat 2" [ref=e108] [cursor=pointer]:
        - generic: "3"
      - button "Country 23, Seat 2, 3 armies, Seat 2" [ref=e110] [cursor=pointer]:
        - generic:
          - generic: "3"
          - generic: ★
      - button "Country 24, Seat 1, 1 armies, Seat 1" [ref=e112] [cursor=pointer]:
        - generic: "1"
      - button "Country 25, Seat 2, 2 armies, Seat 2" [ref=e114] [cursor=pointer]:
        - generic: "2"
      - button "Country 26, Seat 1, 3 armies, Seat 1" [ref=e116] [cursor=pointer]:
        - generic: "3"
      - button "Country 27, Seat 1, 3 armies, Seat 1" [ref=e118] [cursor=pointer]:
        - generic: "3"
      - button "Country 28, Seat 2, 2 armies, Seat 2" [ref=e120] [cursor=pointer]:
        - generic: "2"
      - button "Country 29, Seat 1, 3 armies, Seat 1" [ref=e122] [cursor=pointer]:
        - generic: "3"
      - button "Country 30, Seat 1, 2 armies, Seat 1" [ref=e124] [cursor=pointer]:
        - generic: "2"
      - button "Country 31, Seat 1, 1 armies, Seat 1" [ref=e126] [cursor=pointer]:
        - generic: "1"
      - button "Country 32, Seat 1, 1 armies, Seat 1" [ref=e128] [cursor=pointer]:
        - generic: "1"
      - button "Country 33, Seat 2, 2 armies, Seat 2" [ref=e130] [cursor=pointer]:
        - generic: "2"
      - button "Country 34, Seat 1, 2 armies, Seat 1" [ref=e132] [cursor=pointer]:
        - generic: "2"
      - button "Country 35, Seat 1, 3 armies, Seat 1" [ref=e134] [cursor=pointer]:
        - generic: "3"
      - button "Country 36, Seat 1, 1 armies, Seat 1" [ref=e136] [cursor=pointer]:
        - generic: "1"
      - button "Country 37, Seat 2, 3 armies, Seat 2" [ref=e138] [cursor=pointer]:
        - generic: "3"
      - button "Country 38, Seat 1, 3 armies, Seat 1" [ref=e140] [cursor=pointer]:
        - generic: "3"
      - button "Country 39, Seat 1, 2 armies, Seat 1" [ref=e142] [cursor=pointer]:
        - generic:
          - generic: "2"
          - generic: ★
      - button "Country 40, Seat 2, 1 armies, Seat 2" [ref=e144] [cursor=pointer]:
        - generic: "1"
      - button "Country 41, Seat 1, 1 armies, Seat 1" [ref=e146] [cursor=pointer]:
        - generic: "1"
      - button "Country 42, Seat 2, 2 armies, Seat 2" [ref=e148] [cursor=pointer]:
        - generic: "2"
      - button "Country 43, Seat 2, 3 armies, Seat 2" [ref=e150] [cursor=pointer]:
        - generic: "3"
      - button "Country 44, Seat 2, 2 armies, Seat 2" [ref=e152] [cursor=pointer]:
        - generic: "2"
      - button "Country 45, Seat 2, 2 armies, Seat 2" [ref=e154] [cursor=pointer]:
        - generic: "2"
      - button "Country 46, Seat 2, 3 armies, Seat 2" [ref=e156] [cursor=pointer]:
        - generic: "3"
    - complementary [ref=e158]:
      - generic [ref=e162]:
        - generic [ref=e163]: Seat 2's turn
        - generic [ref=e164]: Round 1 · Reinforcement
      - generic [ref=e165]:
        - generic [ref=e166]:
          - generic [ref=e167]:
            - generic [ref=e168]: Province income
            - strong [ref=e169]: "7"
          - generic [ref=e170]:
            - generic [ref=e171]: Island income
            - strong [ref=e172]: "0"
          - generic [ref=e173]:
            - generic [ref=e174]: Armies to place
            - strong [ref=e175]: "7"
        - paragraph [ref=e176]: Place your armies on your countries, then start combat.
        - generic [ref=e177]:
          - button "Start combat" [disabled] [ref=e178]
          - button "End turn" [disabled] [ref=e179]
      - generic [ref=e180]:
        - heading "Battle log" [level=3] [ref=e181]
        - list "Battle log"
    - toolbar "Game actions" [ref=e182]:
      - button "Hide top panel" [expanded] [ref=e183] [cursor=pointer]
      - button "Hide side panel" [expanded] [ref=e186] [cursor=pointer]
      - button "Game actions" [ref=e189] [cursor=pointer]
      - button "Cards" [disabled] [ref=e192]
      - button "Game details and history" [ref=e195] [cursor=pointer]
      - button "Game settings and files" [ref=e198] [cursor=pointer]
```

# Test source

```ts
  1   | // UNEXECUTED DRAFT. Requires the mounted service/render seams in integration-contract.md.
  2   | // Node imports also work when the browser serves the extracted playable artifact.
  3   | import {expect,test} from '@playwright/test';
  4   | import type {Page} from '@playwright/test';
  5   | import {readFileSync,mkdirSync} from 'node:fs';
  6   | import {join} from 'node:path';
  7   | import {createHash} from 'node:crypto';
  8   | import {activePlayer,apply,attackTargets,raidCardsRules,victoryRules} from '../../src/core';
  9   | import type {Action,GameOptions,GameState} from '../../src/core';
  10  | import {defaultOptions} from '../../src/core/options';
  11  | import {createGeographicGame} from '../../src/core/geographic-game';
  12  | import {GEOGRAPHIC_MATCH_IDENTITY,GEOGRAPHIC_RAID_CARD_MATCH_IDENTITY,REFERENCE_MATCH_IDENTITY,deserializeVersionedMatch} from '../../src/core/match-save';
  13  | import {pinned} from '../core/versioned-match-fixture';
  14  | import frozenCorpus from '../../docs/prototypes/new-game/T36/corpus-selection.json' with {type:'json'};
  15  | import layoutSupplement from '../../docs/prototypes/new-game/T36/corpus-supplement.json' with {type:'json'};
  16  | import {seatLook} from '../../src/ui/palette';
  17  | 
  18  | type Corpus={measured:boolean;targetMet:boolean;sourceHashes:Record<string,string>;selection:{seed:number;purpose:string;mapHash:string}[];refusalSeeds:{seed:number;refusalClasses:string[]}[]};
  19  | // Optional preflight override ONLY. Bare CI uses the committed measured fixture.
  20  | const corpus:Corpus=process.env['GEOGRAPHIC_CORPUS_FILE']?JSON.parse(readFileSync(process.env['GEOGRAPHIC_CORPUS_FILE'],'utf8')):frozenCorpus;
  21  | const visualSelection=[...corpus.selection,...layoutSupplement.selection];
  22  | const hash=(x:unknown)=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
  23  | const optionsFor=(seed:number):GameOptions=>({...defaultOptions(),seed,seats:[{kind:'human'},{kind:'human'}],computerStrengths:[]});
  24  | // Historical/manual fixtures retain victory/1, including their exact dice stream.
  25  | function expected(seed:number){const options=optionsFor(seed),r=createGeographicGame(options,victoryRules(options));if(!r.ok)throw Error(r.errors.join('; '));return {options,...r};}
  26  | // New normal one-human setup consumes the cards3 opening shuffle. No policy oracle.
  27  | function expectedNormal(seed:number){const options={...defaultOptions(),seed},r=createGeographicGame(options,raidCardsRules(options));if(!r.ok)throw Error(r.errors.join('; '));let state=r.state;
  28  |  if(activePlayer(state)!.kind==='human'){expect(state.phase).toBe('cards');expect(state.cards!.hands[activePlayer(state)!.id]).toEqual([]);state=step(state,{kind:'skipCards'});}
  29  |  return {...r,options,initialState:r.state,state};} 
  30  | const country=(p:Page,id:string)=>p.locator(`#geographic-map [data-country="${id}"]`);
  31  | const numbers=(s:string)=>[...s.matchAll(/-?(?:\d+\.?\d*|\.\d+)/g)].map(m=>Number(m[0]));
  32  | async function setup(p:Page,seed=1994){await p.goto(`/?seed=${seed}&control=manual`);await expect(p.getByRole('button',{name:'Start game',exact:true})).toBeVisible();}
  33  | async function start(p:Page,seed:number){await setup(p,seed);await p.getByLabel('Seats',{exact:true}).selectOption('2');for(let n=1;n<=2;n++)await p.getByLabel(`Seat ${n} control`,{exact:true}).selectOption('human');await p.getByRole('button',{name:'Start game',exact:true}).click();await expect(p.locator('#geographic-map')).toBeVisible();}
  34  | async function save(p:Page){const pending=p.waitForEvent('download');await p.getByRole('button',{name:'Save game',exact:true}).click();return readFileSync((await(await pending).path())!,'utf8');}
  35  | async function upload(p:Page,text:string,success=true){const old=await p.getByLabel('Load game',{exact:true}).elementHandle();await p.getByLabel('Load game',{exact:true}).setInputFiles({name:'resume.json',mimeType:'application/json',buffer:Buffer.from(text)});if(success)await expect.poll(()=>old!.evaluate(n=>n.isConnected)).toBe(false);}
  36  | function step(state:GameState,action:Action){const r=apply(state,action);if(!r.ok)throw Error(r.error);return r.state;}
  37  | async function check(p:Page,state:GameState){expect(deserializeVersionedMatch(await save(p)).state).toEqual(state);expect(await p.locator('#geographic-map [data-country]').evaluateAll(ns=>Object.fromEntries(ns.map(n=>[n.getAttribute('data-country'),[n.getAttribute('data-owner'),Number(n.getAttribute('data-armies'))]])))).toEqual(Object.fromEntries(state.map.provinces.map(v=>[v.id,[state.ownerOf[v.id],state.armies[v.id]]])));}
  38  | async function drawing(p:Page){return p.locator('#geographic-map').evaluate(svg=>({
  39  |  countries:[...svg.querySelectorAll<SVGGElement>('[data-country]')].map(g=>({id:g.dataset['country'],d:g.querySelector('.cell')!.getAttribute('d'),x:Number(g.querySelector('.count')!.getAttribute('x')),y:Number(g.querySelector('.count')!.getAttribute('y'))})),
  40  |  routes:[...svg.querySelectorAll('.lane')].map(n=>({edge:n.getAttribute('data-edge'),points:n.getAttribute('points')})),
  41  |  coasts:[...svg.querySelectorAll('.coast')].map(n=>n.getAttribute('d')),
  42  | }));}
  43  | async function labels(p:Page){return p.locator('#geographic-map [data-country]').evaluateAll(nodes=>nodes.map(n=>{
  44  |  const cell=n.querySelector<SVGGeometryElement>('.cell')!,count=n.querySelector<SVGTextElement>('.count')!,badge=n.querySelector<SVGGeometryElement>('.badge')!;
  45  |  const painted=(node:Element)=>{for(let current:Element|null=node;current;current=current.parentElement){const style=getComputedStyle(current);if(style.display==='none'||style.visibility==='hidden'||Number(style.opacity)===0)return false;}return true;};
  46  |  const cellStyle=getComputedStyle(cell);
  47  |  const box=count.getBoundingClientRect(),b=badge.getBoundingClientRect(),ctm=cell.getScreenCTM()!,textStyle=getComputedStyle(count),badgeStyle=getComputedStyle(badge);
  48  |  const anchor=new DOMPoint(Number(count.getAttribute('x')),Number(count.getAttribute('y'))-5).matrixTransform(count.getScreenCTM()!);
  49  |  const hit40=[[-20,-20],[20,-20],[-20,20],[20,20],[0,0]].every(([dx,dy])=>document.elementFromPoint(anchor.x+dx!,anchor.y+dy!)?.closest('[data-country]')===n);
  50  |  const corners=[[box.left,box.top],[box.right,box.top],[box.left,box.bottom],[box.right,box.bottom]];
  51  |  return {id:n.getAttribute('data-country'),text:count.textContent,owner:n.getAttribute('data-owner'),armies:n.getAttribute('data-armies'),name:n.getAttribute('aria-label'),badge:badge.getAttribute('d'),fill:getComputedStyle(cell).fill,
  52  |   cellVisible:painted(cell)&&cell.getTotalLength()>0&&cellStyle.fill!=='none'&&Number(cellStyle.fillOpacity)>0,
  53  |   visible:painted(count)&&count.getClientRects().length>0&&textStyle.visibility!=='hidden'&&textStyle.display!=='none'&&Number(textStyle.opacity)>0&&Number(textStyle.fillOpacity)>0,
  54  |   badgeVisible:painted(badge)&&badge.getTotalLength()>0&&badgeStyle.fill!=='none'&&Number(badgeStyle.opacity)>0&&Number(badgeStyle.fillOpacity)>0,
  55  |   countColor:textStyle.fill,badgeColor:badgeStyle.fill,font:parseFloat(textStyle.fontSize)*Math.hypot(count.getScreenCTM()!.a,count.getScreenCTM()!.b),
  56  |   box:{x:box.left,y:box.top,right:box.right,bottom:box.bottom},inBadge:box.left>=b.left&&box.right<=b.right&&box.top>=b.top&&box.bottom<=b.bottom,
  57  |   hit40,inViewport:box.left>=0&&box.top>=0&&box.right<=innerWidth&&box.bottom<=innerHeight,contained:corners.every(([x,y])=>cell.isPointInFill(new DOMPoint(x,y).matrixTransform(ctm.inverse()))),
  58  |  };
  59  | }));}
  60  | function luminance(s:string){const rgb=numbers(s);expect(rgb.length).toBeGreaterThanOrEqual(3);const c=rgb.slice(0,3).map(n=>n/255).map(n=>n<=.04045?n/12.92:((n+.055)/1.055)**2.4);return c[0]!*.2126+c[1]!*.7152+c[2]!*.0722;}
  61  | function contrast(a:string,b:string){const x=luminance(a),y=luminance(b);return(Math.max(x,y)+.05)/(Math.min(x,y)+.05);}
  62  | 
  63  | test('measured corpus fixture is frozen and reproducible',()=>{
  64  |  expect(corpus.targetMet).toBe(true);expect(corpus.measured,'freeze requires the real retained sweep, never invented rows').toBe(true);
  65  |  expect(corpus.selection).toHaveLength(5);expect(new Set(corpus.selection.map(r=>r.seed)).size).toBe(5);expect(corpus.selection.map(r=>r.seed)).toContain(1994);expect(Object.keys(corpus.sourceHashes).length).toBeGreaterThan(0);
  66  |  expect(layoutSupplement.measured).toBe(true);expect(layoutSupplement.selection.map(r=>r.seed)).toEqual([6]);expect(new Set(visualSelection.map(r=>r.seed)).size).toBe(6);
  67  |  const shapes:string[]=[];for(const row of visualSelection){const game=expected(row.seed);expect(hash(game.state.map)).toBe(row.mapHash);shapes.push(hash({provinces:game.state.map.provinces.map(p=>({polygon:p.polygon,labelAt:p.labelAt})),coasts:game.geography.islands.map(i=>i.polygon),routes:game.geography.entranceReservations.map(r=>r.points)}));
  68  |   const largest=game.state.map.islands.reduce((a,b)=>a.provinces.length>b.provinces.length?a:b),island=game.geography.islands.find(i=>i.id===largest.id)!,center=island.polygon.reduce((sum,p)=>sum+p[1],0)/island.polygon.length/game.geography.unitsPerPixel,diagnostic=layoutSupplement.layoutDiagnostics.find(r=>r.seed===row.seed)!;expect(center).toBeCloseTo(diagnostic.meanVertexCenterYCss,7);
  69  |  }expect(new Set(shapes).size).toBeGreaterThan(1);expect(new Set(layoutSupplement.layoutDiagnostics.map(r=>r.family))).toEqual(new Set(['top','middle','bottom']));
  70  | });
  71  | test('root and unknown view retain the established setup and playback controls',async({page})=>{
  72  |  await page.clock.install({time:new Date('2026-10-18T12:00:00Z')});await page.clock.pauseAt(new Date('2026-10-18T12:00:00Z'));
  73  |  for(const url of ['/','/?view=unknown&seed=1994']){
  74  |   await page.goto(url);await expect(page.getByLabel('Seats',{exact:true})).toHaveValue('4');
  75  |   for(let n=1;n<=4;n++)await expect(page.getByLabel(`Seat ${n} control`,{exact:true})).toHaveValue(n===1?'human':'computer');
  76  |   await page.getByRole('button',{name:'Start game',exact:true}).click();await expect(page.locator('#geographic-map')).toBeVisible();await expect(page.locator('#reference-map')).toHaveCount(0);
  77  |   await expect(page.locator('#game-pause-button')).toBeVisible();await expect(page.locator('#game-speed')).toBeVisible();await expect(page.locator('#game-log-button')).toBeVisible();await expect(page.locator('[data-testid="player-army-total"]')).toHaveCount(4);
  78  |   const actual=deserializeVersionedMatch(await save(page)),opening=expectedNormal(1994);expect(actual.identity).toEqual(GEOGRAPHIC_RAID_CARD_MATCH_IDENTITY);expect(actual.options).toEqual(opening.options);expect(actual.initialState).toEqual(opening.initialState);expect(actual.geography).toEqual(opening.geography);expect(actual.state).toEqual(opening.state);expect(actual.state.rules.cards).toBe('raid-v1');
  79  |  }
  80  | });
  81  | for(const item of visualSelection)test(`seed ${item.seed} paints actual geography and contained legible army labels`,async({page},info)=>{
  82  |  expect(corpus.measured).toBe(true);expect(layoutSupplement.measured).toBe(true);
  83  |   const game=expected(item.seed);expect(hash(game.state.map)).toBe(item.mapHash);await start(page,item.seed);await page.mouse.move(0,0);
  84  |   const actual=await drawing(page),q=1,presentation=JSON.parse(readFileSync(new URL(`../../docs/prototypes/new-game/T75/preflight/phase-b-20261018-01/fixtures/seed-${item.seed}-after.json`,import.meta.url),'utf8'));expect(actual.countries).toHaveLength(46);
  85  |   for(const v of presentation.provinces as {id:string;polygon:number[][];labelAt:[number,number]}[]){const row=actual.countries.find(r=>r.id===v.id)!;expect(numbers(row.d!)).toEqual(v.polygon.flatMap(pt=>pt.map(n=>n/q)));expect(row.x).toBeCloseTo(v.labelAt[0]/q,5);expect(row.y-5).toBeCloseTo(v.labelAt[1]/q,5);}
  86  |   const paint=await page.locator('#geographic-map .lane,#geographic-map .coast').evaluateAll(ns=>ns.map(n=>{const style=getComputedStyle(n),r=n.getBoundingClientRect();return {visible:style.display!=='none'&&style.visibility!=='hidden'&&Number(style.opacity)>0,stroke:style.stroke,strokeOpacity:Number(style.strokeOpacity),length:(n as SVGGeometryElement).getTotalLength(),fits:r.left>=0&&r.top>=0&&r.right<=innerWidth&&r.bottom<=innerHeight};}));for(const row of paint){expect(row.visible).toBe(true);expect(row.stroke).not.toBe('none');expect(row.strokeOpacity).toBeGreaterThan(0);expect(row.length).toBeGreaterThan(0);expect(row.fits).toBe(true);}
  87  |   expect(actual.coasts.map(d=>numbers(d!))).toEqual(presentation.islands.map((i:{polygon:number[][]})=>i.polygon.flatMap(pt=>pt.map(n=>n/q))));
  88  |   const edges=new Set(game.state.map.provinces.flatMap(v=>v.seaLanes.map(id=>[v.id,id].sort().join('|'))));expect(actual.routes).toHaveLength(edges.size);expect(new Set(actual.routes.map(r=>r.edge))).toEqual(edges);
  89  |   for(const r of presentation.routes as {from:string;to:string;points:number[][]}[])expect(numbers(actual.routes.find(a=>a.edge===[r.from,r.to].sort().join('|'))!.points!)).toEqual(r.points.flatMap(pt=>pt.map(n=>n/q)));
> 90  |   const rows=await labels(page);for(const row of rows){const seat=game.state.players.findIndex(p=>p.id===row.owner);expect(row.text).toBe(String(game.state.armies[row.id!]));expect(row.armies).toBe(row.text);expect(row.badge).toBe(seatLook(seat).badge);expect(row.name).toContain(game.state.map.provinces.find(p=>p.id===row.id)!.name);expect(row.cellVisible,`${row.id} visible ownership fill`).toBe(true);expect(row.visible).toBe(true);expect(row.badgeVisible).toBe(true);expect(row.inBadge,`${row.id} count fits marker`).toBe(true);expect(row.contained,`${row.id} count inside country`).toBe(true);expect(row.font).toBeGreaterThanOrEqual(14);expect(contrast(row.countColor,row.badgeColor)).toBeGreaterThanOrEqual(4.5);expect(numbers(row.fill).slice(0,3)).toEqual(seatLook(seat).color.slice(1).match(/.{2}/g)!.map(x=>parseInt(x,16)));expect(row.hit40,`${row.id} 40px actual input square`).toBe(true);expect(row.inViewport).toBe(true);}
      |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ^ Error: province_6 40px actual input square
  91  |   for(let a=0;a<rows.length;a++)for(let b=a+1;b<rows.length;b++){const u=rows[a]!.box,v=rows[b]!.box;expect(u.right<=v.x||v.right<=u.x||u.bottom<=v.y||v.bottom<=u.y).toBe(true);}
  92  |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  93  |   // Names are available through the established accessible/hover/focus treatment;
  94  |   // no always-visible name hierarchy is imposed on the owner's army-first design.
  95  |   const first=country(page,game.state.map.provinces[0]!.id);await first.hover();await expect(first.locator('.name')).toBeVisible();await first.focus();await expect(first.locator('.name')).toBeVisible();await page.mouse.move(0,0);await page.locator('#game-log-button').focus();
  96  |   const out=process.env['GEOGRAPHIC_EVIDENCE_DIR']??'screenshots';mkdirSync(out,{recursive:true});await page.screenshot({path:join(out,`geographic-${item.seed}-${info.project.name}.png`)});
  97  |   await page.reload();await page.getByRole('button',{name:'Start game',exact:true}).click();await expect(page.locator('#geographic-map')).toBeVisible();expect(await drawing(page)).toEqual(actual);
  98  | });
  99  | // Each edge kind starts fresh so one real exchange cannot invalidate the other case.
  100 | for(const kind of ['borders','seaLanes'] as const)test(`painted ${kind} use the core's exact legal targets and exchange`,async({page})=>{
  101 |  const game=expected(1994);let state=game.state;const player=activePlayer(state)!;
  102 |  const source=state.map.provinces.find(p=>state.ownerOf[p.id]===player.id&&p[kind].some(id=>state.ownerOf[id]!==player.id));if(!source)throw Error(`1994 lacks enemy ${kind}; select a measured corpus seed before freeze`);
  103 |  await start(page,1994);while(state.reinforcementPool>0){await country(page,source.id).click();state=step(state,{kind:'reinforce',province:source.id,amount:1});}await page.locator('#start-combat-button').click();state=step(state,{kind:'endReinforcement'});await check(page,state);
  104 |  await country(page,source.id).click();const legal=attackTargets(state,source.id).sort();expect(await page.locator('#geographic-map [data-target="true"]').evaluateAll(ns=>ns.map(n=>n.getAttribute('data-country')).sort())).toEqual(legal);
  105 |  const target=source[kind].find(id=>legal.includes(id));if(!target)throw Error('edge must be legal');
  106 |  if(kind==='seaLanes')await expect(page.locator(`#geographic-map .lane[data-edge="${[source.id,target].sort().join('|')}"]`)).toHaveClass(/active/);
  107 |  const outsider=state.map.provinces.find(p=>state.ownerOf[p.id]!==player.id&&!legal.includes(p.id));if(!outsider)throw Error('need enemy non-neighbour');await country(page,outsider.id).click();await check(page,state);await expect(page.locator('#battle-status')).not.toBeEmpty();
  108 |  await country(page,target).click({modifiers:['Shift']});await check(page,state);await expect(page.locator('#battle-source-name')).toHaveText(source.name);await expect(page.locator('#battle-target-name')).toHaveText(state.map.provinces.find(p=>p.id===target)!.name);
  109 |  await country(page,target).click();state=step(state,{kind:'attack',from:source.id,to:target});await check(page,state);
  110 |  // Loaded history must reconstruct every action in order with exact country deltas.
  111 |  const replay=await save(page);await setup(page);await upload(page,replay);await expect(page.locator('#geographic-map')).toBeVisible();await page.locator('#game-log-button').click();const rows=page.getByRole('dialog',{name:'Game event log'}).locator('[data-event-index]');await expect(rows).toHaveCount(state.history.length+1);let previous=game.state;for(let i=0;i<state.history.length;i++){const next=step(previous,state.history[i]!);const row=rows.nth(i+1);await expect(row).toHaveAttribute('data-event-index',String(i+1));await expect(row).toContainText(`Action ${i+1}`);for(const v of state.map.provinces){const a=previous.armies[v.id]!,b=next.armies[v.id]!;if(a!==b||previous.ownerOf[v.id]!==next.ownerOf[v.id])await expect(row.locator(`[data-region="${v.id}"]`)).toContainText(`${a} → ${b} (${b-a>=0?'+':''}${b-a})`);}previous=next;}expect(previous).toEqual(state);
  112 | });
  113 | test('geographic replay and reference identity dispatch preserve state, history and pause',async({page})=>{
  114 |  await start(page,1994);const game=expected(1994),own=game.state.map.provinces.find(p=>game.state.ownerOf[p.id]===activePlayer(game.state)!.id)!;
  115 |  await country(page,own.id).click();const state=step(game.state,{kind:'reinforce',province:own.id,amount:1}),text=await save(page);expect(deserializeVersionedMatch(text).identity).toEqual(GEOGRAPHIC_MATCH_IDENTITY);await check(page,state);const before=await drawing(page);
  116 |  await setup(page);await upload(page,text);await expect(page.locator('#geographic-map')).toBeVisible();await check(page,state);expect(await drawing(page)).toEqual(before);
  117 |  for(const player of state.players){const total=state.map.provinces.filter(p=>state.ownerOf[p.id]===player.id).reduce((n,p)=>n+state.armies[p.id]!,0);await expect(page.locator(`[data-player="${player.id}"] [data-testid="player-army-total"]`)).toHaveText(`Total armies: ${total}`);}
  118 |  await page.locator('#game-pause-button').click();const frozen=await save(page);await country(page,own.id).focus();await page.keyboard.press('Enter');expect(await save(page)).toBe(frozen);await page.locator('#game-log-button').click();const rows=page.getByRole('dialog',{name:'Game event log'}).locator('[data-event-index]');await expect(rows).toHaveCount(2);await expect(rows.last()).toContainText(`Unplaced armies: ${game.state.reinforcementPool} → ${state.reinforcementPool}`);await page.keyboard.press('Escape');await page.locator('#game-pause-button').click();
  119 |  await country(page,own.id).click();await check(page,step(state,{kind:'reinforce',province:own.id,amount:1}));
  120 |  const bad=JSON.parse(text);bad.boardGenerator.version=99;const stable=await save(page),url=page.url();await upload(page,JSON.stringify(bad),false);await expect(page.getByRole('alert')).toContainText(/Load failed/i);expect(await save(page)).toBe(stable);expect(page.url()).toBe(url);expect(await drawing(page)).toEqual(before);
  121 |  const fixture=pinned('placement');await upload(page,fixture.text);await expect(page.locator('#reference-map')).toBeVisible();await expect(page.locator('#geographic-map')).toHaveCount(0);const refText=await save(page),ref=deserializeVersionedMatch(refText);expect(ref.identity).toEqual(REFERENCE_MATCH_IDENTITY);expect(ref.state.history).toEqual(fixture.actions);await setup(page);await upload(page,refText);await expect(page.locator('#reference-map')).toBeVisible();expect(deserializeVersionedMatch(await save(page)).state).toEqual(ref.state);
  122 | });
  123 | test('invalid seed stays in setup and recovers',async({page})=>{
  124 |  await setup(page);await page.getByLabel('Seed',{exact:true}).fill('-1');await page.getByRole('button',{name:'Start game',exact:true}).click();await expect(page.locator('#geographic-map')).toHaveCount(0);expect(await page.getByLabel('Seed',{exact:true}).evaluate(n=>(n as HTMLInputElement).validity.valid)).toBe(false);await page.getByLabel('Seed',{exact:true}).fill('1994');await page.getByRole('button',{name:'Start game',exact:true}).click();await expect(page.locator('#geographic-map')).toBeVisible();
  125 | });
  126 | // Register only actual measured refusals, with NO test.skip. Zero measured refusals
  127 | // is stated in the fixture; typed refusal/retry remains mandatory in UI unit coverage.
  128 | for(const refusal of corpus.refusalSeeds.slice(0,1))test(`real measured refusal ${refusal.seed} recovers`,async({page})=>{
  129 |  await setup(page,refusal.seed);await page.getByRole('button',{name:'Start game',exact:true}).click();const feedback=page.locator('#geographic-setup form > [role="alert"]');await expect(feedback).toBeVisible();await expect(feedback).toContainText(/another seed/i);await expect(page.locator('#geographic-map')).toHaveCount(0);await page.getByLabel('Seed',{exact:true}).fill('1994');await page.getByRole('button',{name:'Start game',exact:true}).click();await expect(page.locator('#geographic-map')).toBeVisible();
  130 | });
  131 | 
  132 | test('geographic computer playback pauses and cancels stale work on load',async({page})=>{
  133 |  await page.clock.install();await page.clock.pauseAt(new Date());await page.goto('/');await page.getByRole('button',{name:'Start game',exact:true}).click();await expect(page.locator('#geographic-map')).toBeVisible();
  134 |  let initial=deserializeVersionedMatch(await save(page));expect(initial.identity).toEqual(GEOGRAPHIC_RAID_CARD_MATCH_IDENTITY);expect(initial.state.rules.cards).toBe('raid-v1');expect(initial.state).toEqual(expectedNormal(1994).state);let state=initial.state;
  135 |  for(let n=0;n<50&&(activePlayer(state)!.kind!=='computer'||state.phase!=='attack');n++){
  136 |   if(activePlayer(state)!.kind==='human'){
  137 |    if(state.phase==='reinforce'){const own=state.map.provinces.find(p=>state.ownerOf[p.id]===activePlayer(state)!.id)!;while(state.reinforcementPool>0){await country(page,own.id).click();state=step(state,{kind:'reinforce',province:own.id,amount:1});}await page.locator('#start-combat-button').click();state=step(state,{kind:'endReinforcement'});}
  138 |    if(state.phase==='attack')await page.locator('#end-turn-button').click();
  139 |   }else await page.clock.runFor(350);
  140 |   state=deserializeVersionedMatch(await save(page)).state;
  141 |  }
  142 |  expect(activePlayer(state)!.kind).toBe('computer');expect(state.phase).toBe('attack');
  143 |  await page.locator('#game-pause-button').click();const frozen=await save(page);await page.clock.runFor(5000);expect(await save(page)).toBe(frozen);
  144 |  const id=state.map.provinces[0]!.id;await country(page,id).focus();await page.keyboard.press('Enter');expect(await save(page)).toBe(frozen);await page.locator('#game-log-button').click();await expect(page.getByRole('dialog',{name:'Game event log'})).toBeVisible();await page.keyboard.press('Escape');
  145 |  await page.locator('#game-pause-button').click();await page.clock.runFor(350);expect(await save(page)).not.toBe(frozen);
  146 |  // Create a known manual replacement, then load while old automatic work is queued.
  147 |  const manual=expected(1994);const replacement={format:'malpaco-match',version:2,...GEOGRAPHIC_MATCH_IDENTITY,options:manual.options,actions:[]};await upload(page,JSON.stringify(replacement));await check(page,manual.state);await page.clock.runFor(5000);await check(page,manual.state);
  148 | });
  149 | 
  150 | // Select an actual ordinary-action fixture from measured seed1994. No state
  151 | // snapshot or test-only browser entry point is introduced. The accepted first
  152 | // exchange must really leave another scheduled legal exchange, rather than
  153 | // assuming a target's initial stack survives combat.
  154 | function queuedBattle(game:ReturnType<typeof expected>){
  155 |  const initial=game.state,player=activePlayer(initial)!;
  156 |  for(const source of initial.map.provinces.filter(p=>initial.ownerOf[p.id]===player.id)){
  157 |   let state=initial;const actions:Action[]=[];
  158 |   if(state.reinforcementPool>0){const placement:Action={kind:'reinforce',province:source.id,amount:state.reinforcementPool};actions.push(placement);state=step(state,placement);}
  159 |   const start:Action={kind:'endReinforcement'};actions.push(start);state=step(state,start);
  160 |   for(const target of attackTargets(state,source.id)){
  161 |    const attack:Action={kind:'attack',from:source.id,to:target},first=apply(state,attack);
  162 |    if(!first.ok||first.state.phase!=='attack'||first.state.armies[source.id]!<=1||!attackTargets(first.state,source.id).includes(target))continue;
  163 |    const second=apply(first.state,attack);if(!second.ok)continue;
  164 |    return {from:source.id,to:target,state,actions,first:first.state,second:second.state};
  165 |   }
  166 |  }
  167 |  throw Error('Measured seed1994 has no first exchange that leaves a queued legal exchange; select a different measured corpus fixture before freeze');
  168 | }
  169 | test('geographic continuous battle pauses/resumes and cancels stale work on load/new game',async({page},info)=>{
  170 |  await page.clock.install();await page.clock.pauseAt(new Date());await setup(page);
  171 |  const game=expected(1994),fixture=queuedBattle(game);
  172 |  const payload=JSON.stringify({format:'malpaco-match',version:2,...GEOGRAPHIC_MATCH_IDENTITY,options:game.options,actions:fixture.actions});
  173 |  await info.attach('queued-battle-fixture',{body:Buffer.from(JSON.stringify({seed:1994,from:fixture.from,to:fixture.to,actions:fixture.actions},null,2)),contentType:'application/json'});
  174 |  const begin=async()=>{
  175 |   await upload(page,payload);await check(page,fixture.state);await country(page,fixture.from).click();await country(page,fixture.to).click({modifiers:['Shift']});
  176 |   await page.locator('#battle-stop-threshold').fill('1');await page.locator('#battle-stop-threshold').press('Tab');await page.locator('#fight-on-button').click();
  177 |   await expect(page.getByRole('region',{name:'Battle controls',exact:true})).toHaveAttribute('data-running','true');await check(page,fixture.first);
  178 |  };
  179 |  await begin();await page.locator('#game-pause-button').click();const frozen=await save(page);await page.clock.runFor(5000);expect(await save(page)).toBe(frozen);
  180 |  await country(page,fixture.to).focus();await page.keyboard.press('Enter');expect(await save(page)).toBe(frozen);
  181 |  await page.locator('#game-pause-button').click();await page.clock.runFor(400);await check(page,fixture.second);
  182 |  // Load replaces a live continuous scheduler. Waiting must not append old work.
  183 |  await begin();const replacement=JSON.stringify({format:'malpaco-match',version:2,...GEOGRAPHIC_MATCH_IDENTITY,options:game.options,actions:[]});await upload(page,replacement);await check(page,game.state);await page.clock.runFor(5000);await check(page,game.state);
  184 |  // New game also disposes an active scheduler; only setup remains after waiting.
  185 |  await begin();await page.getByRole('button',{name:'New game',exact:true}).click();await page.clock.runFor(5000);await expect(page.getByRole('button',{name:'Start game',exact:true})).toBeVisible();await expect(page.locator('#geographic-map')).toHaveCount(0);
  186 | });
  187 | 
```