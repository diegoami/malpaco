// Disposable feasibility only. Removed before production dispatch.
import {friendlyMoveRules} from "./state";
import {defaultOptions} from "./options";
import type {GameOptions} from "./options";
import {reinforcementIncome} from "./reinforcement";
import type {ApplyResult,GameState,RuleSet} from "./types";
export function victoryRules(options:Pick<GameOptions,"dominationWin"|"roundLimit">=defaultOptions()):RuleSet{return {...friendlyMoveRules(),id:"malpaco-victory",victoryOptions:{dominationWin:options.dominationWin,roundLimit:options.roundLimit}};}
function rows(s:GameState){const origin=s.roundOrigin??0;const order=(id:string)=>(s.players.findIndex(p=>p.id===id)-origin+s.players.length)%s.players.length;return s.players.map(p=>{const ids=s.map.provinces.filter(v=>s.ownerOf[v.id]===p.id).map(v=>v.id);return {player:p.id,countries:ids.length,armies:ids.reduce((n,id)=>n+s.armies[id]!,0)};}).sort((a,b)=>b.countries-a.countries||b.armies-a.armies||order(b.player)-order(a.player));}
function nextSeat(s:GameState){for(let n=1;n<=s.players.length;n++){const i=(s.currentPlayer+n)%s.players.length;if(!s.players[i]!.eliminated)return i;}return s.currentPlayer;}
function boundary(s:GameState){const origin=s.roundOrigin??0,rank=(i:number)=>(i-origin+s.players.length)%s.players.length;return rank(nextSeat(s))<=rank(s.currentPlayer);}
function handoff(s:GameState):ApplyResult{const complete=boundary(s);s.log.push({event:"turn_ended",player:s.players[s.currentPlayer]!.id,turn:s.turnNumber});s.currentPlayer=nextSeat(s);if(complete)s.turnNumber++;s.phase="reinforce";s.capturedThisTurn=false;s.reinforcementPool=reinforcementIncome(s,s.players[s.currentPlayer]!.id).total;return {ok:true,state:s,outcome:null};}
export function mockChoice(s:GameState,kind:"watchComputers"|"stopGame"):ApplyResult{if(s.phase!=="human-loss"||!s.rules.victoryOptions)return {ok:false,error:"No human-loss choice."};if(kind==="stopGame"){s.phase="finished";return {ok:true,state:s,outcome:null};}s.watchingComputers=true;delete s.result;s.currentPlayer=nextSeat(s);return handoff(s);}
export function mockComplete(s:GameState):ApplyResult{
 const standings=rows(s),own=standings.find(r=>r.player===s.players[s.currentPlayer]!.id)!,options=s.rules.victoryOptions!;
 let reason:NonNullable<GameState["result"]>["reason"]|undefined,winner="";
 const full=standings.find(r=>r.countries===s.map.provinces.length);
 if(full){reason="conquest";winner=full.player;}
 else if(standings.filter(r=>r.countries>0).length===1){reason="last-seat";winner=standings[0]!.player;}
 else if(options.dominationWin&&own.countries>=Math.floor((3*s.map.provinces.length+3)/4)){reason="domination";winner=own.player;}
 else if(options.roundLimit!==null&&boundary(s)&&s.turnNumber>=options.roundLimit){reason="round-limit";winner=standings[0]!.player;}
 else if(!s.watchingComputers&&s.players.some(p=>p.kind==="human")&&s.players.filter(p=>p.kind==="human").every(p=>p.eliminated)){reason="no-human-left";}
 if(reason){s.result={reason,standings};s.winner=winner;s.phase=reason==="no-human-left"?"human-loss":"finished";if(winner)s.log.push({event:"victory",player:winner,turn:s.turnNumber});return {ok:true,state:s,outcome:null};}
 return handoff(s);
}
