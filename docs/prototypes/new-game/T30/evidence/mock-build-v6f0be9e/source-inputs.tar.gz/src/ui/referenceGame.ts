// Explicit development route for the approved fixed geography; ordinary apply actions only.
import {victoryRules,defaultOptions} from "../core";
import {createReferenceGame} from "../core/reference-game";
import {referenceMap} from "./referenceData";
import {ReferenceMapView} from "./referenceMapView";
import {App} from "./app";
import {h} from "./dom";
import {ReferenceBattleGame} from "./referenceBattleGame";
import type {BattlePreferences} from "./referenceBattleGame";
export function mountReferenceGame(root:HTMLElement){
 let seed=new URLSearchParams(location.search).get("seed")??"1994",seats="2";
 const legacy=new URLSearchParams(location.search).get("battle")==="legacy";
 const preferences:BattlePreferences={threshold:2,speed:"normal"};
 const setup=()=>{
  root.id="reference-setup";root.className="reference-setup";
  const input=h("input",{id:"reference-seed",type:"number",min:"0",max:"4294967295",required:"",value:seed});
  const count=h("select",{id:"reference-seats"},...[2,3,4].map(n=>h("option",{value:String(n)},String(n))));count.value=seats;
  const alert=h("p",{role:"alert"});
  const controls=h("div");
  const drawControls=()=>{controls.replaceChildren(...Array.from({length:Number(count.value)},(_,i)=>{const select=h("select",{id:`reference-control-${i}`},h("option",{value:"human"},"Human"),h("option",{value:"computer"},"Computer"));return h("label",{for:`reference-control-${i}`},`Seat ${i+1} control`,select);}));};
  count.addEventListener("change",drawControls);drawControls();
  const domination=h("input",{type:"checkbox",id:"reference-domination"});domination.checked=true;
  const limit=h("select",{id:"reference-round-limit"},h("option",{value:"off"},"Off"),...[20,30,40].map(n=>h("option",{value:String(n)},String(n))));
  const form=h("form",{class:"card setup-card"},h("h1",{},"New reference game"),h("p",{},legacy?"Play on the Nine Isles map. The seed changes the deal.":"Development reference game for manual play on Nine Isles. All seats are human; the seed changes the deal."),h("label",{for:"reference-seed"},"Seed"),input,h("label",{for:"reference-seats"},"Human seats"),count,h("button",{type:"submit",class:"primary"},"Start game"),alert);
  if(!legacy)form.insertBefore(h("div",{},controls,h("label",{for:"reference-domination"},"Domination win",domination),h("label",{for:"reference-round-limit"},"Round limit",limit)),alert);
  form.onsubmit=e=>{e.preventDefault();if(!form.reportValidity())return;seed=input.value;seats=count.value;
   try{const specs=Array.from({length:Number(seats)},(_,i)=>({kind:!legacy&&(controls.querySelector(`#reference-control-${i}`) as HTMLSelectElement).value==="computer"?"computer" as const:"human" as const}));const options={...defaultOptions(),seed:Number(seed),seats:specs,computerStrengths:specs.filter(s=>s.kind==="computer").map(()=>"Normal" as const),dominationWin:domination.checked,roundLimit:limit.value==="off"?null:Number(limit.value) as 20|30|40};const result=createReferenceGame(referenceMap,options,legacy?undefined:victoryRules(options));if(!result.ok){alert.textContent=result.errors.join("; ");return;}
    root.id="reference-game";root.className="reference-game-root";root.dataset["seats"]=seats;
    const app=legacy?new App(referenceMap,options.seed,()=>{app.dispose();setup();},result.state,(map,handlers)=>new ReferenceMapView(map,handlers)):new ReferenceBattleGame(referenceMap,options.seed,()=>{app.dispose();setup();},result.state,preferences);app.mount(root);
    root.querySelector(".subtitle")!.textContent=`Nine Isles · ${seats} human seats · Seed ${seed}`;
   }catch(error){alert.textContent=error instanceof Error?error.message:String(error);}
  };root.replaceChildren(form);
 };setup();
}
