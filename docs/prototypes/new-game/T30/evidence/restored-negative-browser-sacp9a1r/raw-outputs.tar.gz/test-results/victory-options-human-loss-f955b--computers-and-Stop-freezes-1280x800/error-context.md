# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: victory-options.spec.ts >> human loss offers Stop or Watch; Watch resumes computers and Stop freezes
- Location: tests/e2e/victory-options.spec.ts:129:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('#victory-reason')
Expected pattern: /human.*eliminat|no human/i
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" locator('#victory-reason') with timeout 5000ms
  - waiting for locator('#victory-reason')

```

```yaml
- banner:
  - heading "Malpaco" [level=1]
  - text: Nine Isles · 3 human seats · Seed 1994 Seat 1 0 provinces · 0 armies Seat 2 22 provinces · 48 armies Seat 3 24 provinces · 46 armies
  - contentinfo:
    - button "New game"
- main:
  - img "Nine Isles reference map":
    - button "River gate, Seat 3, 1 armies": River gate 3 · 1
    - button "New port, Seat 2, 8 armies": New port 2 · 8
    - button "North rest, Seat 2, 1 armies": North rest 2 · 1
    - button "River keep, Seat 2, 1 armies": River keep 2 · 1
    - button "North town, Seat 2, 1 armies": North town 2 · 1
    - button "Dark ford, Seat 2, 1 armies": Dark ford 2 · 1
    - button "Iron point, Seat 3, 2 armies": Iron point 3 · 2
    - button "South rest, Seat 3, 2 armies": South rest 3 · 2
    - button "High shore, Seat 2, 2 armies": High shore 2 · 2
    - button "Wind town, Seat 3, 1 armies": Wind town 3 · 1
    - button "New glen, Seat 2, 8 armies": New glen 2 · 8
    - button "Old rock, Seat 3, 1 armies": Old rock 3 · 1
    - button "Blue peak, Seat 2, 1 armies": Blue peak 2 · 1
    - button "West haven, Seat 3, 1 armies": West haven 3 · 1
    - button "Stone watch, Seat 2, 1 armies": Stone watch 2 · 1
    - button "Upper ridge, Seat 2, 6 armies": Upper ridge 2 · 6
    - button "Marsh keep, Seat 2, 3 armies": Marsh keep 2 · 3
    - button "New fell, Seat 2, 1 armies": New fell 2 · 1
    - button "Moon point, Seat 3, 1 armies": Moon point 3 · 1
    - button "South fell, Seat 2, 1 armies": South fell 2 · 1
    - button "High ridge, Seat 2, 1 armies": High ridge 2 · 1
    - button "Bay ford, Seat 2, 1 armies": Bay ford 2 · 1
    - button "Low moor, Seat 3, 1 armies": Low moor 3 · 1
    - button "Lower field, Seat 3, 1 armies": Lower field 3 · 1
    - button "Wind gate, Seat 3, 1 armies": Wind gate 3 · 1
    - button "Silver shore, Seat 3, 4 armies": Silver shore 3 · 4
    - button "Low peak, Seat 3, 1 armies": Low peak 3 · 1
    - button "Wind port, Seat 3, 1 armies": Wind port 3 · 1
    - button "Gold point, Seat 3, 1 armies": Gold point 3 · 1 ★
    - button "Rock moor, Seat 2, 1 armies": Rock moor 2 · 1
    - button "Marsh rest, Seat 3, 1 armies": Marsh rest 3 · 1
    - button "Wind dale, Seat 3, 11 armies": Wind dale 3 · 11
    - button "Silver ford, Seat 2, 1 armies": Silver ford 2 · 1
    - button "Iron field, Seat 2, 1 armies": Iron field 2 · 1
    - button "North wood, Seat 2, 1 armies": North wood 2 · 1
    - button "Fort town, Seat 3, 1 armies": Fort town 3 · 1 ★
    - button "Red field, Seat 2, 3 armies": Red field 2 · 3 ★
    - button "South ridge, Seat 2, 2 armies": South ridge 2 · 2
    - button "Rock bay, Seat 3, 1 armies": Rock bay 3 · 1
    - button "North ford, Seat 3, 1 armies": North ford 3 · 1
    - button "Port ridge, Seat 3, 1 armies": Port ridge 3 · 1
    - button "New rock, Seat 2, 2 armies": New rock 2 · 2
    - button "South reach, Seat 3, 3 armies": South reach 3 · 3
    - button "Silver point, Seat 3, 1 armies": Silver point 3 · 1
    - button "East ford, Seat 3, 1 armies": East ford 3 · 1
    - button "Gold town, Seat 3, 6 armies": Gold town 3 · 6
    - text: North Isle +3 East Isle +3 West Isle +3 South Isle +3 Central Isle +5 Harbor Isle +5 Palm Isle +6 Cliff Isle +5 Great Isle +9
  - complementary:
    - text: Seat 2's turn Round 6 · Reinforcement Province income
    - strong: "7"
    - text: Island income
    - strong: "3"
    - text: Armies to place
    - strong: "10"
    - paragraph: Place your armies on your countries, then start combat.
    - button "Start combat" [disabled]
    - button "End turn" [disabled]
    - heading "Battle log" [level=3]
    - list "Battle log":
      - listitem: T5 Seat 3 ends the turn
      - listitem: Seat 1 is eliminated
      - listitem: "T5 Seat 3: East ford → Gold town, took Gold town"
      - listitem: "T5 Seat 3: East ford → Gold town, -0 / -1"
      - listitem: "T5 Seat 3: East ford → Gold town, -1 / -0"
      - listitem: "T5 Seat 3: East ford → Gold town, -1 / -0"
      - listitem: "T5 Seat 3: East ford → Gold town, -1 / -0"
```

# Test source

```ts
  35  |   await page.getByLabel("Human seats").selectOption(String(fixture.start.players.length));
  36  |   // Baseline can still reach the same deal/counts without missing controls;
  37  |   // kind affects neither this zero-share deal nor the manually driven actions.
  38  |   for (let i = 0; i < fixture.start.players.length; i++) {
  39  |     const control = page.getByLabel(`Seat ${i + 1} control`, { exact: true });
  40  |     if (await control.count()) await control.selectOption(fixture.start.players[i]!.kind!);
  41  |   }
  42  |   const domination = page.getByLabel("Domination win", { exact: true });
  43  |   if (await domination.count()) await domination.setChecked(fixture.kind === "domination");
  44  |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  45  |   await paint(page, fixture.start);
  46  | }
  47  | async function drive(page: Page, fixture: ReturnType<typeof plan>) {
  48  |   let state = fixture.start;
  49  |   for (const action of fixture.actions) {
  50  |     await clickAction(page, action);
  51  |     state = act(state, action);
  52  |     if (action.kind === "attack" || action.kind === "captureMove" || action.kind === "endTurn") await paint(page, state);
  53  |   }
  54  |   return state;
  55  | }
  56  | async function freeze(page: Page, state: CompleteState) {
  57  |   for (const selector of ["#start-combat-button", "#end-turn-button", "#single-exchange-button", "#fight-on-button", "#start-friendly-move-button", "#confirm-capture-button", "#confirm-friendly-move-button"]) {
  58  |     const node = page.locator(selector);
  59  |     if (await node.count() && await node.isVisible()) await expect(node).toBeDisabled();
  60  |   }
  61  |   await country(page, referenceMap.provinces[0]!.id).dispatchEvent("click");
  62  |   await page.keyboard.press("Enter");
  63  |   await paint(page, state);
  64  | }
  65  | async function fit(page: Page) {
  66  |   const rows = await page.locator('#victory-reason,#victory-standings,#watch-computers-button,#stop-game-button,#new-game-button').evaluateAll(nodes => nodes.filter(n => n.getClientRects().length).map(n => { const b = n.getBoundingClientRect(); return { id: n.id, fits: b.left >= 0 && b.top >= 0 && b.right <= innerWidth && b.bottom <= innerHeight }; }));
  67  |   expect(rows.length).toBeGreaterThan(2);
  68  |   expect(rows.filter(r => !r.fits)).toEqual([]);
  69  | }
  70  | 
  71  | test("domination result names winner/reason, final standings, freezes and restarts", async ({ page }, info) => {
  72  |   test.setTimeout(240000);
  73  |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  74  |   const fixture = plan("domination");
  75  |   await setup(page, fixture);
  76  |   const stale = await page.locator("#end-turn-button").elementHandle();
  77  |   const state = await drive(page, fixture);
  78  |   await expect(page.locator("#victory-reason")).toContainText(/domination/i);
  79  |   await expect(page.locator("#victory-reason")).toContainText(String(Object.values(state.ownerOf).filter(id => id === state.winner).length));
  80  |   await expect(page.locator("#turn-title")).toContainText(state.players.find(p => p.id === state.winner)!.name);
  81  |   await expect(page.locator("#victory-standings [data-result-player]")).toHaveCount(state.players.length);
  82  |   expect(await page.locator("[data-result-player]").evaluateAll(ns => ns.map(n => n.getAttribute("data-result-player")))).toEqual(standings(state).map(r => r.player));
  83  |   for (const player of state.players) {
  84  |     const countries = Object.values(state.ownerOf).filter(id => id === player.id).length;
  85  |     const row = page.locator(`[data-result-player="${player.id}"]`);
  86  |     await expect(row).toContainText(player.name);
  87  |     await expect(row.locator("[data-result-countries]")).toHaveText(String(countries));
  88  |     await expect(row.locator("[data-result-armies]")).toHaveText(String(standings(state).find(r => r.player === player.id)!.armies));
  89  |   }
  90  |   await stale!.evaluate(n => n.dispatchEvent(new MouseEvent("click", { bubbles: true })));
  91  |   await freeze(page, state); await fit(page); await capture(page, "domination", info.project.name);
  92  |   await page.locator("#new-game-button").click();
  93  |   await expect(page.getByRole("heading", { name: "New reference game", exact: true })).toBeVisible();
  94  |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  95  |   await expect(page.locator("#victory-reason")).toHaveCount(0);
  96  |   expect(errors).toEqual([]);
  97  |   console.log(JSON.stringify({ kind: fixture.kind, actions: fixture.actions.length, winner: state.winner }));
  98  | });
  99  | 
  100 | test("round limit finishes after a complete rotated round and explains the score", async ({ page }, info) => {
  101 |   test.setTimeout(240000);
  102 |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  103 |   let state = opening(1994, 2, { dominationWin: false, roundLimit: 20 });
  104 |   const fixture = { start: state, state, actions: [] as CompleteAction[], conqueror: "", kind: "human-loss" as const };
  105 |   await setup(page, fixture);
  106 |   // Change settings through the real setup; no loaded or injected position.
  107 |   await page.locator("#new-game-button").click();
  108 |   const limit = page.getByLabel("Round limit", { exact: true });
  109 |   if (await limit.count()) await limit.selectOption("20");
  110 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  111 |   const origin = state.currentPlayer;
  112 |   for (let turn = 0; turn < 40; turn++) {
  113 |     expect(state.currentPlayer).toBe((origin + turn) % 2);
  114 |     await expect(page.locator(".turn-sub")).toContainText(`Round ${1 + Math.floor(turn / 2)}`);
  115 |     while (state.phase === "reinforce") {
  116 |       const own = state.map.provinces.find(p => state.ownerOf[p.id] === state.players[state.currentPlayer]!.id)!;
  117 |       const action: CompleteAction = state.reinforcementPool ? { kind: "reinforce", province: own.id, amount: 1 } : { kind: "endReinforcement" };
  118 |       await clickAction(page, action); state = act(state, action);
  119 |     }
  120 |     await clickAction(page, { kind: "endTurn" }); state = act(state, { kind: "endTurn" });
  121 |   }
  122 |   await expect(page.locator("#victory-reason")).toContainText(/round.*limit/i);
  123 |   await expect(page.locator("#victory-reason")).toContainText(/arm|order|countr/i);
  124 |   await paint(page, state); await freeze(page, state); await fit(page);
  125 |   await capture(page, "round-limit", info.project.name);
  126 |   expect(errors).toEqual([]);
  127 | });
  128 | 
  129 | test("human loss offers Stop or Watch; Watch resumes computers and Stop freezes", async ({ page }, info) => {
  130 |   test.setTimeout(300000);
  131 |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  132 |   const fixture = plan("human-loss");
  133 |   await setup(page, fixture);
  134 |   let state = await drive(page, fixture);
> 135 |   await expect(page.locator("#victory-reason")).toContainText(/human.*eliminat|no human/i);
      |                                                 ^ Error: expect(locator).toContainText(expected) failed
  136 |   await expect(page.locator("#watch-computers-button")).toBeVisible();
  137 |   await expect(page.locator("#stop-game-button")).toBeVisible();
  138 |   await freeze(page, state); await fit(page); await capture(page, "human-loss", info.project.name);
  139 |   const staleStop = await page.locator("#stop-game-button").elementHandle();
  140 |   await page.locator("#watch-computers-button").click(); state = act(state, { kind: "watchComputers" });
  141 |   await staleStop!.evaluate(n => n.dispatchEvent(new MouseEvent("click", { bubbles: true })));
  142 |   await paint(page, state);
  143 |   await expect(page.locator("#victory-reason")).toHaveCount(0);
  144 |   await expect(page.locator("#turn-title")).toContainText(state.players[state.currentPlayer]!.name);
  145 |   // Scheduling is T32. Drive actual remaining computer actions through the development UI.
  146 |   let handoffs = 0;
  147 |   for (let n = 0; n < VICTORY_ACTION_BUDGET && handoffs < 3; n++) {
  148 |     const action = fixtureAction(state, "human-loss", "");
  149 |     await clickAction(page, action); state = act(state, action);
  150 |     if (action.kind === "endTurn") { handoffs++; await paint(page, state); }
  151 |   }
  152 |   expect(handoffs).toBe(3);
  153 |   await expect(page.locator("#watch-computers-button")).toHaveCount(0);
  154 |   await capture(page, "watch-resumed", info.project.name);
  155 |   await page.locator("#new-game-button").click();
  156 |   await setup(page, fixture); state = await drive(page, fixture);
  157 |   await page.locator("#stop-game-button").click(); state = act(state, { kind: "stopGame" });
  158 |   await freeze(page, state); await fit(page); await capture(page, "human-loss-stopped", info.project.name);
  159 |   await expect(page.locator("#watch-computers-button")).toHaveCount(0);
  160 |   await page.locator("#new-game-button").click();
  161 |   await expect(page.getByRole("heading", { name: "New reference game", exact: true })).toBeVisible();
  162 |   expect(errors).toEqual([]);
  163 |   console.log(JSON.stringify({ kind: fixture.kind, actionsPerRun: fixture.actions.length, resumedHandoffs: handoffs }));
  164 | });
  165 | 
```