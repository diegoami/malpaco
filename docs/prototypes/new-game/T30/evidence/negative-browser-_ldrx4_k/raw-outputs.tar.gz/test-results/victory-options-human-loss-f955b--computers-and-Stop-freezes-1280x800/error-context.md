# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: victory-options.spec.ts >> human loss offers Stop or Watch; Watch resumes computers and Stop freezes
- Location: tests/e2e/victory-options.spec.ts:97:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('#victory-reason')
Expected pattern: /human.*eliminat|no human/i
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" locator('#victory-reason') with timeout 5000ms
  - waiting for locator('#victory-reason')

```

```yaml
- banner:
  - heading "Malpaco" [level=1]
  - text: Nine Isles · 3 human seats · Seed 1994 Seat 1 0 provinces · 0 armies Seat 2 22 provinces · 48 armies Seat 3 24 provinces · 46 armies
  - contentinfo:
    - button "New game"
- main:
  - img "Nine Isles reference map":
    - button "River gate, Seat 3, 1 armies": River gate 3 · 1
    - button "New port, Seat 2, 8 armies": New port 2 · 8
    - button "North rest, Seat 2, 1 armies": North rest 2 · 1
    - button "River keep, Seat 2, 1 armies": River keep 2 · 1
    - button "North town, Seat 2, 1 armies": North town 2 · 1
    - button "Dark ford, Seat 2, 1 armies": Dark ford 2 · 1
    - button "Iron point, Seat 3, 2 armies": Iron point 3 · 2
    - button "South rest, Seat 3, 2 armies": South rest 3 · 2
    - button "High shore, Seat 2, 2 armies": High shore 2 · 2
    - button "Wind town, Seat 3, 1 armies": Wind town 3 · 1
    - button "New glen, Seat 2, 8 armies": New glen 2 · 8
    - button "Old rock, Seat 3, 1 armies": Old rock 3 · 1
    - button "Blue peak, Seat 2, 1 armies": Blue peak 2 · 1
    - button "West haven, Seat 3, 1 armies": West haven 3 · 1
    - button "Stone watch, Seat 2, 1 armies": Stone watch 2 · 1
    - button "Upper ridge, Seat 2, 6 armies": Upper ridge 2 · 6
    - button "Marsh keep, Seat 2, 3 armies": Marsh keep 2 · 3
    - button "New fell, Seat 2, 1 armies": New fell 2 · 1
    - button "Moon point, Seat 3, 1 armies": Moon point 3 · 1
    - button "South fell, Seat 2, 1 armies": South fell 2 · 1
    - button "High ridge, Seat 2, 1 armies": High ridge 2 · 1
    - button "Bay ford, Seat 2, 1 armies": Bay ford 2 · 1
    - button "Low moor, Seat 3, 1 armies": Low moor 3 · 1
    - button "Lower field, Seat 3, 1 armies": Lower field 3 · 1
    - button "Wind gate, Seat 3, 1 armies": Wind gate 3 · 1
    - button "Silver shore, Seat 3, 4 armies": Silver shore 3 · 4
    - button "Low peak, Seat 3, 1 armies": Low peak 3 · 1
    - button "Wind port, Seat 3, 1 armies": Wind port 3 · 1
    - button "Gold point, Seat 3, 1 armies": Gold point 3 · 1 ★
    - button "Rock moor, Seat 2, 1 armies": Rock moor 2 · 1
    - button "Marsh rest, Seat 3, 1 armies": Marsh rest 3 · 1
    - button "Wind dale, Seat 3, 11 armies": Wind dale 3 · 11
    - button "Silver ford, Seat 2, 1 armies": Silver ford 2 · 1
    - button "Iron field, Seat 2, 1 armies": Iron field 2 · 1
    - button "North wood, Seat 2, 1 armies": North wood 2 · 1
    - button "Fort town, Seat 3, 1 armies": Fort town 3 · 1 ★
    - button "Red field, Seat 2, 3 armies": Red field 2 · 3 ★
    - button "South ridge, Seat 2, 2 armies": South ridge 2 · 2
    - button "Rock bay, Seat 3, 1 armies": Rock bay 3 · 1
    - button "North ford, Seat 3, 1 armies": North ford 3 · 1
    - button "Port ridge, Seat 3, 1 armies": Port ridge 3 · 1
    - button "New rock, Seat 2, 2 armies": New rock 2 · 2
    - button "South reach, Seat 3, 3 armies": South reach 3 · 3
    - button "Silver point, Seat 3, 1 armies": Silver point 3 · 1
    - button "East ford, Seat 3, 1 armies": East ford 3 · 1
    - button "Gold town, Seat 3, 6 armies": Gold town 3 · 6
    - text: North Isle +3 East Isle +3 West Isle +3 South Isle +3 Central Isle +5 Harbor Isle +5 Palm Isle +6 Cliff Isle +5 Great Isle +9
  - complementary:
    - text: Seat 2's turn Round 6 · Reinforcement Province income
    - strong: "7"
    - text: Island income
    - strong: "3"
    - text: Armies to place
    - strong: "10"
    - paragraph: Place your armies on your countries, then start combat.
    - button "Start combat" [disabled]
    - button "End turn" [disabled]
    - heading "Battle log" [level=3]
    - list "Battle log":
      - listitem: T5 Seat 3 ends the turn
      - listitem: Seat 1 is eliminated
      - listitem: "T5 Seat 3: East ford → Gold town, took Gold town"
      - listitem: "T5 Seat 3: East ford → Gold town, -0 / -1"
      - listitem: "T5 Seat 3: East ford → Gold town, -1 / -0"
      - listitem: "T5 Seat 3: East ford → Gold town, -1 / -0"
      - listitem: "T5 Seat 3: East ford → Gold town, -1 / -0"
```

# Test source

```ts
  3   | import { mkdirSync, mkdtempSync } from "node:fs";
  4   | import { join } from "node:path";
  5   | import { act, fixtureAction, plan, referenceMap, VICTORY_ACTION_BUDGET } from "./victory-fixture";
  6   | import type { CompleteAction, CompleteState } from "../core/victory-options-fixture";
  7   | 
  8   | const country = (page: Page, id: string) => page.locator(`[data-country="${id}"]`);
  9   | async function capture(page: Page, label: string, project: string) {
  10  |   const root = process.env["VICTORY_EVIDENCE_DIR"] ?? "screenshots";
  11  |   mkdirSync(root, { recursive: true });
  12  |   await page.screenshot({ path: join(mkdtempSync(join(root, "victory-")), `${label}-${project}.png`) });
  13  | }
  14  | async function paint(page: Page, state: CompleteState) {
  15  |   const actual = await page.locator("[data-country]").evaluateAll(nodes => Object.fromEntries(nodes.map(n => [n.getAttribute("data-country"), [n.getAttribute("data-owner"), Number(n.getAttribute("data-armies"))]])));
  16  |   expect(actual).toEqual(Object.fromEntries(referenceMap.provinces.map(p => [p.id, [state.ownerOf[p.id], state.armies[p.id]]])));
  17  | }
  18  | async function clickAction(page: Page, action: CompleteAction) {
  19  |   if (action.kind === "reinforce") await country(page, action.province).click();
  20  |   else if (action.kind === "endReinforcement") await page.locator("#start-combat-button").click();
  21  |   else if (action.kind === "endTurn") await page.locator("#end-turn-button").click();
  22  |   else if (action.kind === "captureMove") await page.locator("#confirm-capture-button").click();
  23  |   else if (action.kind === "attack") {
  24  |     const from = country(page, action.from);
  25  |     if (await from.getAttribute("aria-pressed") !== "true") await from.click();
  26  |     await country(page, action.to).click();
  27  |     await page.locator("#single-exchange-button").click();
  28  |   } else throw Error(`Unhandled fixture click ${action.kind}`);
  29  | }
  30  | async function setup(page: Page, fixture: ReturnType<typeof plan>) {
  31  |   await page.emulateMedia({ reducedMotion: "reduce" });
  32  |   await page.goto("/?view=reference-game");
  33  |   await page.getByLabel("Seed", { exact: true }).fill("1994");
  34  |   await page.getByLabel("Human seats").selectOption(String(fixture.start.players.length));
  35  |   // Baseline can still reach the same deal/counts without missing controls;
  36  |   // kind affects neither this zero-share deal nor the manually driven actions.
  37  |   for (let i = 0; i < fixture.start.players.length; i++) {
  38  |     const control = page.getByLabel(`Seat ${i + 1} control`, { exact: true });
  39  |     if (await control.count()) await control.selectOption(fixture.start.players[i]!.kind!);
  40  |   }
  41  |   const domination = page.getByLabel("Domination win", { exact: true });
  42  |   if (await domination.count()) await domination.setChecked(fixture.kind === "domination");
  43  |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  44  |   await paint(page, fixture.start);
  45  | }
  46  | async function drive(page: Page, fixture: ReturnType<typeof plan>) {
  47  |   let state = fixture.start;
  48  |   for (const action of fixture.actions) {
  49  |     await clickAction(page, action);
  50  |     state = act(state, action);
  51  |     if (action.kind === "attack" || action.kind === "captureMove" || action.kind === "endTurn") await paint(page, state);
  52  |   }
  53  |   return state;
  54  | }
  55  | async function freeze(page: Page, state: CompleteState) {
  56  |   for (const selector of ["#start-combat-button", "#end-turn-button", "#single-exchange-button", "#fight-on-button", "#start-friendly-move-button", "#confirm-capture-button", "#confirm-friendly-move-button"]) {
  57  |     const node = page.locator(selector);
  58  |     if (await node.count() && await node.isVisible()) await expect(node).toBeDisabled();
  59  |   }
  60  |   await country(page, referenceMap.provinces[0]!.id).dispatchEvent("click");
  61  |   await page.keyboard.press("Enter");
  62  |   await paint(page, state);
  63  | }
  64  | async function fit(page: Page) {
  65  |   const rows = await page.locator('#victory-reason,#victory-standings,#watch-computers-button,#stop-game-button,#new-game-button').evaluateAll(nodes => nodes.filter(n => n.getClientRects().length).map(n => { const b = n.getBoundingClientRect(); return { id: n.id, fits: b.left >= 0 && b.top >= 0 && b.right <= innerWidth && b.bottom <= innerHeight }; }));
  66  |   expect(rows.length).toBeGreaterThan(2);
  67  |   expect(rows.filter(r => !r.fits)).toEqual([]);
  68  | }
  69  | 
  70  | test("domination result names winner/reason, final standings, freezes and restarts", async ({ page }, info) => {
  71  |   test.setTimeout(240000);
  72  |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  73  |   const fixture = plan("domination");
  74  |   await setup(page, fixture);
  75  |   const stale = await page.locator("#end-turn-button").elementHandle();
  76  |   const state = await drive(page, fixture);
  77  |   await expect(page.locator("#victory-reason")).toContainText(/domination/i);
  78  |   await expect(page.locator("#victory-reason")).toContainText(/35|36|37|38|39|40|41|42|43|44|45|46/);
  79  |   await expect(page.locator("#turn-title")).toContainText(state.players.find(p => p.id === state.winner)!.name);
  80  |   await expect(page.locator("#victory-standings [data-result-player]")).toHaveCount(state.players.length);
  81  |   for (const player of state.players) {
  82  |     const countries = Object.values(state.ownerOf).filter(id => id === player.id).length;
  83  |     const row = page.locator(`[data-result-player="${player.id}"]`);
  84  |     await expect(row).toContainText(player.name);
  85  |     await expect(row.locator("[data-result-countries]")).toHaveText(String(countries));
  86  |   }
  87  |   await stale!.evaluate(n => n.dispatchEvent(new MouseEvent("click", { bubbles: true })));
  88  |   await freeze(page, state); await fit(page); await capture(page, "domination", info.project.name);
  89  |   await page.locator("#new-game-button").click();
  90  |   await expect(page.getByRole("heading", { name: "New reference game", exact: true })).toBeVisible();
  91  |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  92  |   await expect(page.locator("#victory-reason")).toHaveCount(0);
  93  |   expect(errors).toEqual([]);
  94  |   console.log(JSON.stringify({ kind: fixture.kind, actions: fixture.actions.length, winner: state.winner }));
  95  | });
  96  | 
  97  | test("human loss offers Stop or Watch; Watch resumes computers and Stop freezes", async ({ page }, info) => {
  98  |   test.setTimeout(300000);
  99  |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  100 |   const fixture = plan("human-loss");
  101 |   await setup(page, fixture);
  102 |   let state = await drive(page, fixture);
> 103 |   await expect(page.locator("#victory-reason")).toContainText(/human.*eliminat|no human/i);
      |                                                 ^ Error: expect(locator).toContainText(expected) failed
  104 |   await expect(page.locator("#watch-computers-button")).toBeVisible();
  105 |   await expect(page.locator("#stop-game-button")).toBeVisible();
  106 |   await freeze(page, state); await fit(page); await capture(page, "human-loss", info.project.name);
  107 |   const staleStop = await page.locator("#stop-game-button").elementHandle();
  108 |   await page.locator("#watch-computers-button").click(); state = act(state, { kind: "watchComputers" });
  109 |   await staleStop!.evaluate(n => n.dispatchEvent(new MouseEvent("click", { bubbles: true })));
  110 |   await paint(page, state);
  111 |   await expect(page.locator("#victory-reason")).toHaveCount(0);
  112 |   await expect(page.locator("#turn-title")).toContainText(state.players[state.currentPlayer]!.name);
  113 |   // Scheduling is T32. Drive actual remaining computer actions through the development UI.
  114 |   let handoffs = 0;
  115 |   for (let n = 0; n < VICTORY_ACTION_BUDGET && handoffs < 3; n++) {
  116 |     const action = fixtureAction(state, "human-loss", "");
  117 |     await clickAction(page, action); state = act(state, action);
  118 |     if (action.kind === "endTurn") { handoffs++; await paint(page, state); }
  119 |   }
  120 |   expect(handoffs).toBe(3);
  121 |   await expect(page.locator("#watch-computers-button")).toHaveCount(0);
  122 |   await capture(page, "watch-resumed", info.project.name);
  123 |   await page.locator("#new-game-button").click();
  124 |   await setup(page, fixture); state = await drive(page, fixture);
  125 |   await page.locator("#stop-game-button").click(); state = act(state, { kind: "stopGame" });
  126 |   await freeze(page, state); await fit(page); await capture(page, "human-loss-stopped", info.project.name);
  127 |   await expect(page.locator("#watch-computers-button")).toHaveCount(0);
  128 |   await page.locator("#new-game-button").click();
  129 |   await expect(page.getByRole("heading", { name: "New reference game", exact: true })).toBeVisible();
  130 |   expect(errors).toEqual([]);
  131 |   console.log(JSON.stringify({ kind: fixture.kind, actionsPerRun: fixture.actions.length, resumedHandoffs: handoffs }));
  132 | });
  133 | 
```