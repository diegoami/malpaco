# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: victory-options.spec.ts >> human loss offers Stop or Watch; Watch resumes computers and Stop freezes
- Location: tests/e2e/victory-options.spec.ts:129:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('#victory-reason')
Expected: 0
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('#victory-reason') with timeout 5000ms
  - waiting for locator('#victory-reason')
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 1 human / 2 computer seats · Manual play · Seed 1994
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]: 0 provinces · 0 armies
      - generic [ref=e16]:
        - generic [ref=e17]: Seat 2 · Computer
        - generic [ref=e18]: 22 provinces · 48 armies
      - generic [ref=e22]:
        - generic [ref=e23]: Seat 3 · Computer
        - generic [ref=e24]: 24 provinces · 46 armies
    - contentinfo [ref=e25]:
      - button "New game" [ref=e26] [cursor=pointer]
  - main [ref=e27]:
    - img "Nine Isles reference map" [ref=e29]:
      - button "River gate, Seat 3, 1 armies" [ref=e54] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: 3 · 1
      - button "New port, Seat 2, 8 armies" [ref=e56] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: 2 · 8
      - button "North rest, Seat 2, 1 armies" [ref=e58] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: 2 · 1
      - button "River keep, Seat 2, 1 armies" [ref=e60] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: 2 · 1
      - button "North town, Seat 2, 1 armies" [ref=e62] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: 2 · 1
      - button "Dark ford, Seat 2, 1 armies" [ref=e64] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: 2 · 1
      - button "Iron point, Seat 3, 2 armies" [ref=e66] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: 3 · 2
      - button "South rest, Seat 3, 2 armies" [ref=e68] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: 3 · 2
      - button "High shore, Seat 2, 2 armies" [ref=e70] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: 2 · 2
      - button "Wind town, Seat 3, 1 armies" [ref=e72] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: 3 · 1
      - button "New glen, Seat 2, 8 armies" [ref=e74] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: 2 · 8
      - button "Old rock, Seat 3, 1 armies" [ref=e76] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: 3 · 1
      - button "Blue peak, Seat 2, 1 armies" [ref=e78] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: 2 · 1
      - button "West haven, Seat 3, 1 armies" [ref=e80] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: 3 · 1
      - button "Stone watch, Seat 2, 1 armies" [ref=e82] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: 2 · 1
      - button "Upper ridge, Seat 2, 6 armies" [ref=e84] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: 2 · 6
      - button "Marsh keep, Seat 2, 3 armies" [ref=e86] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: 2 · 3
      - button "New fell, Seat 2, 1 armies" [ref=e88] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: 2 · 1
      - button "Moon point, Seat 3, 1 armies" [ref=e90] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: 3 · 1
      - button "South fell, Seat 2, 1 armies" [ref=e92] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: 2 · 1
      - button "High ridge, Seat 2, 1 armies" [ref=e94] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: 2 · 1
      - button "Bay ford, Seat 2, 1 armies" [ref=e96] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: 2 · 1
      - button "Low moor, Seat 3, 1 armies" [ref=e98] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: 3 · 1
      - button "Lower field, Seat 3, 1 armies" [ref=e100] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: 3 · 1
      - button "Wind gate, Seat 3, 1 armies" [ref=e102] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: 3 · 1
      - button "Silver shore, Seat 3, 4 armies" [ref=e104] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: 3 · 4
      - button "Low peak, Seat 3, 1 armies" [ref=e106] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: 3 · 1
      - button "Wind port, Seat 3, 1 armies" [ref=e108] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: 3 · 1
      - button "Gold point, Seat 3, 1 armies" [ref=e110] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: 3 · 1
        - generic [ref=e112]: ★
      - button "Rock moor, Seat 2, 1 armies" [ref=e113] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: 2 · 1
      - button "Marsh rest, Seat 3, 1 armies" [ref=e115] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: 3 · 1
      - button "Wind dale, Seat 3, 11 armies" [ref=e117] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: 3 · 11
      - button "Silver ford, Seat 2, 1 armies" [ref=e119] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: 2 · 1
      - button "Iron field, Seat 2, 1 armies" [ref=e121] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: 2 · 1
      - button "North wood, Seat 2, 1 armies" [ref=e123] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: 2 · 1
      - button "Fort town, Seat 3, 1 armies" [ref=e125] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: 3 · 1
        - generic [ref=e127]: ★
      - button "Red field, Seat 2, 3 armies" [ref=e128] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: 2 · 3
        - generic [ref=e130]: ★
      - button "South ridge, Seat 2, 2 armies" [ref=e131] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: 2 · 2
      - button "Rock bay, Seat 3, 1 armies" [ref=e133] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: 3 · 1
      - button "North ford, Seat 3, 1 armies" [ref=e135] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: 3 · 1
      - button "Port ridge, Seat 3, 1 armies" [ref=e137] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: 3 · 1
      - button "New rock, Seat 2, 2 armies" [ref=e139] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: 2 · 2
      - button "South reach, Seat 3, 3 armies" [ref=e141] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: 3 · 3
      - button "Silver point, Seat 3, 1 armies" [ref=e143] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: 3 · 1
      - button "East ford, Seat 3, 1 armies" [ref=e145] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: 3 · 1
      - button "Gold town, Seat 3, 6 armies" [ref=e147] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: 3 · 6
      - generic [ref=e179]: North Isle +3
      - generic [ref=e180]: East Isle +3
      - generic [ref=e181]: West Isle +3
      - generic [ref=e182]: South Isle +3
      - generic [ref=e183]: Central Isle +5
      - generic [ref=e184]: Harbor Isle +5
      - generic [ref=e185]: Palm Isle +6
      - generic [ref=e186]: Cliff Isle +5
      - generic [ref=e187]: Great Isle +9
    - complementary [ref=e188]:
      - generic [ref=e192]:
        - generic [ref=e193]: Human seats eliminated
        - generic [ref=e194]: The game is over. Choose New game to play again.
      - region "Game result" [ref=e196]:
        - heading "Final standings" [level=2] [ref=e197]
        - paragraph [ref=e198]: All human seats have been eliminated.
        - table [ref=e199]:
          - caption [ref=e200]: Countries and armies at turn end
          - rowgroup [ref=e201]:
            - row [ref=e202]:
              - columnheader "Seat" [ref=e203]
              - columnheader "Countries" [ref=e204]
              - columnheader "Armies" [ref=e205]
          - rowgroup [ref=e206]:
            - row [ref=e207]:
              - rowheader "Seat 3" [ref=e208]
              - cell "24" [ref=e209]
              - cell "46" [ref=e210]
            - row [ref=e211]:
              - rowheader "Seat 2" [ref=e212]
              - cell "22" [ref=e213]
              - cell "48" [ref=e214]
            - row [ref=e215]:
              - rowheader "Seat 1" [ref=e216]
              - cell "0" [ref=e217]
              - cell "0" [ref=e218]
        - paragraph [ref=e219]: Choose New game to play again.
      - generic [ref=e220]:
        - heading "Battle log" [level=3] [ref=e221]
        - list "Battle log" [ref=e222]:
          - listitem [ref=e223]: T5 Seat 3 ends the turn
          - listitem [ref=e224]: Seat 1 is eliminated
          - listitem [ref=e225]: "T5 Seat 3: East ford → Gold town, took Gold town"
          - listitem [ref=e226]: "T5 Seat 3: East ford → Gold town, -0 / -1"
          - listitem [ref=e227]: "T5 Seat 3: East ford → Gold town, -1 / -0"
          - listitem [ref=e228]: "T5 Seat 3: East ford → Gold town, -1 / -0"
          - listitem [ref=e229]: "T5 Seat 3: East ford → Gold town, -1 / -0"
```

# Test source

```ts
  43  |   if (await domination.count()) await domination.setChecked(fixture.kind === "domination");
  44  |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  45  |   await paint(page, fixture.start);
  46  | }
  47  | async function drive(page: Page, fixture: ReturnType<typeof plan>) {
  48  |   let state = fixture.start;
  49  |   for (const action of fixture.actions) {
  50  |     await clickAction(page, action);
  51  |     state = act(state, action);
  52  |     if (action.kind === "attack" || action.kind === "captureMove" || action.kind === "endTurn") await paint(page, state);
  53  |   }
  54  |   return state;
  55  | }
  56  | async function freeze(page: Page, state: CompleteState) {
  57  |   for (const selector of ["#start-combat-button", "#end-turn-button", "#single-exchange-button", "#fight-on-button", "#start-friendly-move-button", "#confirm-capture-button", "#confirm-friendly-move-button"]) {
  58  |     const node = page.locator(selector);
  59  |     if (await node.count() && await node.isVisible()) await expect(node).toBeDisabled();
  60  |   }
  61  |   await country(page, referenceMap.provinces[0]!.id).dispatchEvent("click");
  62  |   await page.keyboard.press("Enter");
  63  |   await paint(page, state);
  64  | }
  65  | async function fit(page: Page) {
  66  |   const rows = await page.locator('#victory-reason,#victory-standings,#watch-computers-button,#stop-game-button,#new-game-button').evaluateAll(nodes => nodes.filter(n => n.getClientRects().length).map(n => { const b = n.getBoundingClientRect(); return { id: n.id, fits: b.left >= 0 && b.top >= 0 && b.right <= innerWidth && b.bottom <= innerHeight }; }));
  67  |   expect(rows.length).toBeGreaterThan(2);
  68  |   expect(rows.filter(r => !r.fits)).toEqual([]);
  69  | }
  70  | 
  71  | test("domination result names winner/reason, final standings, freezes and restarts", async ({ page }, info) => {
  72  |   test.setTimeout(240000);
  73  |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  74  |   const fixture = plan("domination");
  75  |   await setup(page, fixture);
  76  |   const stale = await page.locator("#end-turn-button").elementHandle();
  77  |   const state = await drive(page, fixture);
  78  |   await expect(page.locator("#victory-reason")).toContainText(/domination/i);
  79  |   await expect(page.locator("#victory-reason")).toContainText(String(Object.values(state.ownerOf).filter(id => id === state.winner).length));
  80  |   await expect(page.locator("#turn-title")).toContainText(state.players.find(p => p.id === state.winner)!.name);
  81  |   await expect(page.locator("#victory-standings [data-result-player]")).toHaveCount(state.players.length);
  82  |   expect(await page.locator("[data-result-player]").evaluateAll(ns => ns.map(n => n.getAttribute("data-result-player")))).toEqual(standings(state).map(r => r.player));
  83  |   for (const player of state.players) {
  84  |     const countries = Object.values(state.ownerOf).filter(id => id === player.id).length;
  85  |     const row = page.locator(`[data-result-player="${player.id}"]`);
  86  |     await expect(row).toContainText(player.name);
  87  |     await expect(row.locator("[data-result-countries]")).toHaveText(String(countries));
  88  |     await expect(row.locator("[data-result-armies]")).toHaveText(String(standings(state).find(r => r.player === player.id)!.armies));
  89  |   }
  90  |   await stale!.evaluate(n => n.dispatchEvent(new MouseEvent("click", { bubbles: true })));
  91  |   await freeze(page, state); await fit(page); await capture(page, "domination", info.project.name);
  92  |   await page.locator("#new-game-button").click();
  93  |   await expect(page.getByRole("heading", { name: "New reference game", exact: true })).toBeVisible();
  94  |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  95  |   await expect(page.locator("#victory-reason")).toHaveCount(0);
  96  |   expect(errors).toEqual([]);
  97  |   console.log(JSON.stringify({ kind: fixture.kind, actions: fixture.actions.length, winner: state.winner }));
  98  | });
  99  | 
  100 | test("round limit finishes after a complete rotated round and explains the score", async ({ page }, info) => {
  101 |   test.setTimeout(240000);
  102 |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  103 |   let state = opening(1994, 2, { dominationWin: false, roundLimit: 20 });
  104 |   const fixture = { start: state, state, actions: [] as CompleteAction[], conqueror: "", kind: "human-loss" as const };
  105 |   await setup(page, fixture);
  106 |   // Change settings through the real setup; no loaded or injected position.
  107 |   await page.locator("#new-game-button").click();
  108 |   const limit = page.getByLabel("Round limit", { exact: true });
  109 |   if (await limit.count()) await limit.selectOption("20");
  110 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  111 |   const origin = state.currentPlayer;
  112 |   for (let turn = 0; turn < 40; turn++) {
  113 |     expect(state.currentPlayer).toBe((origin + turn) % 2);
  114 |     await expect(page.locator(".turn-sub")).toContainText(`Round ${1 + Math.floor(turn / 2)}`);
  115 |     while (state.phase === "reinforce") {
  116 |       const own = state.map.provinces.find(p => state.ownerOf[p.id] === state.players[state.currentPlayer]!.id)!;
  117 |       const action: CompleteAction = state.reinforcementPool ? { kind: "reinforce", province: own.id, amount: 1 } : { kind: "endReinforcement" };
  118 |       await clickAction(page, action); state = act(state, action);
  119 |     }
  120 |     await clickAction(page, { kind: "endTurn" }); state = act(state, { kind: "endTurn" });
  121 |   }
  122 |   await expect(page.locator("#victory-reason")).toContainText(/round.*limit/i);
  123 |   await expect(page.locator("#victory-reason")).toContainText(/arm|order|countr/i);
  124 |   await paint(page, state); await freeze(page, state); await fit(page);
  125 |   await capture(page, "round-limit", info.project.name);
  126 |   expect(errors).toEqual([]);
  127 | });
  128 | 
  129 | test("human loss offers Stop or Watch; Watch resumes computers and Stop freezes", async ({ page }, info) => {
  130 |   test.setTimeout(300000);
  131 |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  132 |   const fixture = plan("human-loss");
  133 |   await setup(page, fixture);
  134 |   let state = await drive(page, fixture);
  135 |   await expect(page.locator("#victory-reason")).toContainText(/human.*eliminat|no human/i);
  136 |   await expect(page.locator("#watch-computers-button")).toBeVisible();
  137 |   await expect(page.locator("#stop-game-button")).toBeVisible();
  138 |   await freeze(page, state); await fit(page); await capture(page, "human-loss", info.project.name);
  139 |   const staleStop = await page.locator("#stop-game-button").elementHandle();
  140 |   await page.locator("#watch-computers-button").click(); state = act(state, { kind: "watchComputers" });
  141 |   await staleStop!.evaluate(n => n.dispatchEvent(new MouseEvent("click", { bubbles: true })));
  142 |   await paint(page, state);
> 143 |   await expect(page.locator("#victory-reason")).toHaveCount(0);
      |                                                 ^ Error: expect(locator).toHaveCount(expected) failed
  144 |   await expect(page.locator("#turn-title")).toContainText(state.players[state.currentPlayer]!.name);
  145 |   // Scheduling is T32. Drive actual remaining computer actions through the development UI.
  146 |   let handoffs = 0;
  147 |   for (let n = 0; n < VICTORY_ACTION_BUDGET && handoffs < 3; n++) {
  148 |     const action = fixtureAction(state, "human-loss", "");
  149 |     await clickAction(page, action); state = act(state, action);
  150 |     if (action.kind === "endTurn") { handoffs++; await paint(page, state); }
  151 |   }
  152 |   expect(handoffs).toBe(3);
  153 |   await expect(page.locator("#watch-computers-button")).toHaveCount(0);
  154 |   await capture(page, "watch-resumed", info.project.name);
  155 |   await page.locator("#new-game-button").click();
  156 |   await setup(page, fixture); state = await drive(page, fixture);
  157 |   await page.locator("#stop-game-button").click(); state = act(state, { kind: "stopGame" });
  158 |   await freeze(page, state); await fit(page); await capture(page, "human-loss-stopped", info.project.name);
  159 |   await expect(page.locator("#watch-computers-button")).toHaveCount(0);
  160 |   await page.locator("#new-game-button").click();
  161 |   await expect(page.getByRole("heading", { name: "New reference game", exact: true })).toBeVisible();
  162 |   expect(errors).toEqual([]);
  163 |   console.log(JSON.stringify({ kind: fixture.kind, actionsPerRun: fixture.actions.length, resumedHandoffs: handoffs }));
  164 | });
  165 | 
```