# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: victory-options.spec.ts >> domination result names winner/reason, final standings, freezes and restarts
- Location: tests/e2e/victory-options.spec.ts:71:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('#victory-reason')
Expected pattern: /domination/i
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" locator('#victory-reason') with timeout 5000ms
  - waiting for locator('#victory-reason')

```

```yaml
- banner:
  - heading "Malpaco" [level=1]
  - text: Nine Isles · 2 human seats · Seed 1994 Seat 1 11 provinces · 35 armies Seat 2 35 provinces · 83 armies
  - contentinfo:
    - button "New game"
- main:
  - img "Nine Isles reference map":
    - button "River gate, Seat 1, 3 armies": River gate 1 · 3
    - button "New port, Seat 2, 1 armies": New port 2 · 1
    - button "North rest, Seat 2, 1 armies": North rest 2 · 1
    - button "River keep, Seat 2, 1 armies": River keep 2 · 1
    - button "North town, Seat 1, 3 armies": North town 1 · 3
    - button "Dark ford, Seat 2, 1 armies": Dark ford 2 · 1
    - button "Iron point, Seat 1, 3 armies": Iron point 1 · 3
    - button "South rest, Seat 2, 1 armies": South rest 2 · 1
    - button "High shore, Seat 2, 1 armies": High shore 2 · 1
    - button "Wind town, Seat 1, 4 armies": Wind town 1 · 4
    - button "New glen, Seat 2, 1 armies": New glen 2 · 1
    - button "Old rock, Seat 1, 3 armies": Old rock 1 · 3
    - button "Blue peak, Seat 1, 3 armies": Blue peak 1 · 3
    - button "West haven, Seat 1, 3 armies": West haven 1 · 3
    - button "Stone watch, Seat 1, 4 armies": Stone watch 1 · 4
    - button "Upper ridge, Seat 2, 1 armies": Upper ridge 2 · 1
    - button "Marsh keep, Seat 2, 1 armies": Marsh keep 2 · 1
    - button "New fell, Seat 2, 1 armies": New fell 2 · 1
    - button "Moon point, Seat 2, 1 armies": Moon point 2 · 1
    - button "South fell, Seat 2, 1 armies": South fell 2 · 1
    - button "High ridge, Seat 2, 1 armies": High ridge 2 · 1
    - button "Bay ford, Seat 2, 1 armies": Bay ford 2 · 1
    - button "Low moor, Seat 2, 1 armies": Low moor 2 · 1
    - button "Lower field, Seat 2, 1 armies": Lower field 2 · 1
    - button "Wind gate, Seat 2, 1 armies": Wind gate 2 · 1
    - button "Silver shore, Seat 2, 1 armies": Silver shore 2 · 1
    - button "Low peak, Seat 2, 15 armies": Low peak 2 · 15
    - button "Wind port, Seat 2, 1 armies": Wind port 2 · 1
    - button "Gold point, Seat 2, 16 armies": Gold point 2 · 16 ★
    - button "Rock moor, Seat 2, 1 armies": Rock moor 2 · 1
    - button "Marsh rest, Seat 1, 3 armies": Marsh rest 1 · 3
    - button "Wind dale, Seat 2, 1 armies": Wind dale 2 · 1
    - button "Silver ford, Seat 2, 3 armies": Silver ford 2 · 3
    - button "Iron field, Seat 2, 1 armies": Iron field 2 · 1
    - button "North wood, Seat 2, 1 armies": North wood 2 · 1
    - button "Fort town, Seat 2, 1 armies": Fort town 2 · 1 ★
    - button "Red field, Seat 2, 1 armies": Red field 2 · 1 ★
    - button "South ridge, Seat 2, 1 armies": South ridge 2 · 1
    - button "Rock bay, Seat 2, 1 armies": Rock bay 2 · 1
    - button "North ford, Seat 2, 1 armies": North ford 2 · 1
    - button "Port ridge, Seat 1, 3 armies": Port ridge 1 · 3
    - button "New rock, Seat 2, 1 armies": New rock 2 · 1
    - button "South reach, Seat 1, 3 armies": South reach 1 · 3
    - button "Silver point, Seat 2, 18 armies": Silver point 2 · 18
    - button "East ford, Seat 2, 1 armies": East ford 2 · 1
    - button "Gold town, Seat 2, 1 armies": Gold town 2 · 1
    - text: North Isle +3 East Isle +3 West Isle +3 South Isle +3 Central Isle +5 Harbor Isle +5 Palm Isle +6 Cliff Isle +5 Great Isle +9
  - complementary:
    - text: Seat 1's turn Round 6 · Reinforcement Province income
    - strong: "3"
    - text: Island income
    - strong: "0"
    - text: Armies to place
    - strong: "3"
    - paragraph: Place your armies on your countries, then start combat.
    - button "Start combat" [disabled]
    - button "End turn" [disabled]
    - heading "Battle log" [level=3]
    - list "Battle log":
      - listitem: T5 Seat 2 ends the turn
      - listitem: "T5 Seat 2: East ford → Silver point, took Silver point"
      - listitem: "T5 Seat 2: East ford → Silver point, -0 / -1"
      - listitem: "T5 Seat 2: East ford → Silver point, -1 / -0"
      - listitem: "T5 Seat 2: East ford → Silver point, -1 / -0"
      - listitem: "T5 Seat 2: East ford → Silver point, -1 / -0"
      - listitem: "T5 Seat 2: East ford → Silver point, -1 / -0"
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test";
  2   | import type { Page } from "@playwright/test";
  3   | import { mkdirSync, mkdtempSync } from "node:fs";
  4   | import { join } from "node:path";
  5   | import { act, fixtureAction, plan, referenceMap, VICTORY_ACTION_BUDGET } from "./victory-fixture";
  6   | import type { CompleteAction, CompleteState } from "../core/victory-options-fixture";
  7   | import { opening, standings } from "../core/victory-options-fixture";
  8   | 
  9   | const country = (page: Page, id: string) => page.locator(`[data-country="${id}"]`);
  10  | async function capture(page: Page, label: string, project: string) {
  11  |   const root = process.env["VICTORY_EVIDENCE_DIR"] ?? "screenshots";
  12  |   mkdirSync(root, { recursive: true });
  13  |   await page.screenshot({ path: join(mkdtempSync(join(root, "victory-")), `${label}-${project}.png`) });
  14  | }
  15  | async function paint(page: Page, state: CompleteState) {
  16  |   const actual = await page.locator("[data-country]").evaluateAll(nodes => Object.fromEntries(nodes.map(n => [n.getAttribute("data-country"), [n.getAttribute("data-owner"), Number(n.getAttribute("data-armies"))]])));
  17  |   expect(actual).toEqual(Object.fromEntries(referenceMap.provinces.map(p => [p.id, [state.ownerOf[p.id], state.armies[p.id]]])));
  18  | }
  19  | async function clickAction(page: Page, action: CompleteAction) {
  20  |   if (action.kind === "reinforce") await country(page, action.province).click();
  21  |   else if (action.kind === "endReinforcement") await page.locator("#start-combat-button").click();
  22  |   else if (action.kind === "endTurn") await page.locator("#end-turn-button").click();
  23  |   else if (action.kind === "captureMove") await page.locator("#confirm-capture-button").click();
  24  |   else if (action.kind === "attack") {
  25  |     const from = country(page, action.from);
  26  |     if (await from.getAttribute("aria-pressed") !== "true") await from.click();
  27  |     await country(page, action.to).click();
  28  |     await page.locator("#single-exchange-button").click();
  29  |   } else throw Error(`Unhandled fixture click ${action.kind}`);
  30  | }
  31  | async function setup(page: Page, fixture: ReturnType<typeof plan>) {
  32  |   await page.emulateMedia({ reducedMotion: "reduce" });
  33  |   await page.goto("/?view=reference-game");
  34  |   await page.getByLabel("Seed", { exact: true }).fill("1994");
  35  |   await page.getByLabel("Human seats").selectOption(String(fixture.start.players.length));
  36  |   // Baseline can still reach the same deal/counts without missing controls;
  37  |   // kind affects neither this zero-share deal nor the manually driven actions.
  38  |   for (let i = 0; i < fixture.start.players.length; i++) {
  39  |     const control = page.getByLabel(`Seat ${i + 1} control`, { exact: true });
  40  |     if (await control.count()) await control.selectOption(fixture.start.players[i]!.kind!);
  41  |   }
  42  |   const domination = page.getByLabel("Domination win", { exact: true });
  43  |   if (await domination.count()) await domination.setChecked(fixture.kind === "domination");
  44  |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  45  |   await paint(page, fixture.start);
  46  | }
  47  | async function drive(page: Page, fixture: ReturnType<typeof plan>) {
  48  |   let state = fixture.start;
  49  |   for (const action of fixture.actions) {
  50  |     await clickAction(page, action);
  51  |     state = act(state, action);
  52  |     if (action.kind === "attack" || action.kind === "captureMove" || action.kind === "endTurn") await paint(page, state);
  53  |   }
  54  |   return state;
  55  | }
  56  | async function freeze(page: Page, state: CompleteState) {
  57  |   for (const selector of ["#start-combat-button", "#end-turn-button", "#single-exchange-button", "#fight-on-button", "#start-friendly-move-button", "#confirm-capture-button", "#confirm-friendly-move-button"]) {
  58  |     const node = page.locator(selector);
  59  |     if (await node.count() && await node.isVisible()) await expect(node).toBeDisabled();
  60  |   }
  61  |   await country(page, referenceMap.provinces[0]!.id).dispatchEvent("click");
  62  |   await page.keyboard.press("Enter");
  63  |   await paint(page, state);
  64  | }
  65  | async function fit(page: Page) {
  66  |   const rows = await page.locator('#victory-reason,#victory-standings,#watch-computers-button,#stop-game-button,#new-game-button').evaluateAll(nodes => nodes.filter(n => n.getClientRects().length).map(n => { const b = n.getBoundingClientRect(); return { id: n.id, fits: b.left >= 0 && b.top >= 0 && b.right <= innerWidth && b.bottom <= innerHeight }; }));
  67  |   expect(rows.length).toBeGreaterThan(2);
  68  |   expect(rows.filter(r => !r.fits)).toEqual([]);
  69  | }
  70  | 
  71  | test("domination result names winner/reason, final standings, freezes and restarts", async ({ page }, info) => {
  72  |   test.setTimeout(240000);
  73  |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  74  |   const fixture = plan("domination");
  75  |   await setup(page, fixture);
  76  |   const stale = await page.locator("#end-turn-button").elementHandle();
  77  |   const state = await drive(page, fixture);
> 78  |   await expect(page.locator("#victory-reason")).toContainText(/domination/i);
      |                                                 ^ Error: expect(locator).toContainText(expected) failed
  79  |   await expect(page.locator("#victory-reason")).toContainText(String(Object.values(state.ownerOf).filter(id => id === state.winner).length));
  80  |   await expect(page.locator("#turn-title")).toContainText(state.players.find(p => p.id === state.winner)!.name);
  81  |   await expect(page.locator("#victory-standings [data-result-player]")).toHaveCount(state.players.length);
  82  |   expect(await page.locator("[data-result-player]").evaluateAll(ns => ns.map(n => n.getAttribute("data-result-player")))).toEqual(standings(state).map(r => r.player));
  83  |   for (const player of state.players) {
  84  |     const countries = Object.values(state.ownerOf).filter(id => id === player.id).length;
  85  |     const row = page.locator(`[data-result-player="${player.id}"]`);
  86  |     await expect(row).toContainText(player.name);
  87  |     await expect(row.locator("[data-result-countries]")).toHaveText(String(countries));
  88  |     await expect(row.locator("[data-result-armies]")).toHaveText(String(standings(state).find(r => r.player === player.id)!.armies));
  89  |   }
  90  |   await stale!.evaluate(n => n.dispatchEvent(new MouseEvent("click", { bubbles: true })));
  91  |   await freeze(page, state); await fit(page); await capture(page, "domination", info.project.name);
  92  |   await page.locator("#new-game-button").click();
  93  |   await expect(page.getByRole("heading", { name: "New reference game", exact: true })).toBeVisible();
  94  |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  95  |   await expect(page.locator("#victory-reason")).toHaveCount(0);
  96  |   expect(errors).toEqual([]);
  97  |   console.log(JSON.stringify({ kind: fixture.kind, actions: fixture.actions.length, winner: state.winner }));
  98  | });
  99  | 
  100 | test("round limit finishes after a complete rotated round and explains the score", async ({ page }, info) => {
  101 |   test.setTimeout(240000);
  102 |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  103 |   let state = opening(1994, 2, { dominationWin: false, roundLimit: 20 });
  104 |   const fixture = { start: state, state, actions: [] as CompleteAction[], conqueror: "", kind: "human-loss" as const };
  105 |   await setup(page, fixture);
  106 |   // Change settings through the real setup; no loaded or injected position.
  107 |   await page.locator("#new-game-button").click();
  108 |   const limit = page.getByLabel("Round limit", { exact: true });
  109 |   if (await limit.count()) await limit.selectOption("20");
  110 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  111 |   const origin = state.currentPlayer;
  112 |   for (let turn = 0; turn < 40; turn++) {
  113 |     expect(state.currentPlayer).toBe((origin + turn) % 2);
  114 |     await expect(page.locator(".turn-sub")).toContainText(`Round ${1 + Math.floor(turn / 2)}`);
  115 |     while (state.phase === "reinforce") {
  116 |       const own = state.map.provinces.find(p => state.ownerOf[p.id] === state.players[state.currentPlayer]!.id)!;
  117 |       const action: CompleteAction = state.reinforcementPool ? { kind: "reinforce", province: own.id, amount: 1 } : { kind: "endReinforcement" };
  118 |       await clickAction(page, action); state = act(state, action);
  119 |     }
  120 |     await clickAction(page, { kind: "endTurn" }); state = act(state, { kind: "endTurn" });
  121 |   }
  122 |   await expect(page.locator("#victory-reason")).toContainText(/round.*limit/i);
  123 |   await expect(page.locator("#victory-reason")).toContainText(/arm|order|countr/i);
  124 |   await paint(page, state); await freeze(page, state); await fit(page);
  125 |   await capture(page, "round-limit", info.project.name);
  126 |   expect(errors).toEqual([]);
  127 | });
  128 | 
  129 | test("human loss offers Stop or Watch; Watch resumes computers and Stop freezes", async ({ page }, info) => {
  130 |   test.setTimeout(300000);
  131 |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  132 |   const fixture = plan("human-loss");
  133 |   await setup(page, fixture);
  134 |   let state = await drive(page, fixture);
  135 |   await expect(page.locator("#victory-reason")).toContainText(/human.*eliminat|no human/i);
  136 |   await expect(page.locator("#watch-computers-button")).toBeVisible();
  137 |   await expect(page.locator("#stop-game-button")).toBeVisible();
  138 |   await freeze(page, state); await fit(page); await capture(page, "human-loss", info.project.name);
  139 |   const staleStop = await page.locator("#stop-game-button").elementHandle();
  140 |   await page.locator("#watch-computers-button").click(); state = act(state, { kind: "watchComputers" });
  141 |   await staleStop!.evaluate(n => n.dispatchEvent(new MouseEvent("click", { bubbles: true })));
  142 |   await paint(page, state);
  143 |   await expect(page.locator("#victory-reason")).toHaveCount(0);
  144 |   await expect(page.locator("#turn-title")).toContainText(state.players[state.currentPlayer]!.name);
  145 |   // Scheduling is T32. Drive actual remaining computer actions through the development UI.
  146 |   let handoffs = 0;
  147 |   for (let n = 0; n < VICTORY_ACTION_BUDGET && handoffs < 3; n++) {
  148 |     const action = fixtureAction(state, "human-loss", "");
  149 |     await clickAction(page, action); state = act(state, action);
  150 |     if (action.kind === "endTurn") { handoffs++; await paint(page, state); }
  151 |   }
  152 |   expect(handoffs).toBe(3);
  153 |   await expect(page.locator("#watch-computers-button")).toHaveCount(0);
  154 |   await capture(page, "watch-resumed", info.project.name);
  155 |   await page.locator("#new-game-button").click();
  156 |   await setup(page, fixture); state = await drive(page, fixture);
  157 |   await page.locator("#stop-game-button").click(); state = act(state, { kind: "stopGame" });
  158 |   await freeze(page, state); await fit(page); await capture(page, "human-loss-stopped", info.project.name);
  159 |   await expect(page.locator("#watch-computers-button")).toHaveCount(0);
  160 |   await page.locator("#new-game-button").click();
  161 |   await expect(page.getByRole("heading", { name: "New reference game", exact: true })).toBeVisible();
  162 |   expect(errors).toEqual([]);
  163 |   console.log(JSON.stringify({ kind: fixture.kind, actionsPerRun: fixture.actions.length, resumedHandoffs: handoffs }));
  164 | });
  165 | 
```