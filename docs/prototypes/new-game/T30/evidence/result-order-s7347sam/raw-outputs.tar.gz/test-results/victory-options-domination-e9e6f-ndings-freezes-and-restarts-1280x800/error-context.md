# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: victory-options.spec.ts >> domination result names winner/reason, final standings, freezes and restarts
- Location: tests/e2e/victory-options.spec.ts:71:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 1

  Array [
-   "seat2",
    "seat1",
+   "seat2",
  ]
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 2 human seats · Seed 1994
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]: 11 provinces · 35 armies
      - generic [ref=e16]:
        - generic [ref=e17]: Seat 2
        - generic [ref=e18]: 35 provinces · 83 armies
    - contentinfo [ref=e19]:
      - button "New game" [ref=e20] [cursor=pointer]
  - main [ref=e21]:
    - img "Nine Isles reference map" [ref=e23]:
      - button "River gate, Seat 1, 3 armies" [ref=e48] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: 1 · 3
      - button "New port, Seat 2, 1 armies" [ref=e50] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: 2 · 1
      - button "North rest, Seat 2, 1 armies" [ref=e52] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: 2 · 1
      - button "River keep, Seat 2, 1 armies" [ref=e54] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: 2 · 1
      - button "North town, Seat 1, 3 armies" [ref=e56] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: 1 · 3
      - button "Dark ford, Seat 2, 1 armies" [ref=e58] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: 2 · 1
      - button "Iron point, Seat 1, 3 armies" [ref=e60] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: 1 · 3
      - button "South rest, Seat 2, 1 armies" [ref=e62] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: 2 · 1
      - button "High shore, Seat 2, 1 armies" [ref=e64] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: 2 · 1
      - button "Wind town, Seat 1, 4 armies" [ref=e66] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: 1 · 4
      - button "New glen, Seat 2, 1 armies" [ref=e68] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: 2 · 1
      - button "Old rock, Seat 1, 3 armies" [ref=e70] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: 1 · 3
      - button "Blue peak, Seat 1, 3 armies" [ref=e72] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: 1 · 3
      - button "West haven, Seat 1, 3 armies" [ref=e74] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: 1 · 3
      - button "Stone watch, Seat 1, 4 armies" [ref=e76] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: 1 · 4
      - button "Upper ridge, Seat 2, 1 armies" [ref=e78] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: 2 · 1
      - button "Marsh keep, Seat 2, 1 armies" [ref=e80] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: 2 · 1
      - button "New fell, Seat 2, 1 armies" [ref=e82] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: 2 · 1
      - button "Moon point, Seat 2, 1 armies" [ref=e84] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: 2 · 1
      - button "South fell, Seat 2, 1 armies" [ref=e86] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: 2 · 1
      - button "High ridge, Seat 2, 1 armies" [ref=e88] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: 2 · 1
      - button "Bay ford, Seat 2, 1 armies" [ref=e90] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: 2 · 1
      - button "Low moor, Seat 2, 1 armies" [ref=e92] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: 2 · 1
      - button "Lower field, Seat 2, 1 armies" [ref=e94] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: 2 · 1
      - button "Wind gate, Seat 2, 1 armies" [ref=e96] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: 2 · 1
      - button "Silver shore, Seat 2, 1 armies" [ref=e98] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: 2 · 1
      - button "Low peak, Seat 2, 15 armies" [ref=e100] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: 2 · 15
      - button "Wind port, Seat 2, 1 armies" [ref=e102] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: 2 · 1
      - button "Gold point, Seat 2, 16 armies" [ref=e104] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: 2 · 16
        - generic [ref=e106]: ★
      - button "Rock moor, Seat 2, 1 armies" [ref=e107] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: 2 · 1
      - button "Marsh rest, Seat 1, 3 armies" [ref=e109] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: 1 · 3
      - button "Wind dale, Seat 2, 1 armies" [ref=e111] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: 2 · 1
      - button "Silver ford, Seat 2, 3 armies" [ref=e113] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: 2 · 3
      - button "Iron field, Seat 2, 1 armies" [ref=e115] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: 2 · 1
      - button "North wood, Seat 2, 1 armies" [ref=e117] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: 2 · 1
      - button "Fort town, Seat 2, 1 armies" [ref=e119] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: 2 · 1
        - generic [ref=e121]: ★
      - button "Red field, Seat 2, 1 armies" [ref=e122] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: 2 · 1
        - generic [ref=e124]: ★
      - button "South ridge, Seat 2, 1 armies" [ref=e125] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: 2 · 1
      - button "Rock bay, Seat 2, 1 armies" [ref=e127] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: 2 · 1
      - button "North ford, Seat 2, 1 armies" [ref=e129] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: 2 · 1
      - button "Port ridge, Seat 1, 3 armies" [ref=e131] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: 1 · 3
      - button "New rock, Seat 2, 1 armies" [ref=e133] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: 2 · 1
      - button "South reach, Seat 1, 3 armies" [ref=e135] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: 1 · 3
      - button "Silver point, Seat 2, 18 armies" [ref=e137] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: 2 · 18
      - button "East ford, Seat 2, 1 armies" [ref=e139] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: 2 · 1
      - button "Gold town, Seat 2, 1 armies" [ref=e141] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: 2 · 1
      - generic [ref=e173]: North Isle +3
      - generic [ref=e174]: East Isle +3
      - generic [ref=e175]: West Isle +3
      - generic [ref=e176]: South Isle +3
      - generic [ref=e177]: Central Isle +5
      - generic [ref=e178]: Harbor Isle +5
      - generic [ref=e179]: Palm Isle +6
      - generic [ref=e180]: Cliff Isle +5
      - generic [ref=e181]: Great Isle +9
    - complementary [ref=e182]:
      - generic [ref=e186]:
        - generic [ref=e187]: Seat 2 wins
        - generic [ref=e188]: The game is over. Choose New game to play again.
      - region "Game result" [ref=e190]:
        - heading "Final standings" [level=2] [ref=e191]
        - paragraph [ref=e192]: "Domination: Seat 2 holds 35 of 46 countries."
        - table [ref=e193]:
          - caption [ref=e194]: Countries and armies at turn end
          - rowgroup [ref=e195]:
            - row [ref=e196]:
              - columnheader "Seat" [ref=e197]
              - columnheader "Countries" [ref=e198]
              - columnheader "Armies" [ref=e199]
          - rowgroup [ref=e200]:
            - row [ref=e201]:
              - rowheader "Seat 1" [ref=e202]
              - cell "11" [ref=e203]
              - cell "35" [ref=e204]
            - row [ref=e205]:
              - rowheader "Seat 2" [ref=e206]
              - cell "35" [ref=e207]
              - cell "83" [ref=e208]
        - paragraph [ref=e209]: Choose New game to play again.
      - generic [ref=e210]:
        - heading "Battle log" [level=3] [ref=e211]
        - list "Battle log" [ref=e212]:
          - listitem [ref=e213]: Seat 2 wins
          - listitem [ref=e214]: T5 Seat 2 ends the turn
          - listitem [ref=e215]: "T5 Seat 2: East ford → Silver point, took Silver point"
          - listitem [ref=e216]: "T5 Seat 2: East ford → Silver point, -0 / -1"
          - listitem [ref=e217]: "T5 Seat 2: East ford → Silver point, -1 / -0"
          - listitem [ref=e218]: "T5 Seat 2: East ford → Silver point, -1 / -0"
          - listitem [ref=e219]: "T5 Seat 2: East ford → Silver point, -1 / -0"
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test";
  2   | import type { Page } from "@playwright/test";
  3   | import { mkdirSync, mkdtempSync } from "node:fs";
  4   | import { join } from "node:path";
  5   | import { act, fixtureAction, plan, referenceMap, VICTORY_ACTION_BUDGET } from "./victory-fixture";
  6   | import type { CompleteAction, CompleteState } from "../core/victory-options-fixture";
  7   | import { opening, standings } from "../core/victory-options-fixture";
  8   | 
  9   | const country = (page: Page, id: string) => page.locator(`[data-country="${id}"]`);
  10  | async function capture(page: Page, label: string, project: string) {
  11  |   const root = process.env["VICTORY_EVIDENCE_DIR"] ?? "screenshots";
  12  |   mkdirSync(root, { recursive: true });
  13  |   await page.screenshot({ path: join(mkdtempSync(join(root, "victory-")), `${label}-${project}.png`) });
  14  | }
  15  | async function paint(page: Page, state: CompleteState) {
  16  |   const actual = await page.locator("[data-country]").evaluateAll(nodes => Object.fromEntries(nodes.map(n => [n.getAttribute("data-country"), [n.getAttribute("data-owner"), Number(n.getAttribute("data-armies"))]])));
  17  |   expect(actual).toEqual(Object.fromEntries(referenceMap.provinces.map(p => [p.id, [state.ownerOf[p.id], state.armies[p.id]]])));
  18  | }
  19  | async function clickAction(page: Page, action: CompleteAction) {
  20  |   if (action.kind === "reinforce") await country(page, action.province).click();
  21  |   else if (action.kind === "endReinforcement") await page.locator("#start-combat-button").click();
  22  |   else if (action.kind === "endTurn") await page.locator("#end-turn-button").click();
  23  |   else if (action.kind === "captureMove") await page.locator("#confirm-capture-button").click();
  24  |   else if (action.kind === "attack") {
  25  |     const from = country(page, action.from);
  26  |     if (await from.getAttribute("aria-pressed") !== "true") await from.click();
  27  |     await country(page, action.to).click();
  28  |     await page.locator("#single-exchange-button").click();
  29  |   } else throw Error(`Unhandled fixture click ${action.kind}`);
  30  | }
  31  | async function setup(page: Page, fixture: ReturnType<typeof plan>) {
  32  |   await page.emulateMedia({ reducedMotion: "reduce" });
  33  |   await page.goto("/?view=reference-game&control=manual");
  34  |   await page.getByLabel("Seed", { exact: true }).fill("1994");
  35  |   await page.getByLabel("Human seats").selectOption(String(fixture.start.players.length));
  36  |   // Baseline can still reach the same deal/counts without missing controls;
  37  |   // kind affects neither this zero-share deal nor the manually driven actions.
  38  |   for (let i = 0; i < fixture.start.players.length; i++) {
  39  |     const control = page.getByLabel(`Seat ${i + 1} control`, { exact: true });
  40  |     if (await control.count()) await control.selectOption(fixture.start.players[i]!.kind!);
  41  |   }
  42  |   const domination = page.getByLabel("Domination win", { exact: true });
  43  |   if (await domination.count()) await domination.setChecked(fixture.kind === "domination");
  44  |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  45  |   await paint(page, fixture.start);
  46  | }
  47  | async function drive(page: Page, fixture: ReturnType<typeof plan>) {
  48  |   let state = fixture.start;
  49  |   for (const action of fixture.actions) {
  50  |     await clickAction(page, action);
  51  |     state = act(state, action);
  52  |     if (action.kind === "attack" || action.kind === "captureMove" || action.kind === "endTurn") await paint(page, state);
  53  |   }
  54  |   return state;
  55  | }
  56  | async function freeze(page: Page, state: CompleteState) {
  57  |   for (const selector of ["#start-combat-button", "#end-turn-button", "#single-exchange-button", "#fight-on-button", "#start-friendly-move-button", "#confirm-capture-button", "#confirm-friendly-move-button"]) {
  58  |     const node = page.locator(selector);
  59  |     if (await node.count() && await node.isVisible()) await expect(node).toBeDisabled();
  60  |   }
  61  |   await country(page, referenceMap.provinces[0]!.id).dispatchEvent("click");
  62  |   await page.keyboard.press("Enter");
  63  |   await paint(page, state);
  64  | }
  65  | async function fit(page: Page) {
  66  |   const rows = await page.locator('#victory-reason,#victory-standings,#watch-computers-button,#stop-game-button,#new-game-button').evaluateAll(nodes => nodes.filter(n => n.getClientRects().length).map(n => { const b = n.getBoundingClientRect(); return { id: n.id, fits: b.left >= 0 && b.top >= 0 && b.right <= innerWidth && b.bottom <= innerHeight }; }));
  67  |   expect(rows.length).toBeGreaterThan(2);
  68  |   expect(rows.filter(r => !r.fits)).toEqual([]);
  69  | }
  70  | 
  71  | test("domination result names winner/reason, final standings, freezes and restarts", async ({ page }, info) => {
  72  |   test.setTimeout(240000);
  73  |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  74  |   const fixture = plan("domination");
  75  |   await setup(page, fixture);
  76  |   const stale = await page.locator("#end-turn-button").elementHandle();
  77  |   const state = await drive(page, fixture);
  78  |   await expect(page.locator("#victory-reason")).toContainText(/domination/i);
  79  |   await expect(page.locator("#victory-reason")).toContainText(String(Object.values(state.ownerOf).filter(id => id === state.winner).length));
  80  |   await expect(page.locator("#turn-title")).toContainText(state.players.find(p => p.id === state.winner)!.name);
  81  |   await expect(page.locator("#victory-standings [data-result-player]")).toHaveCount(state.players.length);
> 82  |   expect(await page.locator("[data-result-player]").evaluateAll(ns => ns.map(n => n.getAttribute("data-result-player")))).toEqual(standings(state).map(r => r.player));
      |                                                                                                                           ^ Error: expect(received).toEqual(expected) // deep equality
  83  |   for (const player of state.players) {
  84  |     const countries = Object.values(state.ownerOf).filter(id => id === player.id).length;
  85  |     const row = page.locator(`[data-result-player="${player.id}"]`);
  86  |     await expect(row).toContainText(player.name);
  87  |     await expect(row.locator("[data-result-countries]")).toHaveText(String(countries));
  88  |     await expect(row.locator("[data-result-armies]")).toHaveText(String(standings(state).find(r => r.player === player.id)!.armies));
  89  |   }
  90  |   await stale!.evaluate(n => n.dispatchEvent(new MouseEvent("click", { bubbles: true })));
  91  |   await freeze(page, state); await fit(page); await capture(page, "domination", info.project.name);
  92  |   await page.locator("#new-game-button").click();
  93  |   await expect(page.getByRole("heading", { name: "New reference game", exact: true })).toBeVisible();
  94  |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  95  |   await expect(page.locator("#victory-reason")).toHaveCount(0);
  96  |   expect(errors).toEqual([]);
  97  |   console.log(JSON.stringify({ kind: fixture.kind, actions: fixture.actions.length, winner: state.winner }));
  98  | });
  99  | 
  100 | test("round limit finishes after a complete rotated round and explains the score", async ({ page }, info) => {
  101 |   test.setTimeout(240000);
  102 |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  103 |   let state = opening(1994, 2, { dominationWin: false, roundLimit: 20 });
  104 |   const fixture = { start: state, state, actions: [] as CompleteAction[], conqueror: "", kind: "human-loss" as const };
  105 |   await setup(page, fixture);
  106 |   // Change settings through the real setup; no loaded or injected position.
  107 |   await page.locator("#new-game-button").click();
  108 |   const limit = page.getByLabel("Round limit", { exact: true });
  109 |   if (await limit.count()) await limit.selectOption("20");
  110 |   await page.getByRole("button", { name: "Start game", exact: true }).click();
  111 |   const origin = state.currentPlayer;
  112 |   for (let turn = 0; turn < 40; turn++) {
  113 |     expect(state.currentPlayer).toBe((origin + turn) % 2);
  114 |     await expect(page.locator(".turn-sub")).toContainText(`Round ${1 + Math.floor(turn / 2)}`);
  115 |     while (state.phase === "reinforce") {
  116 |       const own = state.map.provinces.find(p => state.ownerOf[p.id] === state.players[state.currentPlayer]!.id)!;
  117 |       const action: CompleteAction = state.reinforcementPool ? { kind: "reinforce", province: own.id, amount: 1 } : { kind: "endReinforcement" };
  118 |       await clickAction(page, action); state = act(state, action);
  119 |     }
  120 |     await clickAction(page, { kind: "endTurn" }); state = act(state, { kind: "endTurn" });
  121 |   }
  122 |   await expect(page.locator("#victory-reason")).toContainText(/round.*limit/i);
  123 |   await expect(page.locator("#victory-reason")).toContainText(/arm|order|countr/i);
  124 |   await paint(page, state); await freeze(page, state); await fit(page);
  125 |   await capture(page, "round-limit", info.project.name);
  126 |   expect(errors).toEqual([]);
  127 | });
  128 | 
  129 | test("human loss offers Stop or Watch; Watch resumes computers and Stop freezes", async ({ page }, info) => {
  130 |   test.setTimeout(300000);
  131 |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  132 |   const fixture = plan("human-loss");
  133 |   await setup(page, fixture);
  134 |   let state = await drive(page, fixture);
  135 |   await expect(page.locator("#victory-reason")).toContainText(/human.*eliminat|no human/i);
  136 |   await expect(page.locator("#watch-computers-button")).toBeVisible();
  137 |   await expect(page.locator("#stop-game-button")).toBeVisible();
  138 |   await freeze(page, state); await fit(page); await capture(page, "human-loss", info.project.name);
  139 |   const staleStop = await page.locator("#stop-game-button").elementHandle();
  140 |   await page.locator("#watch-computers-button").click(); state = act(state, { kind: "watchComputers" });
  141 |   await staleStop!.evaluate(n => n.dispatchEvent(new MouseEvent("click", { bubbles: true })));
  142 |   await paint(page, state);
  143 |   await expect(page.locator("#victory-reason")).toHaveCount(0);
  144 |   await expect(page.locator("#turn-title")).toContainText(state.players[state.currentPlayer]!.name);
  145 |   // Scheduling is T32. Drive actual remaining computer actions through the development UI.
  146 |   let handoffs = 0;
  147 |   for (let n = 0; n < VICTORY_ACTION_BUDGET && handoffs < 3; n++) {
  148 |     const action = fixtureAction(state, "human-loss", "");
  149 |     await clickAction(page, action); state = act(state, action);
  150 |     if (action.kind === "endTurn") { handoffs++; await paint(page, state); }
  151 |   }
  152 |   expect(handoffs).toBe(3);
  153 |   await expect(page.locator("#watch-computers-button")).toHaveCount(0);
  154 |   await capture(page, "watch-resumed", info.project.name);
  155 |   await page.locator("#new-game-button").click();
  156 |   await setup(page, fixture); state = await drive(page, fixture);
  157 |   await page.locator("#stop-game-button").click(); state = act(state, { kind: "stopGame" });
  158 |   await freeze(page, state); await fit(page); await capture(page, "human-loss-stopped", info.project.name);
  159 |   await expect(page.locator("#watch-computers-button")).toHaveCount(0);
  160 |   await page.locator("#new-game-button").click();
  161 |   await expect(page.getByRole("heading", { name: "New reference game", exact: true })).toBeVisible();
  162 |   expect(errors).toEqual([]);
  163 |   console.log(JSON.stringify({ kind: fixture.kind, actionsPerRun: fixture.actions.length, resumedHandoffs: handoffs }));
  164 | });
  165 | 
```