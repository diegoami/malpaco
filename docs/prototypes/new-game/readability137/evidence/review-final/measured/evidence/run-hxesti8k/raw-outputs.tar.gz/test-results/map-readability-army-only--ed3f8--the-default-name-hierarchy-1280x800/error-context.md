# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: map-readability.spec.ts >> army-only labels and ownership shapes reduce the default name hierarchy
- Location: tests/e2e/map-readability.spec.ts:11:1

# Error details

```
Error: expect(received).toContain(expected) // indexOf

Expected substring: "Seat 3, 2 armies"
Received string:    "province_4"
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 4 human seats · Seed 1994
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]: 11 provinces · 22 armies
      - generic [ref=e16]:
        - generic [ref=e17]: Seat 2
        - generic [ref=e18]: 12 provinces · 24 armies
      - generic [ref=e22]:
        - generic [ref=e23]: Seat 3
        - generic [ref=e24]: 12 provinces · 24 armies
      - generic [ref=e28]:
        - generic [ref=e29]: Seat 4
        - generic [ref=e30]: 11 provinces · 22 armies
    - contentinfo [ref=e31]:
      - button "New game" [ref=e32] [cursor=pointer]
    - generic [ref=e33]:
      - button "Save game" [ref=e34] [cursor=pointer]
      - generic [ref=e35]:
        - generic [ref=e36]: Load game
        - button "Load game" [ref=e37]
  - main [ref=e38]:
    - img "Nine Isles reference map" [ref=e40]:
      - button "province_4" [ref=e65] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: "2"
      - button "province_30" [ref=e67] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: "2"
      - button "province_8" [ref=e69] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: "1"
      - button "province_38" [ref=e71] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: "1"
      - button "province_28" [ref=e73] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: "1"
      - button "province_45" [ref=e75] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: "1"
      - button "province_41" [ref=e77] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: "1"
      - button "province_2" [ref=e79] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: "3"
      - button "province_16" [ref=e81] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: "2"
      - button "province_11" [ref=e83] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: "3"
      - button "province_31" [ref=e85] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: "2"
      - button "province_22" [ref=e87] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: "2"
      - button "province_9" [ref=e89] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: "3"
      - button "province_19" [ref=e91] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: "1"
      - button "province_1" [ref=e93] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: "3"
      - button "province_3" [ref=e95] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: "2"
      - button "province_40" [ref=e97] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: "3"
      - button "province_24" [ref=e99] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: "2"
      - button "province_17" [ref=e101] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: "2"
      - button "province_29" [ref=e103] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: "3"
      - button "province_33" [ref=e105] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: "2"
      - button "province_13" [ref=e107] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: "3"
      - button "province_0" [ref=e109] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: "2"
      - button "province_10" [ref=e111] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: "1"
      - button "province_12" [ref=e113] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: "1"
      - button "province_20" [ref=e115] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: "1"
      - button "province_36" [ref=e117] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: "1"
      - button "province_25" [ref=e119] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: "3"
      - button "province_5" [ref=e121] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: "2"
        - generic [ref=e123]: ★
      - button "province_27" [ref=e124] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: "2"
      - button "province_37" [ref=e126] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: "2"
      - button "province_43" [ref=e128] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: "1"
      - button "province_6" [ref=e130] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: "2"
      - button "province_42" [ref=e132] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: "2"
      - button "province_32" [ref=e134] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: "1"
      - button "province_18" [ref=e136] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: "2"
        - generic [ref=e138]: ★
      - button "province_34" [ref=e139] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: "3"
        - generic [ref=e141]: ★
      - button "province_26" [ref=e142] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: "2"
      - button "province_7" [ref=e144] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: "1"
      - button "province_35" [ref=e146] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: "3"
      - button "province_44" [ref=e148] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: "3"
      - button "province_39" [ref=e150] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: "1"
      - button "province_14" [ref=e152] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: "3"
      - button "province_21" [ref=e154] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: "2"
      - button "province_15" [ref=e156] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: "3"
      - button "province_23" [ref=e158] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: "3"
      - generic [ref=e190]: North Isle +3
      - generic [ref=e191]: East Isle +3
      - generic [ref=e192]: West Isle +3
      - generic [ref=e193]: South Isle +3
      - generic [ref=e194]: Central Isle +5
      - generic [ref=e195]: Harbor Isle +5
      - generic [ref=e196]: Palm Isle +6
      - generic [ref=e197]: Cliff Isle +5
      - generic [ref=e198]: Great Isle +9
    - complementary [ref=e199]:
      - generic [ref=e203]:
        - generic [ref=e204]: Seat 4's turn
        - generic [ref=e205]: Round 1 · Reinforcement
      - generic [ref=e206]:
        - generic [ref=e207]:
          - generic [ref=e208]:
            - generic [ref=e209]: Province income
            - strong [ref=e210]: "3"
          - generic [ref=e211]:
            - generic [ref=e212]: Island income
            - strong [ref=e213]: "0"
          - generic [ref=e214]:
            - generic [ref=e215]: Armies to place
            - strong [ref=e216]: "3"
        - paragraph [ref=e217]: Place your armies on your countries, then start combat.
        - generic [ref=e218]:
          - button "Start combat" [disabled] [ref=e219]
          - button "End turn" [disabled] [ref=e220]
      - generic [ref=e221]:
        - heading "Battle log" [level=3] [ref=e222]
        - list "Battle log"
```

# Test source

```ts
  1  | import {test,expect} from "@playwright/test";
  2  | import type {Page} from "@playwright/test";
  3  | import {mkdirSync} from "node:fs";
  4  | import {join} from "node:path";
  5  | import {pinned} from "../core/versioned-match-fixture";
  6  | import {seatLook} from "../../src/ui/palette";
  7  | const country=(p:Page,id:string)=>p.locator(`[data-country="${id}"]`);
  8  | const output=process.env["READABILITY_EVIDENCE_DIR"]??"screenshots";
  9  | async function shot(page:Page,name:string,project:string){mkdirSync(output,{recursive:true});await page.mouse.move(0,0);await page.screenshot({path:join(output,`${name}-${project}.png`)});}
  10 | async function opening(page:Page){await page.goto("/?control=manual");await page.getByLabel("Seed",{exact:true}).fill("1994");await page.getByLabel("Seats",{exact:true}).selectOption("4");await page.getByRole("button",{name:"Start game",exact:true}).click();await expect(page.locator("[data-country]")).toHaveCount(46);}
  11 | test("army-only labels and ownership shapes reduce the default name hierarchy",async({page},info)=>{
  12 |  await opening(page);await shot(page,"opening",info.project.name);
  13 |  const rows=await page.locator("[data-country]").evaluateAll(ns=>ns.map(n=>{
  14 |   const count=n.querySelector(".army-count")!,name=n.querySelector(".name")!,badge=n.querySelector(".badge")!;
  15 |   return {army:n.getAttribute("data-armies"),owner:n.getAttribute("data-owner"),label:n.getAttribute("aria-label"),text:count.textContent,nameSize:parseFloat(getComputedStyle(name).fontSize),countSize:parseFloat(getComputedStyle(count).fontSize),nameWeight:Number(getComputedStyle(name).fontWeight),countWeight:Number(getComputedStyle(count).fontWeight),nameVisible:getComputedStyle(name).visibility!=="hidden"&&getComputedStyle(name).display!=="none",shape:badge.getAttribute("d")};
  16 |  }));
  17 |  const owners=[...new Set(rows.map(r=>r.owner))];expect(owners).toHaveLength(4);
  18 |  const players=await page.locator("[data-player]").evaluateAll(ns=>ns.map(n=>n.getAttribute("data-player")));
> 19 |  for(const r of rows){expect(r.text).toBe(r.army);expect(r.label).toContain(`Seat ${players.indexOf(r.owner)+1}, ${r.army} armies`);expect(r.nameSize).toBeLessThanOrEqual(r.countSize*.7);expect(r.nameWeight).toBeLessThan(r.countWeight);expect(r.nameVisible).toBe(true);expect(r.shape).toBe(seatLook(players.indexOf(r.owner)).badge);}
     |                                                                   ^ Error: expect(received).toContain(expected) // indexOf
  20 |  expect(new Set(rows.map(r=>r.shape)).size).toBe(4);
  21 | });
  22 | test("region names remain identifiable on mouse, keyboard and touch without changing inputs",async({page,browser},info)=>{
  23 |  await opening(page);
  24 |  const first=page.locator("[data-country]").first();const normal=await first.locator(".name").first().evaluate(n=>parseFloat(getComputedStyle(n).fontSize));
  25 |  await first.hover();expect(await first.locator(".name").first().evaluate(n=>parseFloat(getComputedStyle(n).fontSize))).toBeGreaterThan(normal);
  26 |  await page.mouse.move(0,0);await first.focus();expect(await first.locator(".name").first().evaluate(n=>parseFloat(getComputedStyle(n).fontSize))).toBeGreaterThan(normal);
  27 |  await page.keyboard.press("ArrowRight");await expect(page.locator("[data-country]").nth(1)).toBeFocused();
  28 |  const active=await page.locator(".topbar .score-row.active").getAttribute("data-player");
  29 |  const source=page.locator(`[data-country][data-owner="${active}"]`).first();
  30 |  while(Number(await page.locator("#reinforcement-pool").textContent())>0)await source.click();
  31 |  await page.locator("#start-combat-button").click();await source.click();await expect(source).toHaveAttribute("aria-pressed","true");
  32 |  const sourceName=(await source.getAttribute("aria-label"))!.split(",")[0]!;await expect(page.locator("#battle-source-name")).toHaveText(sourceName);
  33 |  expect(await source.locator(".name").first().evaluate(n=>parseFloat(getComputedStyle(n).fontSize))).toBeGreaterThan(normal);await shot(page,"selected",info.project.name);
  34 |  const save=pinned("round-limit");await page.getByLabel("Load game",{exact:true}).setInputFiles({name:"round-limit.json",mimeType:"application/json",buffer:Buffer.from(save.text)});
  35 |  await expect(page.locator("#victory-reason")).toBeVisible();
  36 |  const armies=save.expected["armies"] as Record<string,number>,id=Object.keys(armies).find(id=>armies[id]===143)!;expect(id).toBeTruthy();
  37 |  await expect(country(page,id).locator(".army-count")).toHaveText("143");
  38 |  const fit=await country(page,id).evaluate(n=>{const c=(n.querySelector(".count")! as SVGGraphicsElement).getBoundingClientRect(),b=(n.querySelector(".badge")! as SVGGraphicsElement).getBoundingClientRect();return {ok:c.left>=b.left&&c.right<=b.right&&c.top>=b.top&&c.bottom<=b.bottom,count:c.toJSON(),badge:b.toJSON()};});expect(fit.ok,JSON.stringify(fit)).toBe(true);
  39 |  await shot(page,"large-stack",info.project.name);
  40 |  const context=await browser.newContext({viewport:page.viewportSize()!,hasTouch:true});const touch=await context.newPage();
  41 |  try{await opening(touch);const node=touch.locator("[data-country]").first();const label=await node.getAttribute("aria-label");const box=await node.boundingBox();expect(box).not.toBeNull();await touch.touchscreen.tap(box!.x+box!.width/2,box!.y+box!.height/2);await expect(node).toHaveAttribute("aria-label",/Seat \d, \d+ armies/);expect(label).toBeTruthy();await expect(node.locator(".name").first()).toBeVisible();await shot(touch,"touch",info.project.name);}finally{await context.close();}
  42 | });
  43 | 
```