# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: map-readability.spec.ts >> region names remain identifiable on mouse, keyboard and touch without changing inputs
- Location: tests/e2e/map-readability.spec.ts:22:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  locator('#battle-source-name')
Expected: "province_31"
Received: "New glen"
Timeout:  5000ms

Call log:
  - Expect "toHaveText" locator('#battle-source-name') with timeout 5000ms
  - waiting for locator('#battle-source-name')
    14 × locator resolved to <strong id="battle-source-name">New glen</strong>
       - unexpected value "New glen"

```

```yaml
- strong: New glen
```

# Test source

```ts
  1  | import {test,expect} from "@playwright/test";
  2  | import type {Page} from "@playwright/test";
  3  | import {mkdirSync} from "node:fs";
  4  | import {join} from "node:path";
  5  | import {pinned} from "../core/versioned-match-fixture";
  6  | import {seatLook} from "../../src/ui/palette";
  7  | const country=(p:Page,id:string)=>p.locator(`[data-country="${id}"]`);
  8  | const output=process.env["READABILITY_EVIDENCE_DIR"]??"screenshots";
  9  | async function shot(page:Page,name:string,project:string){mkdirSync(output,{recursive:true});await page.mouse.move(0,0);await page.screenshot({path:join(output,`${name}-${project}.png`)});}
  10 | async function opening(page:Page){await page.goto("/?control=manual");await page.getByLabel("Seed",{exact:true}).fill("1994");await page.getByLabel("Seats",{exact:true}).selectOption("4");await page.getByRole("button",{name:"Start game",exact:true}).click();await expect(page.locator("[data-country]")).toHaveCount(46);}
  11 | test("army-only labels and ownership shapes reduce the default name hierarchy",async({page},info)=>{
  12 |  await opening(page);await shot(page,"opening",info.project.name);
  13 |  const rows=await page.locator("[data-country]").evaluateAll(ns=>ns.map(n=>{
  14 |   const count=n.querySelector(".army-count")!,name=n.querySelector(".name")!,badge=n.querySelector(".badge")!;
  15 |   return {army:n.getAttribute("data-armies"),owner:n.getAttribute("data-owner"),label:n.getAttribute("aria-label"),text:count.textContent,nameSize:parseFloat(getComputedStyle(name).fontSize),countSize:parseFloat(getComputedStyle(count).fontSize),nameWeight:Number(getComputedStyle(name).fontWeight),countWeight:Number(getComputedStyle(count).fontWeight),nameVisible:getComputedStyle(name).visibility!=="hidden"&&getComputedStyle(name).display!=="none",shape:badge.getAttribute("d")};
  16 |  }));
  17 |  const owners=[...new Set(rows.map(r=>r.owner))];expect(owners).toHaveLength(4);
  18 |  const players=await page.locator("[data-player]").evaluateAll(ns=>ns.map(n=>n.getAttribute("data-player")));
  19 |  for(const r of rows){expect(r.text).toBe(r.army);expect(r.label).toContain(`Seat ${players.indexOf(r.owner)+1}, ${r.army} armies`);expect(r.nameSize).toBeLessThanOrEqual(r.countSize*.7);expect(r.nameWeight).toBeLessThan(r.countWeight);expect(r.nameVisible).toBe(true);expect(r.shape).toBe(seatLook(players.indexOf(r.owner)).badge);}
  20 |  expect(new Set(rows.map(r=>r.shape)).size).toBe(4);
  21 | });
  22 | test("region names remain identifiable on mouse, keyboard and touch without changing inputs",async({page,browser},info)=>{
  23 |  await opening(page);
  24 |  const first=page.locator("[data-country]").first();const normal=await first.locator(".name").first().evaluate(n=>parseFloat(getComputedStyle(n).fontSize));
  25 |  await first.hover();expect(await first.locator(".name").first().evaluate(n=>parseFloat(getComputedStyle(n).fontSize))).toBeGreaterThan(normal);
  26 |  await page.mouse.move(0,0);await first.focus();expect(await first.locator(".name").first().evaluate(n=>parseFloat(getComputedStyle(n).fontSize))).toBeGreaterThan(normal);
  27 |  await page.keyboard.press("ArrowRight");await expect(page.locator("[data-country]").nth(1)).toBeFocused();
  28 |  const active=await page.locator(".topbar .score-row.active").getAttribute("data-player");
  29 |  const source=page.locator(`[data-country][data-owner="${active}"]`).first();
  30 |  while(Number(await page.locator("#reinforcement-pool").textContent())>0)await source.click();
  31 |  await page.locator("#start-combat-button").click();await source.click();await expect(source).toHaveAttribute("aria-pressed","true");
> 32 |  const sourceName=(await source.getAttribute("aria-label"))!.split(",")[0]!;await expect(page.locator("#battle-source-name")).toHaveText(sourceName);
     |                                                                                                                               ^ Error: expect(locator).toHaveText(expected) failed
  33 |  expect(await source.locator(".name").first().evaluate(n=>parseFloat(getComputedStyle(n).fontSize))).toBeGreaterThan(normal);await shot(page,"selected",info.project.name);
  34 |  const save=pinned("round-limit");await page.getByLabel("Load game",{exact:true}).setInputFiles({name:"round-limit.json",mimeType:"application/json",buffer:Buffer.from(save.text)});
  35 |  await expect(page.locator("#victory-reason")).toBeVisible();
  36 |  const armies=save.expected["armies"] as Record<string,number>,id=Object.keys(armies).find(id=>armies[id]===143)!;expect(id).toBeTruthy();
  37 |  await expect(country(page,id).locator(".army-count")).toHaveText("143");
  38 |  const fit=await country(page,id).evaluate(n=>{const c=(n.querySelector(".count")! as SVGGraphicsElement).getBoundingClientRect(),b=(n.querySelector(".badge")! as SVGGraphicsElement).getBoundingClientRect();return {ok:c.left>=b.left&&c.right<=b.right&&c.top>=b.top&&c.bottom<=b.bottom,count:c.toJSON(),badge:b.toJSON()};});expect(fit.ok,JSON.stringify(fit)).toBe(true);
  39 |  await shot(page,"large-stack",info.project.name);
  40 |  const context=await browser.newContext({viewport:page.viewportSize()!,hasTouch:true});const touch=await context.newPage();
  41 |  try{await opening(touch);const node=touch.locator("[data-country]").first();const label=await node.getAttribute("aria-label");const box=await node.boundingBox();expect(box).not.toBeNull();await touch.touchscreen.tap(box!.x+box!.width/2,box!.y+box!.height/2);await expect(node).toHaveAttribute("aria-label",/Seat \d, \d+ armies/);expect(label).toBeTruthy();await expect(node.locator(".name").first()).toBeVisible();await shot(touch,"touch",info.project.name);}finally{await context.close();}
  42 | });
  43 | 
```