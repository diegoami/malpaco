# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: map-readability.spec.ts >> region names remain identifiable on mouse, keyboard and touch without changing inputs
- Location: tests/e2e/map-readability.spec.ts:22:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 2 human seats · Seed 1994
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]: 23 provinces · 186 armies
      - generic [ref=e16]:
        - generic [ref=e17]: Seat 2
        - generic [ref=e18]: 23 provinces · 186 armies
    - contentinfo [ref=e19]:
      - button "New game" [ref=e20] [cursor=pointer]
    - generic [ref=e21]:
      - button "Save game" [ref=e22] [cursor=pointer]
      - generic [ref=e23]:
        - generic [ref=e24]: Load game
        - button "Load game" [ref=e25]
  - main [ref=e26]:
    - img "Nine Isles reference map" [ref=e28]:
      - button "River gate, Seat 1, 143 armies, Seat 1" [ref=e53] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: "143"
      - button "New port, Seat 2, 141 armies, Seat 2" [ref=e55] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: "141"
      - button "North rest, Seat 1, 1 armies, Seat 1" [ref=e57] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: "1"
      - button "River keep, Seat 2, 2 armies, Seat 2" [ref=e59] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: "2"
      - button "North town, Seat 1, 2 armies, Seat 1" [ref=e61] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: "2"
      - button "Dark ford, Seat 2, 1 armies, Seat 2" [ref=e63] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: "1"
      - button "Iron point, Seat 1, 3 armies, Seat 1" [ref=e65] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: "3"
      - button "South rest, Seat 2, 2 armies, Seat 2" [ref=e67] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: "2"
      - button "High shore, Seat 1, 1 armies, Seat 1" [ref=e69] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: "1"
      - button "Wind town, Seat 1, 2 armies, Seat 1" [ref=e71] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: "2"
      - button "New glen, Seat 2, 1 armies, Seat 2" [ref=e73] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: "1"
      - button "Old rock, Seat 1, 1 armies, Seat 1" [ref=e75] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: "1"
      - button "Blue peak, Seat 1, 3 armies, Seat 1" [ref=e77] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: "3"
      - button "West haven, Seat 1, 2 armies, Seat 1" [ref=e79] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: "2"
      - button "Stone watch, Seat 1, 3 armies, Seat 1" [ref=e81] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: "3"
      - button "Upper ridge, Seat 2, 2 armies, Seat 2" [ref=e83] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: "2"
      - button "Marsh keep, Seat 2, 3 armies, Seat 2" [ref=e85] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: "3"
      - button "New fell, Seat 2, 3 armies, Seat 2" [ref=e87] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: "3"
      - button "Moon point, Seat 1, 2 armies, Seat 1" [ref=e89] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: "2"
      - button "South fell, Seat 2, 2 armies, Seat 2" [ref=e91] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: "2"
      - button "High ridge, Seat 1, 2 armies, Seat 1" [ref=e93] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: "2"
      - button "Bay ford, Seat 1, 2 armies, Seat 1" [ref=e95] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: "2"
      - button "Low moor, Seat 2, 2 armies, Seat 2" [ref=e97] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: "2"
      - button "Lower field, Seat 2, 2 armies, Seat 2" [ref=e99] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: "2"
      - button "Wind gate, Seat 1, 2 armies, Seat 1" [ref=e101] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: "2"
      - button "Silver shore, Seat 2, 1 armies, Seat 2" [ref=e103] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: "1"
      - button "Low peak, Seat 1, 2 armies, Seat 1" [ref=e105] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: "2"
      - button "Wind port, Seat 2, 3 armies, Seat 2" [ref=e107] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: "3"
      - button "Gold point, Seat 1, 3 armies, Seat 1" [ref=e109] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: "3"
        - generic [ref=e111]: ★
      - button "Rock moor, Seat 2, 3 armies, Seat 2" [ref=e112] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: "3"
      - button "Marsh rest, Seat 1, 2 armies, Seat 1" [ref=e114] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: "2"
      - button "Wind dale, Seat 2, 2 armies, Seat 2" [ref=e116] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: "2"
      - button "Silver ford, Seat 2, 3 armies, Seat 2" [ref=e118] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: "3"
      - button "Iron field, Seat 2, 1 armies, Seat 2" [ref=e120] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: "1"
      - button "North wood, Seat 2, 2 armies, Seat 2" [ref=e122] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: "2"
      - button "Fort town, Seat 1, 1 armies, Seat 1" [ref=e124] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: "1"
        - generic [ref=e126]: ★
      - button "Red field, Seat 1, 2 armies, Seat 1" [ref=e127] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: "2"
        - generic [ref=e129]: ★
      - button "South ridge, Seat 2, 2 armies, Seat 2" [ref=e130] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: "2"
      - button "Rock bay, Seat 1, 1 armies, Seat 1" [ref=e132] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: "1"
      - button "North ford, Seat 2, 2 armies, Seat 2" [ref=e134] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: "2"
      - button "Port ridge, Seat 1, 3 armies, Seat 1" [ref=e136] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: "3"
      - button "New rock, Seat 2, 2 armies, Seat 2" [ref=e138] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: "2"
      - button "South reach, Seat 1, 1 armies, Seat 1" [ref=e140] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: "1"
      - button "Silver point, Seat 1, 2 armies, Seat 1" [ref=e142] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: "2"
      - button "East ford, Seat 2, 2 armies, Seat 2" [ref=e144] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: "2"
      - button "Gold town, Seat 2, 2 armies, Seat 2" [ref=e146] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: "2"
      - generic [ref=e178]: North Isle +3
      - generic [ref=e179]: East Isle +3
      - generic [ref=e180]: West Isle +3
      - generic [ref=e181]: South Isle +3
      - generic [ref=e182]: Central Isle +5
      - generic [ref=e183]: Harbor Isle +5
      - generic [ref=e184]: Palm Isle +6
      - generic [ref=e185]: Cliff Isle +5
      - generic [ref=e186]: Great Isle +9
    - complementary [ref=e187]:
      - generic [ref=e191]:
        - generic [ref=e192]: Seat 1 wins
        - generic [ref=e193]: The game is over. Choose New game to play again.
      - region "Game result" [ref=e195]:
        - heading "Final standings" [level=2] [ref=e196]
        - paragraph [ref=e197]: Round limit reached after 20 rounds. Ranked by countries, then armies, then later turn order.
        - table [ref=e198]:
          - caption [ref=e199]: Countries and armies at turn end
          - rowgroup [ref=e200]:
            - row [ref=e201]:
              - columnheader "Seat" [ref=e202]
              - columnheader "Countries" [ref=e203]
              - columnheader "Armies" [ref=e204]
          - rowgroup [ref=e205]:
            - row [ref=e206]:
              - rowheader "Seat 1" [ref=e207]
              - cell "23" [ref=e208]
              - cell "186" [ref=e209]
            - row [ref=e210]:
              - rowheader "Seat 2" [ref=e211]
              - cell "23" [ref=e212]
              - cell "186" [ref=e213]
        - paragraph [ref=e214]: Choose New game to play again.
      - generic [ref=e215]:
        - heading "Battle log" [level=3] [ref=e216]
        - list "Battle log" [ref=e217]:
          - listitem [ref=e218]: Seat 1 wins
          - listitem [ref=e219]: T20 Seat 1 ends the turn
          - listitem [ref=e220]: T20 Seat 2 ends the turn
          - listitem [ref=e221]: T19 Seat 1 ends the turn
          - listitem [ref=e222]: T19 Seat 2 ends the turn
          - listitem [ref=e223]: T18 Seat 1 ends the turn
          - listitem [ref=e224]: T18 Seat 2 ends the turn
```

# Test source

```ts
  1  | import {test,expect} from "@playwright/test";
  2  | import type {Page} from "@playwright/test";
  3  | import {mkdirSync} from "node:fs";
  4  | import {join} from "node:path";
  5  | import {pinned} from "../core/versioned-match-fixture";
  6  | import {seatLook} from "../../src/ui/palette";
  7  | const country=(p:Page,id:string)=>p.locator(`[data-country="${id}"]`);
  8  | const output=process.env["READABILITY_EVIDENCE_DIR"]??"screenshots";
  9  | async function shot(page:Page,name:string,project:string){mkdirSync(output,{recursive:true});await page.mouse.move(0,0);await page.screenshot({path:join(output,`${name}-${project}.png`)});}
  10 | async function opening(page:Page){await page.goto("/?control=manual");await page.getByLabel("Seed",{exact:true}).fill("1994");await page.getByLabel("Seats",{exact:true}).selectOption("4");await page.getByRole("button",{name:"Start game",exact:true}).click();await expect(page.locator("[data-country]")).toHaveCount(46);}
  11 | test("army-only labels and ownership shapes reduce the default name hierarchy",async({page},info)=>{
  12 |  await opening(page);await shot(page,"opening",info.project.name);
  13 |  const rows=await page.locator("[data-country]").evaluateAll(ns=>ns.map(n=>{
  14 |   const count=n.querySelector(".army-count")!,name=n.querySelector(".name")!,badge=n.querySelector(".badge")!;
  15 |   return {army:n.getAttribute("data-armies"),owner:n.getAttribute("data-owner"),label:n.getAttribute("aria-label"),text:count.textContent,nameSize:parseFloat(getComputedStyle(name).fontSize),countSize:parseFloat(getComputedStyle(count).fontSize),nameWeight:Number(getComputedStyle(name).fontWeight),countWeight:Number(getComputedStyle(count).fontWeight),nameVisible:getComputedStyle(name).visibility!=="hidden"&&getComputedStyle(name).display!=="none",shape:badge.getAttribute("d")};
  16 |  }));
  17 |  const owners=[...new Set(rows.map(r=>r.owner))];expect(owners).toHaveLength(4);
  18 |  const players=await page.locator("[data-player]").evaluateAll(ns=>ns.map(n=>n.getAttribute("data-player")));
  19 |  for(const r of rows){expect(r.text).toBe(r.army);expect(r.label).toContain(`Seat ${players.indexOf(r.owner)+1}, ${r.army} armies`);expect(r.nameSize).toBeLessThanOrEqual(r.countSize*.7);expect(r.nameWeight).toBeLessThan(r.countWeight);expect(r.nameVisible).toBe(true);expect(r.shape).toBe(seatLook(players.indexOf(r.owner)).badge);}
  20 |  expect(new Set(rows.map(r=>r.shape)).size).toBe(4);
  21 | });
  22 | test("region names remain identifiable on mouse, keyboard and touch without changing inputs",async({page,browser},info)=>{
  23 |  await opening(page);
  24 |  const first=page.locator("[data-country]").first();const normal=await first.locator(".name").first().evaluate(n=>parseFloat(getComputedStyle(n).fontSize));
  25 |  await first.hover();expect(await first.locator(".name").first().evaluate(n=>parseFloat(getComputedStyle(n).fontSize))).toBeGreaterThan(normal);
  26 |  await page.mouse.move(0,0);await first.focus();expect(await first.locator(".name").first().evaluate(n=>parseFloat(getComputedStyle(n).fontSize))).toBeGreaterThan(normal);
  27 |  await page.keyboard.press("ArrowRight");await expect(page.locator("[data-country]").nth(1)).toBeFocused();
  28 |  const active=await page.locator(".topbar .score-row.active").getAttribute("data-player");
  29 |  const source=page.locator(`[data-country][data-owner="${active}"]`).first();
  30 |  while(Number(await page.locator("#reinforcement-pool").textContent())>0)await source.click();
  31 |  await page.locator("#start-combat-button").click();await source.click();await expect(source).toHaveAttribute("aria-pressed","true");
  32 |  const sourceName=(await source.getAttribute("aria-label"))!.split(",")[0]!;await expect(page.locator("#battle-source-name")).toHaveText(sourceName);
  33 |  expect(await source.locator(".name").first().evaluate(n=>parseFloat(getComputedStyle(n).fontSize))).toBeGreaterThan(normal);await shot(page,"selected",info.project.name);
  34 |  const save=pinned("round-limit");await page.getByLabel("Load game",{exact:true}).setInputFiles({name:"round-limit.json",mimeType:"application/json",buffer:Buffer.from(save.text)});
  35 |  await expect(page.locator("#victory-reason")).toBeVisible();
  36 |  const armies=save.expected["armies"] as Record<string,number>,id=Object.keys(armies).find(id=>armies[id]===143)!;expect(id).toBeTruthy();
  37 |  await expect(country(page,id).locator(".army-count")).toHaveText("143");
> 38 |  const fit=await country(page,id).evaluate(n=>{const c=(n.querySelector(".count")! as SVGGraphicsElement).getBoundingClientRect(),b=(n.querySelector(".badge")! as SVGGraphicsElement).getBoundingClientRect();return c.left>=b.left&&c.right<=b.right&&c.top>=b.top&&c.bottom<=b.bottom;});expect(fit).toBe(true);
     |                                                                                                                                                                                                                                                                                                         ^ Error: expect(received).toBe(expected) // Object.is equality
  39 |  await shot(page,"large-stack",info.project.name);
  40 |  const context=await browser.newContext({viewport:page.viewportSize()!,hasTouch:true});const touch=await context.newPage();
  41 |  try{await opening(touch);const node=touch.locator("[data-country]").first();const label=await node.getAttribute("aria-label");const box=await node.boundingBox();expect(box).not.toBeNull();await touch.touchscreen.tap(box!.x+box!.width/2,box!.y+box!.height/2);await expect(node).toHaveAttribute("aria-label",/Seat \d, \d+ armies/);expect(label).toBeTruthy();await expect(node.locator(".name").first()).toBeVisible();await shot(touch,"touch",info.project.name);}finally{await context.close();}
  42 | });
  43 | 
```