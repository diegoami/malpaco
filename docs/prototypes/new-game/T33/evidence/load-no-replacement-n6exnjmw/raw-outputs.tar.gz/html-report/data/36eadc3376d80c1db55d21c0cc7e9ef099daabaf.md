# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: reference-complete-game.spec.ts >> real human/computer setup, friendly move, pending save/resume, elimination and conquest
- Location: tests/e2e/reference-complete-game.spec.ts:26:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator: locator('#capture-amount')
Expected: "12"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toHaveAttribute" locator('#capture-amount') with timeout 5000ms
  - waiting for locator('#capture-amount')

```

```yaml
- heading "New reference game" [level=1]
- paragraph: Play on Nine Isles against three Normal computers, or choose each seat’s controller. The seed changes the deal.
- text: Seed
- spinbutton "Seed": "1994"
- text: Seats
- combobox "Seats":
  - option "2"
  - option "3"
  - option "4" [selected]
- text: Seat 1 control
- combobox "Seat 1 control":
  - option "Human" [selected]
  - option "Computer"
- text: Seat 2 control
- combobox "Seat 2 control":
  - option "Human"
  - option "Computer" [selected]
- text: Seat 3 control
- combobox "Seat 3 control":
  - option "Human"
  - option "Computer" [selected]
- text: Seat 4 control
- combobox "Seat 4 control":
  - option "Human"
  - option "Computer" [selected]
- checkbox "Domination win" [checked]
- text: Domination win Round limit
- combobox "Round limit":
  - option "Off" [selected]
  - option "20 rounds"
  - option "30 rounds"
  - option "40 rounds"
- button "Start game"
- alert
- text: Load game
- button "Load game"
```

# Test source

```ts
  1  | import { expect, test } from "@playwright/test";
  2  | import type { Page } from "@playwright/test";
  3  | import { readFileSync, writeFileSync, mkdirSync, mkdtempSync } from "node:fs";
  4  | import { join } from "node:path";
  5  | import { activePlayer, apply, victoryRules } from "../../src/core";
  6  | import type { Action, GameOptions, GameState } from "../../src/core";
  7  | import { createReferenceGame } from "../../src/core/reference-game";
  8  | import { referenceMap } from "../../src/core/reference-map";
  9  | import { deserializeVersionedMatch } from "../../src/core/match-save";
  10 | 
  11 | const fixture = JSON.parse(readFileSync(new URL("../../docs/prototypes/new-game/T33/fixtures/conquest.json", import.meta.url), "utf8")) as {
  12 |   options: GameOptions; actions: Action[]; expected: { actions: number; computerActions: number; humanActions: number; winner: string };
  13 | };
  14 | const country = (page: Page, id: string) => page.locator(`[data-country="${id}"]`);
  15 | function step(state: GameState, action: Action) {
  16 |   const result = apply(state, action); if (!result.ok) throw Error(JSON.stringify(action) + ": " + result.error); return result.state;
  17 | }
  18 | async function save(page: Page) {
  19 |   const event = page.waitForEvent("download"); await page.getByRole("button", {name: "Save game", exact: true}).click();
  20 |   return readFileSync((await (await event).path())!, "utf8");
  21 | }
  22 | async function paint(page: Page, state: GameState) {
  23 |   expect(await page.locator("[data-country]").evaluateAll(nodes => Object.fromEntries(nodes.map(n => [n.getAttribute("data-country"), [n.getAttribute("data-owner"), Number(n.getAttribute("data-armies"))]])))).toEqual(Object.fromEntries(state.map.provinces.map(p => [p.id, [state.ownerOf[p.id], state.armies[p.id]]])));
  24 | }
  25 | 
  26 | test("real human/computer setup, friendly move, pending save/resume, elimination and conquest", async ({page}, info) => {
  27 |   test.setTimeout(240_000);
  28 |   const root = process.env["REFERENCE_COMPLETE_EVIDENCE_DIR"] ?? "screenshots"; mkdirSync(root, {recursive: true});
  29 |   const evidence = mkdtempSync(join(root, `reference-complete-${info.project.name}-`));
  30 |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message)); page.on("console", m => {if (m.type() === "error") errors.push(m.text());});
  31 |   const screenshot = async (name: string) => { await page.mouse.move(0, 0); await page.screenshot({path: join(evidence, name + ".png"), animations: "disabled"}); };
  32 |   await page.clock.install(); await page.clock.pauseAt(new Date("2026-10-17T12:00:00Z"));
  33 |   await page.goto("/");
  34 |   await expect(page.getByLabel("Seat 1 control", {exact: true})).toHaveValue("human");
  35 |   for (let seat = 2; seat <= 4; seat++) await expect(page.getByLabel(`Seat ${seat} control`, {exact: true})).toHaveValue("computer");
  36 |   await page.getByLabel("Seed", {exact: true}).fill(String(fixture.options.seed));
  37 |   await page.getByLabel("Seats", {exact: true}).selectOption("2");
  38 |   await page.getByLabel("Domination win", {exact: true}).uncheck();
  39 |   await page.getByRole("button", {name: "Start game", exact: true}).click();
  40 |   const opening = createReferenceGame(referenceMap, fixture.options, victoryRules(fixture.options)); if (!opening.ok) throw Error(opening.errors.join(";"));
  41 |   let state = opening.state;
  42 |   expect(deserializeVersionedMatch(await save(page)).options).toEqual(fixture.options);
  43 |   await paint(page, state); await screenshot("opening");
  44 |   let index = 0, resumed = false, moved = false, battle = false, computer = false, eliminated = false;
  45 |   const assertSaved = async (name: string) => { const text = await save(page); writeFileSync(join(evidence, name + ".json"), text); expect(deserializeVersionedMatch(text).state).toEqual(state); return text; };
  46 |   while (index < fixture.actions.length) {
  47 |     if (activePlayer(state)!.kind === "computer") {
  48 |       if (!computer) { await expect(page.locator("#reference-computer-status")).toBeVisible(); await expect(page.locator("#end-turn-button")).toBeDisabled(); await screenshot("computer-turn"); computer = true; }
  49 |       let steps = 0;
  50 |       do { state = step(state, fixture.actions[index++]!); steps++; } while (index < fixture.actions.length && activePlayer(state)!.kind === "computer" && state.phase !== "finished");
  51 |       await page.clock.runFor(steps * 350);
  52 |       await paint(page, state); await assertSaved(`handoff-${index}`);
  53 |       continue;
  54 |     }
  55 |     const action = fixture.actions[index++]!;
  56 |     if (action.kind === "reinforce") await country(page, action.province).click();
  57 |     else if (action.kind === "endReinforcement") await page.locator("#start-combat-button").click();
  58 |     else if (action.kind === "endTurn") await page.locator("#end-turn-button").click();
  59 |     else if (action.kind === "attack") {
  60 |       if (await country(page, action.from).getAttribute("aria-pressed") !== "true") await country(page, action.from).click();
  61 |       await country(page, action.to).click(); await page.locator("#single-exchange-button").click();
  62 |       if (!battle) { await screenshot("battle"); battle = true; }
  63 |     } else if (action.kind === "friendlyMove") {
  64 |       await page.locator("#start-friendly-move-button").click(); await country(page, action.from).click(); await country(page, action.to).click();
  65 |       await page.locator("#friendly-move-amount").fill(String(action.amount)); await screenshot("friendly-move");
  66 |       await page.locator("#confirm-friendly-move-button").click(); moved = true;
  67 |     } else if (action.kind === "captureMove") {
  68 |       const pending = state.pendingCapture!;
  69 |       await expect(page.locator("#capture-amount")).toHaveAttribute("min", String(pending.min)); await expect(page.locator("#capture-amount")).toHaveAttribute("max", String(pending.max));
  70 |       if (!resumed) {
  71 |         const text = await assertSaved("pending-capture"); await screenshot("pending-capture");
  72 |         await page.reload(); await expect(page.locator("#reference-setup")).toBeVisible();
  73 |         await page.getByLabel("Load game", {exact: true}).setInputFiles({name: "resume.json", mimeType: "application/json", buffer: Buffer.from(text)});
> 74 |         await expect(page.locator("#capture-amount")).toHaveAttribute("max", String(pending.max));
     |                                                       ^ Error: expect(locator).toHaveAttribute(expected) failed
  75 |         await assertSaved("resumed-capture"); await paint(page, state); await screenshot("save-resume"); resumed = true;
  76 |       }
  77 |       await page.locator("#capture-amount").fill(String(action.amount)); await page.locator("#confirm-capture-button").click();
  78 |     } else throw Error("Unexpected human action " + action.kind);
  79 |     state = step(state, action);
  80 |     if (action.kind !== "reinforce") await paint(page, state);
  81 |     if (!eliminated && state.players.some(p => p.eliminated)) { eliminated = true; const dead = state.players.find(p => p.eliminated)!; await expect(page.locator(`[data-player="${dead.id}"] .score-num`)).toContainText("0 provinces"); await screenshot("elimination"); }
  82 |   }
  83 |   expect(index).toBe(fixture.expected.actions); expect([resumed, moved, battle, computer, eliminated]).toEqual([true,true,true,true,true]);
  84 |   expect(state.phase).toBe("finished"); expect(state.winner).toBe("seat1"); expect(state.result!.reason).toBe("conquest");
  85 |   await expect(page.locator("#victory-reason")).toContainText(/conquest|all.*46|46.*countr/i);
  86 |   await expect(page.locator("#turn-title")).toContainText("Seat 1");
  87 |   await expect(page.locator('[data-result-player="seat1"] [data-result-countries]')).toHaveText("46");
  88 |   await assertSaved("winner"); await screenshot("winner");
  89 |   const finished = await save(page); await country(page, state.map.provinces[0]!.id).click(); await page.clock.runFor(4000); expect(await save(page)).toBe(finished);
  90 |   await page.getByRole("button", {name: "New game", exact: true}).click(); await expect(page.locator("#reference-setup")).toBeVisible();
  91 |   expect(errors).toEqual([]);
  92 |   writeFileSync(join(evidence, "summary.json"), JSON.stringify({url: page.url(), options: fixture.options, actions: index, computerActions: fixture.expected.computerActions, humanActions: fixture.expected.humanActions, winner: state.winner, observed: {resumed, moved, battle, computer, eliminated}, errors}, null, 2));
  93 | });
  94 | 
```