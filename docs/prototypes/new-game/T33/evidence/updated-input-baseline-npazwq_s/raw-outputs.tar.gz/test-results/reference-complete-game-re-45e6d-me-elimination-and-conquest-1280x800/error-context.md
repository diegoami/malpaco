# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: reference-complete-game.spec.ts >> real human/computer setup, friendly move, pending save/resume, elimination and conquest
- Location: tests/e2e/reference-complete-game.spec.ts:26:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 1

@@ -7,11 +7,11 @@
      "seat2",
      1,
    ],
    "province_10": Array [
      "seat1",
-     15,
+     14,
    ],
    "province_11": Array [
      "seat1",
      1,
    ],
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 1 human / 1 computer seats · Computer play · Seed 7
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]: 19 provinces · 52 armies
      - generic [ref=e16]:
        - generic [ref=e17]: Seat 2 · Computer
        - generic [ref=e18]: 27 provinces · 47 armies
    - contentinfo [ref=e19]:
      - button "New game" [ref=e20] [cursor=pointer]
    - generic [ref=e21]:
      - button "Save game" [ref=e22] [cursor=pointer]
      - generic [ref=e23]:
        - generic [ref=e24]: Load game
        - button "Load game" [ref=e25]
  - main [ref=e26]:
    - img "Nine Isles reference map" [ref=e28]:
      - button "River gate, Seat 1, 2 armies, Seat 1" [ref=e54] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: "2"
      - button "New port, Seat 1, 4 armies, Seat 1" [ref=e56] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: "4"
      - button "North rest, Seat 2, 2 armies, Seat 2" [ref=e58] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: "2"
      - button "River keep, Seat 1, 3 armies, Seat 1" [ref=e60] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: "3"
      - button "North town, Seat 2, 1 armies, Seat 2" [ref=e62] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: "1"
      - button "Dark ford, Seat 1, 1 armies, Seat 1" [ref=e64] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: "1"
      - button "Iron point, Seat 2, 1 armies, Seat 2" [ref=e66] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: "1"
      - button "South rest, Seat 1, 2 armies, Seat 1" [ref=e68] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: "2"
      - button "High shore, Seat 1, 2 armies, Seat 1" [ref=e70] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: "2"
      - button "Wind town, Seat 1, 1 armies, Seat 1" [ref=e72] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: "1"
      - button "New glen, Seat 2, 1 armies, Seat 2" [ref=e74] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: "1"
        - generic [ref=e76]: ★
      - button "Old rock, Seat 1, 1 armies, Seat 1" [ref=e77] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: "1"
      - button "Blue peak, Seat 2, 3 armies, Seat 2" [ref=e79] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: "3"
      - button "West haven, Seat 2, 1 armies, Seat 2" [ref=e81] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: "1"
      - button "Stone watch, Seat 2, 1 armies, Seat 2" [ref=e83] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: "1"
      - button "Upper ridge, Seat 2, 1 armies, Seat 2" [ref=e85] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: "1"
      - button "Marsh keep, Seat 1, 3 armies, Seat 1" [ref=e87] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: "3"
      - button "New fell, Seat 1, 2 armies, Seat 1" [ref=e89] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: "2"
      - button "Moon point, Seat 2, 2 armies, Seat 2" [ref=e91] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: "2"
      - button "South fell, Seat 2, 1 armies, Seat 2" [ref=e93] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: "1"
      - button "High ridge, Seat 2, 1 armies, Seat 2" [ref=e95] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: "1"
      - button "Bay ford, Seat 1, 2 armies, Seat 1" [ref=e97] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: "2"
        - generic [ref=e99]: ★
      - button "Low moor, Seat 1, 2 armies, Seat 1" [ref=e100] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: "2"
      - button "Lower field, Seat 1, 14 armies, Seat 1" [pressed] [ref=e102] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: "14"
      - button "Wind gate, Seat 2, 1 armies, Seat 2" [ref=e104] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: "1"
      - button "Silver shore, Seat 1, 2 armies, Seat 1" [ref=e106] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: "2"
      - button "Low peak, Seat 1, 2 armies, Seat 1" [ref=e108] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: "2"
      - button "Wind port, Seat 2, 1 armies, Seat 2" [ref=e110] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: "1"
      - button "Gold point, Seat 1, 2 armies, Seat 1" [ref=e112] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: "2"
        - generic [ref=e114]: ★
      - button "Rock moor, Seat 2, 2 armies, Seat 2" [ref=e115] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: "2"
      - button "Marsh rest, Seat 1, 2 armies, Seat 1" [ref=e117] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: "2"
      - button "Wind dale, Seat 2, 2 armies, Seat 2" [ref=e119] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: "2"
      - button "Silver ford, Seat 2, 1 armies, Seat 2" [ref=e121] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: "1"
      - button "Iron field, Seat 2, 2 armies, Seat 2" [ref=e123] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: "2"
      - button "North wood, Seat 2, 1 armies, Seat 2" [ref=e125] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: "1"
      - button "Fort town, Seat 1, 2 armies, Seat 1" [ref=e127] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: "2"
      - button "Red field, Seat 1, 3 armies, Seat 1" [ref=e129] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: "3"
      - button "South ridge, Seat 2, 9 armies, Seat 2" [ref=e131] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: "9"
      - button "Rock bay, Seat 2, 2 armies, Seat 2" [ref=e133] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: "2"
      - button "North ford, Seat 2, 2 armies, Seat 2" [ref=e135] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: "2"
      - button "Port ridge, Seat 2, 1 armies, Seat 2" [ref=e137] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: "1"
      - button "New rock, Seat 2, 1 armies, Seat 2" [ref=e139] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: "1"
      - button "South reach, Seat 2, 1 armies, Seat 2" [ref=e141] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: "1"
      - button "Silver point, Seat 2, 1 armies, Seat 2" [ref=e143] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: "1"
      - button "East ford, Seat 2, 2 armies, Seat 2" [ref=e145] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: "2"
      - button "Gold town, Seat 2, 3 armies, Seat 2" [ref=e147] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: "3"
      - generic [ref=e179]: North Isle +3
      - generic [ref=e180]: East Isle +3
      - generic [ref=e181]: West Isle +3
      - generic [ref=e182]: South Isle +3
      - generic [ref=e183]: Central Isle +5
      - generic [ref=e184]: Harbor Isle +5
      - generic [ref=e185]: Palm Isle +6
      - generic [ref=e186]: Cliff Isle +5
      - generic [ref=e187]: Great Isle +9
    - complementary [ref=e188]:
      - generic [ref=e192]:
        - generic [ref=e193]: Seat 1's turn
        - generic [ref=e194]: Round 2 · Attack
      - generic [ref=e195]:
        - generic [ref=e196]:
          - button "End turn" [ref=e197] [cursor=pointer]
          - button "Move armies" [ref=e198] [cursor=pointer]
        - region "Battle controls" [ref=e199]:
          - heading "Battle" [level=2] [ref=e200]
          - generic [ref=e201]:
            - generic [ref=e202]:
              - generic [ref=e203]: From
              - strong [ref=e204]: Lower field
              - generic "Source armies" [ref=e205]: "14"
            - generic [ref=e206]:
              - generic [ref=e207]: Target
              - strong [ref=e208]: Wind gate
              - generic "Target armies" [ref=e209]: "1"
          - generic [ref=e210]:
            - generic [ref=e211]:
              - text: Stop at armies
              - spinbutton "Stop at armies" [ref=e212]: "2"
            - generic [ref=e213]:
              - text: Battle speed
              - combobox "Battle speed" [ref=e214]:
                - option "Slow"
                - option "Normal" [selected]
                - option "Fast"
          - paragraph [ref=e215]: This battle stops at 2 armies, or on capture.
          - generic [ref=e216]:
            - button "Fight on" [ref=e217] [cursor=pointer]
            - button "Stop" [disabled] [ref=e218]
            - button "Single exchange" [active] [ref=e219] [cursor=pointer]
          - generic [ref=e220]:
            - strong [ref=e221]: Defender wins · source loses 1 army
            - paragraph [ref=e222]: One exchange complete.
          - paragraph [ref=e223]:
            - text: Won 0 · Lost 2 · Ties
            - strong [ref=e224]: "0"
          - list "Latest exchange dice" [ref=e225]:
            - listitem [ref=e226]:
              - img "Attacker rolled 2" [ref=e227]: "2"
              - generic [ref=e228]: Defender wins
              - img "Defender rolled 5" [ref=e229]: "5"
      - generic [ref=e230]:
        - heading "Battle log" [level=3] [ref=e231]
        - list "Battle log" [ref=e232]:
          - listitem [ref=e233]: "T2 Seat 1: Lower field → Wind gate, -1 / -0"
          - listitem [ref=e234]: "T2 Seat 1: Lower field → Wind gate, -1 / -0"
          - listitem [ref=e235]: T1 Seat 2 ends the turn
          - listitem [ref=e236]: "T1 Seat 2: North rest → River gate, -1 / -0"
          - listitem [ref=e237]: "T1 Seat 2: Silver point → South reach, took South reach"
          - listitem [ref=e238]: "T1 Seat 2: Silver point → South reach, -1 / -0"
          - listitem [ref=e239]: "T1 Seat 2: Silver point → South reach, -0 / -1"
```

# Test source

```ts
  1  | import { expect, test } from "@playwright/test";
  2  | import type { Page } from "@playwright/test";
  3  | import { readFileSync, writeFileSync, mkdirSync, mkdtempSync } from "node:fs";
  4  | import { join } from "node:path";
  5  | import { activePlayer, apply, victoryRules } from "../../src/core";
  6  | import type { Action, GameOptions, GameState } from "../../src/core";
  7  | import { createReferenceGame } from "../../src/core/reference-game";
  8  | import { referenceMap } from "../../src/core/reference-map";
  9  | import { deserializeVersionedMatch } from "../../src/core/match-save";
  10 | 
  11 | const fixture = JSON.parse(readFileSync(new URL("../../docs/prototypes/new-game/T33/fixtures/conquest.json", import.meta.url), "utf8")) as {
  12 |   options: GameOptions; actions: Action[]; expected: { actions: number; computerActions: number; humanActions: number; winner: string };
  13 | };
  14 | const country = (page: Page, id: string) => page.locator(`[data-country="${id}"]`);
  15 | function step(state: GameState, action: Action) {
  16 |   const result = apply(state, action); if (!result.ok) throw Error(JSON.stringify(action) + ": " + result.error); return result.state;
  17 | }
  18 | async function save(page: Page) {
  19 |   const event = page.waitForEvent("download"); await page.getByRole("button", {name: "Save game", exact: true}).click();
  20 |   return readFileSync((await (await event).path())!, "utf8");
  21 | }
  22 | async function paint(page: Page, state: GameState) {
> 23 |   expect(await page.locator("[data-country]").evaluateAll(nodes => Object.fromEntries(nodes.map(n => [n.getAttribute("data-country"), [n.getAttribute("data-owner"), Number(n.getAttribute("data-armies"))]])))).toEqual(Object.fromEntries(state.map.provinces.map(p => [p.id, [state.ownerOf[p.id], state.armies[p.id]]])));
     |                                                                                                                                                                                                                  ^ Error: expect(received).toEqual(expected) // deep equality
  24 | }
  25 | 
  26 | test("real human/computer setup, friendly move, pending save/resume, elimination and conquest", async ({page}, info) => {
  27 |   test.setTimeout(240_000);
  28 |   const root = process.env["REFERENCE_COMPLETE_EVIDENCE_DIR"] ?? "screenshots"; mkdirSync(root, {recursive: true});
  29 |   const evidence = mkdtempSync(join(root, `reference-complete-${info.project.name}-`));
  30 |   const errors: string[] = []; page.on("pageerror", e => errors.push(e.message)); page.on("console", m => {if (m.type() === "error") errors.push(m.text());});
  31 |   const screenshot = async (name: string) => { await page.mouse.move(0, 0); await page.screenshot({path: join(evidence, name + ".png"), animations: "disabled"}); };
  32 |   await page.clock.install(); await page.clock.pauseAt(new Date("2026-10-17T12:00:00Z"));
  33 |   await page.goto("/");
  34 |   await expect(page.getByLabel("Seat 1 control", {exact: true})).toHaveValue("human");
  35 |   for (let seat = 2; seat <= 4; seat++) await expect(page.getByLabel(`Seat ${seat} control`, {exact: true})).toHaveValue("computer");
  36 |   await page.getByLabel("Seed", {exact: true}).fill(String(fixture.options.seed));
  37 |   await page.getByLabel("Seats", {exact: true}).selectOption("2");
  38 |   await page.getByLabel("Domination win", {exact: true}).uncheck();
  39 |   await page.getByRole("button", {name: "Start game", exact: true}).click();
  40 |   const opening = createReferenceGame(referenceMap, fixture.options, victoryRules(fixture.options)); if (!opening.ok) throw Error(opening.errors.join(";"));
  41 |   let state = opening.state;
  42 |   expect(deserializeVersionedMatch(await save(page)).options).toEqual(fixture.options);
  43 |   await paint(page, state); await screenshot("opening");
  44 |   let index = 0, resumed = false, moved = false, battle = false, computer = false, eliminated = false;
  45 |   const assertSaved = async (name: string) => { const text = await save(page); writeFileSync(join(evidence, name + ".json"), text); expect(deserializeVersionedMatch(text).state).toEqual(state); return text; };
  46 |   while (index < fixture.actions.length) {
  47 |     if (activePlayer(state)!.kind === "computer") {
  48 |       if (!computer) { await expect(page.locator("#reference-computer-status")).toBeVisible(); await expect(page.locator("#end-turn-button")).toBeDisabled(); await screenshot("computer-turn"); computer = true; }
  49 |       let steps = 0;
  50 |       do { state = step(state, fixture.actions[index++]!); steps++; } while (index < fixture.actions.length && activePlayer(state)!.kind === "computer" && state.phase !== "finished");
  51 |       await page.clock.runFor(steps * 350);
  52 |       await paint(page, state); await assertSaved(`handoff-${index}`);
  53 |       continue;
  54 |     }
  55 |     const action = fixture.actions[index++]!;
  56 |     if (action.kind === "reinforce") await country(page, action.province).click();
  57 |     else if (action.kind === "endReinforcement") await page.locator("#start-combat-button").click();
  58 |     else if (action.kind === "endTurn") await page.locator("#end-turn-button").click();
  59 |     else if (action.kind === "attack") {
  60 |       if (await country(page, action.from).getAttribute("aria-pressed") !== "true") await country(page, action.from).click();
  61 |       await country(page, action.to).click(); await page.locator("#single-exchange-button").click();
  62 |       if (!battle) { await screenshot("battle"); battle = true; }
  63 |     } else if (action.kind === "friendlyMove") {
  64 |       await page.locator("#start-friendly-move-button").click(); await country(page, action.from).click(); await country(page, action.to).click();
  65 |       await page.locator("#friendly-move-amount").fill(String(action.amount)); await screenshot("friendly-move");
  66 |       await page.locator("#confirm-friendly-move-button").click(); moved = true;
  67 |     } else if (action.kind === "captureMove") {
  68 |       const pending = state.pendingCapture!;
  69 |       await expect(page.locator("#capture-amount")).toHaveAttribute("min", String(pending.min)); await expect(page.locator("#capture-amount")).toHaveAttribute("max", String(pending.max));
  70 |       if (!resumed) {
  71 |         const text = await assertSaved("pending-capture"); await screenshot("pending-capture");
  72 |         await page.reload(); await expect(page.locator("#reference-setup")).toBeVisible();
  73 |         await page.getByLabel("Load game", {exact: true}).setInputFiles({name: "resume.json", mimeType: "application/json", buffer: Buffer.from(text)});
  74 |         await expect(page.locator("#capture-amount")).toHaveAttribute("max", String(pending.max));
  75 |         await assertSaved("resumed-capture"); await paint(page, state); await screenshot("save-resume"); resumed = true;
  76 |       }
  77 |       await page.locator("#capture-amount").fill(String(action.amount)); await page.locator("#confirm-capture-button").click();
  78 |     } else throw Error("Unexpected human action " + action.kind);
  79 |     state = step(state, action);
  80 |     if (action.kind !== "reinforce") await paint(page, state);
  81 |     if (!eliminated && state.players.some(p => p.eliminated)) { eliminated = true; const dead = state.players.find(p => p.eliminated)!; await expect(page.locator(`[data-player="${dead.id}"] .score-num`)).toContainText("0 provinces"); await screenshot("elimination"); }
  82 |   }
  83 |   expect(index).toBe(fixture.expected.actions); expect([resumed, moved, battle, computer, eliminated]).toEqual([true,true,true,true,true]);
  84 |   expect(state.phase).toBe("finished"); expect(state.winner).toBe("seat1"); expect(state.result!.reason).toBe("conquest");
  85 |   await expect(page.locator("#victory-reason")).toContainText(/conquest|all.*46|46.*countr/i);
  86 |   await expect(page.locator("#turn-title")).toContainText("Seat 1");
  87 |   await expect(page.locator('[data-result-player="seat1"] [data-result-countries]')).toHaveText("46");
  88 |   await assertSaved("winner"); await screenshot("winner");
  89 |   const finished = await save(page); await country(page, state.map.provinces[0]!.id).click(); await page.clock.runFor(4000); expect(await save(page)).toBe(finished);
  90 |   await page.getByRole("button", {name: "New game", exact: true}).click(); await expect(page.locator("#reference-setup")).toBeVisible();
  91 |   expect(errors).toEqual([]);
  92 |   writeFileSync(join(evidence, "summary.json"), JSON.stringify({url: page.url(), options: fixture.options, actions: index, computerActions: fixture.expected.computerActions, humanActions: fixture.expected.humanActions, winner: state.winner, observed: {resumed, moved, battle, computer, eliminated}, errors}, null, 2));
  93 | });
  94 | 
```