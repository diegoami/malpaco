// PARENT MOCK ONLY. Removed before implementation.
import {readFileSync} from 'node:fs';
import {selectedPath} from './audit.mjs';
import {html,svg} from './render.mjs';
export function construct(){const bytes=readFileSync(selectedPath),b=JSON.parse(bytes);return {'board.json':bytes,'map.svg':svg(b),'preview.html':html(b)};}
