// PARENT MOCK ONLY. Interface feasibility using retained T25 UI.
import {html as baseHtml,svg} from '../T25/render.mjs';
export {svg};
export const html=b=>baseHtml(b,'Parent mock only').replace('grid-template-rows:56px','grid-template-rows:80px').replace('</style>','.lane.active{stroke:#fff7bf;stroke-width:3}</style>').replace('function select(id){',`function select(id){for(const lane of document.querySelectorAll('.lane'))lane.classList.toggle('active',lane.dataset.edge.split('|').includes(id));`);
