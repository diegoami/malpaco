# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: direct-attack.spec.ts >> Shift-click retains separate controls and Stop cancels the next continuous exchange
- Location: tests/e2e/direct-attack.spec.ts:43:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -  2
+ Received  + 27

@@ -6,11 +6,11 @@
      "province_11": 3,
      "province_12": 2,
      "province_13": 3,
      "province_14": 1,
      "province_15": 2,
-     "province_16": 10,
+     "province_16": 9,
      "province_17": 2,
      "province_18": 2,
      "province_19": 2,
      "province_2": 3,
      "province_20": 2,
@@ -86,19 +86,44 @@
        "kind": "reinforce",
        "province": "province_16",
      },
      Object {
        "kind": "endReinforcement",
+     },
+     Object {
+       "from": "province_16",
+       "kind": "attack",
+       "to": "province_2",
      },
    ],
    "log": Array [
      Object {
        "event": "game_started",
        "players": 2,
        "seed": 0,
      },
+     Object {
+       "attacker": "seat1",
+       "attackerLosses": 1,
+       "attackerRolls": Array [
+         1,
        ],
+       "captured": false,
+       "defender": "seat2",
+       "defenderLosses": 0,
+       "defenderRolls": Array [
+         6,
+       ],
+       "endsPhase": false,
+       "event": "attack",
+       "from": "province_16",
+       "moved": 0,
+       "penalty": false,
+       "to": "province_2",
+       "turn": 1,
+     },
+   ],
    "map": Object {
      "id": "reference-coast-first-a",
      "islands": Array [
        Object {
          "bonus": 3,
@@ -2597,11 +2622,11 @@
      "province_33",
    ],
    "reinforcementPool": 0,
    "rng": Object {
      "seed": 0,
-     "state": 1816413213,
+     "state": 1184577543,
    },
    "roundOrigin": 0,
    "rules": Object {
      "combat": Object {
        "attackRatio": 1,
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 2 human seats · Seed 0
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]: 23 provinces · 52 armies
      - generic [ref=e16]:
        - generic [ref=e17]: Seat 2
        - generic [ref=e18]: 23 provinces · 46 armies
    - contentinfo [ref=e19]:
      - button "New game" [ref=e20] [cursor=pointer]
    - generic [ref=e21]:
      - button "Save game" [active] [ref=e22] [cursor=pointer]
      - generic [ref=e23]:
        - generic [ref=e24]: Load game
        - button "Load game" [ref=e25]
  - main [ref=e26]:
    - img "Nine Isles reference map" [ref=e28]:
      - button "River gate, Seat 1, 3 armies, Seat 1" [ref=e53] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: "3"
      - button "New port, Seat 2, 2 armies, Seat 2" [ref=e55] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: "2"
      - button "North rest, Seat 1, 2 armies, Seat 1" [ref=e57] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: "2"
      - button "River keep, Seat 2, 1 armies, Seat 2" [ref=e59] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: "1"
      - button "North town, Seat 1, 2 armies, Seat 1" [ref=e61] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: "2"
      - button "Dark ford, Seat 1, 3 armies, Seat 1" [ref=e63] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: "3"
      - button "Iron point, Seat 2, 2 armies, Seat 2" [ref=e65] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: "2"
      - button "South rest, Seat 2, 3 armies, Seat 2" [ref=e67] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: "3"
      - button "High shore, Seat 1, 9 armies, Seat 1" [pressed] [ref=e69] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: "9"
      - button "Wind town, Seat 1, 3 armies, Seat 1" [ref=e71] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: "3"
      - button "New glen, Seat 1, 1 armies, Seat 1" [ref=e73] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: "1"
      - button "Old rock, Seat 2, 1 armies, Seat 2" [ref=e75] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: "1"
      - button "Blue peak, Seat 2, 1 armies, Seat 2" [ref=e77] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: "1"
      - button "West haven, Seat 1, 2 armies, Seat 1" [ref=e79] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: "2"
      - button "Stone watch, Seat 2, 3 armies, Seat 2" [ref=e81] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: "3"
      - button "Upper ridge, Seat 1, 2 armies, Seat 1" [ref=e83] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: "2"
      - button "Marsh keep, Seat 2, 2 armies, Seat 2" [ref=e85] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: "2"
      - button "New fell, Seat 1, 1 armies, Seat 1" [ref=e87] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: "1"
      - button "Moon point, Seat 2, 2 armies, Seat 2" [ref=e89] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: "2"
      - button "South fell, Seat 2, 3 armies, Seat 2" [ref=e91] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: "3"
      - button "High ridge, Seat 2, 1 armies, Seat 2" [ref=e93] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: "1"
        - generic [ref=e95]: ★
      - button "Bay ford, Seat 1, 3 armies, Seat 1" [ref=e96] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: "3"
      - button "Low moor, Seat 2, 2 armies, Seat 2" [ref=e98] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: "2"
      - button "Lower field, Seat 1, 1 armies, Seat 1" [ref=e100] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: "1"
      - button "Wind gate, Seat 2, 2 armies, Seat 2" [ref=e102] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: "2"
      - button "Silver shore, Seat 1, 2 armies, Seat 1" [ref=e104] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: "2"
      - button "Low peak, Seat 1, 1 armies, Seat 1" [ref=e106] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: "1"
      - button "Wind port, Seat 2, 3 armies, Seat 2" [ref=e108] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: "3"
      - button "Gold point, Seat 2, 3 armies, Seat 2" [ref=e110] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: "3"
      - button "Rock moor, Seat 1, 1 armies, Seat 1" [ref=e112] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: "1"
      - button "Marsh rest, Seat 1, 3 armies, Seat 1" [ref=e114] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: "3"
        - generic [ref=e116]: ★
      - button "Wind dale, Seat 1, 2 armies, Seat 1" [ref=e117] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: "2"
      - button "Silver ford, Seat 1, 1 armies, Seat 1" [ref=e119] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: "1"
      - button "Iron field, Seat 2, 3 armies, Seat 2" [ref=e121] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: "3"
      - button "North wood, Seat 2, 1 armies, Seat 2" [ref=e123] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: "1"
      - button "Fort town, Seat 1, 2 armies, Seat 1" [ref=e125] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: "2"
      - button "Red field, Seat 2, 1 armies, Seat 2" [ref=e127] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: "1"
      - button "South ridge, Seat 2, 3 armies, Seat 2" [ref=e129] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: "3"
      - button "Rock bay, Seat 1, 2 armies, Seat 1" [ref=e131] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: "2"
      - button "North ford, Seat 2, 1 armies, Seat 2" [ref=e133] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: "1"
      - button "Port ridge, Seat 1, 3 armies, Seat 1" [ref=e135] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: "3"
      - button "New rock, Seat 2, 3 armies, Seat 2" [ref=e137] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: "3"
      - button "South reach, Seat 2, 1 armies, Seat 2" [ref=e139] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: "1"
        - generic [ref=e141]: ★
      - button "Silver point, Seat 1, 1 armies, Seat 1" [ref=e142] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: "1"
      - button "East ford, Seat 1, 2 armies, Seat 1" [ref=e144] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: "2"
      - button "Gold town, Seat 2, 2 armies, Seat 2" [ref=e146] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: "2"
      - generic [ref=e178]: North Isle +3
      - generic [ref=e179]: East Isle +3
      - generic [ref=e180]: West Isle +3
      - generic [ref=e181]: South Isle +3
      - generic [ref=e182]: Central Isle +5
      - generic [ref=e183]: Harbor Isle +5
      - generic [ref=e184]: Palm Isle +6
      - generic [ref=e185]: Cliff Isle +5
      - generic [ref=e186]: Great Isle +9
    - complementary [ref=e187]:
      - generic [ref=e191]:
        - generic [ref=e192]: Seat 1's turn
        - generic [ref=e193]: Round 1 · Attack
      - generic [ref=e194]:
        - generic [ref=e195]:
          - button "End turn" [ref=e196] [cursor=pointer]
          - button "Move armies" [ref=e197] [cursor=pointer]
        - region "Battle controls" [ref=e198]:
          - heading "Battle" [level=2] [ref=e199]
          - generic [ref=e200]:
            - generic [ref=e201]:
              - generic [ref=e202]: From
              - strong [ref=e203]: High shore
              - generic "Source armies" [ref=e204]: "9"
            - generic [ref=e205]:
              - generic [ref=e206]: Target
              - strong [ref=e207]: South rest
              - generic "Target armies" [ref=e208]: "3"
          - generic [ref=e209]:
            - generic [ref=e210]:
              - text: Stop at armies
              - spinbutton "Stop at armies" [ref=e211]: "2"
            - generic [ref=e212]:
              - text: Battle speed
              - combobox "Battle speed" [ref=e213]:
                - option "Slow"
                - option "Normal" [selected]
                - option "Fast"
          - paragraph [ref=e214]: This battle stops at 2 armies, or on capture.
          - generic [ref=e215]:
            - button "Fight on" [ref=e216] [cursor=pointer]
            - button "Stop" [disabled] [ref=e217]
            - button "Single exchange" [ref=e218] [cursor=pointer]
          - generic [ref=e219]:
            - strong [ref=e220]: Defender wins · source loses 1 army
            - paragraph [ref=e221]: One exchange complete.
          - paragraph [ref=e222]:
            - text: Won 0 · Lost 1 · Ties
            - strong [ref=e223]: "0"
          - list "Latest exchange dice" [ref=e224]:
            - listitem [ref=e225]:
              - img "Attacker rolled 1" [ref=e226]: "1"
              - generic [ref=e227]: Defender wins
              - img "Defender rolled 6" [ref=e228]: "6"
      - generic [ref=e229]:
        - heading "Battle log" [level=3] [ref=e230]
        - list "Battle log" [ref=e231]:
          - listitem [ref=e232]: "T1 Seat 1: High shore → South rest, -1 / -0"
```

# Test source

```ts
  1  | import {test,expect} from "@playwright/test";
  2  | import type {Page} from "@playwright/test";
  3  | import {mkdirSync,mkdtempSync,readFileSync,writeFileSync} from "node:fs";
  4  | import {join} from "node:path";
  5  | import {fixture,step,map} from "./battle-fixture";
  6  | import {activePlayer,attackTargets,whyNot} from "../../src/core";
  7  | import type {GameState} from "../../src/core";
  8  | import {deserializeVersionedMatch} from "../../src/core/match-save";
  9  | import {logicalState} from "../core/versioned-match-fixture";
  10 | test.use({hasTouch:true});
  11 | const country=(p:Page,id:string)=>p.locator(`[data-country="${id}"]`);
  12 | const output=process.env["ATTACK_EVIDENCE_DIR"]??"screenshots";
  13 | async function save(page:Page){const pending=page.waitForEvent("download");await page.getByRole("button",{name:"Save game",exact:true}).click();const text=readFileSync((await (await pending).path())!,"utf8");mkdirSync(output,{recursive:true});writeFileSync(join(mkdtempSync(join(output,"save-")),"match.json"),text);return text;}
> 14 | async function check(page:Page,state:GameState){const text=await save(page);expect(logicalState(deserializeVersionedMatch(text).state)).toEqual(logicalState(state));expect(await page.locator("[data-country]").evaluateAll(ns=>Object.fromEntries(ns.map(n=>[n.getAttribute("data-country"),[n.getAttribute("data-owner"),Number(n.getAttribute("data-armies"))]])))).toEqual(Object.fromEntries(state.map.provinces.map(p=>[p.id,[state.ownerOf[p.id],state.armies[p.id]]])));return text;}
     |                                                                                                                                         ^ Error: expect(received).toEqual(expected) // deep equality
  15 | async function shot(page:Page,label:string,project:string){mkdirSync(output,{recursive:true});await page.mouse.move(0,0);await page.screenshot({path:join(output,`${label}-${project}.png`)});}
  16 | async function prepare(page:Page,kind:Parameters<typeof fixture>[0]="manual"){
  17 |  const f=fixture(kind);await page.clock.install();await page.clock.pauseAt(new Date());await page.goto("/?control=manual");await page.getByLabel("Seed",{exact:true}).fill(String(f.seed));await page.getByLabel("Seats",{exact:true}).selectOption("2");await page.getByRole("button",{name:"Start game",exact:true}).click();for(let n=0;n<f.placements;n++)await country(page,f.from).click();await page.locator("#start-combat-button").click();return {...f,state:deserializeVersionedMatch(await save(page)).state};
  18 | }
  19 | async function context(page:Page,from:string,to:string){await expect(country(page,from)).toHaveAttribute("aria-pressed","true");await expect(page.locator("#battle-source-name")).toHaveText(map.provinces.find(p=>p.id===from)!.name);await expect(page.locator("#battle-target-name")).toHaveText(map.provinces.find(p=>p.id===to)!.name);}
  20 | test("mouse enemy activation attacks once and repeats without source/target reselection",async({page},info)=>{
  21 |  const f=await prepare(page);let state=f.state;await country(page,f.from).click();await check(page,state);await country(page,f.to).click();state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);await context(page,f.from,f.to);await country(page,f.to).click();state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);await context(page,f.from,f.to);await page.clock.runFor(3000);await check(page,state);await shot(page,"mouse-repeat",info.project.name);
  22 | });
  23 | test("keyboard attacks agree with mouse; held-key repeats are ignored and Shift selects only",async({page},info)=>{
  24 |  const f=await prepare(page);let state=f.state;await country(page,f.from).focus();await page.keyboard.press("Enter");await country(page,f.to).focus();await page.keyboard.press("Shift+Enter");await check(page,state);await context(page,f.from,f.to);
  25 |  await country(page,f.to).focus();await expect(country(page,f.to)).toBeFocused();await page.keyboard.press("Space");state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);
  26 |  for(const key of ["Enter"," "])await country(page,f.to).dispatchEvent("keydown",{key,repeat:true,bubbles:true});await check(page,state);
  27 |  await country(page,f.to).focus();await expect(country(page,f.to)).toBeFocused();await page.keyboard.press("Enter");state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);await context(page,f.from,f.to);await shot(page,"keyboard-repeat",info.project.name);
  28 | });
  29 | test("touch uses the same one-exchange repeat gesture",async({page},info)=>{
  30 |  const f=await prepare(page);let state=f.state;await country(page,f.from).tap();await country(page,f.to).tap();state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);await country(page,f.to).tap();state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);await context(page,f.from,f.to);await shot(page,"touch-repeat",info.project.name);
  31 | });
  32 | for(const quantity of ["minimum","intermediate","maximum"] as const)test(`direct capture ${quantity} waits for explicit choice through save/reload/upload`,async({page},info)=>{
  33 |  const f=await prepare(page,"capture");let state=f.state;await country(page,f.from).click();let attacks=0;
  34 |  while(state.phase==="attack"&&attacks<128){await country(page,f.to).click();state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);attacks++;}
  35 |  expect(state.phase).toBe("capture");expect(state.pendingCapture!.max).toBeGreaterThan(2);await context(page,f.from,f.to);
  36 |  const pending=await check(page,state);await shot(page,`capture-${quantity}-pending`,info.project.name);
  37 |  for(let n=0;n<3;n++)await country(page,f.to).click();await country(page,f.to).focus();await page.keyboard.press("Enter");await page.keyboard.press("Space");await page.locator("#capture-amount").press("Enter");await page.locator("#fight-on-button").dispatchEvent("click");await page.clock.runFor(3000);expect(await save(page)).toBe(pending);
  38 |  await page.reload();await page.getByLabel("Load game",{exact:true}).setInputFiles({name:"pending.json",mimeType:"application/json",buffer:Buffer.from(pending)});await check(page,state);await context(page,f.from,f.to);await expect(page.locator("#capture-amount")).toHaveAttribute("min",String(state.pendingCapture!.min));await expect(page.locator("#capture-amount")).toHaveAttribute("max",String(state.pendingCapture!.max));
  39 |  await page.locator("#capture-amount").fill("0");await page.locator("#confirm-capture-button").dispatchEvent("click");await check(page,state);
  40 |  const amount=quantity==="minimum"?state.pendingCapture!.min:quantity==="maximum"?state.pendingCapture!.max:state.pendingCapture!.min+1;
  41 |  const before=Object.values(state.armies).reduce((a,b)=>a+b,0);await page.locator("#capture-amount").fill(String(amount));const stale=await page.locator("#confirm-capture-button").elementHandle();await page.locator("#confirm-capture-button").click();state=step(state,{kind:"captureMove",amount});expect(Object.values(state.armies).reduce((a,b)=>a+b,0)).toBe(before);expect(state.armies[f.from]).toBeGreaterThanOrEqual(1);await check(page,state);await stale!.evaluate(n=>n.dispatchEvent(new MouseEvent("click",{bubbles:true})));await check(page,state);await shot(page,`capture-${quantity}-confirmed`,info.project.name);
  42 | });
  43 | test("Shift-click retains separate controls and Stop cancels the next continuous exchange",async({page},info)=>{
  44 |  const f=await prepare(page);let state=f.state;await country(page,f.from).click();await country(page,f.to).click({modifiers:["Shift"]});await check(page,state);await context(page,f.from,f.to);await page.locator("#battle-stop-threshold").fill("1");await page.locator("#battle-stop-threshold").press("Tab");await page.locator("#fight-on-button").click();state=step(state,{kind:"attack",from:f.from,to:f.to});await expect(page.getByRole("region",{name:"Battle controls",exact:true})).toHaveAttribute("data-running","true");await page.locator("#stop-battle-button").click();await page.clock.runFor(3000);await check(page,state);await context(page,f.from,f.to);await page.locator("#single-exchange-button").click();state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);await shot(page,"manual-stop",info.project.name);
  45 | });
  46 | test("friendly, distant and one-army inputs refuse attacks with the engine reason",async({page},info)=>{
  47 |  const f=await prepare(page);const state=f.state;await country(page,f.from).click();
  48 |  const distant=state.map.provinces.find(p=>state.ownerOf[p.id]!==activePlayer(state)!.id&&!attackTargets(state,f.from).includes(p.id))!.id;await country(page,distant).click();await check(page,state);await expect(page.locator("#battle-status")).toHaveText(whyNot(state,f.from,distant));
  49 |  const thin=state.map.provinces.find(p=>state.ownerOf[p.id]===activePlayer(state)!.id&&state.armies[p.id]===1&&[...p.borders,...p.seaLanes].some(id=>state.ownerOf[id]!==activePlayer(state)!.id))!;expect(thin).toBeTruthy();await country(page,thin.id).click();await check(page,state);const enemy=[...thin.borders,...thin.seaLanes].find(id=>state.ownerOf[id]!==activePlayer(state)!.id)!;await country(page,enemy).click();await check(page,state);await expect(page.locator("#battle-status")).toHaveText(whyNot(state,thin.id,enemy));await shot(page,"refused",info.project.name);
  50 | });
  51 | test("automatic computer attack phase refuses map, touch and keyboard human activations",async({page})=>{
  52 |  await page.clock.install();await page.clock.pauseAt(new Date());await page.goto("/");await page.getByLabel("Seed",{exact:true}).fill("1994");await page.getByRole("button",{name:"Start game",exact:true}).click();let state=deserializeVersionedMatch(await save(page)).state;
  53 |  for(let n=0;state.phase!=="attack"&&n<30;n++){await page.clock.runFor(350);state=deserializeVersionedMatch(await save(page)).state;}
  54 |  expect(state.phase).toBe("attack");expect(activePlayer(state)!.kind).toBe("computer");const from=state.map.provinces.find(p=>state.ownerOf[p.id]===activePlayer(state)!.id&&attackTargets(state,p.id).length>0)!.id,to=attackTargets(state,from)[0]!;const before=await check(page,state);
  55 |  await country(page,from).click();await country(page,to).tap();await country(page,to).focus();await page.keyboard.press("Enter");await page.keyboard.press("Space");expect(await save(page)).toBe(before);
  56 | });
  57 | 
```