# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: direct-attack.spec.ts >> friendly, distant and one-army inputs refuse attacks with the engine reason
- Location: tests/e2e/direct-attack.spec.ts:47:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  locator('#battle-status')
Expected: "High shore does not reach New port"
Received: ""
Timeout:  5000ms

Call log:
  - Expect "toHaveText" locator('#battle-status') with timeout 5000ms
  - waiting for locator('#battle-status')
    14 × locator resolved to <p id="battle-status"></p>
       - unexpected value ""

```

```yaml
- banner:
  - heading "Malpaco" [level=1]
  - text: Nine Isles · 2 human seats · Seed 0 Seat 1 23 provinces · 53 armies Seat 2 23 provinces · 46 armies
  - contentinfo:
    - button "New game"
  - button "Save game"
  - text: Load game
  - button "Load game"
- main:
  - img "Nine Isles reference map":
    - button "River gate, Seat 1, 3 armies, Seat 1": River gate 3
    - button "New port, Seat 2, 2 armies, Seat 2": New port 2
    - button "North rest, Seat 1, 2 armies, Seat 1": North rest 2
    - button "River keep, Seat 2, 1 armies, Seat 2": River keep 1
    - button "North town, Seat 1, 2 armies, Seat 1": North town 2
    - button "Dark ford, Seat 1, 3 armies, Seat 1": Dark ford 3
    - button "Iron point, Seat 2, 2 armies, Seat 2": Iron point 2
    - button "South rest, Seat 2, 3 armies, Seat 2": South rest 3
    - button "High shore, Seat 1, 10 armies, Seat 1" [pressed]: High shore 10
    - button "Wind town, Seat 1, 3 armies, Seat 1": Wind town 3
    - button "New glen, Seat 1, 1 armies, Seat 1": New glen 1
    - button "Old rock, Seat 2, 1 armies, Seat 2": Old rock 1
    - button "Blue peak, Seat 2, 1 armies, Seat 2": Blue peak 1
    - button "West haven, Seat 1, 2 armies, Seat 1": West haven 2
    - button "Stone watch, Seat 2, 3 armies, Seat 2": Stone watch 3
    - button "Upper ridge, Seat 1, 2 armies, Seat 1": Upper ridge 2
    - button "Marsh keep, Seat 2, 2 armies, Seat 2": Marsh keep 2
    - button "New fell, Seat 1, 1 armies, Seat 1": New fell 1
    - button "Moon point, Seat 2, 2 armies, Seat 2": Moon point 2
    - button "South fell, Seat 2, 3 armies, Seat 2": South fell 3
    - button "High ridge, Seat 2, 1 armies, Seat 2": High ridge 1 ★
    - button "Bay ford, Seat 1, 3 armies, Seat 1": Bay ford 3
    - button "Low moor, Seat 2, 2 armies, Seat 2": Low moor 2
    - button "Lower field, Seat 1, 1 armies, Seat 1": Lower field 1
    - button "Wind gate, Seat 2, 2 armies, Seat 2": Wind gate 2
    - button "Silver shore, Seat 1, 2 armies, Seat 1": Silver shore 2
    - button "Low peak, Seat 1, 1 armies, Seat 1": Low peak 1
    - button "Wind port, Seat 2, 3 armies, Seat 2": Wind port 3
    - button "Gold point, Seat 2, 3 armies, Seat 2": Gold point 3
    - button "Rock moor, Seat 1, 1 armies, Seat 1": Rock moor 1
    - button "Marsh rest, Seat 1, 3 armies, Seat 1": Marsh rest 3 ★
    - button "Wind dale, Seat 1, 2 armies, Seat 1": Wind dale 2
    - button "Silver ford, Seat 1, 1 armies, Seat 1": Silver ford 1
    - button "Iron field, Seat 2, 3 armies, Seat 2": Iron field 3
    - button "North wood, Seat 2, 1 armies, Seat 2": North wood 1
    - button "Fort town, Seat 1, 2 armies, Seat 1": Fort town 2
    - button "Red field, Seat 2, 1 armies, Seat 2": Red field 1
    - button "South ridge, Seat 2, 3 armies, Seat 2": South ridge 3
    - button "Rock bay, Seat 1, 2 armies, Seat 1": Rock bay 2
    - button "North ford, Seat 2, 1 armies, Seat 2": North ford 1
    - button "Port ridge, Seat 1, 3 armies, Seat 1": Port ridge 3
    - button "New rock, Seat 2, 3 armies, Seat 2": New rock 3
    - button "South reach, Seat 2, 1 armies, Seat 2": South reach 1 ★
    - button "Silver point, Seat 1, 1 armies, Seat 1": Silver point 1
    - button "East ford, Seat 1, 2 armies, Seat 1": East ford 2
    - button "Gold town, Seat 2, 2 armies, Seat 2": Gold town 2
    - text: North Isle +3 East Isle +3 West Isle +3 South Isle +3 Central Isle +5 Harbor Isle +5 Palm Isle +6 Cliff Isle +5 Great Isle +9
  - complementary:
    - text: Seat 1's turn Round 1 · Attack
    - button "End turn"
    - button "Move armies"
    - region "Battle controls":
      - heading "Battle" [level=2]
      - text: From
      - strong: High shore
      - text: 10 Target
      - strong: Choose an enemy neighbour
      - text: — Stop at armies
      - spinbutton "Stop at armies": "2"
      - text: Battle speed
      - combobox "Battle speed":
        - option "Slow"
        - option "Normal" [selected]
        - option "Fast"
      - paragraph: This battle stops at 2 armies, or on capture.
      - button "Fight on" [disabled]
      - button "Stop" [disabled]
      - button "Single exchange" [disabled]
      - strong: Ready for your choice
      - paragraph
      - paragraph:
        - text: Won 0 · Lost 0 · Ties
        - strong: "0"
    - heading "Battle log" [level=3]
    - list "Battle log"
```

# Test source

```ts
  1  | import {test,expect} from "@playwright/test";
  2  | import type {Page} from "@playwright/test";
  3  | import {mkdirSync,mkdtempSync,readFileSync,writeFileSync} from "node:fs";
  4  | import {join} from "node:path";
  5  | import {fixture,step,map} from "./battle-fixture";
  6  | import {activePlayer,attackTargets,whyNot} from "../../src/core";
  7  | import type {GameState} from "../../src/core";
  8  | import {deserializeVersionedMatch} from "../../src/core/match-save";
  9  | import {logicalState} from "../core/versioned-match-fixture";
  10 | test.use({hasTouch:true});
  11 | const country=(p:Page,id:string)=>p.locator(`[data-country="${id}"]`);
  12 | const output=process.env["ATTACK_EVIDENCE_DIR"]??"screenshots";
  13 | async function save(page:Page){const pending=page.waitForEvent("download");await page.getByRole("button",{name:"Save game",exact:true}).click();const text=readFileSync((await (await pending).path())!,"utf8");mkdirSync(output,{recursive:true});writeFileSync(join(mkdtempSync(join(output,"save-")),"match.json"),text);return text;}
  14 | async function check(page:Page,state:GameState){const text=await save(page);expect(logicalState(deserializeVersionedMatch(text).state)).toEqual(logicalState(state));expect(await page.locator("[data-country]").evaluateAll(ns=>Object.fromEntries(ns.map(n=>[n.getAttribute("data-country"),[n.getAttribute("data-owner"),Number(n.getAttribute("data-armies"))]])))).toEqual(Object.fromEntries(state.map.provinces.map(p=>[p.id,[state.ownerOf[p.id],state.armies[p.id]]])));return text;}
  15 | async function shot(page:Page,label:string,project:string){mkdirSync(output,{recursive:true});await page.mouse.move(0,0);await page.screenshot({path:join(output,`${label}-${project}.png`)});}
  16 | async function prepare(page:Page,kind:Parameters<typeof fixture>[0]="manual"){
  17 |  const f=fixture(kind);await page.clock.install();await page.clock.pauseAt(new Date());await page.goto("/?control=manual");await page.getByLabel("Seed",{exact:true}).fill(String(f.seed));await page.getByLabel("Seats",{exact:true}).selectOption("2");await page.getByRole("button",{name:"Start game",exact:true}).click();for(let n=0;n<f.placements;n++)await country(page,f.from).click();await page.locator("#start-combat-button").click();return {...f,state:deserializeVersionedMatch(await save(page)).state};
  18 | }
  19 | async function context(page:Page,from:string,to:string){await expect(country(page,from)).toHaveAttribute("aria-pressed","true");await expect(page.locator("#battle-source-name")).toHaveText(map.provinces.find(p=>p.id===from)!.name);await expect(page.locator("#battle-target-name")).toHaveText(map.provinces.find(p=>p.id===to)!.name);}
  20 | test("mouse enemy activation attacks once and repeats without source/target reselection",async({page},info)=>{
  21 |  const f=await prepare(page);let state=f.state;await country(page,f.from).click();await check(page,state);await country(page,f.to).click();state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);await context(page,f.from,f.to);await country(page,f.to).click();state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);await context(page,f.from,f.to);await page.clock.runFor(3000);await check(page,state);await shot(page,"mouse-repeat",info.project.name);
  22 | });
  23 | test("keyboard attacks agree with mouse; held-key repeats are ignored and Shift selects only",async({page},info)=>{
  24 |  const f=await prepare(page);let state=f.state;await country(page,f.from).focus();await page.keyboard.press("Enter");await country(page,f.to).focus();await page.keyboard.press("Shift+Enter");await check(page,state);await context(page,f.from,f.to);
  25 |  await country(page,f.to).focus();await page.keyboard.press("Shift+Space");await check(page,state);
  26 |  await country(page,f.to).focus();await expect(country(page,f.to)).toBeFocused();await page.keyboard.press("Space");state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);
  27 |  for(const key of ["Enter"," "])await country(page,f.to).dispatchEvent("keydown",{key,repeat:true,bubbles:true});await check(page,state);
  28 |  await country(page,f.to).focus();await expect(country(page,f.to)).toBeFocused();await page.keyboard.press("Enter");state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);await context(page,f.from,f.to);await shot(page,"keyboard-repeat",info.project.name);
  29 | });
  30 | test("touch uses the same one-exchange repeat gesture",async({page},info)=>{
  31 |  const f=await prepare(page);let state=f.state;await country(page,f.from).tap();await country(page,f.to).tap();state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);await country(page,f.to).tap();state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);await context(page,f.from,f.to);await shot(page,"touch-repeat",info.project.name);
  32 | });
  33 | for(const quantity of ["minimum","intermediate","maximum"] as const)test(`direct capture ${quantity} waits for explicit choice through save/reload/upload`,async({page},info)=>{
  34 |  const f=await prepare(page,"capture");let state=f.state;await country(page,f.from).click();let attacks=0;
  35 |  while(state.phase==="attack"&&attacks<128){await country(page,f.to).click();state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);attacks++;}
  36 |  expect(state.phase).toBe("capture");expect(state.pendingCapture!.max).toBeGreaterThan(2);await context(page,f.from,f.to);
  37 |  const pending=await check(page,state);await shot(page,`capture-${quantity}-pending`,info.project.name);
  38 |  for(let n=0;n<3;n++)await country(page,f.to).click();await check(page,state);await country(page,f.to).focus();await page.keyboard.press("Enter");await page.keyboard.press("Space");await page.locator("#capture-amount").press("Enter");await page.locator("#fight-on-button").dispatchEvent("click");await page.clock.runFor(3000);expect(await save(page)).toBe(pending);
  39 |  await page.reload();await page.getByLabel("Load game",{exact:true}).setInputFiles({name:"pending.json",mimeType:"application/json",buffer:Buffer.from(pending)});await check(page,state);await context(page,f.from,f.to);await expect(page.locator("#capture-amount")).toHaveAttribute("min",String(state.pendingCapture!.min));await expect(page.locator("#capture-amount")).toHaveAttribute("max",String(state.pendingCapture!.max));
  40 |  await page.locator("#capture-amount").fill("0");await page.locator("#confirm-capture-button").dispatchEvent("click");await check(page,state);
  41 |  const amount=quantity==="minimum"?state.pendingCapture!.min:quantity==="maximum"?state.pendingCapture!.max:state.pendingCapture!.min+1;
  42 |  const before=Object.values(state.armies).reduce((a,b)=>a+b,0);await page.locator("#capture-amount").fill(String(amount));const stale=await page.locator("#confirm-capture-button").elementHandle();await page.locator("#confirm-capture-button").click();state=step(state,{kind:"captureMove",amount});expect(Object.values(state.armies).reduce((a,b)=>a+b,0)).toBe(before);expect(state.armies[f.from]).toBeGreaterThanOrEqual(1);await check(page,state);await stale!.evaluate(n=>n.dispatchEvent(new MouseEvent("click",{bubbles:true})));await check(page,state);await shot(page,`capture-${quantity}-confirmed`,info.project.name);
  43 | });
  44 | test("Shift-click retains separate controls and Stop cancels the next continuous exchange",async({page},info)=>{
  45 |  const f=await prepare(page);let state=f.state;await country(page,f.from).click();await country(page,f.to).click({modifiers:["Shift"]});await check(page,state);await context(page,f.from,f.to);await page.locator("#battle-stop-threshold").fill("1");await page.locator("#battle-stop-threshold").press("Tab");await page.locator("#fight-on-button").click();state=step(state,{kind:"attack",from:f.from,to:f.to});await expect(page.getByRole("region",{name:"Battle controls",exact:true})).toHaveAttribute("data-running","true");await page.locator("#stop-battle-button").click();await page.clock.runFor(3000);await check(page,state);await context(page,f.from,f.to);await page.locator("#single-exchange-button").click();state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);await shot(page,"manual-stop",info.project.name);
  46 | });
  47 | test("friendly, distant and one-army inputs refuse attacks with the engine reason",async({page},info)=>{
  48 |  const f=await prepare(page);const state=f.state;await country(page,f.from).click();
> 49 |  const distant=state.map.provinces.find(p=>state.ownerOf[p.id]!==activePlayer(state)!.id&&!attackTargets(state,f.from).includes(p.id))!.id;await country(page,distant).click();await check(page,state);await expect(page.locator("#battle-status")).toHaveText(whyNot(state,f.from,distant));
     |                                                                                                                                                                                                                                                     ^ Error: expect(locator).toHaveText(expected) failed
  50 |  const thin=state.map.provinces.find(p=>state.ownerOf[p.id]===activePlayer(state)!.id&&state.armies[p.id]===1&&[...p.borders,...p.seaLanes].some(id=>state.ownerOf[id]!==activePlayer(state)!.id))!;expect(thin).toBeTruthy();await country(page,thin.id).click();await check(page,state);const enemy=[...thin.borders,...thin.seaLanes].find(id=>state.ownerOf[id]!==activePlayer(state)!.id)!;await country(page,enemy).click();await check(page,state);await expect(page.locator("#battle-status")).toHaveText(whyNot(state,thin.id,enemy));await shot(page,"refused",info.project.name);
  51 | });
  52 | test("automatic computer attack phase refuses map, touch and keyboard human activations",async({page})=>{
  53 |  await page.clock.install();await page.clock.pauseAt(new Date());await page.goto("/");await page.getByLabel("Seed",{exact:true}).fill("1994");await page.getByRole("button",{name:"Start game",exact:true}).click();let state=deserializeVersionedMatch(await save(page)).state;
  54 |  for(let n=0;state.phase!=="attack"&&n<30;n++){await page.clock.runFor(350);state=deserializeVersionedMatch(await save(page)).state;}
  55 |  expect(state.phase).toBe("attack");expect(activePlayer(state)!.kind).toBe("computer");const from=state.map.provinces.find(p=>state.ownerOf[p.id]===activePlayer(state)!.id&&attackTargets(state,p.id).length>0)!.id,to=attackTargets(state,from)[0]!;const before=await check(page,state);
  56 |  await country(page,from).click();await country(page,to).tap();await country(page,to).focus();await page.keyboard.press("Enter");await page.keyboard.press("Space");expect(await save(page)).toBe(before);
  57 | });
  58 | 
```