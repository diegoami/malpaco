# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: direct-attack.spec.ts >> mouse enemy activation attacks once and repeats without source/target reselection
- Location: tests/e2e/direct-attack.spec.ts:20:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  locator('[data-country="province_16"]')
Expected: "true"
Received: "false"
Timeout:  5000ms

Call log:
  - Expect "toHaveAttribute" locator('[data-country="province_16"]') with timeout 5000ms
  - waiting for locator('[data-country="province_16"]')
    14 × locator resolved to <g role="button" tabindex="-1" data-armies="9" data-owner="seat1" data-target="false" aria-pressed="false" data-id="province_16" data-selected="false" class="country province" data-country="province_16" data-province="province_16" aria-label="High shore, Seat 1, 9 armies, Seat 1">…</g>
       - unexpected value "false"

```

```yaml
- button "High shore, Seat 1, 9 armies, Seat 1": High shore 9
```

# Test source

```ts
  1  | import {test,expect} from "@playwright/test";
  2  | import type {Page} from "@playwright/test";
  3  | import {mkdirSync,mkdtempSync,readFileSync,writeFileSync} from "node:fs";
  4  | import {join} from "node:path";
  5  | import {fixture,step,map} from "./battle-fixture";
  6  | import {activePlayer,attackTargets,whyNot} from "../../src/core";
  7  | import type {GameState} from "../../src/core";
  8  | import {deserializeVersionedMatch} from "../../src/core/match-save";
  9  | import {logicalState} from "../core/versioned-match-fixture";
  10 | test.use({hasTouch:true});
  11 | const country=(p:Page,id:string)=>p.locator(`[data-country="${id}"]`);
  12 | const output=process.env["ATTACK_EVIDENCE_DIR"]??"screenshots";
  13 | async function save(page:Page){const pending=page.waitForEvent("download");await page.getByRole("button",{name:"Save game",exact:true}).click();const text=readFileSync((await (await pending).path())!,"utf8");mkdirSync(output,{recursive:true});writeFileSync(join(mkdtempSync(join(output,"save-")),"match.json"),text);return text;}
  14 | async function check(page:Page,state:GameState){const text=await save(page);expect(logicalState(deserializeVersionedMatch(text).state)).toEqual(logicalState(state));expect(await page.locator("[data-country]").evaluateAll(ns=>Object.fromEntries(ns.map(n=>[n.getAttribute("data-country"),[n.getAttribute("data-owner"),Number(n.getAttribute("data-armies"))]])))).toEqual(Object.fromEntries(state.map.provinces.map(p=>[p.id,[state.ownerOf[p.id],state.armies[p.id]]])));return text;}
  15 | async function shot(page:Page,label:string,project:string){mkdirSync(output,{recursive:true});await page.mouse.move(0,0);await page.screenshot({path:join(output,`${label}-${project}.png`)});}
  16 | async function prepare(page:Page,kind:Parameters<typeof fixture>[0]="manual"){
  17 |  const f=fixture(kind);await page.clock.install();await page.clock.pauseAt(new Date());await page.goto("/?control=manual");await page.getByLabel("Seed",{exact:true}).fill(String(f.seed));await page.getByLabel("Seats",{exact:true}).selectOption("2");await page.getByRole("button",{name:"Start game",exact:true}).click();for(let n=0;n<f.placements;n++)await country(page,f.from).click();await page.locator("#start-combat-button").click();return {...f,state:deserializeVersionedMatch(await save(page)).state};
  18 | }
> 19 | async function context(page:Page,from:string,to:string){await expect(country(page,from)).toHaveAttribute("aria-pressed","true");await expect(page.locator("#battle-source-name")).toHaveText(map.provinces.find(p=>p.id===from)!.name);await expect(page.locator("#battle-target-name")).toHaveText(map.provinces.find(p=>p.id===to)!.name);}
     |                                                                                          ^ Error: expect(locator).toHaveAttribute(expected) failed
  20 | test("mouse enemy activation attacks once and repeats without source/target reselection",async({page},info)=>{
  21 |  const f=await prepare(page);let state=f.state;await country(page,f.from).click();await check(page,state);await country(page,f.to).click();state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);await context(page,f.from,f.to);await country(page,f.to).click();state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);await context(page,f.from,f.to);await page.clock.runFor(3000);await check(page,state);await shot(page,"mouse-repeat",info.project.name);
  22 | });
  23 | test("keyboard attacks agree with mouse; held-key repeats are ignored and Shift selects only",async({page},info)=>{
  24 |  const f=await prepare(page);let state=f.state;await country(page,f.from).focus();await page.keyboard.press("Enter");await country(page,f.to).focus();await page.keyboard.press("Shift+Enter");await check(page,state);await context(page,f.from,f.to);
  25 |  await country(page,f.to).focus();await page.keyboard.press("Shift+Space");await check(page,state);
  26 |  await country(page,f.to).focus();await expect(country(page,f.to)).toBeFocused();await page.keyboard.press("Space");state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);
  27 |  for(const key of ["Enter"," "])await country(page,f.to).dispatchEvent("keydown",{key,repeat:true,bubbles:true});await check(page,state);
  28 |  await country(page,f.to).focus();await expect(country(page,f.to)).toBeFocused();await page.keyboard.press("Enter");state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);await context(page,f.from,f.to);await shot(page,"keyboard-repeat",info.project.name);
  29 | });
  30 | test("touch uses the same one-exchange repeat gesture",async({page},info)=>{
  31 |  const f=await prepare(page);let state=f.state;await country(page,f.from).tap();await country(page,f.to).tap();state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);await country(page,f.to).tap();state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);await context(page,f.from,f.to);await shot(page,"touch-repeat",info.project.name);
  32 | });
  33 | for(const quantity of ["minimum","intermediate","maximum"] as const)test(`direct capture ${quantity} waits for explicit choice through save/reload/upload`,async({page},info)=>{
  34 |  const f=await prepare(page,"capture");let state=f.state;await country(page,f.from).click();let attacks=0;
  35 |  while(state.phase==="attack"&&attacks<128){await country(page,f.to).click();state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);attacks++;}
  36 |  expect(state.phase).toBe("capture");expect(state.pendingCapture!.max).toBeGreaterThan(2);await context(page,f.from,f.to);
  37 |  const pending=await check(page,state);await shot(page,`capture-${quantity}-pending`,info.project.name);
  38 |  for(let n=0;n<3;n++)await country(page,f.to).click();await check(page,state);await country(page,f.to).focus();await page.keyboard.press("Enter");await page.keyboard.press("Space");await page.locator("#capture-amount").press("Enter");await page.locator("#fight-on-button").dispatchEvent("click");await page.clock.runFor(3000);expect(await save(page)).toBe(pending);
  39 |  await page.reload();await page.getByLabel("Load game",{exact:true}).setInputFiles({name:"pending.json",mimeType:"application/json",buffer:Buffer.from(pending)});await check(page,state);await context(page,f.from,f.to);await expect(page.locator("#capture-amount")).toHaveAttribute("min",String(state.pendingCapture!.min));await expect(page.locator("#capture-amount")).toHaveAttribute("max",String(state.pendingCapture!.max));
  40 |  await page.locator("#capture-amount").fill("0");await page.locator("#confirm-capture-button").dispatchEvent("click");await check(page,state);
  41 |  const amount=quantity==="minimum"?state.pendingCapture!.min:quantity==="maximum"?state.pendingCapture!.max:state.pendingCapture!.min+1;
  42 |  const before=Object.values(state.armies).reduce((a,b)=>a+b,0);await page.locator("#capture-amount").fill(String(amount));const stale=await page.locator("#confirm-capture-button").elementHandle();await page.locator("#confirm-capture-button").click();state=step(state,{kind:"captureMove",amount});expect(Object.values(state.armies).reduce((a,b)=>a+b,0)).toBe(before);expect(state.armies[f.from]).toBeGreaterThanOrEqual(1);await check(page,state);await stale!.evaluate(n=>n.dispatchEvent(new MouseEvent("click",{bubbles:true})));await check(page,state);await shot(page,`capture-${quantity}-confirmed`,info.project.name);
  43 | });
  44 | test("Shift-click retains separate controls and Stop cancels the next continuous exchange",async({page},info)=>{
  45 |  const f=await prepare(page);let state=f.state;await country(page,f.from).click();await country(page,f.to).click({modifiers:["Shift"]});await check(page,state);await context(page,f.from,f.to);await page.locator("#battle-stop-threshold").fill("1");await page.locator("#battle-stop-threshold").press("Tab");await page.locator("#fight-on-button").click();state=step(state,{kind:"attack",from:f.from,to:f.to});await expect(page.getByRole("region",{name:"Battle controls",exact:true})).toHaveAttribute("data-running","true");await page.locator("#stop-battle-button").click();await page.clock.runFor(3000);await check(page,state);await context(page,f.from,f.to);await page.locator("#single-exchange-button").click();state=step(state,{kind:"attack",from:f.from,to:f.to});await check(page,state);await shot(page,"manual-stop",info.project.name);
  46 | });
  47 | test("friendly, distant and one-army inputs refuse attacks with the engine reason",async({page},info)=>{
  48 |  const f=await prepare(page);const state=f.state;await country(page,f.from).click();
  49 |  const distant=state.map.provinces.find(p=>state.ownerOf[p.id]!==activePlayer(state)!.id&&!attackTargets(state,f.from).includes(p.id))!.id;await country(page,distant).click();await check(page,state);await expect(page.locator("#battle-status")).toHaveText(whyNot(state,f.from,distant));
  50 |  const thin=state.map.provinces.find(p=>state.ownerOf[p.id]===activePlayer(state)!.id&&state.armies[p.id]===1&&[...p.borders,...p.seaLanes].some(id=>state.ownerOf[id]!==activePlayer(state)!.id))!;expect(thin).toBeTruthy();await country(page,thin.id).click();await check(page,state);const enemy=[...thin.borders,...thin.seaLanes].find(id=>state.ownerOf[id]!==activePlayer(state)!.id)!;await country(page,enemy).click();await check(page,state);await expect(page.locator("#battle-status")).toHaveText(whyNot(state,thin.id,enemy));await shot(page,"refused",info.project.name);
  51 | });
  52 | test("automatic computer attack phase refuses map, touch and keyboard human activations",async({page})=>{
  53 |  await page.clock.install();await page.clock.pauseAt(new Date());await page.goto("/");await page.getByLabel("Seed",{exact:true}).fill("1994");await page.getByRole("button",{name:"Start game",exact:true}).click();let state=deserializeVersionedMatch(await save(page)).state;
  54 |  for(let n=0;state.phase!=="attack"&&n<30;n++){await page.clock.runFor(350);state=deserializeVersionedMatch(await save(page)).state;}
  55 |  expect(state.phase).toBe("attack");expect(activePlayer(state)!.kind).toBe("computer");const from=state.map.provinces.find(p=>state.ownerOf[p.id]===activePlayer(state)!.id&&attackTargets(state,p.id).length>0)!.id,to=attackTargets(state,from)[0]!;const before=await check(page,state);
  56 |  await country(page,from).click();await country(page,to).tap();await country(page,to).focus();await page.keyboard.press("Enter");await page.keyboard.press("Space");expect(await save(page)).toBe(before);
  57 | });
  58 | 
```