# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: computer-turn-flow.spec.ts >> loaded computer capture resolves without a click; replacement and new game cancel old callbacks
- Location: tests/e2e/computer-turn-flow.spec.ts:27:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   Object {
+     "fits": false,
+     "font": 13,
+     "id": "reference-computer-status",
+   },
+ ]
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - heading "Malpaco" [level=1] [ref=e4]
    - generic [ref=e5]: Nine Isles · 1 human / 2 computer seats · Computer play · Seed 1994
    - generic [ref=e6]:
      - generic [ref=e10]:
        - generic [ref=e11]: Seat 1
        - generic [ref=e12]: 14 provinces · 34 armies
      - generic [ref=e16]:
        - generic [ref=e17]: Seat 2 · Computer
        - generic [ref=e18]: 16 provinces · 35 armies
      - generic [ref=e22]:
        - generic [ref=e23]: Seat 3 · Computer
        - generic [ref=e24]: 16 provinces · 32 armies
    - contentinfo [ref=e25]:
      - button "New game" [ref=e26] [cursor=pointer]
    - generic [ref=e27]:
      - button "Save game" [ref=e28] [cursor=pointer]
      - generic [ref=e29]:
        - generic [ref=e30]: Load game
        - button "Load game" [ref=e31]
  - main [ref=e32]:
    - img "Nine Isles reference map" [ref=e34]:
      - button "River gate, Seat 3, 3 armies, Seat 3" [ref=e59] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: gate
          - generic: "3"
      - button "New port, Seat 1, 3 armies, Seat 1" [ref=e61] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: port
          - generic: "3"
      - button "North rest, Seat 2, 2 armies, Seat 2" [ref=e63] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: rest
          - generic: "2"
      - button "River keep, Seat 2, 1 armies, Seat 2" [ref=e65] [cursor=pointer]:
        - generic:
          - generic: River
          - generic: keep
          - generic: "1"
      - button "North town, Seat 2, 1 armies, Seat 2" [ref=e67] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: town
          - generic: "1"
      - button "Dark ford, Seat 1, 3 armies, Seat 1" [ref=e69] [cursor=pointer]:
        - generic:
          - generic: Dark
          - generic: ford
          - generic: "3"
      - button "Iron point, Seat 3, 2 armies, Seat 3" [ref=e71] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: point
          - generic: "2"
      - button "South rest, Seat 3, 2 armies, Seat 3" [ref=e73] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: rest
          - generic: "2"
      - button "High shore, Seat 2, 2 armies, Seat 2" [ref=e75] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: shore
          - generic: "2"
      - button "Wind town, Seat 3, 3 armies, Seat 3" [ref=e77] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: town
          - generic: "3"
      - button "New glen, Seat 1, 3 armies, Seat 1" [ref=e79] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: glen
          - generic: "3"
      - button "Old rock, Seat 3, 1 armies, Seat 3" [ref=e81] [cursor=pointer]:
        - generic:
          - generic: Old
          - generic: rock
          - generic: "1"
      - button "Blue peak, Seat 2, 1 armies, Seat 2" [ref=e83] [cursor=pointer]:
        - generic:
          - generic: Blue
          - generic: peak
          - generic: "1"
      - button "West haven, Seat 3, 1 armies, Seat 3" [ref=e85] [cursor=pointer]:
        - generic:
          - generic: West
          - generic: haven
          - generic: "1"
      - button "Stone watch, Seat 2, 8 armies, Seat 2" [ref=e87] [cursor=pointer]:
        - generic:
          - generic: Stone
          - generic: watch
          - generic: "8"
      - button "Upper ridge, Seat 1, 4 armies, Seat 1" [ref=e89] [cursor=pointer]:
        - generic:
          - generic: Upper
          - generic: ridge
          - generic: "4"
      - button "Marsh keep, Seat 2, 3 armies, Seat 2" [ref=e91] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: keep
          - generic: "3"
      - button "New fell, Seat 2, 1 armies, Seat 2" [ref=e93] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: fell
          - generic: "1"
      - button "Moon point, Seat 3, 1 armies, Seat 3" [ref=e95] [cursor=pointer]:
        - generic:
          - generic: Moon
          - generic: point
          - generic: "1"
      - button "South fell, Seat 2, 1 armies, Seat 2" [ref=e97] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: fell
          - generic: "1"
      - button "High ridge, Seat 2, 2 armies, Seat 2" [pressed] [ref=e99] [cursor=pointer]:
        - generic:
          - generic: High
          - generic: ridge
          - generic: "2"
      - button "Bay ford, Seat 2, 2 armies, Seat 2" [ref=e101] [cursor=pointer]:
        - generic:
          - generic: Bay
          - generic: ford
          - generic: "2"
      - button "Low moor, Seat 1, 3 armies, Seat 1" [ref=e103] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: moor
          - generic: "3"
      - button "Lower field, Seat 3, 2 armies, Seat 3" [ref=e105] [cursor=pointer]:
        - generic:
          - generic: Lower
          - generic: field
          - generic: "2"
      - button "Wind gate, Seat 3, 3 armies, Seat 3" [ref=e107] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: gate
          - generic: "3"
      - button "Silver shore, Seat 1, 1 armies, Seat 1" [ref=e109] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: shore
          - generic: "1"
      - button "Low peak, Seat 1, 2 armies, Seat 1" [ref=e111] [cursor=pointer]:
        - generic:
          - generic: Low
          - generic: peak
          - generic: "2"
      - button "Wind port, Seat 1, 3 armies, Seat 1" [ref=e113] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: port
          - generic: "3"
      - button "Gold point, Seat 3, 1 armies, Seat 3" [ref=e115] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: point
          - generic: "1"
        - generic [ref=e117]: ★
      - button "Rock moor, Seat 2, 2 armies, Seat 2" [ref=e118] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: moor
          - generic: "2"
      - button "Marsh rest, Seat 3, 2 armies, Seat 3" [ref=e120] [cursor=pointer]:
        - generic:
          - generic: Marsh
          - generic: rest
          - generic: "2"
      - button "Wind dale, Seat 1, 3 armies, Seat 1" [ref=e122] [cursor=pointer]:
        - generic:
          - generic: Wind
          - generic: dale
          - generic: "3"
      - button "Silver ford, Seat 1, 2 armies, Seat 1" [ref=e124] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: ford
          - generic: "2"
      - button "Iron field, Seat 1, 1 armies, Seat 1" [ref=e126] [cursor=pointer]:
        - generic:
          - generic: Iron
          - generic: field
          - generic: "1"
      - button "North wood, Seat 2, 2 armies, Seat 2" [ref=e128] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: wood
          - generic: "2"
      - button "Fort town, Seat 3, 1 armies, Seat 3" [ref=e130] [cursor=pointer]:
        - generic:
          - generic: Fort
          - generic: town
          - generic: "1"
        - generic [ref=e132]: ★
      - button "Red field, Seat 2, 3 armies, Seat 2" [ref=e133] [cursor=pointer]:
        - generic:
          - generic: Red
          - generic: field
          - generic: "3"
        - generic [ref=e135]: ★
      - button "South ridge, Seat 2, 2 armies, Seat 2" [ref=e136] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: ridge
          - generic: "2"
      - button "Rock bay, Seat 3, 3 armies, Seat 3" [ref=e138] [cursor=pointer]:
        - generic:
          - generic: Rock
          - generic: bay
          - generic: "3"
      - button "North ford, Seat 1, 1 armies, Seat 1" [ref=e140] [cursor=pointer]:
        - generic:
          - generic: North
          - generic: ford
          - generic: "1"
      - button "Port ridge, Seat 3, 1 armies, Seat 3" [ref=e142] [cursor=pointer]:
        - generic:
          - generic: Port
          - generic: ridge
          - generic: "1"
      - button "New rock, Seat 2, 2 armies, Seat 2" [ref=e144] [cursor=pointer]:
        - generic:
          - generic: New
          - generic: rock
          - generic: "2"
      - button "South reach, Seat 3, 3 armies, Seat 3" [ref=e146] [cursor=pointer]:
        - generic:
          - generic: South
          - generic: reach
          - generic: "3"
      - button "Silver point, Seat 3, 3 armies, Seat 3" [ref=e148] [cursor=pointer]:
        - generic:
          - generic: Silver
          - generic: point
          - generic: "3"
      - button "East ford, Seat 1, 3 armies, Seat 1" [ref=e150] [cursor=pointer]:
        - generic:
          - generic: East
          - generic: ford
          - generic: "3"
      - button "Gold town, Seat 1, 2 armies, Seat 1" [ref=e152] [cursor=pointer]:
        - generic:
          - generic: Gold
          - generic: town
          - generic: "2"
      - generic [ref=e184]: North Isle +3
      - generic [ref=e185]: East Isle +3
      - generic [ref=e186]: West Isle +3
      - generic [ref=e187]: South Isle +3
      - generic [ref=e188]: Central Isle +5
      - generic [ref=e189]: Harbor Isle +5
      - generic [ref=e190]: Palm Isle +6
      - generic [ref=e191]: Cliff Isle +5
      - generic [ref=e192]: Great Isle +9
    - complementary [ref=e193]:
      - generic [ref=e197]:
        - generic [ref=e198]: Seat 2's turn
        - generic [ref=e199]: Computer · Normal · Round 1 · Capture move-in
      - generic [ref=e200]:
        - button "End turn" [disabled] [ref=e202]
        - region "Battle controls" [ref=e203]:
          - heading "Battle" [level=2] [ref=e204]
          - generic [ref=e205]:
            - generic [ref=e206]:
              - generic [ref=e207]: From
              - strong [ref=e208]: High ridge
              - generic "Source armies" [ref=e209]: "2"
            - generic [ref=e210]:
              - generic [ref=e211]: Target
              - strong [ref=e212]: New fell
              - generic "Target armies" [ref=e213]: "1"
          - generic [ref=e214]:
            - generic [ref=e215]:
              - text: Stop at armies
              - spinbutton "Stop at armies" [disabled] [ref=e216]: "2"
            - generic [ref=e217]:
              - text: Battle speed
              - combobox "Battle speed" [ref=e218]:
                - option "Slow"
                - option "Normal" [selected]
                - option "Fast"
          - paragraph [ref=e219]: This battle stops at 1 army, or on capture.
          - generic [ref=e220]:
            - button "Fight on" [disabled] [ref=e221]
            - button "Stop" [disabled] [ref=e222]
            - button "Single exchange" [disabled] [ref=e223]
          - generic [ref=e224]:
            - strong [ref=e225]: Choose your attack
            - paragraph [ref=e226]: Choose your country, then click an enemy to attack. Shift-click or Shift-Enter selects only.
          - paragraph [ref=e227]:
            - text: Won 0 · Lost 0 · Ties
            - strong [ref=e228]: "0"
          - region "Capture move-in" [ref=e229]:
            - heading "Move armies into the capture" [level=3] [ref=e230]
            - paragraph [ref=e231]: Choose 1–2 total armies. Leave at least one behind.
            - generic [ref=e232]:
              - text: Armies to move
              - spinbutton "Armies to move" [disabled] [ref=e233]: "2"
            - generic [ref=e234]:
              - button "Minimum" [disabled] [ref=e235]
              - button "Move one fewer army" [disabled] [ref=e236]: −
              - button "Move one more army" [disabled] [ref=e237]: +
              - button "Maximum" [disabled] [ref=e238]
            - button "Confirm move-in" [disabled] [ref=e239]
        - status [ref=e240]: Seat 2 is playing…
      - generic [ref=e241]:
        - heading "Battle log" [level=3] [ref=e242]
        - list "Battle log" [ref=e243]:
          - listitem [ref=e244]: "T1 Seat 2: High ridge → New fell, took New fell"
          - listitem [ref=e245]: T1 Seat 1 ends the turn
```

# Test source

```ts
  1  | import { expect, test } from "@playwright/test";
  2  | import type { Page } from "@playwright/test";
  3  | import { mkdirSync, mkdtempSync, readFileSync } from "node:fs";
  4  | import { join } from "node:path";
  5  | import { activePlayer, apply } from "../../src/core";
  6  | import type { GameState } from "../../src/core";
  7  | import { deserializeVersionedMatch, serializeVersionedMatch, REFERENCE_MATCH_IDENTITY } from "../../src/core/match-save";
  8  | import { pinned } from "../core/versioned-match-fixture";
  9  | async function save(page:Page){const p=page.waitForEvent("download");await page.getByRole("button",{name:"Save game",exact:true}).click();return readFileSync((await (await p).path())!,"utf8");}
  10 | async function load(page:Page,text:string){await page.getByLabel("Load game",{exact:true}).setInputFiles({name:"resume.json",mimeType:"application/json",buffer:Buffer.from(text)});await expect(page.locator("[data-country]")).toHaveCount(46);}
  11 | async function begin(page:Page){await page.clock.install();await page.clock.pauseAt(new Date());await page.goto("/?view=reference-game");}
> 12 | async function capture(page:Page,name:string,project:string){const dir=process.env["COMPUTER_FLOW_EVIDENCE_DIR"]??"screenshots";mkdirSync(dir,{recursive:true});expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);const boxes=await page.locator("#reference-computer-status,#confirm-capture-button,#reference-save-game").evaluateAll(nodes=>nodes.filter(n=>n.getClientRects().length).map(n=>{const r=n.getBoundingClientRect();return {id:n.id,font:parseFloat(getComputedStyle(n).fontSize),fits:r.left>=0&&r.top>=0&&r.right<=innerWidth+1&&r.bottom<=innerHeight+1};}));expect(boxes.filter(b=>!b.fits||b.font<12)).toEqual([]);await page.screenshot({path:join(mkdtempSync(join(dir,"flow-")),`${name}-${project}.png`)});}
     |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ^ Error: expect(received).toEqual(expected) // deep equality
  13 | function computerCapture(){const f=pinned("human-loss");let s=deserializeVersionedMatch(serializeVersionedMatch(f.options,[],REFERENCE_MATCH_IDENTITY)).state;for(const a of f.actions){const r=apply(s,a);if(!r.ok)throw Error(r.error);s=r.state;if(s.phase==="capture"&&activePlayer(s)!.kind==="computer")return serializeVersionedMatch(f.options,s.history,REFERENCE_MATCH_IDENTITY);}throw Error("No computer capture");}
  14 | async function runToHuman(page:Page){for(let i=0;i<400;i++){if(await page.locator("#reference-computer-status").isHidden())return;await page.clock.runFor(525);}throw Error("Computer did not hand back control");}
  15 | 
  16 | test("untouched setup starts one human and three Normal computers and consecutive turns return",async({page},info)=>{
  17 |  await begin(page);await expect(page.locator("#reference-seats")).toHaveValue("4");for(let i=1;i<=4;i++)await expect(page.getByLabel(`Seat ${i} control`)).toHaveValue(i===1?"human":"computer");
  18 |  await page.getByRole("button",{name:"Start game",exact:true}).click();let text=await save(page),loaded=deserializeVersionedMatch(text),s=loaded.state;
  19 |  expect(loaded.options.computerStrengths).toEqual(["Normal","Normal","Normal"]);expect(loaded.options.seats.map(p=>p.kind)).toEqual(["human","computer","computer","computer"]);
  20 |  await runToHuman(page);s=deserializeVersionedMatch(await save(page)).state;expect(activePlayer(s)!.kind).toBe("human");const priorHandoffs=s.history.filter(a=>a.kind==="endTurn"||a.kind==="friendlyMove").length;
  21 |  const own=s.map.provinces.find(p=>s.ownerOf[p.id]===activePlayer(s)!.id)!.id;
  22 |  for(let i=0;i<s.reinforcementPool;i++)await page.locator(`[data-country="${own}"]`).press("Enter");await page.locator("#start-combat-button").click();await page.locator("#end-turn-button").click();
  23 |  await expect(page.locator("#reference-computer-status")).toBeVisible();await expect(page.locator("#end-turn-button")).toBeDisabled();await capture(page,"computer-turn",info.project.name);
  24 |  const during=await save(page),computerState=deserializeVersionedMatch(during).state,computerCountry=computerState.map.provinces.find(p=>computerState.ownerOf[p.id]===activePlayer(computerState)!.id)!.id;await page.locator(`[data-country="${computerCountry}"]`).press("Enter");await page.keyboard.press("Escape");expect(await save(page)).toBe(during);
  25 |  await runToHuman(page);s=deserializeVersionedMatch(await save(page)).state;expect(activePlayer(s)!.kind).toBe("human");expect(s.currentPlayer).toBe(0);expect(s.history.filter(a=>a.kind==="endTurn"||a.kind==="friendlyMove")).toHaveLength(priorHandoffs+4);await capture(page,"human-return",info.project.name);
  26 | });
  27 | test("loaded computer capture resolves without a click; replacement and new game cancel old callbacks",async({page},info)=>{
  28 |  await begin(page);await page.evaluate(()=>{const original=window.setTimeout.bind(window);const callbacks:(()=>void)[]=[],canceled:number[]=[];Reflect.set(window,"oldComputerCallbacks",callbacks);Reflect.set(window,"canceledComputerTimers",canceled);const clear=window.clearTimeout.bind(window);window.clearTimeout=((id?:number)=>{if(id!==undefined)canceled.push(id);clear(id);}) as typeof window.clearTimeout;window.setTimeout=((fn:TimerHandler,delay?:number,...args:unknown[])=>{const id=original(fn,delay,...args);if(typeof fn==="function"&&[175,350,525].includes(delay??0)){callbacks.push(fn as ()=>void);Reflect.set(window,"lastComputerTimer",id);}return id;}) as typeof window.setTimeout;});
  29 |  const pending=computerCapture();await load(page,pending);await expect(page.locator("#confirm-capture-button")).toBeDisabled();await capture(page,"pending-computer",info.project.name);
  30 |  const before=deserializeVersionedMatch(pending).state.history.length;await page.clock.runFor(350);let s=deserializeVersionedMatch(await save(page)).state;expect(s.history[before]?.kind).toBe("captureMove");await runToHuman(page);
  31 |  await load(page,pending);const queued=await page.evaluate(()=>Reflect.get(window,"lastComputerTimer") as number);const restored=pinned("placement").text;await load(page,restored);const fresh=await save(page);expect(await page.evaluate(() => Reflect.get(window,"canceledComputerTimers") as number[])).toContain(queued);
  32 |  expect(await page.evaluate(()=>(Reflect.get(window,"oldComputerCallbacks") as unknown[]).length)).toBeGreaterThan(0);
  33 |  await page.evaluate(()=>{for(const cb of Reflect.get(window,"oldComputerCallbacks") as (()=>void)[])cb();});await page.clock.runFor(2000);expect(await save(page)).toBe(fresh);
  34 |  await load(page,pending);const queuedNew=await page.evaluate(()=>Reflect.get(window,"lastComputerTimer") as number);await page.getByRole("button",{name:"New game",exact:true}).click();expect(await page.evaluate(()=>Reflect.get(window,"canceledComputerTimers") as number[])).toContain(queuedNew);await page.evaluate(()=>{for(const cb of Reflect.get(window,"oldComputerCallbacks") as (()=>void)[])cb();});await page.clock.runFor(2000);await expect(page.getByRole("heading",{name:"New reference game",exact:true})).toBeVisible();
  35 | });
  36 | test("loss waits for Watch or Stop; finished game schedules no play; manual route stays manual",async({page},info)=>{
  37 |  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));await begin(page);await load(page,pinned("human-loss").text);const loss=await save(page);await page.clock.runFor(10000);expect(await save(page)).toBe(loss);
  38 |  await page.locator("#watch-computers-button").click();await expect(page.locator("#reference-computer-status")).toBeVisible();await page.clock.runFor(1050);expect(deserializeVersionedMatch(await save(page)).state.history.length).toBeGreaterThan(deserializeVersionedMatch(loss).state.history.length+1);
  39 |  await load(page,loss);await page.locator("#stop-game-button").click();const stopped=await save(page);await page.clock.runFor(10000);expect(await save(page)).toBe(stopped);await capture(page,"stopped",info.project.name);
  40 |  await page.goto("/?view=reference-game&control=manual");await expect(page.locator("#reference-seats")).toHaveValue("2");await load(page,computerCapture());const manual=await save(page);await page.clock.runFor(10000);expect(await save(page)).toBe(manual);await expect(page.locator("#confirm-capture-button")).toBeEnabled();expect(errors).toEqual([]);
  41 | });
  42 | 
```