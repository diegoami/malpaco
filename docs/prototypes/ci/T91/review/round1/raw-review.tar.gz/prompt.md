T91 review (Opus Medium)
You review PR #212 at ad6fe08cefb05127df95441a911a313d4e39b15c. You did not write it. The task file follows.
0. Prove the tree: HEAD is ad6fe08cefb05127df95441a911a313d4e39b15c and the diff against origin/main is the PR's; findings name its files.
1. Re-run every Done-when line yourself, and account for each (L32). The PR's evidence is no proof.
2. [evidence-driven] Every constant traces to a fixture, report or investigation; a [designed] one says what was searched.
3. [seeded] No wall clock, unseeded random or order-dependent iteration in rule code.
4. Every changed file and behaviour is one the task asks for (L44); docs it makes wrong are updated.
5. Sweep the diff: tests that pass with the behaviour deleted (mutate, rebuild clean, re-take any
   negative result), branches no input reaches, edge comments without a test, CI misclassification, skipped/cancelled verification, immutable diff binding, sparse missing fixtures, truncated browser inventory, incorrect package provenance, cancellation scope, and evidence loss.
   Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
   restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
   a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
   copy inside your worktree (`<file>.saved`, deleted afterwards) or in a `mktemp -d` folder under
   `/tmp`, never as a loose file elsewhere.
6. The blocking and one-pass sections below apply.
Prove each finding (run it, or delete the behaviour and name the test that fails) or label it
unverified. Your final message is the review: the header; the verdict (approve | approve after
named fixes | rework | user decision); per Done-when line `DW<k>: ran <command> → <result>` or
`DW<k>: not run — <reason>`; the findings R1..Rn (file:line, blocking or not); the verdict again
last. Never post it: the script posts it and applies the label.

# T91 Simplify development CI and document reusable adoption

- **Kind**: infrastructure (validation guard).
- **Issue**: #211; consolidates T66/#108 and T67/#118. **Branch**: `task/T91-development-ci`. **Merge after**: none (independent tooling).
- **Priority / difficulty**: High / Hard.
- **Implementer**: owner-authorized native Sol High, isolated worktree; standing difficulty selection.
- **Reviewer**: independent Opus Medium through direct Claude harness; standing owner selection, one review unless additionally authorized.
- **Evidence**: owner approval 2026-10-19; [baseline CI](https://github.com/diegoami/malpaco/actions/runs/39270431182): 48 minutes, checkout 9m25s, duplicate browser passes 17m34s/17m33s; [checkout](https://github.com/actions/checkout/tree/v4), [concurrency](https://docs.github.com/en/actions/how-tos/write-workflows/choose-when-workflows-run/control-workflow-concurrency), [billing](https://docs.github.com/en/billing/concepts/product-billing/github-actions).
- **Owns**: `.github/workflows/ci.yml`; `tools/ci/**`; `tests/tools/ci-*.test.mjs`; `docs/ci-development.md`; `docs/prototypes/ci/T91/**`; append-only `RUN-NOTES.md`. Main owns task contracts and index/process amendments.
- **Scope**: Keep unconditional workflow events and a stable required `ci` result. Permit only narrowly approved prose changes to use lightweight validation; uncertain/malformed changes select full. Routine code verification keeps complete unit/harness/type/package checks and every browser case/project once against the extracted artifact. Explicit manual full-release mode adds source-server browsers. Reduce sparse checkout bulk while retaining runtime/fixture closure and real Git provenance. Cancel only superseded same-PR runs. Bound future temporary artifact retention; preserve existing evidence, worktrees and durable release artifacts. Document architecture, measured versus estimated savings, operations, rollback and Goal2 adaptation without changing Goal2.
- **Done when**:
  1. `node --test tests/tools/ci-*.test.mjs` — frozen classification, uncertainty, required-gate and workflow guard cases pass; each predicted bypass has a failing deletion/mutation control.
  2. `npm test && npm run build` — all existing unit/harness and type/build checks pass from the actual sparse input set, without changing runtime/test assertions.
  3. `node tools/ci/verify.mjs` — verifies workflow wiring, full browser inventory equivalence, sparse input completeness/byte preservation and package source SHA; retains auditable results. The final single required CI executes the entire extracted browser suite; do not run duplicate remote experiments.
- **Pre-dispatch**: Main freezes semantic boundary/tests and red/mock/green evidence before ready.
- **Hazards**: Never infer safety from all Markdown/docs, labels or incomplete diffs. Failed/cancelled/unexpected skipped jobs cannot green the gate. Sparse checkout must preserve executable prototypes/fixtures and provenance; checkout filter overrides sparse inputs. Do not alter existing task Done-when, game code, current T78 CI, publication or repository protections.

## Blocking means

Any one is enough; a blocking finding means rework, never approve.
1. A Done-when line fails, or cannot be run as written.
2. What this task protects can be got past: narrow prose classification, immutable complete Git diff binding, full unit/type/package/browser coverage, failed/cancelled/skipped job gating, sparse dependency closure, true commit provenance and protected evidence. A bypass you proved is blocking, even when it
   looks like an edge case. Never "follow-up hardening" or "outside the threat model" unless the
   task says so; if it does, quote the line. (L47)
3. Behaviour the task forbids, or behaviour nobody asked for, inside a file the task requires. (L44)
4. An untested bypass of these guards or an unauthorized change to game behavior or existing task assertions.
Not blocking: wording, style, and defects in code the PR did not change: file those as follow-ups.
When unsure, say how likely the problem is. Rate it blocking only if it is likely and would get
past what the task protects; otherwise it is a follow-up. (L53)

## Report every blocking finding in this one review

This review is your only pass before the author fixes. Do not stop at the first blocking
finding: finish reading the whole diff and the task file, check every Done-when line and
every item under "Blocking means", and report all blocking findings together.

- Before you write the verdict, make one last pass over the full diff for anything you have
  not yet rated, and say "Final pass done" as the last line before the verdict.
- Number the findings R1, R2, … in order of severity. A finding you held back because an
  earlier one was already blocking is a review defect: if two problems share a cause, list
  both and say so.
- Do not rely on a later round. The author fixes everything you list, and the next review
  checks those fixes and new code only, not anything you saw but did not report.
- If you ran out of time or context before covering the whole diff, say which files or
  sections you did not cover. Do not approve in that case.

Main review context:
- Main froze task contract, semantic boundary,13 preflight guards before implementation. SHA256 manifest and historical red/mock/green/mutation controls are in docs/prototypes/ci/T91/preflight/. Inspect all new executable code, including historical mock MJS scripts and original/mock YAML; do not rerun historical runners or overwrite historical outputs.
- Re-run all DW commands exactly. Use copied private dependencies in your own review worktree. Do not run npm install/update or any actual GitHub workflow dispatch/rerun/cancel. A single ordinary final-head CI after review will execute full packaged browser suite. Inventory listing is not execution; state limits explicitly. No need to repeat full browser suite locally.
- Audit actual workflow behavior, not just textual tests. Inject at least one bounded realistic bypass mutation, restore saved bytes in finally and show which assertion kills it. In particular inspect whether plan tests/Git metadata failures could light-classify runtime changes, whether aggregator always runs and consumes actual conclusions, and whether cancelled/unexpected skip can green requiredci.
- Check routine retains full existing source/release case+project inventory and only removes duplicated server execution. Type/unit/harness/package/HTTP/checksum gates stay complete. Release mode is explicit workflow_dispatch full_release. Source test commands required by other tasks still apply.
- Sparse checkout omissions are ephemeral and must preserve source/fixture/transitive-code inputs and Git metadata. No filter input alongside sparse-checkout. Evaluate binary dependencies needed by fixture HTML/SVG, package sourceCommit and potential stale-dist acceptance. Do not delete or rewrite any retained evidence/archive/worktree.
- New docs must be usable by another session: operating commands, rollout/rollback, measured versus estimated savings, retention and Goal2-specific discovery. Goal2 currently uses manual-onlyCI with python3 tools/check_premerge.py --expected-head "$GITHUB_SHA"; preserve that design in guidance rather than blindly adding this Vite architecture.
- Raw historical TXT outputs intentionally preserve trailing whitespace. Do not rewrite them or classify it as a blocker. Newly authored executable/docs should pass scoped whitespace checks.
- One independent review: do not publish, change labels, spawn agents, start another reviewer or touch another worktree. Report every blocker together and inspect full changed-file inventory.
- Formatting: begin directly with T91 review (Opus Medium), standalone SCOPE: complete, exact FILE: path for EACH executable/script/YAML file, including mock sources and workfloworiginal/mock evidence. EVIDENCE: docs/prototypes/ci/T91/ may group generated allowed data suffixes only and must be a bare path with no explanation after it. DW1/DW2/DW3 each need exact ran/result or explicit not-run. Final pass done directly before finalverdict.

Reviewed-head context: ad6fe08c merges only main planning changes into final implementation8de7ba0f; all workflow/tool/guard hashes are identical (main saved sync audit). Local successful sparse receipt9407b827 predates evidence/provenance commits, so independently rerun DW3 on your actual reviewhead. Your harness reviewworktree may include policy-excluded historical binaries; verifier records presentExcludedFiles honestly instead of claiming physical omission. Main and implementer actually used sparse checkout with zero excluded filespresent. Scope includes PLANNING.md retained parentnotes, no deletion. CurrentT78runremainsuntouched andinflight; do not operate it.


---
OUTPUT RULES (from tools/harness/review.mjs; they override anything above that conflicts):
- Do not post to GitHub, commit, push, label or merge anything. The script posts your review.
  Edit nothing, but for a mutation made in place in your worktree and never committed.
  Undo a mutation or scratch edit by writing back the file's saved contents (read it first,
  restore it in a `finally`), or commit first; never `git checkout`, `git restore` or `git reset`
  a file with uncommitted work: they return the last commit and destroy the rest. Keep the saved
  copy inside your worktree (`<file>.saved`, deleted afterwards) or in your own folder under
  `/tmp/opencode/`. Outside your worktree, write only under `/tmp/opencode/` (a
  `mktemp -d /tmp/opencode/mlp-review-XXXXXX` folder is the tidiest, removed afterwards; the reviewer
  agent file allows nothing else). Every other path outside your worktree is forbidden.
- Your final message is the review and nothing else. Line 1 is exactly: T91 review (Opus Medium)
  Line 2 is the verdict, alone on its line: approve, approve after named fixes, rework, or user
  decision. Then any where-I-worked lines (worktree, HEAD, diff, the commands you ran), then the
  findings (R1, R2, ... with file and line, blocking or not), then the verdict again as the very
  last line. Nothing comes after it.
- A finding you proved that lets a forbidden action or a wrong result past what the task protects
  is blocking, and blocks an approve: never "follow-up hardening" or "outside the threat model"
  unless the task's text says so (L47).
- Report every blocking finding in this one review, not one per round: read the whole diff, then
  make a final pass and write "Final pass done" as the line before the closing verdict. Name any
  part you did not cover, and do not approve then (L49).
- The task has 3 Done-when lines. Right after the verdict line, account for each, one
  line per Done-when line, DW1 to DW3: "DW<k>: ran <command> → <result>", or
  "DW<k>: not run — <reason>". An approve with one missing, or one not run, is not applied. A review that does not end with its verdict, or that has a
  finding after it, is posted flagged and acted on by no one until the main session reads it.
- Your worktree is /home/diego/projects/malpaco-work/212-review-c53f7122 at ad6fe08cefb05127df95441a911a313d4e39b15c, and it is already your working directory. Run git
  there without -C, and never type that path: a mistyped path ends the run. This rule is about
  your own worktree only (L61): a Done-when line may send git at a pinned repository outside it
  (git -C <path> show <pin>:<file>); run that exactly as written — OpenCode does not path-check
  git -C — and read a granted outside path only with the L59 recipe.

The launcher dependency tree was copied into a private node_modules directory in this retained review worktree.

CLAUDE BACKEND CONTRACT: The exact PR base is 87512385274ad556b9a3227f5b8d12f2d0431cd4, head ad6fe08cefb05127df95441a911a313d4e39b15c. Do not use origin/main for a merged PR. Complete local diff: /home/diego/projects/malpaco/.cache/review-evidence/pr212-990703980725/full.diff; bounded parts: /home/diego/projects/malpaco/.cache/review-evidence/pr212-990703980725/diff-parts; full changed-file inventory: /home/diego/projects/malpaco/.cache/review-evidence/pr212-990703980725/inventory.json. Read all executable changes. For generated evidence you may audit a group explicitly. Never claim a file you did not inspect. Before Final pass done, emit SCOPE: complete only if you covered all changes; otherwise SCOPE: incomplete plus UNCOVERED: paths/reasons. Emit FILE: <exact path> for each changed file inspected; EVIDENCE: <docs/prototypes/.../ prefix> may account for generated evidence only, never executable scripts. These are coverage claims, not independent proof. Every Done-when must be run; include exact DW lines. A missing scope acknowledgment prevents approval. No subagents or GitHub writes. Native Claude permission denials mirror OpenCode publishing restrictions; the trusted hook protects credential paths for Read/Grep/Glob. Bash is granted for tests and in-tree mutations. These are mistake safeguards, not an OS sandbox. Preserve scratch/evidence; do not clean up. Ignore obsolete OpenCode-only path restrictions above: your scratch is your retained worktree. No blanket permission bypass.
