import {readFileSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
const f='.github/workflows/ci.yml';const saved=readFileSync(f,'utf8');
const R=(a,b)=>t=>{if(!t.includes(a))throw new Error('nomatch '+a);return t.replace(a,b);};
const M={
 skipNpmTest:R('      - name: Complete unit and harness checks\n','      - name: Complete unit and harness checks\n        if: github.event_name == \'push\'\n'),
 skipVerify:R('      - name: Audit workflow, browser inventory, sparse inputs and playable package\n','      - name: Audit workflow, browser inventory, sparse inputs and playable package\n        if: false\n'),
 skipPW:R('      - name: Complete Playwright suite against extracted playable\n','      - name: Complete Playwright suite against extracted playable\n        if: github.event_name == \'push\'\n'),
 cont:R('        run: npm test\n','        run: npm test\n        continue-on-error: true\n'),
 g:R('release.config.ts --workers=2','release.config.ts --workers=2 -g slice'),
 u:R('release.config.ts --workers=2','release.config.ts --workers=2 --update-snapshots'),
 retries:R('release.config.ts --workers=2','release.config.ts --workers=2 --retries=3'),
 maxf:R('release.config.ts --workers=2','release.config.ts --workers=2 --max-failures=1'),
 ignsnap:R('release.config.ts --workers=2','release.config.ts --workers=2 --ignore-snapshots'),
 tolerate:R('release.config.ts --workers=2','release.config.ts --workers=2 || true'),
 jobCOE:R('    needs: plan\n','    needs: plan\n    continue-on-error: true\n'),
};
try{for(const [k,fn] of Object.entries(M)){writeFileSync(f,fn(saved));
 const r=spawnSync('node',['--test','tests/tools/ci-workflow.test.mjs','tests/tools/ci-review-regressions.test.mjs'],{encoding:'utf8'});
 const fails=(r.stdout.match(/^✖ .*/gm)||[]).map(s=>s.slice(0,90));
 console.log(k,r.status===0?'SURVIVED':'killed',JSON.stringify(fails));}
}finally{writeFileSync(f,saved);}
